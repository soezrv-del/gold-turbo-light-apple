import { corsHeaders } from '../_shared/cors.ts';

// Speech-to-Text edge function
// Primary: OpenAI Whisper via OnSpace AI (OpenAI-compatible)
// Fallback: xAI grok-2-audio chat-based transcription
// Accepts { audio: base64string, mimeType: 'audio/m4a' | 'audio/wav' | 'audio/mp4' }
// Returns { transcript: string }

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { audio, mimeType = 'audio/m4a', language = 'en' } = await req.json();

    if (!audio || typeof audio !== 'string') {
      return new Response(
        JSON.stringify({ error: 'audio (base64) is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Decode base64 → binary bytes
    const binaryStr = atob(audio);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }

    console.log(`xai-stt: mimeType=${mimeType}, bytes=${bytes.length}`);

    const ext = mimeType.includes('wav') ? 'wav' : mimeType.includes('mp4') ? 'mp4' : 'm4a';

    // ── PRIMARY: OpenAI Whisper via OnSpace AI ────────────────────────────────
    const onspaceKey = Deno.env.get('ONSPACE_AI_API_KEY');
    const onspaceUrl = Deno.env.get('ONSPACE_AI_BASE_URL') ?? 'https://api.openai.com';

    if (onspaceKey) {
      try {
        const formData = new FormData();
        const blob = new Blob([bytes], { type: mimeType });
        formData.append('file', blob, `recording.${ext}`);
        formData.append('model', 'whisper-1');
        formData.append('language', language);
        formData.append('response_format', 'json');

        const whisperEndpoint = onspaceUrl.replace(/\/$/, '').replace(/\/v1$/, '') + '/v1/audio/transcriptions';
        console.log(`xai-stt: trying Whisper at ${whisperEndpoint}`);

        const whisperResp = await fetch(whisperEndpoint, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${onspaceKey}` },
          body: formData,
        });

        if (whisperResp.ok) {
          const result = await whisperResp.json();
          const transcript = result.text ?? '';
          console.log(`xai-stt: Whisper transcript="${transcript.slice(0, 80)}"`);
          return new Response(
            JSON.stringify({ transcript, model: 'whisper-1' }),
            { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const whisperErr = await whisperResp.text();
        console.warn(`xai-stt: Whisper failed (${whisperResp.status}):`, whisperErr.slice(0, 200));
      } catch (whisperEx) {
        console.warn('xai-stt: Whisper exception:', whisperEx);
      }
    }

    // ── FALLBACK: xAI grok-2-audio chat-based transcription ──────────────────
    // xAI supports audio input via chat completions using grok-2-audio model.
    // We send the audio as a base64 content part asking it to transcribe.
    const xaiKey = Deno.env.get('XAI_API_KEY');

    if (xaiKey) {
      try {
        console.log('xai-stt: trying xAI grok-2-audio chat transcription');

        const xaiResp = await fetch('https://api.x.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${xaiKey}`,
          },
          body: JSON.stringify({
            model: 'grok-2-audio',
            messages: [
              {
                role: 'user',
                content: [
                  {
                    type: 'input_audio',
                    input_audio: {
                      data: audio,
                      format: ext === 'wav' ? 'wav' : 'mp4',
                    },
                  },
                  {
                    type: 'text',
                    text: 'Please transcribe the audio above. Return ONLY the spoken words with no extra commentary, punctuation corrections are fine. If nothing was said, return an empty string.',
                  },
                ],
              },
            ],
            max_tokens: 500,
          }),
        });

        if (xaiResp.ok) {
          const data = await xaiResp.json();
          const transcript = data.choices?.[0]?.message?.content?.trim() ?? '';
          console.log(`xai-stt: grok-2-audio transcript="${transcript.slice(0, 80)}"`);
          return new Response(
            JSON.stringify({ transcript, model: 'grok-2-audio' }),
            { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const xaiErr = await xaiResp.text();
        console.error(`xai-stt: xAI fallback failed (${xaiResp.status}):`, xaiErr.slice(0, 200));

        // Return empty transcript rather than error — mic stops gracefully
        return new Response(
          JSON.stringify({ transcript: '', error: `Transcription unavailable: ${xaiErr.slice(0, 100)}` }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } catch (xaiEx) {
        console.error('xai-stt: xAI fallback exception:', xaiEx);
      }
    }

    // No backend available
    return new Response(
      JSON.stringify({ transcript: '', error: 'No transcription backend configured' }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (err) {
    console.error('xai-stt error:', err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
