/**
 * here-routing — RV-Aware Turn-by-Turn Navigation
 *
 * Uses HERE Routing v8 API with transportMode=truck and full vehicle
 * dimension constraints (height, width, length, grossWeight, axleCount).
 * Propane is mapped to tunnelCategory=B (flammable gases restriction).
 *
 * Returns:
 *  - distanceMi, durationMin
 *  - polyline: Array<{latitude, longitude}>
 *  - steps: Array<{instruction, distanceMi, distanceM, maneuver, coords}>
 */

import { corsHeaders } from '../_shared/cors.ts';

// ─── Flexible Polyline Decoder ────────────────────────────────────────────────
// HERE uses a custom encoding (not Google's Polyline Algorithm).
// Spec: https://github.com/heremaps/flexible-polyline

const DECODE_TABLE = [
  62, -1, -1, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1,
  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
  20, 21, 22, 23, 24, 25, -1, -1, -1, -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33,
  34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51,
];

function decodeValue(encoded: string, idx: number): [number, number] {
  let result = 0, shift = 0, delta = 0;
  do {
    const charCode = encoded.charCodeAt(idx) - 45;
    if (charCode < 0 || charCode >= DECODE_TABLE.length) break;
    delta = DECODE_TABLE[charCode];
    result |= (delta & 0x1F) << shift;
    shift += 5;
    idx++;
  } while (delta >= 32);
  if ((result & 1) !== 0) result = ~result;
  return [result >> 1, idx];
}

function decodeFlexPolyline(encoded: string): Array<{ latitude: number; longitude: number }> {
  if (!encoded || encoded.length < 2) return [];

  // Header byte — precision is lower 4 bits
  const headerCode = encoded.charCodeAt(0) - 45;
  const headerVal  = headerCode >= 0 && headerCode < DECODE_TABLE.length ? DECODE_TABLE[headerCode] : 0;
  const precision  = headerVal & 0xF;
  const factor     = Math.pow(10, precision);

  let idx = 1; // skip header
  let lat = 0, lng = 0;
  const points: Array<{ latitude: number; longitude: number }> = [];

  while (idx < encoded.length) {
    let delta: number;
    [delta, idx] = decodeValue(encoded, idx);
    lat += delta;
    [delta, idx] = decodeValue(encoded, idx);
    lng += delta;
    points.push({ latitude: lat / factor, longitude: lng / factor });
  }
  return points;
}

// ─── Maneuver normalizer ──────────────────────────────────────────────────────

function normalizeManeuver(action: string, direction?: string): string {
  const a = (action || '').toLowerCase();
  const d = (direction || '').toLowerCase();
  if (a === 'arrive') return 'arrive';
  if (a === 'depart') return 'straight';
  if (a === 'turn') {
    if (d.includes('left'))  return 'left';
    if (d.includes('right')) return 'right';
    if (d === 'uturn')       return 'u-turn';
    return 'straight';
  }
  if (a === 'ramp') return d.includes('left') ? 'ramp-left' : 'ramp-right';
  if (a === 'merge') return 'merge';
  if (a === 'roundabout' || a === 'enter roundabout') return 'roundabout';
  if (a === 'exit roundabout') return 'straight';
  if (a === 'fork') return d.includes('left') ? 'left' : 'right';
  return 'straight';
}

// ─── Main handler ─────────────────────────────────────────────────────────────

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('HERE_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'HERE_API_KEY not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const body = await req.json();
    const { origin, destination, vehicle } = body;

    if (!origin?.latitude || !destination?.latitude) {
      return new Response(
        JSON.stringify({ error: 'origin and destination coordinates required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // ── Build HERE Routing v8 request ─────────────────────────────────────
    // Vehicle dimensions: HERE uses meters for height/width/length, kg for weight
    const params = new URLSearchParams({
      transportMode: 'truck',
      origin:        `${origin.latitude},${origin.longitude}`,
      destination:   `${destination.latitude},${destination.longitude}`,
      return:        'polyline,actions,summary,turnByTurnActions',
      apikey:        apiKey,
    });

    // Vehicle dimension constraints (convert from US units to metric)
    if (vehicle?.heightFt && vehicle.heightFt > 0) {
      const heightM = (vehicle.heightFt * 0.3048).toFixed(2);
      params.set('vehicle[height]', heightM); // meters
    }
    if (vehicle?.widthFt && vehicle.widthFt > 0) {
      const widthM = (vehicle.widthFt * 0.3048).toFixed(2);
      params.set('vehicle[width]', widthM); // meters
    }
    if (vehicle?.lengthFt && vehicle.lengthFt > 0) {
      const lengthM = (vehicle.lengthFt * 0.3048).toFixed(2);
      params.set('vehicle[length]', lengthM); // meters
    }
    if (vehicle?.gvwrLbs && vehicle.gvwrLbs > 0) {
      const weightKg = Math.round(vehicle.gvwrLbs * 0.453592);
      params.set('vehicle[grossWeight]', weightKg.toString()); // kg
    }
    if (vehicle?.axles && vehicle.axles > 0) {
      params.set('vehicle[axleCount]', vehicle.axles.toString());
    }

    // Propane → tunnelCategory B (flammable gases — stricter tunnel avoidance)
    if (vehicle?.hasPropane) {
      params.set('vehicle[tunnelCategory]', 'B');
    }

    console.log(`HERE routing: ${origin.latitude},${origin.longitude} → ${destination.latitude},${destination.longitude}`);
    console.log(`Vehicle constraints: H=${vehicle?.heightFt}ft W=${vehicle?.widthFt}ft L=${vehicle?.lengthFt}ft GW=${vehicle?.gvwrLbs}lbs propane=${vehicle?.hasPropane}`);

    const hereRes = await fetch(
      `https://router.hereapi.com/v8/routes?${params.toString()}`,
      { headers: { 'Accept': 'application/json' } }
    );

    if (!hereRes.ok) {
      const errText = await hereRes.text();
      console.error('HERE API error:', hereRes.status, errText);
      return new Response(
        JSON.stringify({ error: `HERE API: ${hereRes.status} - ${errText}` }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const hereData = await hereRes.json();

    if (!hereData.routes || hereData.routes.length === 0) {
      return new Response(
        JSON.stringify({ error: 'No route found between these points' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const route   = hereData.routes[0];
    const section = route.sections?.[0];
    if (!section) {
      return new Response(
        JSON.stringify({ error: 'Route has no sections' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // ── Decode polyline ───────────────────────────────────────────────────
    const polyline = decodeFlexPolyline(section.polyline || '');
    console.log(`Polyline decoded: ${polyline.length} points`);

    // ── Extract steps from actions ────────────────────────────────────────
    const actions = section.actions || [];
    const steps = actions.map((action: any, i: number) => {
      // offset into polyline for this step's starting coordinate
      const offset = action.offset ?? 0;
      const coords = polyline[Math.min(offset, polyline.length - 1)] ?? { latitude: origin.latitude, longitude: origin.longitude };

      return {
        instruction: action.instruction || `Continue`,
        distanceMi:  parseFloat(((action.length ?? 0) / 1609.34).toFixed(2)),
        distanceM:   action.length ?? 0,
        maneuver:    normalizeManeuver(action.action, action.direction),
        coords,
      };
    });

    // Add arrive step if not present
    const lastAction = actions[actions.length - 1];
    if (!lastAction || (lastAction.action || '').toLowerCase() !== 'arrive') {
      steps.push({
        instruction: `Arrive at destination`,
        distanceMi: 0,
        distanceM: 0,
        maneuver: 'arrive',
        coords: { latitude: destination.latitude, longitude: destination.longitude },
      });
    }

    const summary    = section.summary || {};
    const distanceMi = parseFloat(((summary.length ?? 0) / 1609.34).toFixed(1));
    const durationMin = Math.round((summary.duration ?? 0) / 60);

    console.log(`Route: ${distanceMi}mi, ${durationMin}min, ${steps.length} steps`);

    return new Response(
      JSON.stringify({
        distanceMi,
        durationMin,
        polyline,
        steps,
        source: 'here',
        vehicleConstrained: !!(vehicle?.heightFt || vehicle?.gvwrLbs),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (err: any) {
    console.error('here-routing error:', err);
    return new Response(
      JSON.stringify({ error: err?.message ?? 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
