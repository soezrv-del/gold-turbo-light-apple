import { corsHeaders } from '../_shared/cors.ts';

// Voice Library edge function
// Returns available TTS voices — matched to OpenAI TTS voices (used by OnSpace AI)

// RvGrok voice identities — displayed with branded names, backed by OpenAI TTS
const OPENAI_VOICES = [
  { id: 'altair',  name: 'Altair',  description: 'Resonant, powerful voice — authoritative and clear',             gender: 'male',    preview: '' },
  { id: 'ara',     name: 'Ara',     description: 'Warm, expressive female voice — engaging and conversational',    gender: 'female',  preview: '' },
  { id: 'atlas',   name: 'Atlas',   description: 'Deep, steady voice — confident and reassuring',                  gender: 'male',    preview: '' },
  { id: 'carina',  name: 'Carina',  description: 'Bright, professional female voice — crisp and articulate',       gender: 'female',  preview: '' },
  { id: 'castor',  name: 'Castor',  description: 'Balanced, neutral voice — versatile for any RV topic',           gender: 'neutral', preview: '' },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  // Return the curated voice list directly — no API call needed
  // These match the OpenAI TTS voices used by OnSpace AI
  console.log(`xai-voices: returning ${OPENAI_VOICES.length} RvGrok branded voices`);

  return new Response(
    JSON.stringify({ voices: OPENAI_VOICES, source: 'openai' }),
    { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
});
