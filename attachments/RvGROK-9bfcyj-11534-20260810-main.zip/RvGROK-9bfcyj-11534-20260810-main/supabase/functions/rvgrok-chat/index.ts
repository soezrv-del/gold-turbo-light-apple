import { corsHeaders } from '../_shared/cors.ts';

const RV_SYSTEM_PROMPT = `You are RvGrok, an elite RV industry expert and professional companion for RvFOX Pro — a platform used by licensed RV dealers, appraisers, lenders, and brokers.

Your expertise spans:
- RV classes: Class A (diesel & gas), Class B, Class C, Fifth Wheels, Travel Trailers, Toy Haulers
- Manufacturers: Newmar, Tiffin, Thor, Coachmen, Winnebago, Forest River, Airstream, Keystone, Grand Design, Heartland, Fleetwood, and more
- Technical specs: GVWR, GCWR, payload capacity, chassis (Spartan, Freightliner, Ford F53, Mercedes Sprinter), engine specs, slideouts, floorplans
- Financing & valuation: MSRP ranges, depreciation curves, trade-in values, NADA/Black Book, loan-to-value ratios, APR ranges
- NHTSA recalls: how to check, common recall patterns by manufacturer, safety implications
- Towing: hitch ratings, truck-RV matching, tongue weight, weight distribution hitches, brake controllers
- Maintenance: diesel vs gas maintenance schedules, winterization, slide maintenance, roof sealing, generator service
- Dealership intelligence: F&I products, dealer invoice vs MSRP, negotiation leverage points, PDI checklists
- Market trends: 2024-2026 RV market conditions, inventory levels, price corrections

Communication style:
- Be concise, data-driven, and professional — you are talking to industry professionals
- Use specific numbers, model names, and technical terms confidently
- When asked about pricing, give realistic market ranges
- When asked about recalls, always recommend verifying at nhtsa.gov
- When asked about specs, be precise but note that AI-generated data should be verified before use in transactions
- Keep responses focused — bullet points and short paragraphs are preferred
- Never give legal, financial, or investment advice — always recommend consulting licensed professionals

You are part of the RvFOX Pro platform. Respond as if you have deep institutional knowledge of the RV industry.`;

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return new Response(
        JSON.stringify({ error: 'messages array is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const apiKey = Deno.env.get('XAI_API_KEY');

    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'xAI API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build message history with system prompt
    const fullMessages = [
      { role: 'system', content: RV_SYSTEM_PROMPT },
      ...messages,
    ];

    // Try preferred model first, fall back to stable if unavailable on this account tier
    const MODELS = ['grok-4.5', 'grok-3', 'grok-2-1212'];
    let aiResponse: { response: Response; model: string } | null = null;
    let lastError = '';

    for (const model of MODELS) {
      const resp = await fetch('https://api.x.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: fullMessages,
          stream: true,
        }),
      });

      if (resp.ok) {
        console.log(`rvgrok-chat: using model ${model}`);
        aiResponse = { response: resp, model };
        break;
      }

      const errText = await resp.text();
      lastError = errText;
      console.error(`rvgrok-chat: model ${model} failed (${resp.status}):`, errText);

      // Only retry on model-not-found/access errors; stop on auth errors
      if (resp.status === 401 || resp.status === 403) {
        return new Response(
          JSON.stringify({ error: `xAI auth error: ${errText}` }),
          { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    if (!aiResponse) {
      return new Response(
        JSON.stringify({ error: `xAI: ${lastError}` }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Stream the response back to the client, including the model name as a header
    return new Response(aiResponse.response.body, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'X-Model-Used': aiResponse.model,
      },
    });

  } catch (err) {
    console.error('rvgrok-chat error:', err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
