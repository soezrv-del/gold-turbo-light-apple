import { corsHeaders } from '../_shared/cors.ts';

// ─── AGENT TOOLS ─────────────────────────────────────────────────────────────

const RV_AGENT_TOOLS = [
  {
    type: 'function',
    function: {
      name: 'analyze_requirements',
      description: 'Break down the user RV search query into structured research requirements. Call this first for any search or purchase decision.',
      parameters: {
        type: 'object',
        properties: {
          summary:    { type: 'string', description: 'One-sentence summary of what the user wants' },
          rvType:     { type: 'string', description: 'RV type (Class A Diesel, Class A Gas, Class B, Class C, Fifth Wheel, Travel Trailer, Toy Hauler)' },
          makes:      { type: 'array',  items: { type: 'string' }, description: 'Preferred manufacturers or empty for any' },
          yearMin:    { type: 'number', description: 'Minimum model year' },
          yearMax:    { type: 'number', description: 'Maximum model year' },
          budgetMax:  { type: 'number', description: 'Maximum purchase price in USD' },
          mileageMax: { type: 'number', description: 'Maximum odometer miles' },
          mustHave:   { type: 'array',  items: { type: 'string' }, description: 'Required features (slides, generator, etc.)' },
          niceToHave: { type: 'array',  items: { type: 'string' }, description: 'Preferred but optional features' },
        },
        required: ['summary'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'search_rv_models',
      description: 'Search for RV models matching the structured requirements. Returns top 3–5 matching models with brief specs and market price range.',
      parameters: {
        type: 'object',
        properties: {
          rvType:    { type: 'string' },
          makes:     { type: 'array', items: { type: 'string' } },
          yearMin:   { type: 'number' },
          yearMax:   { type: 'number' },
          budgetMax: { type: 'number' },
          features:  { type: 'array', items: { type: 'string' } },
        },
        required: ['rvType'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'get_model_details',
      description: 'Get detailed specs, floorplans, common options, NHTSA recall count, known owner complaints, and resale value for a specific RV model.',
      parameters: {
        type: 'object',
        properties: {
          year:  { type: 'string' },
          make:  { type: 'string' },
          model: { type: 'string' },
        },
        required: ['make', 'model'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'check_market_availability',
      description: 'Check current dealer inventory levels, days-on-lot trends, and negotiation leverage for a specific make/model within a budget. Returns realistic price windows and buying strategy.',
      parameters: {
        type: 'object',
        properties: {
          make:       { type: 'string' },
          model:      { type: 'string' },
          yearRange:  { type: 'string', description: 'e.g. "2021-2023"' },
          budgetMax:  { type: 'number' },
        },
        required: ['make', 'model'],
      },
    },
  },
];

// ─── SYSTEM PROMPTS ───────────────────────────────────────────────────────────

const AGENT_SYSTEM_PROMPT = `You are RvGrok Agent — an elite RV industry AI with multi-step research capabilities, deployed inside RvFOX Pro for licensed dealers, appraisers, and brokers.

For any RV search, comparison, or purchase-decision query you MUST use the available tools in this sequence:
1. Call analyze_requirements to parse what the buyer needs
2. Call search_rv_models to find matching candidates  
3. Call get_model_details for the top 2–3 candidates
4. Call check_market_availability for the best match(es)

After all tool calls return, synthesize a structured, actionable final answer with:
- Top 3 matching RVs ranked by fit
- Key specs comparison table (format as text)
- Market pricing intel and negotiation tips
- Any recall/reliability concerns
- Clear recommendation

Be precise, data-driven, and professional — these are real transactions for industry professionals.`;

const TOOL_EXECUTOR_PROMPT = `You are an RV market data API. Based on the tool name and input parameters, generate a realistic, data-dense JSON response that an RV industry professional would trust. Include specific model names, realistic pricing, real manufacturer data, accurate NHTSA recall counts, and honest owner feedback. Return ONLY valid JSON — no prose, no markdown.`;

// ─── TOOL EXECUTOR ────────────────────────────────────────────────────────────

async function executeTool(
  toolName: string,
  toolInput: Record<string, unknown>,
  apiKey: string,
): Promise<string> {
  const prompt = `Tool: ${toolName}\nInput: ${JSON.stringify(toolInput, null, 2)}\n\nGenerate the API response JSON:`;

  const resp = await fetch('https://api.x.ai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: 'grok-3',
      messages: [
        { role: 'system', content: TOOL_EXECUTOR_PROMPT },
        { role: 'user',   content: prompt },
      ],
      max_tokens: 1200,
      temperature: 0.2,
      stream: false,
    }),
  });

  if (!resp.ok) {
    return JSON.stringify({ error: 'Tool data unavailable', toolName });
  }

  const data = await resp.json();
  return data.choices?.[0]?.message?.content ?? JSON.stringify({ error: 'Empty tool result' });
}

// ─── MAIN HANDLER ─────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return new Response(
        JSON.stringify({ error: 'messages array required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    const apiKey = Deno.env.get('XAI_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'XAI_API_KEY not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // ── SSE stream back to client ──────────────────────────────────────────────
    const { readable, writable } = new TransformStream();
    const writer = writable.getWriter();
    const enc = new TextEncoder();

    const send = async (obj: unknown) => {
      await writer.write(enc.encode(`data: ${JSON.stringify(obj)}\n\n`));
    };

    // ── Model fallback chain ──────────────────────────────────────────────
    const AGENT_MODELS = ['grok-4.5', 'grok-3', 'grok-2-1212'];

    // Run agentic loop in background
    (async () => {
      try {
        await send({ type: 'agent_start', model: AGENT_MODELS[0] });

        // Build message history (last 6 messages for context)
        const history = messages.slice(-6).map((m: { role: string; content: string }) => ({
          role: m.role,
          content: m.content,
        }));

        const agentMessages: Array<{
          role: string;
          content?: string | null;
          tool_calls?: Array<{
            id: string;
            type: string;
            function: { name: string; arguments: string };
          }>;
          tool_call_id?: string;
          name?: string;
        }> = [
          { role: 'system', content: AGENT_SYSTEM_PROMPT },
          ...history,
        ];

        let stepIndex = 0;
        const MAX_ITERATIONS = 5;

        // ── Agentic tool-call loop ─────────────────────────────────────────────
        for (let iter = 0; iter < MAX_ITERATIONS; iter++) {
          // Try models in fallback order for each iteration
          let resp: Response | null = null;
          let usedModel = AGENT_MODELS[0];
          for (const candidateModel of AGENT_MODELS) {
            const attempt = await fetch('https://api.x.ai/v1/chat/completions', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
              },
              body: JSON.stringify({
                model: candidateModel,
                messages: agentMessages,
                tools: RV_AGENT_TOOLS,
                tool_choice: 'auto',
                stream: false,
                max_tokens: 3000,
              }),
            });
            if (attempt.ok) {
              resp = attempt;
              usedModel = candidateModel;
              console.log(`rvgrok-agent: using model ${candidateModel} at iter ${iter}`);
              break;
            }
            const errText = await attempt.text();
            console.warn(`rvgrok-agent: model ${candidateModel} failed (${attempt.status}):`, errText.slice(0, 120));
            if (attempt.status === 401 || attempt.status === 403) break; // auth error, don't retry
          }

          if (!resp) {
            await send({ type: 'agent_error', message: 'All models unavailable. Please check your xAI API key.' });
            break;
          }

          const data = await resp.json();
          const choice = data.choices?.[0];
          const msg = choice?.message;

          if (!msg) break;

          // No more tool calls — this is the final answer
          if (!msg.tool_calls || msg.tool_calls.length === 0) {
            // Stream the final content character by character in chunks
            const finalContent: string = msg.content ?? '';
            if (finalContent) {
              const CHUNK_SIZE = 12;
              for (let i = 0; i < finalContent.length; i += CHUNK_SIZE) {
                await send({ type: 'delta', content: finalContent.slice(i, i + CHUNK_SIZE) });
              }
            }
            break;
          }

          // Push the assistant message with tool_calls
          agentMessages.push({ role: 'assistant', content: msg.content ?? null, tool_calls: msg.tool_calls });

          // Execute each tool call
          for (const toolCall of msg.tool_calls) {
            const toolName = toolCall.function.name;
            let toolInput: Record<string, unknown> = {};
            try {
              toolInput = JSON.parse(toolCall.function.arguments);
            } catch { /* ignore parse errors */ }

            stepIndex++;
            await send({
              type: 'step',
              step: stepIndex,
              tool: toolName,
              input: toolInput,
              status: 'running',
            });

            const toolResult = await executeTool(toolName, toolInput, apiKey);

            // Try to parse for a cleaner summary
            let resultSummary = toolResult;
            try {
              const parsed = JSON.parse(toolResult);
              resultSummary = JSON.stringify(parsed);
            } catch { /* keep raw */ }

            await send({
              type: 'step',
              step: stepIndex,
              tool: toolName,
              input: toolInput,
              result: resultSummary,
              status: 'done',
            });

            // Append tool result to messages
            agentMessages.push({
              role: 'tool',
              tool_call_id: toolCall.id,
              name: toolName,
              content: toolResult,
            });
          }

          // If stop_reason is tool_calls, loop again; otherwise break
          if (choice.finish_reason !== 'tool_calls') break;
        }

        await writer.write(enc.encode('data: [DONE]\n\n'));
      } catch (err) {
        console.error('rvgrok-agent loop error:', err);
        await send({ type: 'error', message: String(err) });
        await writer.write(enc.encode('data: [DONE]\n\n'));
      } finally {
        await writer.close();
      }
    })();

    return new Response(readable, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'X-Agent-Mode': 'true',
      },
    });
  } catch (err) {
    console.error('rvgrok-agent error:', err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
