import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const CACHE_DAYS = 30;

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { make, model, year } = await req.json();

    if (!make || !model || !year) {
      return new Response(
        JSON.stringify({ error: 'make, model, and year are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // ── Check cache first ──────────────────────────────────────────────────
    const cacheKey = `${make.toLowerCase()}|${model.toLowerCase()}|${year}`;
    const { data: cached } = await supabase
      .from('verified_motorhomes')
      .select('data, fetched_at')
      .eq('make', make.toLowerCase())
      .eq('model', model.toLowerCase())
      .eq('year', year)
      .maybeSingle();

    if (cached?.data && cached?.fetched_at) {
      const ageMs = Date.now() - new Date(cached.fetched_at).getTime();
      const ageDays = ageMs / (1000 * 60 * 60 * 24);
      if (ageDays < CACHE_DAYS) {
        return new Response(
          JSON.stringify({ ...cached.data, cached: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // ── Normalize make/model for NHTSA (Title Case, URL-encoded) ──────────
    const nhtsaMake = make
      .split(' ')
      .map((w: string) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
    const nhtsaModel = model
      .split(' ')
      .map((w: string) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');

    const makeEnc = encodeURIComponent(nhtsaMake);
    const modelEnc = encodeURIComponent(nhtsaModel);
    const yearEnc = encodeURIComponent(year);

    // ── Fetch recalls + complaints in parallel ─────────────────────────────
    const [recallRes, defectRes] = await Promise.allSettled([
      fetch(
        `https://api.nhtsa.gov/recalls/recallsByVehicle?make=${makeEnc}&model=${modelEnc}&modelYear=${yearEnc}`
      ),
      fetch(
        `https://api.nhtsa.gov/complaints/complaintsByVehicle?make=${makeEnc}&model=${modelEnc}&modelYear=${yearEnc}`
      ),
    ]);

    // ── Parse recalls ──────────────────────────────────────────────────────
    let recallCount = 0;
    let recalls: any[] = [];

    if (recallRes.status === 'fulfilled' && recallRes.value.ok) {
      try {
        const recallJson = await recallRes.value.json();
        const results = recallJson.results ?? [];
        recallCount = results.length;
        recalls = results.slice(0, 5).map((r: any) => ({
          component: r.Component ?? '',
          summary: r.Summary ?? '',
          consequence: r.Consequence ?? '',
          remedy: r.Remedy ?? '',
          date: r.ReportReceivedDate ?? '',
          campaignNumber: r.NHTSACampaignNumber ?? '',
        }));
      } catch {
        // graceful fallback — NHTSA data parse failure
      }
    }

    // ── Parse complaints ───────────────────────────────────────────────────
    let defectCount = 0;
    let defects: any[] = [];

    if (defectRes.status === 'fulfilled' && defectRes.value.ok) {
      try {
        const defectJson = await defectRes.value.json();
        const results = defectJson.results ?? [];
        defectCount = results.length;
        defects = results.slice(0, 5).map((d: any) => ({
          component: d.components ?? '',
          summary: d.cdescr ?? '',
          date: d.datea ?? '',
          crashFlag: d.crash === 'Yes',
          fireFlag: d.fire === 'Yes',
        }));
      } catch {
        // graceful fallback
      }
    }

    const payload = {
      recallCount,
      recalls,
      defectCount,
      defects,
      make: nhtsaMake,
      model: nhtsaModel,
      year,
      cached: false,
    };

    // ── Upsert to cache ────────────────────────────────────────────────────
    await supabase
      .from('verified_motorhomes')
      .upsert(
        {
          make: make.toLowerCase(),
          model: model.toLowerCase(),
          year,
          data: payload,
          fetched_at: new Date().toISOString(),
        },
        { onConflict: 'make,model,year' }
      );

    return new Response(
      JSON.stringify(payload),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('nhtsa-lookup error:', err);
    // Always return a safe fallback — never crash the detail screen
    return new Response(
      JSON.stringify({ recallCount: 0, recalls: [], defectCount: 0, defects: [], cached: false }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
