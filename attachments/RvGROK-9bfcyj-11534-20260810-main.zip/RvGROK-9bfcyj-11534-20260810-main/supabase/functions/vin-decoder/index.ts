import { corsHeaders } from '../_shared/cors.ts';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { vin } = await req.json();

    if (!vin || typeof vin !== 'string') {
      return new Response(
        JSON.stringify({ error: 'VIN is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const cleanVin = vin.trim().toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, '');

    if (cleanVin.length !== 17) {
      return new Response(
        JSON.stringify({ error: 'VIN must be exactly 17 characters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // NHTSA vPIC free API — no key required
    const url = `https://vpic.nhtsa.dot.gov/api/vehicles/decodevinvalues/${cleanVin}?format=json`;
    const res = await fetch(url);

    if (!res.ok) {
      throw new Error(`NHTSA vPIC responded with ${res.status}`);
    }

    const json = await res.json();
    const r = json.Results?.[0];

    if (!r) {
      return new Response(
        JSON.stringify({ error: 'No results returned for this VIN' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if the VIN decode returned valid data
    const errorCode = r.ErrorCode ?? '';
    const hasValidDecode = errorCode === '0' || errorCode === '' || (r.Make && r.Make !== '');

    const payload = {
      vin: cleanVin,
      valid: hasValidDecode,
      errorText: r.ErrorText ?? '',
      // Core identity
      year: r.ModelYear ?? '',
      make: r.Make ?? '',
      model: r.Model ?? '',
      trim: r.Trim ?? '',
      series: r.Series ?? '',
      // Vehicle classification
      vehicleType: r.VehicleType ?? '',
      bodyClass: r.BodyClass ?? '',
      // Drivetrain
      engineDisplacement: r.DisplacementL ?? '',
      engineCylinders: r.EngineCylinders ?? '',
      engineHP: r.EngineHP ?? '',
      fuelType: r.FuelTypePrimary ?? '',
      driveType: r.DriveType ?? '',
      transmissionStyle: r.TransmissionStyle ?? '',
      transmissionSpeeds: r.TransmissionSpeeds ?? '',
      // Dimensions
      gvwr: r.GVWR ?? '',
      // Manufacturing
      manufacturer: r.Manufacturer ?? '',
      plantCountry: r.PlantCountry ?? '',
      plantCity: r.PlantCity ?? '',
      plantState: r.PlantState ?? '',
      // Safety
      abs: r.ABS ?? '',
      airBags: r.Airbags ?? '',
      // RV-specific
      motorhomeType: r.MotorcycleChassisType ?? r.OtherMotorcycleInfo ?? '',
      busType: r.BusType ?? '',
      bedLength: r.BedLengthIN ?? '',
      doors: r.Doors ?? '',
      windows: r.Windows ?? '',
    };

    return new Response(
      JSON.stringify(payload),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('vin-decoder error:', err);
    return new Response(
      JSON.stringify({ error: 'VIN decode failed. Please verify the VIN and try again.' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
