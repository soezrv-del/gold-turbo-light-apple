import { corsHeaders } from '../_shared/cors.ts';

// Text-to-Speech edge function
// Primary: OnSpace AI (OpenAI-compatible TTS) using tts-1 / tts-1-hd
// Fallback: xAI audio/speech (if OnSpace AI unavailable)
// Accepts { text, voice } → returns base64-encoded MP3 audio

// Map xAI-style voice names to OpenAI voice names (in case old voice IDs come in)
const VOICE_MAP: Record<string, string> = {
  // RvGrok branded voices → OpenAI TTS voices
  altair:  'onyx',
  ara:     'nova',
  atlas:   'echo',
  carina:  'shimmer',
  castor:  'alloy',
  // Legacy xAI voice names
  aria:    'nova',
  bill:    'onyx',
  echo:    'echo',
  grace:   'shimmer',
  hunter:  'fable',
  ivy:     'nova',
  josh:    'echo',
  shimmer: 'shimmer',
  // OpenAI native voices pass through unchanged
  alloy:   'alloy',
  fable:   'fable',
  onyx:    'onyx',
  nova:    'nova',
  coral:   'coral',
  sage:    'sage',
  verse:   'verse',
  ballad:  'ballad',
  ash:     'ash',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { text, voice = 'nova' } = await req.json();

    if (!text || typeof text !== 'string') {
      return new Response(
        JSON.stringify({ error: 'text is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Normalize voice ID
    const resolvedVoice = VOICE_MAP[voice] ?? voice;

    // Truncate to TTS limit
    const truncatedText = text.slice(0, 4096);

    console.log(`xai-tts: voice=${voice} → ${resolvedVoice}, length=${truncatedText.length}`);

    // ── PRIMARY: OnSpace AI (OpenAI TTS) ─────────────────────────────────────
    const onspaceKey = Deno.env.get('ONSPACE_AI_API_KEY');
    // Strip trailing slash AND any trailing /v1 — the base URL from env may already include /v1
    // so we normalise to the root before appending /v1/audio/speech ourselves
    const onspaceUrl = (Deno.env.get('ONSPACE_AI_BASE_URL') ?? 'https://api.openai.com')
      .replace(/\/$/, '')
      .replace(/\/v1$/, '');

    if (onspaceKey) {
      try {
        console.log(`xai-tts: trying OnSpace AI TTS at ${onspaceUrl}/v1/audio/speech`);

        const ttsResp = await fetch(`${onspaceUrl}/v1/audio/speech`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${onspaceKey}`,
          },
          body: JSON.stringify({
            model: 'tts-1',
            input: truncatedText,
            voice: resolvedVoice,
            response_format: 'mp3',
          }),
        });

        if (ttsResp.ok) {
          const audioBuffer = await ttsResp.arrayBuffer();
          const bytes = new Uint8Array(audioBuffer);
          let binary = '';
          for (let i = 0; i < bytes.length; i++) {
            binary += String.fromCharCode(bytes[i]);
          }
          const base64Audio = btoa(binary);
          console.log(`xai-tts: OnSpace AI success, bytes=${bytes.length}`);
          return new Response(
            JSON.stringify({ audio: base64Audio, format: 'mp3', voice: resolvedVoice, provider: 'onspace' }),
            { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const errText = await ttsResp.text();
        console.warn(`xai-tts: OnSpace AI TTS failed (${ttsResp.status}): ${errText.slice(0, 200)}`);
      } catch (ex) {
        console.warn('xai-tts: OnSpace AI exception:', ex);
      }
    }

    // ── FALLBACK: xAI audio/speech ────────────────────────────────────────────
    const xaiKey = Deno.env.get('XAI_API_KEY');
    if (xaiKey) {
      try {
        console.log('xai-tts: trying xAI TTS fallback');
        const ttsResp = await fetch('https://api.x.ai/v1/audio/speech', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${xaiKey}`,
          },
          body: JSON.stringify({
            model: 'grok-2-audio',
            input: truncatedText,
            voice,
            response_format: 'mp3',
          }),
        });

        if (ttsResp.ok) {
          const audioBuffer = await ttsResp.arrayBuffer();
          const bytes = new Uint8Array(audioBuffer);
          let binary = '';
          for (let i = 0; i < bytes.length; i++) {
            binary += String.fromCharCode(bytes[i]);
          }
          const base64Audio = btoa(binary);
          console.log(`xai-tts: xAI fallback success, bytes=${bytes.length}`);
          return new Response(
            JSON.stringify({ audio: base64Audio, format: 'mp3', voice, provider: 'xai' }),
            { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const errText = await ttsResp.text();
        console.error(`xai-tts: xAI fallback failed (${ttsResp.status}): ${errText.slice(0, 200)}`);
        return new Response(
          JSON.stringify({ error: `TTS unavailable: xAI ${ttsResp.status} - Team may not have TTS permission enabled` }),
          { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } catch (ex) {
        console.error('xai-tts: xAI fallback exception:', ex);
      }
    }

    return new Response(
      JSON.stringify({ error: 'No TTS backend configured (ONSPACE_AI_API_KEY or XAI_API_KEY required)' }),
      { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (err) {
    console.error('xai-tts error:', err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
