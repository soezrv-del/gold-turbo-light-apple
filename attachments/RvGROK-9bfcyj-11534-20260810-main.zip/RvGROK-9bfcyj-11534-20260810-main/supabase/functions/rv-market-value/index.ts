import { corsHeaders } from '../_shared/cors.ts';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { year, make, model, floorplan } = await req.json();

    if (!year || !make || !model) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: year, make, model' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const xaiKey         = Deno.env.get('XAI_API_KEY') ?? '';
    const onspaceBaseUrl = Deno.env.get('ONSPACE_AI_BASE_URL') ?? '';
    const onspaceApiKey  = Deno.env.get('ONSPACE_AI_API_KEY') ?? '';

    // Build vehicle descriptor — include floorplan for precision when available
    const floorplanNote = floorplan
      ? ` (floorplan: ${floorplan})`
      : '';
    const vehicleDesc = `${year} ${make} ${model}${floorplanNote}`;

    // Derive floorplan length hint for static fallback length-based pricing
    const floorplanFeet = floorplan ? parseFloorplanLength(floorplan) : null;

    let result: any = null;

    // ── PRIMARY: Grok with live web search ───────────────────────────────
    if (xaiKey) {
      const webSearchPrompt = `Search the current US used RV market right now for a ${vehicleDesc}.

IMPORTANT: Ignore any pre-coded numbers. Synthesize a fresh, current market value range by researching recent comparable sales and active listings on RVTrader.com, Craigslist, eBay Motors, and RV dealer websites.

${floorplan ? `The specific floorplan is "${floorplan}". Use this to narrow pricing — some floorplans (e.g. outdoor patio, bunk layouts, quad-slide) command significant premiums over other floorplans of the same model.` : ''}

Adjust your values for:
- Current mileage typical for a ${year} model (estimate average miles for age)
- Typical condition for a ${new Date().getFullYear() - parseInt(year)} year old coach
- Regional US market (use national average)
- Any recent market shifts in RV pricing
- Whether this specific model${floorplan ? ` and floorplan (${floorplan})` : ''} commands a premium or discount vs competitors

Return ONLY valid JSON, no markdown, no explanation:
{
  "tradeIn": <integer dollar amount — what a dealer would pay today>,
  "retailLow": <integer — lowest realistic asking price in current market>,
  "retailHigh": <integer — highest realistic dealer asking price today>,
  "mileageAdjustment": <integer per 10k miles deviation from average, positive = above average value>,
  "conditionNote": "<one sentence: current market conditions and what drives this specific model${floorplan ? '/floorplan' : ''}'s value>",
  "source": "Grok Live Search · RVTrader / Dealer Sites"
}`;

      try {
        const xaiRes = await fetch('https://api.x.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${xaiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'grok-3',
            messages: [
              {
                role: 'system',
                content: 'You are an RV market analyst with real-time web access. Search the live web for current RV listings and sales. When a specific floorplan is provided, factor its premium or discount vs the base model into your pricing. Never use pre-coded estimates — always research actual current market data. Respond with valid JSON only.',
              },
              { role: 'user', content: webSearchPrompt },
            ],
            search_parameters: {
              mode: 'auto',
              sources: [{ type: 'web' }],
            },
            temperature: 0.2,
            max_tokens: 500,
          }),
        });

        if (xaiRes.ok) {
          const xaiData = await xaiRes.json();
          const content = xaiData?.choices?.[0]?.message?.content ?? '';
          const clean = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
          const jsonMatch = clean.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            result = JSON.parse(jsonMatch[0]);
            result.source = 'Grok Live Search · RVTrader / Dealer Sites';
            console.log('Grok web search success for', vehicleDesc);
          }
        } else {
          const errText = await xaiRes.text();
          console.error('Grok web search error:', errText);
        }
      } catch (e) {
        console.error('Grok web search exception:', e);
      }
    }

    // ── FALLBACK 1: Grok without search ──────────────────────────────────
    if (!result && xaiKey) {
      try {
        const fallbackPrompt = `Provide your best estimate of current 2025/2026 US used RV market values for a ${vehicleDesc}.

${floorplan ? `The specific floorplan is "${floorplan}". Factor any known floorplan premium (e.g. outdoor patio, bunkhouse, full-wall slide, toy hauler variants) into the pricing. Premium floorplans can command 10–25% above base model pricing.` : ''}

Base this on your knowledge of RVTrader pricing, typical dealer markups, and RV depreciation curves.

Return ONLY valid JSON:
{
  "tradeIn": <integer>,
  "retailLow": <integer>,
  "retailHigh": <integer>,
  "mileageAdjustment": <integer per 10k miles>,
  "conditionNote": "<one sentence about this model${floorplan ? '/floorplan' : ''}'s market position>",
  "source": "Grok · Market Knowledge"
}`;

        const xaiRes2 = await fetch('https://api.x.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${xaiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'grok-3-mini',
            messages: [
              {
                role: 'system',
                content: 'You are an RV market valuation expert. When a floorplan is specified, apply appropriate premiums for sought-after layouts (outdoor patio, quad-slide, bunkhouse, toy hauler). Respond with valid JSON only.',
              },
              { role: 'user', content: fallbackPrompt },
            ],
            temperature: 0.3,
            max_tokens: 350,
          }),
        });

        if (xaiRes2.ok) {
          const d2 = await xaiRes2.json();
          const content = d2?.choices?.[0]?.message?.content ?? '';
          const clean = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
          const jsonMatch = clean.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            result = JSON.parse(jsonMatch[0]);
            result.source = 'Grok · Market Knowledge';
          }
        }
      } catch (e) {
        console.error('Grok fallback exception:', e);
      }
    }

    // ── FALLBACK 2: OnSpace AI ────────────────────────────────────────────
    if (!result && onspaceBaseUrl && onspaceApiKey) {
      try {
        const aiPrompt = `Provide current 2025/2026 US used RV market values for a ${vehicleDesc}.
${floorplan ? `Floorplan "${floorplan}" — apply any premium for sought-after layouts (outdoor patio, bunkhouse, full-wall slide, toy hauler).` : ''}
Return ONLY valid JSON:
{"tradeIn":<int>,"retailLow":<int>,"retailHigh":<int>,"mileageAdjustment":<int>,"conditionNote":"<one sentence>","source":"OnSpace AI · Market Analysis"}`;

        const aiRes = await fetch(`${onspaceBaseUrl}/chat/completions`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${onspaceApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: 'You are an RV market valuation expert. Apply floorplan premiums when specified. Respond with valid JSON only.',
              },
              { role: 'user', content: aiPrompt },
            ],
            temperature: 0.3,
            max_tokens: 350,
          }),
        });

        if (aiRes.ok) {
          const aiData = await aiRes.json();
          const content = aiData?.choices?.[0]?.message?.content ?? '';
          const clean = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
          const jsonMatch = clean.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            result = JSON.parse(jsonMatch[0]);
            result.source = 'OnSpace AI · Market Analysis';
          }
        }
      } catch (e) {
        console.error('OnSpace AI fallback error:', e);
      }
    }

    // ── FALLBACK 3: Static MSRP-based estimate ────────────────────────────
    if (!result) {
      result = buildStaticFallback(year, make, model, floorplan, floorplanFeet);
      result.source = 'Estimated · MSRP Reference Data';
      console.log('Using static fallback for', vehicleDesc);
    }

    return new Response(
      JSON.stringify(result),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (err) {
    console.error('rv-market-value fatal error:', err);
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// ── FLOORPLAN LENGTH PARSER ────────────────────────────────────────────────────
// Decodes length from common RV floorplan number conventions:
//   "4369" → 43 ft  |  "40MX" → 40 ft  |  "37TS" → 37 ft  |  "22B" → 22 ft
function parseFloorplanLength(fp: string): number | null {
  if (!fp) return null;
  // 4-digit starting: first 2 = feet
  const four = fp.match(/^(\d{2})\d{2}/);
  if (four) { const f = parseInt(four[1]); if (f >= 16 && f <= 50) return f; }
  // 2-digit + letters: e.g. 40MX, 37TS
  const twoLetter = fp.match(/^(\d{2})[A-Z]/);
  if (twoLetter) { const f = parseInt(twoLetter[1]); if (f >= 16 && f <= 50) return f; }
  // 2-digit alone or 2-digit + lower
  const two = fp.match(/^(\d{2})/);
  if (two) { const f = parseInt(two[1]); if (f >= 16 && f <= 50) return f; }
  return null;
}

// ── FLOORPLAN PREMIUM CLASSIFIER ──────────────────────────────────────────────
// Returns a multiplier (1.0 = no premium; 1.20 = 20% premium, etc.)
function floorplanPremium(fp: string | undefined): number {
  if (!fp) return 1.0;
  const u = fp.toUpperCase();
  // Outdoor patio / outdoor kitchen variants
  if (u.includes('OPP') || u.includes('OP') || u.includes('OK') || u.includes('OUT')) return 1.18;
  // Toy hauler
  if (u.includes('TH') || u.includes('TS') || u.includes('RKT') || u.includes('TOY')) return 1.12;
  // Bunkhouse
  if (u.includes('BH') || u.includes('BBH') || u.includes('BNK')) return 1.05;
  // Quad / 5-slide
  if (u.includes('DEQ') || u.includes('QBH') || u.includes('QDP')) return 1.10;
  // Front bedroom
  if (u.includes('FB') || u.includes('FBQ')) return 1.06;
  // Master bath / rear bath premium
  if (u.includes('MB') || u.includes('MBQ') || u.includes('RBQ')) return 1.04;
  return 1.0;
}

// ── STATIC FALLBACK ────────────────────────────────────────────────────────────

function buildStaticFallback(
  year: string,
  make: string,
  modelName: string,
  floorplan?: string,
  floorplanFeet?: number | null,
): any {
  const currentYear = new Date().getFullYear();
  const age = currentYear - parseInt(year, 10);
  const makeLower = make.toLowerCase();
  const modelLower = modelName.toLowerCase();

  let baseMsrp = 150000;
  let depreciationRate = 0.12;

  if (['newmar', 'entegra', 'tiffin', 'foretravel', 'american coach'].some(b => makeLower.includes(b))) {
    baseMsrp = 350000; depreciationRate = 0.09;
  } else if (['fleetwood', 'thor', 'coachmen'].some(b => makeLower.includes(b))) {
    baseMsrp = 250000; depreciationRate = 0.11;
  } else if (['winnebago', 'monaco', 'holiday rambler'].some(b => makeLower.includes(b))) {
    baseMsrp = 200000; depreciationRate = 0.11;
  }

  if (['king', 'essex', 'london', 'marathon', 'anthem', 'cornerstone'].some(m => modelLower.includes(m))) {
    baseMsrp *= 1.6;
  } else if (['dutch', 'mountain', 'ventana', 'allegro', 'aspire'].some(m => modelLower.includes(m))) {
    baseMsrp *= 1.2;
  } else if (['accolade', 'expanse', 'esteem'].some(m => modelLower.includes(m))) {
    baseMsrp = 280000; depreciationRate = 0.10;
  } else if (['sprinter', 'view', 'wayfarer'].some(m => modelLower.includes(m))) {
    baseMsrp = 120000; depreciationRate = 0.10;
  }

  // Length adjustment from floorplan number (longer = more valuable at same age)
  if (floorplanFeet) {
    const lengthBonus = Math.max(0, (floorplanFeet - 30) * 0.008);
    baseMsrp *= (1 + lengthBonus);
  }

  // Apply floorplan-specific premium
  baseMsrp *= floorplanPremium(floorplan);

  const depFactor = Math.max(0.25, 1 - Math.min(age * depreciationRate, 0.75));
  const currentValue = Math.round(baseMsrp * depFactor);
  const roundTo = (n: number, nearest = 500) => Math.round(n / nearest) * nearest;

  const fpNote = floorplan ? ` · Floorplan: ${floorplan}` : '';

  return {
    tradeIn:           roundTo(Math.round(currentValue * 0.78)),
    retailLow:         roundTo(Math.round(currentValue * 0.92)),
    retailHigh:        roundTo(Math.round(currentValue * 1.08)),
    mileageAdjustment: Math.round(currentValue * 0.02),
    conditionNote:     `${year} ${make} ${modelName}${fpNote} — estimated from MSRP depreciation curve. Verify with a certified RV appraiser.`,
  };
}
