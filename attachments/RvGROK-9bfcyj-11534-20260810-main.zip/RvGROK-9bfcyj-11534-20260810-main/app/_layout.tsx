import '@/constants/rvDataExtra'; // register extra RV brands & models before any screen loads
import { Stack } from 'expo-router';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Text, TextInput } from 'react-native';
import { AlertProvider, AuthProvider } from '@/template';
import { SubscriptionProvider } from '@/contexts/SubscriptionContext';

// ── Global font scaling: respect system text-size, capped to prevent layout breaks ──
if (!Text.defaultProps) (Text as any).defaultProps = {};
(Text.defaultProps as any).allowFontScaling = true;
(Text.defaultProps as any).maxFontSizeMultiplier = 1.3;
if (!TextInput.defaultProps) (TextInput as any).defaultProps = {};
(TextInput.defaultProps as any).allowFontScaling = true;
(TextInput.defaultProps as any).maxFontSizeMultiplier = 1.2; // stricter for inputs — avoids KeyboardAvoidingView height collapse
// v2.2

export default function RootLayout() {
  return (
    <AlertProvider>
      <SafeAreaProvider>
        <AuthProvider>
          <SubscriptionProvider>
            <Stack screenOptions={{ headerShown: false, gestureEnabled: true, gestureDirection: 'horizontal', animationTypeForReplace: 'push' }}>
              <Stack.Screen name="index" />
              <Stack.Screen name="login" />
              <Stack.Screen name="nda" />
              <Stack.Screen name="(tabs)" />
              <Stack.Screen name="rv-detail" />
              <Stack.Screen name="rv-profile" />
              <Stack.Screen name="subscription" />
              <Stack.Screen name="vin-history" />
              <Stack.Screen name="professional-dashboard" />
            </Stack>
          </SubscriptionProvider>
        </AuthProvider>
      </SafeAreaProvider>
    </AlertProvider>
  );
}
