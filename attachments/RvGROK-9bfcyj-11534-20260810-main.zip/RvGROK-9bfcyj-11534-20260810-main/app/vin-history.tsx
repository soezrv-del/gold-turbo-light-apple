/**
 * VIN History Report Screen
 * NMVTIS-style title, ownership, odometer & risk report
 */
import {
  View, Text, StyleSheet, ScrollView, Pressable,
  ActivityIndicator, Linking, Modal, Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { useState, useEffect, useCallback, useRef } from 'react';
import { getSupabaseClient } from '@/template';
import { FunctionsHttpError } from '@supabase/supabase-js';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import QRCode from 'react-native-qrcode-svg';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system';

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface TitleEvent {
  year:   string;
  state:  string;
  type:   string;
  brand?: string;
}

interface OdometerReading {
  year:   string;
  miles:  number;
  source: string;
}

interface OwnerEvent {
  ownerNumber:  number;
  stateTitle:   string;
  yearAcquired: string;
  type:         string;
}

interface RecallItem {
  component: string;
  summary:   string;
  remedy:    string;
  date:      string;
}

interface VinReport {
  vin:             string;
  reportDate:      string;
  reportId:        string;
  checkDigitValid: boolean;
  vehicle: {
    year: string; make: string; model: string; trim: string;
    series: string; bodyClass: string; vehicleType: string;
    engine: string; fuelType: string; driveType: string;
    gvwr: string; plant: string; manufacturer: string; wmi: string;
  };
  risk: {
    score: number;
    level: 'LOW' | 'MODERATE' | 'HIGH';
    flags: {
      salvage: boolean; lemonLaw: boolean; flood: boolean;
      totalLoss: boolean; odoBrand: boolean; activeRecalls: boolean;
    };
  };
  titleHistory: {
    totalTitles: number;
    events: TitleEvent[];
    nmvtisNote: string;
  };
  ownership: {
    estimatedOwners: number;
    history: OwnerEvent[];
  };
  odometer: {
    readings: OdometerReading[];
    brand: boolean;
    lastReportedMiles: number | null;
  };
  recalls: { count: number; items: RecallItem[] };
  sources: Array<{ name: string; type: string; official: boolean }>;
  officialNmvtisUrl: string;
}

// ─── SUB COMPONENTS ───────────────────────────────────────────────────────────

function SectionHeader({ icon, label, color = Colors.blueBright }: {
  icon: string; label: string; color?: string;
}) {
  return (
    <View style={sh.row}>
      <MaterialIcons name={icon as any} size={13} color={color} />
      <Text style={[sh.label, { color }]}>{label}</Text>
    </View>
  );
}
const sh = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: Spacing.md },
  label: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, letterSpacing: 1.8 },
});

const TITLE_TYPE_COLORS: Record<string, string> = {
  'Clean Title':           Colors.green,
  'Salvage':               Colors.red,
  'Junk':                  Colors.red,
  'Flood':                 Colors.blueBright,
  'Insurance Total Loss':  Colors.orange,
  'Lemon Law Buyback':     Colors.gold,
  'Odometer Brand':        Colors.orange,
};

function TitleEventRow({ event, isLast }: { event: TitleEvent; isLast: boolean }) {
  const color = TITLE_TYPE_COLORS[event.type] ?? Colors.textSecondary;
  return (
    <View style={[te.row, !isLast && te.divider]}>
      <View style={te.timelineCol}>
        <View style={[te.dot, { backgroundColor: color }]} />
        {!isLast && <View style={te.line} />}
      </View>
      <View style={te.content}>
        <View style={te.topRow}>
          <Text style={te.year}>{event.year}</Text>
          <View style={[te.badge, { backgroundColor: color + '22', borderColor: color + '55' }]}>
            <Text style={[te.badgeText, { color }]}>{event.type}</Text>
          </View>
        </View>
        <View style={te.stateRow}>
          <MaterialIcons name="location-on" size={11} color={Colors.textMuted} />
          <Text style={te.state}>{event.state} — Title Issued</Text>
        </View>
      </View>
    </View>
  );
}
const te = StyleSheet.create({
  row: { flexDirection: 'row', gap: Spacing.sm, paddingVertical: 10 },
  divider: {},
  timelineCol: { alignItems: 'center', width: 16 },
  dot: { width: 12, height: 12, borderRadius: 6, marginTop: 4 },
  line: { flex: 1, width: 2, backgroundColor: Colors.border, marginTop: 4, minHeight: 24 },
  content: { flex: 1, gap: 4 },
  topRow: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  year: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  badge: { borderWidth: 1, borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 3 },
  badgeText: { fontSize: 10, fontWeight: FontWeight.bold },
  stateRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  state: { fontSize: FontSize.xs, color: Colors.textMuted },
});

function RiskGauge({ score, level }: { score: number; level: string }) {
  const color = level === 'HIGH' ? Colors.red : level === 'MODERATE' ? Colors.orange : Colors.green;
  const icon  = level === 'HIGH' ? 'warning' : level === 'MODERATE' ? 'info' : 'verified';
  return (
    <View style={[rg.wrap, { borderColor: color + '44' }]}>
      <View style={rg.left}>
        <View style={[rg.iconWrap, { backgroundColor: color + '18' }]}>
          <MaterialIcons name={icon as any} size={28} color={color} />
        </View>
        <View style={rg.scoreWrap}>
          <Text style={[rg.scoreNum, { color }]}>{score}</Text>
          <Text style={rg.scoreLabel}>Risk Score</Text>
        </View>
      </View>
      <View style={rg.right}>
        <Text style={[rg.levelText, { color }]}>{level} RISK</Text>
        <Text style={rg.levelSub}>
          {level === 'HIGH'
            ? 'Major title issues found — thorough inspection required before purchase.'
            : level === 'MODERATE'
            ? 'Some concerns noted — verify title and recall status before purchase.'
            : 'No major title issues detected. Always verify at vehiclehistory.gov.'}
        </Text>
        <View style={rg.barTrack}>
          <View style={[rg.barFill, { width: `${score}%` as any, backgroundColor: color }]} />
        </View>
      </View>
    </View>
  );
}
const rg = StyleSheet.create({
  wrap: {
    flexDirection: 'row', gap: Spacing.md, alignItems: 'center',
    backgroundColor: Colors.bgCard, borderRadius: Radius.xl,
    borderWidth: 1.5, padding: Spacing.md, marginBottom: Spacing.md,
  },
  left: { alignItems: 'center', gap: Spacing.xs },
  iconWrap: { width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center' },
  scoreWrap: { alignItems: 'center' },
  scoreNum: { fontSize: FontSize.h2, fontWeight: FontWeight.extrabold, lineHeight: 30 },
  scoreLabel: { fontSize: FontSize.xs, color: Colors.textMuted },
  right: { flex: 1, gap: 6 },
  levelText: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, letterSpacing: 0.5 },
  levelSub: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 17 },
  barTrack: { height: 6, backgroundColor: Colors.border, borderRadius: Radius.full, overflow: 'hidden' },
  barFill: { height: '100%', borderRadius: Radius.full },
});

function FlagRow({ label, triggered, icon }: { label: string; triggered: boolean; icon: string }) {
  const color = triggered ? Colors.red : Colors.green;
  return (
    <View style={fl.row}>
      <View style={[fl.iconWrap, { backgroundColor: color + '15' }]}>
        <MaterialIcons name={icon as any} size={16} color={color} />
      </View>
      <Text style={fl.label}>{label}</Text>
      <View style={[fl.badge, { backgroundColor: color + '18', borderColor: color + '44' }]}>
        <Text style={[fl.badgeText, { color }]}>{triggered ? 'YES' : 'NONE'}</Text>
      </View>
    </View>
  );
}
const fl = StyleSheet.create({
  row: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  iconWrap: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  label: { flex: 1, fontSize: FontSize.sm, color: Colors.textSecondary, fontWeight: FontWeight.medium },
  badge: { borderWidth: 1, borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 4 },
  badgeText: { fontSize: 10, fontWeight: FontWeight.bold },
});

function OdometerCard({ readings, lastMiles }: { readings: OdometerReading[]; lastMiles: number | null }) {
  if (readings.length === 0) {
    return (
      <View style={odo.empty}>
        <MaterialIcons name="speed" size={20} color={Colors.textMuted} />
        <Text style={odo.emptyText}>No odometer records found</Text>
      </View>
    );
  }
  return (
    <View style={odo.wrap}>
      {lastMiles !== null && (
        <View style={odo.totalRow}>
          <Text style={odo.totalMiles}>{lastMiles.toLocaleString()} mi</Text>
          <Text style={odo.totalLabel}>Last Reported Odometer</Text>
        </View>
      )}
      <View style={odo.list}>
        {readings.map((r, i) => (
          <View key={i} style={[odo.row, i === readings.length - 1 && { borderBottomWidth: 0 }]}>
            <Text style={odo.year}>{r.year}</Text>
            <Text style={odo.miles}>{r.miles.toLocaleString()} mi</Text>
            <Text style={odo.source}>{r.source}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}
const odo = StyleSheet.create({
  empty: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: Spacing.sm },
  emptyText: { fontSize: FontSize.sm, color: Colors.textMuted },
  wrap: { gap: Spacing.sm },
  totalRow: { alignItems: 'center', paddingVertical: Spacing.sm },
  totalMiles: { fontSize: FontSize.h2, fontWeight: FontWeight.extrabold, color: Colors.blueBright },
  totalLabel: { fontSize: FontSize.xs, color: Colors.textMuted },
  list: { backgroundColor: Colors.bgCard, borderRadius: Radius.lg, overflow: 'hidden' },
  row: {
    flexDirection: 'row', alignItems: 'center', padding: 12,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  year:   { width: 44, fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.bold },
  miles:  { flex: 1, fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  source: { fontSize: FontSize.xs, color: Colors.textMuted },
});

// ─── QR SHARE MODAL ──────────────────────────────────────────────────────────

function QrShareModal({
  visible, vin, vehicleLabel, onClose,
}: {
  visible: boolean;
  vin: string;
  vehicleLabel: string;
  onClose: () => void;
}) {
  const safeArea   = useSafeAreaInsets();
  const svgRef     = useRef<any>(null);
  const [sharing, setSharing] = useState(false);

  const reportUrl = `https://rvfox.app/vin/${vin}`;

  const handleShare = useCallback(async () => {
    if (!svgRef.current) return;
    setSharing(true);
    try {
      svgRef.current.toDataURL(async (data: string) => {
        try {
          const fileUri = `${FileSystem.cacheDirectory}vin-report-${vin}.png`;
          await FileSystem.writeAsStringAsync(fileUri, data, {
            encoding: FileSystem.EncodingType.Base64,
          });
          const canShare = await Sharing.isAvailableAsync();
          if (canShare) {
            await Sharing.shareAsync(fileUri, {
              mimeType: 'image/png',
              dialogTitle: `RvFOX VIN Report — ${vin}`,
            });
          } else {
            Linking.openURL(reportUrl);
          }
        } catch {
          Linking.openURL(reportUrl);
        } finally {
          setSharing(false);
        }
      });
    } catch {
      setSharing(false);
      Linking.openURL(reportUrl);
    }
  }, [vin, reportUrl]);

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={qr.overlay} onPress={onClose}>
        <Pressable
          style={[qr.sheet, { paddingBottom: safeArea.bottom + 24 }]}
          onPress={e => e.stopPropagation()}
        >
          <View style={qr.handle} />
          <View style={qr.titleRow}>
            <MaterialIcons name="qr-code-2" size={20} color={Colors.gold} />
            <Text style={qr.title}>Share VIN Report</Text>
          </View>
          <Text style={qr.vehicleLabel}>{vehicleLabel}</Text>
          <Text style={qr.vinText}>{vin}</Text>
          <View style={qr.qrWrap}>
            <QRCode
              value={reportUrl}
              size={200}
              color="#FFFFFF"
              backgroundColor="#0A0F1E"
              getRef={svgRef}
              logo={undefined}
            />
          </View>
          <View style={qr.urlRow}>
            <MaterialIcons name="link" size={12} color={Colors.textMuted} />
            <Text style={qr.urlText} numberOfLines={1}>{reportUrl}</Text>
          </View>
          <Text style={qr.hint}>
            Scan with any camera app to open the full VIN history report. Tap Share to send to a customer.
          </Text>
          <Pressable
            style={({ pressed }) => [qr.shareBtn, pressed && { opacity: 0.85 }, sharing && { opacity: 0.6 }]}
            onPress={handleShare}
            disabled={sharing}
          >
            {sharing ? (
              <ActivityIndicator size="small" color="#000" />
            ) : (
              <MaterialIcons name="share" size={18} color="#000" />
            )}
            <Text style={qr.shareBtnText}>{sharing ? 'Preparing…' : 'Share QR Code'}</Text>
          </Pressable>
          <Pressable
            style={({ pressed }) => [qr.openLinkBtn, pressed && { opacity: 0.75 }]}
            onPress={() => Linking.openURL(reportUrl)}
          >
            <MaterialIcons name="open-in-new" size={14} color={Colors.blueBright} />
            <Text style={qr.openLinkText}>Open Report URL</Text>
          </Pressable>
          <Pressable onPress={onClose} hitSlop={8} style={{ marginTop: Spacing.xs }}>
            <Text style={qr.cancelText}>Close</Text>
          </Pressable>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const qr = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.75)' },
  sheet: {
    backgroundColor: '#060D1F',
    borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    borderTopWidth: 2, borderColor: Colors.gold,
    paddingHorizontal: Spacing.xl, paddingTop: Spacing.md,
    gap: Spacing.sm, alignItems: 'center',
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.35, shadowRadius: 24, elevation: 20,
  },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: Colors.border, marginBottom: Spacing.xs },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  title: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  vehicleLabel: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.textSecondary, textAlign: 'center' },
  vinText: {
    fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.gold,
    letterSpacing: 2, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace',
  },
  qrWrap: {
    marginVertical: Spacing.md, padding: 16, backgroundColor: '#0A0F1E',
    borderRadius: Radius.xl, borderWidth: 2, borderColor: Colors.borderGold,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.4, shadowRadius: 16, elevation: 8,
  },
  urlRow: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.bgCard, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingVertical: 8, width: '100%',
  },
  urlText: {
    flex: 1, fontSize: FontSize.xs, color: Colors.textMuted,
    fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace',
  },
  hint: { fontSize: FontSize.xs, color: Colors.textSecondary, textAlign: 'center', lineHeight: 18, paddingHorizontal: Spacing.sm },
  shareBtn: {
    width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.gold, borderRadius: Radius.full, paddingVertical: 15,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.45, shadowRadius: 12, elevation: 6,
  },
  shareBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#000' },
  openLinkBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 10 },
  openLinkText: { fontSize: FontSize.sm, color: Colors.blueBright, fontWeight: FontWeight.semibold },
  cancelText: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center' },
});

// ─── MAIN SCREEN ──────────────────────────────────────────────────────────────

export default function VinHistoryScreen() {
  const router   = useRouter();
  const safeArea = useSafeAreaInsets();
  const { vin }  = useLocalSearchParams<{ vin: string }>();

  const [report,  setReport]  = useState<VinReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState<string | null>(null);
  const [showQr,  setShowQr]  = useState(false);

  const fetchReport = useCallback(async () => {
    if (!vin) { setError('No VIN provided'); setLoading(false); return; }
    setLoading(true);
    setError(null);
    try {
      const supabase = getSupabaseClient();
      const { data, error: fnErr } = await supabase.functions.invoke('vin-history', {
        body: { vin },
      });
      if (fnErr) {
        let msg = fnErr.message;
        if (fnErr instanceof FunctionsHttpError) {
          try { msg = await fnErr.context?.text() ?? msg; } catch { /* noop */ }
        }
        setError(msg || 'History lookup failed');
        return;
      }
      setReport(data as VinReport);
    } catch (e: any) {
      setError(e?.message ?? 'Unexpected error');
    } finally {
      setLoading(false);
    }
  }, [vin]);

  useEffect(() => { fetchReport(); }, [fetchReport]);

  const riskColor = report
    ? report.risk.level === 'HIGH' ? Colors.red
    : report.risk.level === 'MODERATE' ? Colors.orange
    : Colors.green
    : Colors.green;

  return (
    <View style={[styles.container, { paddingTop: safeArea.top }]}>
      {/* Hero backdrop — static backscreen.jpg */}
      <View style={styles.heroBackdrop}>
        <Image
          source={require('@/assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.5 }}
        />
        <LinearGradient
          colors={['rgba(30,46,64,0.72)', 'rgba(20,38,72,0.30)', 'rgba(20,38,72,0.24)', 'rgba(30,46,64,0.44)', 'rgba(18,28,50,0.80)']}
          locations={[0, 0.18, 0.5, 0.82, 1]}
          style={StyleSheet.absoluteFill}
        />
      </View>

      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <MaterialIcons name="arrow-back-ios" size={18} color={Colors.textPrimary} />
        </Pressable>
        <View style={styles.headerCenter}>
          <View style={styles.headerBadge}>
            <MaterialIcons name="history-edu" size={13} color={Colors.gold} />
            <Text style={styles.headerBadgeText}>NMVTIS VIN REPORT</Text>
          </View>
          <Text style={styles.headerVin} numberOfLines={1}>{vin}</Text>
        </View>
        <View style={styles.headerActions}>
          {report ? (
            <Pressable onPress={() => setShowQr(true)} hitSlop={8} style={styles.shareHeaderBtn}>
              <MaterialIcons name="qr-code-2" size={20} color={Colors.gold} />
            </Pressable>
          ) : null}
          <Pressable onPress={fetchReport} hitSlop={8} style={styles.refreshBtn} disabled={loading}>
            <MaterialIcons name="refresh" size={20} color={loading ? Colors.textMuted : Colors.blueBright} />
          </Pressable>
        </View>
      </View>

      {vin ? (
        <QrShareModal
          visible={showQr}
          vin={vin}
          vehicleLabel={report ? `${report.vehicle.year} ${report.vehicle.make} ${report.vehicle.model}` : 'VIN Report'}
          onClose={() => setShowQr(false)}
        />
      ) : null}

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Colors.gold} />
          <Text style={styles.loadingTitle}>Fetching VIN History</Text>
          <Text style={styles.loadingSubtitle}>Querying NHTSA · NMVTIS data sources…</Text>
        </View>
      ) : error ? (
        <View style={styles.centered}>
          <MaterialIcons name="error-outline" size={48} color={Colors.red} />
          <Text style={styles.errorTitle}>Lookup Failed</Text>
          <Text style={styles.errorSub}>{error}</Text>
          <Pressable style={styles.retryBtn} onPress={fetchReport}>
            <MaterialIcons name="refresh" size={16} color="#000" />
            <Text style={styles.retryBtnText}>Try Again</Text>
          </Pressable>
        </View>
      ) : report ? (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: safeArea.bottom + 40 }}
        >
          {/* ── REPORT ID STRIP ── */}
          <View style={styles.reportIdStrip}>
            <View style={styles.reportIdLeft}>
              <Text style={styles.reportIdLabel}>REPORT ID</Text>
              <Text style={styles.reportIdValue}>{report.reportId}</Text>
            </View>
            <View style={styles.reportIdRight}>
              <Text style={styles.reportIdLabel}>GENERATED</Text>
              <Text style={styles.reportIdValue}>{report.reportDate}</Text>
            </View>
            <View style={[styles.checkDigitBadge,
              { backgroundColor: report.checkDigitValid ? 'rgba(74,222,128,0.12)' : 'rgba(255,68,68,0.12)',
                borderColor:      report.checkDigitValid ? 'rgba(74,222,128,0.35)' : 'rgba(255,68,68,0.35)' }
            ]}>
              <MaterialIcons
                name={report.checkDigitValid ? 'verified' : 'cancel'}
                size={12}
                color={report.checkDigitValid ? Colors.green : Colors.red}
              />
              <Text style={{ fontSize: 9, fontWeight: FontWeight.bold,
                color: report.checkDigitValid ? Colors.green : Colors.red }}>
                {report.checkDigitValid ? 'VIN VALID' : 'CHECK DIGIT'}
              </Text>
            </View>
          </View>

          {/* ── VEHICLE IDENTITY ── */}
          <View style={styles.card}>
            <SectionHeader icon="directions-bus" label="VEHICLE IDENTITY" color={Colors.blueBright} />
            <View style={styles.vehicleHero}>
              <View style={styles.vehicleHeroYear}>
                <Text style={styles.vehicleHeroYearText}>{report.vehicle.year}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.vehicleHeroName}>{report.vehicle.make} {report.vehicle.model}</Text>
                {report.vehicle.trim ? (
                  <Text style={styles.vehicleHeroTrim}>{report.vehicle.trim} {report.vehicle.series}</Text>
                ) : null}
                <Text style={styles.vehicleHeroType}>{report.vehicle.bodyClass || report.vehicle.vehicleType}</Text>
              </View>
            </View>
            <View style={styles.vehicleGrid}>
              {report.vehicle.engine    ? <VehicleCell label="Engine"   value={report.vehicle.engine} /> : null}
              {report.vehicle.fuelType  ? <VehicleCell label="Fuel"     value={report.vehicle.fuelType} /> : null}
              {report.vehicle.driveType ? <VehicleCell label="Drive"    value={report.vehicle.driveType} /> : null}
              {report.vehicle.gvwr      ? <VehicleCell label="GVWR"     value={report.vehicle.gvwr} /> : null}
              {report.vehicle.plant     ? <VehicleCell label="Plant"    value={report.vehicle.plant} /> : null}
              <VehicleCell label="WMI" value={report.vehicle.wmi} />
            </View>
          </View>

          {/* ── RISK ASSESSMENT ── */}
          <View style={styles.card}>
            <SectionHeader icon="security" label="RISK ASSESSMENT" color={riskColor} />
            <RiskGauge score={report.risk.score} level={report.risk.level} />
            <FlagRow label="Salvage Title"          triggered={report.risk.flags.salvage}      icon="cancel" />
            <FlagRow label="Insurance Total Loss"   triggered={report.risk.flags.totalLoss}    icon="money-off" />
            <FlagRow label="Flood Damage"           triggered={report.risk.flags.flood}        icon="water-damage" />
            <FlagRow label="Lemon Law Buyback"      triggered={report.risk.flags.lemonLaw}     icon="gavel" />
            <FlagRow label="Odometer Brand / Issue" triggered={report.risk.flags.odoBrand}     icon="speed" />
            <FlagRow label="Active NHTSA Recalls"   triggered={report.risk.flags.activeRecalls} icon="warning" />
          </View>

          {/* ── NMVTIS TITLE HISTORY ── */}
          <View style={styles.card}>
            <SectionHeader icon="history-edu" label="NMVTIS TITLE HISTORY" color={Colors.gold} />
            <View style={styles.titleCountRow}>
              <View style={styles.titleCountBadge}>
                <Text style={styles.titleCountNum}>{report.titleHistory.totalTitles}</Text>
                <Text style={styles.titleCountLabel}>Title Records</Text>
              </View>
              <Text style={styles.titleCountNote}>
                Title events reported to NMVTIS by participating state DMVs
              </Text>
            </View>
            <View style={styles.timelineWrap}>
              {report.titleHistory.events.map((ev, i) => (
                <TitleEventRow key={i} event={ev} isLast={i === report.titleHistory.events.length - 1} />
              ))}
            </View>
            <View style={styles.nmvtisNote}>
              <MaterialIcons name="info-outline" size={12} color={Colors.textMuted} />
              <Text style={styles.nmvtisNoteText}>{report.titleHistory.nmvtisNote}</Text>
            </View>
          </View>

          {/* ── OWNERSHIP HISTORY ── */}
          <View style={styles.card}>
            <SectionHeader icon="people" label="OWNERSHIP HISTORY" color={Colors.blueBright} />
            <View style={styles.ownerCountRow}>
              <Text style={styles.ownerCountNum}>{report.ownership.estimatedOwners}</Text>
              <Text style={styles.ownerCountLabel}>
                Estimated owner{report.ownership.estimatedOwners !== 1 ? 's' : ''}
              </Text>
            </View>
            <View style={styles.ownerList}>
              {report.ownership.history.map((o, i) => (
                <View key={i} style={[styles.ownerRow, i === report.ownership.history.length - 1 && { borderBottomWidth: 0 }]}>
                  <View style={styles.ownerNumBadge}>
                    <Text style={styles.ownerNumText}>{o.ownerNumber}</Text>
                  </View>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={styles.ownerType}>{o.type}</Text>
                    <Text style={styles.ownerState}>{o.stateTitle} · {o.yearAcquired}</Text>
                  </View>
                  <MaterialIcons name="chevron-right" size={16} color={Colors.textMuted} />
                </View>
              ))}
            </View>
          </View>

          {/* ── ODOMETER ── */}
          <View style={styles.card}>
            <SectionHeader icon="speed" label="ODOMETER HISTORY" color={Colors.green} />
            <OdometerCard readings={report.odometer.readings} lastMiles={report.odometer.lastReportedMiles} />
          </View>

          {/* ── NHTSA RECALLS ── */}
          <View style={styles.card}>
            <SectionHeader
              icon="warning"
              label={`NHTSA RECALLS (${report.recalls.count})`}
              color={report.recalls.count > 0 ? Colors.orange : Colors.green}
            />
            {report.recalls.count === 0 ? (
              <View style={styles.noRecallRow}>
                <MaterialIcons name="check-circle" size={20} color={Colors.green} />
                <Text style={styles.noRecallText}>No active NHTSA recalls found for this vehicle</Text>
              </View>
            ) : (
              <View style={{ gap: Spacing.sm }}>
                {report.recalls.items.map((r, i) => (
                  <View key={i} style={styles.recallItem}>
                    <Text style={styles.recallComponent}>{r.component}</Text>
                    {r.summary ? <Text style={styles.recallSummary} numberOfLines={3}>{r.summary}</Text> : null}
                    {r.remedy ? (
                      <View style={styles.recallRemedy}>
                        <MaterialIcons name="build" size={10} color={Colors.green} />
                        <Text style={styles.recallRemedyText} numberOfLines={2}>{r.remedy}</Text>
                      </View>
                    ) : null}
                  </View>
                ))}
              </View>
            )}
          </View>

          {/* ── DATA SOURCES ── */}
          <View style={styles.card}>
            <SectionHeader icon="source" label="DATA SOURCES" color={Colors.textSecondary} />
            {report.sources.map((s, i) => (
              <View key={i} style={[styles.sourceRow, i === report.sources.length - 1 && { borderBottomWidth: 0 }]}>
                <MaterialIcons
                  name={s.official ? 'verified' : 'info-outline'}
                  size={14}
                  color={s.official ? Colors.green : Colors.textMuted}
                />
                <View style={{ flex: 1 }}>
                  <Text style={styles.sourceName}>{s.name}</Text>
                  <Text style={styles.sourceType}>{s.type}</Text>
                </View>
                {s.official && (
                  <View style={styles.officialBadge}>
                    <Text style={styles.officialBadgeText}>OFFICIAL</Text>
                  </View>
                )}
              </View>
            ))}
          </View>

          {/* ── OFFICIAL NMVTIS CTA ── */}
          <Pressable
            style={({ pressed }) => [styles.nmvtisCta, pressed && { opacity: 0.85 }]}
            onPress={() => Linking.openURL(report.officialNmvtisUrl)}
          >
            <View style={styles.nmvtisCtaLeft}>
              <MaterialIcons name="account-balance" size={24} color={Colors.gold} />
              <View>
                <Text style={styles.nmvtisCtaTitle}>Get Official NMVTIS Report</Text>
                <Text style={styles.nmvtisCtaSub}>vehiclehistory.gov · U.S. Dept of Justice</Text>
              </View>
            </View>
            <MaterialIcons name="open-in-new" size={18} color={Colors.gold} />
          </Pressable>

          {/* Disclaimer */}
          <View style={styles.disclaimer}>
            <MaterialIcons name="gavel" size={12} color={Colors.textMuted} />
            <Text style={styles.disclaimerText}>
              This report is for informational purposes only and does not constitute an official NMVTIS report. Title history data is estimated from VIN pattern analysis and public NHTSA records. Always obtain an official NMVTIS report from vehiclehistory.gov before purchasing any vehicle. RvFOX Pro is not liable for decisions made based on this report.
            </Text>
          </View>
        </ScrollView>
      ) : null}
    </View>
  );
}

function VehicleCell({ label, value }: { label: string; value: string }) {
  return (
    <View style={vc.wrap}>
      <Text style={vc.label}>{label}</Text>
      <Text style={vc.value} numberOfLines={2}>{value}</Text>
    </View>
  );
}
const vc = StyleSheet.create({
  wrap: { width: '50%', paddingVertical: 8, paddingRight: 8 },
  label: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium, marginBottom: 2 },
  value: { fontSize: FontSize.sm, color: Colors.textPrimary, fontWeight: FontWeight.semibold },
});

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.black },
  heroBackdrop: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 0,
  },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md, padding: Spacing.lg, zIndex: 2 },

  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    gap: Spacing.sm,
    zIndex: 2,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.bgCard, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  headerCenter: { flex: 1, alignItems: 'center', gap: 3 },
  headerBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(255,215,0,0.10)',
    borderWidth: 1, borderColor: Colors.borderGold,
    borderRadius: Radius.full, paddingHorizontal: 10, paddingVertical: 4,
  },
  headerBadgeText: { fontSize: 10, fontWeight: FontWeight.bold, color: Colors.gold, letterSpacing: 1 },
  headerVin: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary, letterSpacing: 1.5 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  shareHeaderBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(255,215,0,0.1)',
    borderWidth: 1, borderColor: Colors.borderGold,
    alignItems: 'center', justifyContent: 'center',
  },
  refreshBtn: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },

  loadingTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  loadingSubtitle: { fontSize: FontSize.sm, color: Colors.textSecondary, textAlign: 'center' },
  errorTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  errorSub: { fontSize: FontSize.sm, color: Colors.textSecondary, textAlign: 'center' },
  retryBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingHorizontal: 24, paddingVertical: 12,
  },
  retryBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#000' },

  reportIdStrip: {
    flexDirection: 'row', alignItems: 'center',
    marginHorizontal: Spacing.md, marginTop: Spacing.md,
    backgroundColor: 'rgba(0,0,0,0.42)', borderRadius: Radius.lg,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
    padding: Spacing.md, gap: Spacing.md,
    zIndex: 2,
  },
  reportIdLeft:  { flex: 1, gap: 2 },
  reportIdRight: { flex: 1, gap: 2 },
  reportIdLabel: { fontSize: 9, color: Colors.textMuted, fontWeight: FontWeight.bold, letterSpacing: 1 },
  reportIdValue: { fontSize: FontSize.xs, color: Colors.textPrimary, fontWeight: FontWeight.semibold },
  checkDigitBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    borderWidth: 1, borderRadius: Radius.sm, paddingHorizontal: 7, paddingVertical: 5,
  },

  card: {
    marginHorizontal: Spacing.md, marginTop: Spacing.md,
    backgroundColor: 'rgba(0,0,0,0.40)', borderRadius: Radius.xl,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
    padding: Spacing.md,
    zIndex: 2,
  },

  vehicleHero: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.md },
  vehicleHeroYear: {
    backgroundColor: 'rgba(255,215,0,0.1)', borderWidth: 1, borderColor: Colors.borderGold,
    borderRadius: Radius.md, paddingHorizontal: 12, paddingVertical: 6,
  },
  vehicleHeroYearText: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.gold },
  vehicleHeroName: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  vehicleHeroTrim: { fontSize: FontSize.sm, color: Colors.textSecondary },
  vehicleHeroType: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },
  vehicleGrid: { flexDirection: 'row', flexWrap: 'wrap', borderTopWidth: 1, borderTopColor: Colors.border, paddingTop: Spacing.sm },

  titleCountRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    marginBottom: Spacing.md, backgroundColor: 'rgba(255,215,0,0.05)',
    borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.borderGold, padding: Spacing.sm,
  },
  titleCountBadge: { alignItems: 'center', gap: 2 },
  titleCountNum: { fontSize: 28, fontWeight: FontWeight.extrabold, color: Colors.gold, lineHeight: 32 },
  titleCountLabel: { fontSize: 9, color: Colors.textMuted, fontWeight: FontWeight.bold, letterSpacing: 0.8 },
  titleCountNote: { flex: 1, fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 17 },
  timelineWrap: { paddingLeft: Spacing.xs },
  nmvtisNote: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 5, marginTop: Spacing.sm,
    backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: Radius.md, padding: Spacing.sm,
  },
  nmvtisNoteText: { flex: 1, fontSize: 10, color: Colors.textMuted, lineHeight: 16 },

  ownerCountRow: { alignItems: 'center', paddingVertical: Spacing.sm, marginBottom: Spacing.sm },
  ownerCountNum: { fontSize: 36, fontWeight: FontWeight.extrabold, color: Colors.blueBright },
  ownerCountLabel: { fontSize: FontSize.sm, color: Colors.textMuted },
  ownerList: { backgroundColor: Colors.bgCard, borderRadius: Radius.lg, overflow: 'hidden' },
  ownerRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    padding: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  ownerNumBadge: {
    width: 28, height: 28, borderRadius: 14, backgroundColor: 'rgba(77,166,255,0.15)',
    borderWidth: 1, borderColor: 'rgba(77,166,255,0.35)',
    alignItems: 'center', justifyContent: 'center',
  },
  ownerNumText: { fontSize: FontSize.sm, fontWeight: FontWeight.extrabold, color: Colors.blueBright },
  ownerType:  { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  ownerState: { fontSize: FontSize.xs, color: Colors.textMuted },

  noRecallRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.sm },
  noRecallText: { fontSize: FontSize.sm, color: Colors.textSecondary },
  recallItem: {
    backgroundColor: 'rgba(255,140,0,0.06)', borderWidth: 1,
    borderColor: 'rgba(255,140,0,0.2)', borderRadius: Radius.md, padding: Spacing.sm, gap: 4,
  },
  recallComponent: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.orange },
  recallSummary: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 17 },
  recallRemedy: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 4,
    backgroundColor: 'rgba(74,222,128,0.06)', borderRadius: Radius.sm, padding: 6,
  },
  recallRemedyText: { flex: 1, fontSize: FontSize.xs, color: Colors.green, lineHeight: 16 },

  sourceRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: 11, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  sourceName: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  sourceType: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 1 },
  officialBadge: {
    backgroundColor: 'rgba(74,222,128,0.1)', borderWidth: 1,
    borderColor: 'rgba(74,222,128,0.3)', borderRadius: Radius.sm, paddingHorizontal: 6, paddingVertical: 3,
  },
  officialBadgeText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.green, letterSpacing: 0.8 },

  nmvtisCta: {
    marginHorizontal: Spacing.md, marginTop: Spacing.md,
    backgroundColor: 'rgba(0,0,0,0.40)', borderWidth: 1.5, borderColor: Colors.borderSilver,
    borderRadius: Radius.xl, padding: Spacing.md,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2, shadowRadius: 12, elevation: 4,
    zIndex: 2,
  },
  nmvtisCtaLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flex: 1 },
  nmvtisCtaTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.silverBright },
  nmvtisCtaSub: { fontSize: FontSize.xs, color: Colors.textSecondary, marginTop: 2 },

  disclaimer: {
    marginHorizontal: Spacing.md, marginTop: Spacing.md,
    flexDirection: 'row', alignItems: 'flex-start', gap: 6,
    borderRadius: Radius.lg, borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)',
    padding: Spacing.md, zIndex: 2,
  },
  disclaimerText: { flex: 1, fontSize: 10, color: Colors.textMuted, lineHeight: 16 },
});
