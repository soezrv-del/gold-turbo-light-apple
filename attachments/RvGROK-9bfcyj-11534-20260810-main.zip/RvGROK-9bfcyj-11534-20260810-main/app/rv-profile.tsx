import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Alert,
  Modal,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useState, useCallback, useEffect, useRef } from 'react';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import { getSupabaseClient, useAuth } from '@/template';
import { Image } from 'expo-image';
import { RV_DATA, MAKES, YEARS, type RVSpec } from '@/constants/rvData';

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface RVProfile {
  year: string;
  make: string;
  model: string;
  floorplan: string;
  // Auto-filled GPS fields
  height: string;
  width: string;
  length: string;
  gvwr: string;
  axles: string;
  hasPropane: boolean;
}



const EMPTY_PROFILE: RVProfile = {
  year: '',
  make: '',
  model: '',
  floorplan: '',
  height: '',
  width: '',
  length: '',
  gvwr: '',
  axles: '',
  hasPropane: false,
};

// ─── FLOORPLAN LENGTH PARSER ──────────────────────────────────────────────────
// Many RV floorplan numbers directly encode the length:
//   "4369" → first 2 digits = 43 ft  (Newmar, Tiffin, Winnebago, Thor convention)
//   "3717" → 37 ft
//   "40MX" → 40 ft  (letter-suffix models)
//   "22B"  → 22 ft  (Class C / towable short codes)

function parseFloorplanLength(floorplan: string): number | null {
  if (!floorplan) return null;

  // Pattern 1: starts with 4 digits  e.g. "4369", "4311"
  const fourDigit = floorplan.match(/^(\d{2})(\d{2})/);
  if (fourDigit) {
    const feet = parseInt(fourDigit[1], 10);
    if (feet >= 16 && feet <= 50) return feet;
  }

  // Pattern 2: starts with 2 digits followed by letters  e.g. "40MX", "40IP", "45AT"
  const twoDigitLetter = floorplan.match(/^(\d{2})[A-Z]/);
  if (twoDigitLetter) {
    const feet = parseInt(twoDigitLetter[1], 10);
    if (feet >= 16 && feet <= 50) return feet;
  }

  // Pattern 3: starts with 2 digits  e.g. "22B", "31Z", "34J"
  const twoDigit = floorplan.match(/^(\d{2})/);
  if (twoDigit) {
    const feet = parseInt(twoDigit[1], 10);
    if (feet >= 16 && feet <= 50) return feet;
  }

  // Pattern 4: starts with 4-digit with decimal  e.g. "30.3", "32.1"
  const decimal = floorplan.match(/^(\d{2})\.\d/);
  if (decimal) {
    const feet = parseInt(decimal[1], 10);
    if (feet >= 16 && feet <= 50) return feet;
  }

  return null;
}

// ─── AUTO-FILL LOGIC ─────────────────────────────────────────────────────────

function deriveGpsFields(
  spec: RVSpec,
  floorplan?: string
): {
  height: string;
  width: string;
  length: string;
  gvwr: string;
  axles: string;
  hasPropane: boolean;
} {
  const type = spec.type.toLowerCase();
  const isClassA = type.includes('class a');
  const isClassB = type.includes('class b');
  const isClassC = type.includes('class c');
  const isTowable =
    type.includes('travel trailer') ||
    type.includes('fifth wheel') ||
    type.includes('towable');

  // ── Length: prefer floorplan-parsed value, fall back to range midpoint ──
  const parsedLength = floorplan ? parseFloorplanLength(floorplan) : null;
  const midLength = Math.round((spec.lengthRange[0] + spec.lengthRange[1]) / 2);
  const resolvedLength = parsedLength ?? midLength;
  const length = String(resolvedLength);

  // ── GVWR: interpolate within weight range based on resolved length ──
  const [wMin, wMax] = spec.weightRange;
  const [lMin, lMax] = spec.lengthRange;
  const lengthFraction = lMax > lMin
    ? Math.max(0, Math.min(1, (resolvedLength - lMin) / (lMax - lMin)))
    : 0.5;
  const interpolatedGvwr = Math.round(wMin + lengthFraction * (wMax - wMin));
  const gvwr = String(interpolatedGvwr);

  // ── Height ──
  let height = '13.5';
  if (isClassB) height = '9.5';
  else if (isClassC) height = '12.5';
  else if (isTowable) height = '11.5';
  else if (isClassA) {
    height = spec.fuelType === 'Diesel' ? '13.5' : '12.5';
  }

  // ── Width ──
  const width = isTowable ? '8.0' : '8.5';

  // ── Axles (adjusted by interpolated weight) ──
  let axles = '2';
  if (isClassA && spec.fuelType === 'Diesel') {
    axles = interpolatedGvwr >= 48000 ? '3' : '2';
  } else if (isClassB) {
    axles = '1';
  } else if (isTowable) {
    axles = resolvedLength >= 30 ? '2' : '1';
  }

  const hasPropane = !type.includes('electric');

  return { height, width, length, gvwr, axles, hasPropane };
}

// ─── INLINE PICKER MODAL ─────────────────────────────────────────────────────

function PickerModal({
  visible,
  title,
  subtitle,
  items,
  selected,
  onSelect,
  onClose,
}: {
  visible: boolean;
  title: string;
  subtitle?: string;
  items: string[];
  selected: string;
  onSelect: (v: string) => void;
  onClose: () => void;
}) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={pickerStyles.overlay}>
        <Pressable style={pickerStyles.overlayBg} onPress={onClose} />
        <View style={pickerStyles.sheet}>
          <View style={pickerStyles.handle} />
          <View style={pickerStyles.header}>
            <View style={{ flex: 1 }}>
              <Text style={pickerStyles.title}>{title}</Text>
              {subtitle ? <Text style={pickerStyles.subtitle}>{subtitle}</Text> : null}
            </View>
            <Pressable onPress={onClose} hitSlop={8}>
              <MaterialIcons name="close" size={22} color={Colors.textSecondary} />
            </Pressable>
          </View>
          <FlatList
            data={items}
            keyExtractor={i => i}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            renderItem={({ item }) => (
              <TouchableOpacity
                style={[pickerStyles.item, item === selected && pickerStyles.itemSelected]}
                onPress={() => { onSelect(item); onClose(); }}
                activeOpacity={0.7}
              >
                <View style={{ flex: 1 }}>
                  <Text style={[pickerStyles.itemText, item === selected && pickerStyles.itemTextSelected]}>
                    {item}
                  </Text>
                  {/* Show parsed length hint for floorplan items */}
                  {parseFloorplanLength(item) !== null && (
                    <Text style={pickerStyles.itemHint}>
                      ~{parseFloorplanLength(item)} ft
                    </Text>
                  )}
                </View>
                {item === selected && (
                  <MaterialIcons name="check" size={18} color={Colors.gold} />
                )}
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
    </Modal>
  );
}

// ─── GPS FIELD ROW ────────────────────────────────────────────────────────────

function GpsField({ label, value, icon, unit, note }: {
  label: string;
  value: string;
  icon: string;
  unit?: string;
  note?: string;
}) {
  const isEmpty = !value;
  return (
    <View style={gpsStyles.fieldWrap}>
      <View style={gpsStyles.fieldTop}>
        <MaterialIcons name={icon as any} size={14} color={isEmpty ? Colors.textMuted : Colors.orange} />
        <Text style={gpsStyles.fieldLabel}>{label}</Text>
      </View>
      <View style={[gpsStyles.fieldValue, isEmpty && gpsStyles.fieldValueEmpty]}>
        <Text style={[gpsStyles.fieldValueText, isEmpty && gpsStyles.fieldValueTextEmpty]}>
          {isEmpty ? '—' : value}
        </Text>
        {unit && !isEmpty ? <Text style={gpsStyles.fieldUnit}>{unit}</Text> : null}
        {!isEmpty ? <MaterialIcons name="auto-awesome" size={11} color="rgba(255,140,0,0.6)" /> : null}
      </View>
      {note && !isEmpty ? <Text style={gpsStyles.fieldNote}>{note}</Text> : null}
    </View>
  );
}

// ─── STEP BADGE ───────────────────────────────────────────────────────────────

function StepBadge({ number, done }: { number: number | string; done: boolean }) {
  return (
    <View style={[styles.stepBadge, done && styles.stepBadgeDone]}>
      <Text style={styles.stepBadgeText}>{done ? '✓' : number}</Text>
    </View>
  );
}

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

export default function RvProfileScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();

  // Real display name from whitelist
  const displayName = user?.username && !user.username.startsWith('user_')
    ? user.username
    : null;

  const [profile, setProfile] = useState<RVProfile>(EMPTY_PROFILE);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [yearOpen, setYearOpen] = useState(false);
  const [makeOpen, setMakeOpen] = useState(false);
  const [modelOpen, setModelOpen] = useState(false);
  const [floorplanOpen, setFloorplanOpen] = useState(false);

  const availableModels = profile.make ? Object.keys(RV_DATA[profile.make] || {}).sort() : [];
  const selectedSpec: RVSpec | undefined = profile.make && profile.model
    ? RV_DATA[profile.make]?.[profile.model]
    : undefined;
  const availableFloorplans: string[] = selectedSpec?.floorplans ?? [];

  const isComplete = Boolean(profile.year && profile.make && profile.model && profile.floorplan);
  const hasGpsData = Boolean(profile.height && profile.width && profile.length && profile.gvwr);

  const floorplanLength = profile.floorplan ? parseFloorplanLength(profile.floorplan) : null;

  // ── Load saved profile on mount ───────────────────────────────────────────
  useEffect(() => {
    if (!user) { setLoadingProfile(false); return; }
    let cancelled = false;
    async function load() {
      try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
          .from('rv_profiles')
          .select('*')
          .eq('user_id', user!.id)
          .maybeSingle();
        if (!cancelled && !error && data) {
          setProfile({
            year: data.year ?? '',
            make: data.make ?? '',
            model: data.model ?? '',
            floorplan: data.trim ?? '',
            height: data.height ?? '',
            width: data.width ?? '',
            length: data.length ?? '',
            gvwr: data.gvwr ?? '',
            axles: data.axles ?? '',
            hasPropane: data.has_propane ?? false,
          });
        }
      } catch {
        // non-fatal
      } finally {
        if (!cancelled) setLoadingProfile(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  // ── Handlers ─────────────────────────────────────────────────────────────
  const handleSelectYear = (y: string) => setProfile(prev => ({ ...prev, year: y }));

  const handleSelectMake = (m: string) => {
    setProfile(prev => ({
      ...prev, make: m, model: '', floorplan: '',
      height: '', width: '', length: '', gvwr: '', axles: '', hasPropane: false,
    }));
  };

  const handleSelectModel = (mod: string) => {
    const spec = profile.make ? RV_DATA[profile.make]?.[mod] : undefined;
    if (spec) {
      // Pre-fill from model spec range midpoint — floorplan will refine later
      const gps = deriveGpsFields(spec, undefined);
      setProfile(prev => ({ ...prev, model: mod, floorplan: '', ...gps }));
    } else {
      setProfile(prev => ({
        ...prev, model: mod, floorplan: '',
        height: '', width: '', length: '', gvwr: '', axles: '', hasPropane: false,
      }));
    }
  };

  const handleSelectFloorplan = useCallback((fp: string) => {
    const spec = profile.make && profile.model ? RV_DATA[profile.make]?.[profile.model] : undefined;
    if (!spec) {
      setProfile(prev => ({ ...prev, floorplan: fp }));
      return;
    }
    const gps = deriveGpsFields(spec, fp);
    setProfile(prev => ({ ...prev, floorplan: fp, ...gps }));
  }, [profile.make, profile.model]);

  // ── Upsert to Supabase ────────────────────────────────────────────────────
  const handleSave = useCallback(async () => {
    if (!isComplete) {
      Alert.alert('Missing Info', 'Please complete all 4 steps first.');
      return;
    }
    if (!user) {
      Alert.alert('Not Signed In', 'Please sign in to save your RV Profile.');
      return;
    }
    setSaving(true);
    try {
      const supabase = getSupabaseClient();
      const { error } = await supabase
        .from('rv_profiles')
        .upsert(
          {
            user_id: user.id,
            year: profile.year,
            make: profile.make,
            model: profile.model,
            trim: profile.floorplan,        // floorplan stored in trim column
            vin: '',
            fuel_type: selectedSpec?.fuelType ?? '',
            engine: selectedSpec?.engine ?? '',
            color: '',
            purchase_date: '',
            purchase_price: '',
            notes: '',
            height: profile.height,
            width: profile.width,
            length: profile.length,
            gvwr: profile.gvwr,
            axles: profile.axles,
            has_propane: profile.hasPropane,
          },
          { onConflict: 'user_id' }
        );
      if (error) {
        Alert.alert('Save Failed', 'Could not save your profile. Please try again.');
        return;
      }
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      const ownerLabel = displayName ? `${displayName}'s RV` : 'RV Profile';
      Alert.alert(
        `${ownerLabel} Saved! ✓`,
        `${profile.year} ${profile.make} ${profile.model}\nFloorplan: ${profile.floorplan}\n\nGPS safety dimensions saved.`
      );
    } catch {
      Alert.alert('Save Failed', 'Could not reach the server. Please try again.');
    } finally {
      setSaving(false);
    }
  }, [user, profile, isComplete, selectedSpec]);

  const handleClear = () => {
    Alert.alert('Clear Profile', 'Remove your saved RV?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: () => setProfile(EMPTY_PROFILE) },
    ]);
  };

  if (loadingProfile) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, alignItems: 'center', justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color={Colors.gold} />
        <Text style={styles.loadingText}>Loading your RV Profile…</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Hero backdrop */}
      <View style={styles.heroBackdrop}>
        <Image
          source={require('@/assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.5 }}
        />
        <LinearGradient
          colors={['rgba(30,46,64,0.72)', 'rgba(20,38,72,0.30)', 'rgba(20,38,72,0.24)', 'rgba(30,46,64,0.44)', 'rgba(18,28,50,0.80)']}
          locations={[0, 0.18, 0.5, 0.82, 1]}
          style={StyleSheet.absoluteFill}
        />
        {/* Floating type label overlay — appears once a model is selected */}
        {selectedSpec && profile.model ? (
          <View style={styles.heroOverlay}>
            <View style={styles.heroTypeBadge}>
              <Text style={styles.heroTypeText}>{selectedSpec.type}</Text>
            </View>
            <Text style={styles.heroRvName} numberOfLines={1}>
              {profile.year ? `${profile.year} ` : ''}{profile.make} {profile.model}
            </Text>
            {profile.floorplan ? (
              <Text style={styles.heroFloorplanText}>Floorplan {profile.floorplan}</Text>
            ) : null}
          </View>
        ) : null}
      </View>

      {/* ── Header ── */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn} hitSlop={10}>
          <MaterialIcons name="arrow-back-ios" size={20} color={Colors.blueBright} />
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>
            {displayName ? `${displayName.split(' ')[0]}'s RV` : 'My RV'}
          </Text>
          <Text style={styles.headerSub}>PROFILE</Text>
        </View>
        {isComplete ? (
          <Pressable onPress={handleClear} style={styles.clearBtn} hitSlop={8}>
            <MaterialIcons name="refresh" size={18} color={Colors.textMuted} />
          </Pressable>
        ) : (
          <View style={{ width: 36 }} />
        )}
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 120 }}
      >

        {/* ── INSTRUCTION CARD ── */}
        <View style={styles.instructionCard}>
          <View style={styles.instructionIcon}>
            <MaterialIcons name="auto-awesome" size={24} color={Colors.gold} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.instructionTitle}>4-step RV identification</Text>
            <Text style={styles.instructionSub}>
              Year · Make · Model · Floorplan — each floorplan has its own exact length, weight, and GPS dimensions.
            </Text>
          </View>
        </View>

        {/* ── STEP 1: YEAR ── */}
        <View style={styles.stepBlock}>
          <View style={styles.stepHeader}>
            <StepBadge number={1} done={Boolean(profile.year)} />
            <Text style={styles.stepTitle}>Select Year</Text>
          </View>
          <Pressable
            style={({ pressed }) => [
              styles.picker,
              profile.year && styles.pickerFilled,
              pressed && styles.pickerPressed,
            ]}
            onPress={() => setYearOpen(true)}
          >
            <Text style={[styles.pickerText, !profile.year && styles.pickerPlaceholder]}>
              {profile.year || 'Tap to select year'}
            </Text>
            <MaterialIcons name="keyboard-arrow-down" size={22}
              color={profile.year ? Colors.gold : Colors.textMuted} />
          </Pressable>
        </View>

        {/* ── STEP 2: MAKE ── */}
        <View style={styles.stepBlock}>
          <View style={styles.stepHeader}>
            <StepBadge number={2} done={Boolean(profile.make)} />
            <Text style={styles.stepTitle}>Select Make</Text>
          </View>
          <Pressable
            style={({ pressed }) => [
              styles.picker,
              profile.make && styles.pickerFilled,
              pressed && styles.pickerPressed,
            ]}
            onPress={() => setMakeOpen(true)}
          >
            <Text style={[styles.pickerText, !profile.make && styles.pickerPlaceholder]}>
              {profile.make || 'Tap to select manufacturer'}
            </Text>
            <MaterialIcons name="keyboard-arrow-down" size={22}
              color={profile.make ? Colors.gold : Colors.textMuted} />
          </Pressable>
        </View>

        {/* ── STEP 3: MODEL ── */}
        <View style={styles.stepBlock}>
          <View style={styles.stepHeader}>
            <StepBadge number={3} done={Boolean(profile.model)} />
            <Text style={styles.stepTitle}>Select Model</Text>
          </View>
          <Pressable
            style={({ pressed }) => [
              styles.picker,
              profile.model && styles.pickerFilled,
              !profile.make && styles.pickerDisabled,
              pressed && profile.make && styles.pickerPressed,
            ]}
            onPress={() => profile.make && setModelOpen(true)}
            disabled={!profile.make}
          >
            <Text style={[styles.pickerText, !profile.model && styles.pickerPlaceholder]}>
              {profile.model || (profile.make ? `Tap to select ${profile.make} model` : 'Select a make first')}
            </Text>
            <MaterialIcons name="keyboard-arrow-down" size={22}
              color={profile.model ? Colors.gold : Colors.textMuted} />
          </Pressable>
        </View>

        {/* ── STEP 4: FLOORPLAN / SERIES ── */}
        <View style={styles.stepBlock}>
          <View style={styles.stepHeader}>
            <StepBadge number={4} done={Boolean(profile.floorplan)} />
            <View style={{ flex: 1 }}>
              <Text style={styles.stepTitle}>Select Series / Floorplan</Text>
              <Text style={styles.stepHint}>
                Each floorplan has its own exact length &amp; weight
              </Text>
            </View>
          </View>
          <Pressable
            style={({ pressed }) => [
              styles.picker,
              profile.floorplan && styles.pickerFilledFloorplan,
              !profile.model && styles.pickerDisabled,
              pressed && profile.model && styles.pickerPressedFloorplan,
            ]}
            onPress={() => profile.model && setFloorplanOpen(true)}
            disabled={!profile.model}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.pickerText, !profile.floorplan && styles.pickerPlaceholder]}>
                {profile.floorplan || (profile.model ? `Tap to select floorplan` : 'Select a model first')}
              </Text>
              {floorplanLength !== null ? (
                <Text style={styles.pickerSubtext}>
                  ~{floorplanLength} ft · length-encoded from floorplan number
                </Text>
              ) : null}
            </View>
            <MaterialIcons name="keyboard-arrow-down" size={22}
              color={profile.floorplan ? Colors.blueBright : Colors.textMuted} />
          </Pressable>
        </View>

        {/* ── SELECTED RV SUMMARY ── */}
        {selectedSpec && profile.floorplan && (
          <View style={styles.rvSummaryCard}>
            <View style={styles.rvSummaryRow}>
              <View style={styles.rvSummaryTypeBadge}>
                <Text style={styles.rvSummaryTypeText}>{selectedSpec.type}</Text>
              </View>
              <View style={styles.rvSummaryFloorplanBadge}>
                <MaterialIcons name="dashboard" size={11} color={Colors.blueBright} />
                <Text style={styles.rvSummaryFloorplanText}>{profile.floorplan}</Text>
              </View>
              <View style={styles.rvSummaryRating}>
                <MaterialIcons name="star" size={13} color={Colors.gold} />
                <Text style={styles.rvSummaryRatingText}>{selectedSpec.rating.toFixed(1)}</Text>
              </View>
            </View>
            <Text style={styles.rvSummaryName}>
              {profile.year} {profile.make} {profile.model}
            </Text>
            {selectedSpec.engine ? (
              <Text style={styles.rvSummaryEngine}>
                {selectedSpec.engine} · {selectedSpec.fuelType}
              </Text>
            ) : null}
            {floorplanLength !== null && (
              <View style={styles.floorplanLengthBadge}>
                <MaterialIcons name="straighten" size={12} color={Colors.blueBright} />
                <Text style={styles.floorplanLengthText}>
                  Floorplan {profile.floorplan} is approximately {floorplanLength} ft long
                </Text>
              </View>
            )}
          </View>
        )}

        {/* ── AUTO-FILLED GPS DIMENSIONS ── */}
        {hasGpsData && !profile.floorplan && (
          <View style={styles.previewBanner}>
            <MaterialIcons name="info" size={14} color={Colors.blueBright} />
            <Text style={styles.previewBannerText}>
              Range estimate from {profile.make} {profile.model} specs. Select a floorplan in Step 4 for exact dimensions.
            </Text>
          </View>
        )}
        {hasGpsData && (
          <View style={styles.gpsCard}>
            <View style={styles.gpsTitleRow}>
              <MaterialIcons name="auto-awesome" size={16} color={Colors.orange} />
              <Text style={styles.gpsTitle}>GPS Safety Dimensions</Text>
              <View style={styles.autoFilledBadge}>
                <Text style={styles.autoFilledText}>
                  {floorplanLength !== null ? 'FLOORPLAN-EXACT' : 'AUTO-FILLED'}
                </Text>
              </View>
            </View>
            <Text style={styles.gpsSub}>
              {floorplanLength !== null
                ? `Calculated for the ${profile.make} ${profile.model} floorplan ${profile.floorplan} — length and GVWR derived from the floorplan number.`
                : `Estimated from ${profile.make} ${profile.model} spec range. Add a floorplan for exact values.`
              }
            </Text>

            <View style={styles.gpsGrid}>
              <GpsField
                label="Height"
                value={profile.height}
                icon="height"
                unit="ft"
              />
              <GpsField
                label="Width"
                value={profile.width}
                icon="swap-horiz"
                unit="ft"
              />
              <GpsField
                label="Length"
                value={profile.length}
                icon="straighten"
                unit="ft"
                note={floorplanLength !== null ? `Exact — from FP ${profile.floorplan}` : undefined}
              />
              <GpsField
                label="GVWR"
                value={profile.gvwr ? Number(profile.gvwr).toLocaleString() : ''}
                icon="monitor-weight"
                unit="lbs"
                note={floorplanLength !== null ? 'Interpolated by length' : undefined}
              />
              <GpsField
                label="Axles"
                value={profile.axles}
                icon="settings"
              />
              <View style={styles.propaneCell}>
                <View style={gpsStyles.fieldTop}>
                  <MaterialIcons
                    name="local-fire-department"
                    size={14}
                    color={profile.hasPropane ? Colors.orange : Colors.textMuted}
                  />
                  <Text style={gpsStyles.fieldLabel}>Propane</Text>
                </View>
                <View style={[gpsStyles.fieldValue, profile.hasPropane && styles.propaneActive]}>
                  <Text style={[gpsStyles.fieldValueText, !profile.hasPropane && gpsStyles.fieldValueTextEmpty]}>
                    {profile.hasPropane ? 'Yes' : 'No'}
                  </Text>
                  {profile.hasPropane
                    ? <MaterialIcons name="auto-awesome" size={11} color="rgba(255,140,0,0.6)" />
                    : null
                  }
                </View>
              </View>
            </View>

            <View style={styles.gpsNote}>
              <MaterialIcons name="info-outline" size={12} color={Colors.textMuted} />
              <Text style={styles.gpsNoteText}>
                {floorplanLength !== null
                  ? `Length decoded from floorplan "${profile.floorplan}" (first two digits = feet). GVWR interpolated within the ${profile.make} ${profile.model} weight range. Verify with your owner's manual.`
                  : `Values estimated from manufacturer specs. Select a floorplan above for more precise dimensions.`
                }
              </Text>
            </View>
          </View>
        )}

        {/* ── EMPTY STATE ── */}
        {!hasGpsData && (
          <View style={styles.emptyGps}>
            <MaterialIcons name="warning" size={32} color="rgba(255,140,0,0.3)" />
            <Text style={styles.emptyGpsTitle}>GPS Dimensions Pending</Text>
            <Text style={styles.emptyGpsSub}>
              {!profile.model
                ? 'Complete Steps 1–3 to unlock the floorplan selector.'
                : 'Select a floorplan in Step 4 to get length-accurate GPS dimensions.'}
            </Text>
          </View>
        )}

      </ScrollView>

      {/* ── SAVE BUTTON ── */}
      <View style={[styles.saveRow, { paddingBottom: insets.bottom + Spacing.md }]}>
        <Pressable
          style={({ pressed }) => [
            styles.saveBtn,
            !isComplete && styles.saveBtnDisabled,
            pressed && isComplete && styles.saveBtnPressed,
            saved && styles.saveBtnSaved,
          ]}
          onPress={handleSave}
          disabled={!isComplete || saving}
        >
          {saving ? (
            <ActivityIndicator color="#000" size="small" />
          ) : (
            <>
              <MaterialIcons
                name={saved ? 'check-circle' : 'save'}
                size={20}
                color={!isComplete ? Colors.textMuted : '#000'}
              />
              <Text style={[styles.saveBtnText, !isComplete && { color: Colors.textMuted }]}>
                {saved ? 'Saved!' : 'Save RV Profile'}
              </Text>
            </>
          )}
        </Pressable>
      </View>

      {/* ── PICKERS ── */}
      <PickerModal
        visible={yearOpen}
        title="Select Year"
        items={YEARS}
        selected={profile.year}
        onSelect={handleSelectYear}
        onClose={() => setYearOpen(false)}
      />
      <PickerModal
        visible={makeOpen}
        title="Select Manufacturer"
        items={MAKES}
        selected={profile.make}
        onSelect={handleSelectMake}
        onClose={() => setMakeOpen(false)}
      />
      <PickerModal
        visible={modelOpen}
        title={profile.make ? `${profile.make} Models` : 'Select Model'}
        items={availableModels}
        selected={profile.model}
        onSelect={handleSelectModel}
        onClose={() => setModelOpen(false)}
      />
      <PickerModal
        visible={floorplanOpen}
        title={profile.model ? `${profile.make} ${profile.model} Floorplans` : 'Select Floorplan'}
        subtitle="Each floorplan encodes exact length — numbers shown are decoded from the floorplan ID"
        items={availableFloorplans}
        selected={profile.floorplan}
        onSelect={handleSelectFloorplan}
        onClose={() => setFloorplanOpen(false)}
      />
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.black },
  loadingText: { color: Colors.textMuted, fontSize: FontSize.sm, marginTop: 12 },
  heroBackdrop: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 0,
  },
  heroOverlay: {
    position: 'absolute',
    bottom: 0, left: 0, right: 0,
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.sm,
    paddingTop: 32,
    gap: 3,
  },
  heroTypeBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(30,111,255,0.70)',
    borderRadius: Radius.sm,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: 'rgba(77,166,255,0.5)',
    marginBottom: 2,
  },
  heroTypeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: '#fff',
    letterSpacing: 0.5,
  },
  heroRvName: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.extrabold,
    color: '#fff',
    textShadowColor: 'rgba(0,0,0,0.6)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  heroFloorplanText: {
    fontSize: FontSize.xs,
    color: 'rgba(255,255,255,0.55)',
    fontWeight: FontWeight.medium,
  },

  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, paddingBottom: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    zIndex: 2,
  },
  backBtn: { width: 36, alignItems: 'flex-start' },
  headerCenter: { flex: 1, alignItems: 'center' },
  headerTitle: {
    fontSize: FontSize.xl, fontWeight: FontWeight.extrabold,
    color: Colors.blueBright, letterSpacing: 0.3,
  },
  headerSub: {
    fontSize: FontSize.xs, color: Colors.gold,
    fontWeight: FontWeight.semibold, letterSpacing: 1.2, marginTop: 1,
  },
  clearBtn: { width: 36, alignItems: 'flex-end' },

  instructionCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm,
    margin: Spacing.md,
    backgroundColor: 'rgba(0,0,0,0.38)',
    borderWidth: 1.5, borderColor: Colors.borderBlue,
    borderRadius: Radius.xl, padding: Spacing.md,
    zIndex: 2,
  },
  instructionIcon: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: 'rgba(255,215,0,0.1)', borderWidth: 1.5, borderColor: 'rgba(255,215,0,0.3)',
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  instructionTitle: {
    fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.blueBright, marginBottom: 4,
  },
  instructionSub: { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 19 },

  stepBlock: { paddingHorizontal: Spacing.md, marginBottom: Spacing.lg, zIndex: 2 },
  stepHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, marginBottom: Spacing.sm },
  stepBadge: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(30,111,255,0.15)',
    borderWidth: 1.5, borderColor: 'rgba(30,111,255,0.4)',
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  stepBadgeDone: {
    backgroundColor: 'rgba(74,222,128,0.15)',
    borderColor: 'rgba(74,222,128,0.5)',
  },
  stepBadgeText: { fontSize: FontSize.xs, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  stepTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  stepHint: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },

  picker: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderWidth: 1.5, borderColor: Colors.borderBlue,
    borderRadius: Radius.lg, paddingHorizontal: Spacing.md, paddingVertical: 16,
    shadowColor: '#1E6FFF', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12, shadowRadius: 8, elevation: 2,
  },
  pickerFilled: {
    borderColor: 'rgba(255,215,0,0.55)',
    backgroundColor: 'rgba(255,215,0,0.05)',
    shadowColor: Colors.gold, shadowOpacity: 0.25, shadowRadius: 12, elevation: 4,
  },
  pickerFilledFloorplan: {
    borderColor: 'rgba(30,111,255,0.7)',
    backgroundColor: 'rgba(30,111,255,0.07)',
    shadowColor: Colors.blueBright, shadowOpacity: 0.35, shadowRadius: 14, elevation: 5,
  },
  pickerPressed: {
    borderColor: Colors.blueBright,
    shadowColor: Colors.blueBright, shadowOpacity: 0.5, shadowRadius: 16, elevation: 6,
    transform: [{ scale: 0.99 }],
  },
  pickerPressedFloorplan: {
    borderColor: Colors.blueBright,
    shadowColor: Colors.blueBright, shadowOpacity: 0.7, shadowRadius: 20, elevation: 8,
    transform: [{ scale: 0.99 }],
  },
  pickerDisabled: { opacity: 0.45 },
  pickerText: { fontSize: FontSize.lg, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  pickerPlaceholder: { color: Colors.textMuted, fontSize: FontSize.base, fontWeight: FontWeight.regular },
  pickerSubtext: { fontSize: FontSize.xs, color: Colors.blueBright, marginTop: 3, fontWeight: FontWeight.semibold },

  rvSummaryCard: {
    marginHorizontal: Spacing.md, marginBottom: Spacing.md,
    backgroundColor: 'rgba(0,0,0,0.42)',
    borderRadius: Radius.xl, borderWidth: 1.5, borderColor: Colors.borderBlue,
    padding: Spacing.md, gap: Spacing.sm,
    shadowColor: '#1E6FFF', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3, shadowRadius: 16, elevation: 6,
  },
  rvSummaryRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flexWrap: 'wrap' },
  rvSummaryTypeBadge: {
    backgroundColor: 'rgba(30,111,255,0.15)', borderWidth: 1, borderColor: 'rgba(30,111,255,0.4)',
    borderRadius: Radius.sm, paddingHorizontal: 10, paddingVertical: 4,
  },
  rvSummaryTypeText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright },
  rvSummaryFloorplanBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(30,111,255,0.1)', borderWidth: 1, borderColor: 'rgba(30,111,255,0.3)',
    borderRadius: Radius.sm, paddingHorizontal: 10, paddingVertical: 4,
  },
  rvSummaryFloorplanText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright },
  rvSummaryRating: { flexDirection: 'row', alignItems: 'center', gap: 4, marginLeft: 'auto' },
  rvSummaryRatingText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.gold },
  rvSummaryName: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  rvSummaryEngine: { fontSize: FontSize.sm, color: Colors.textMuted },
  floorplanLengthBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(30,111,255,0.08)',
    borderRadius: Radius.md, paddingHorizontal: 10, paddingVertical: 6,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.2)',
  },
  floorplanLengthText: { fontSize: FontSize.xs, color: Colors.blueBright, fontWeight: FontWeight.semibold },

  gpsCard: {
    marginHorizontal: Spacing.md, marginBottom: Spacing.md,
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderRadius: Radius.xl, borderWidth: 1.5, borderColor: Colors.borderBlue,
    padding: Spacing.md, gap: Spacing.md,
    shadowColor: Colors.orange, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2, shadowRadius: 14, elevation: 5,
  },
  gpsTitleRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  gpsTitle: { flex: 1, fontSize: FontSize.base, fontWeight: FontWeight.extrabold, color: Colors.orange },
  autoFilledBadge: {
    backgroundColor: Colors.orange, borderRadius: Radius.sm,
    paddingHorizontal: 8, paddingVertical: 3,
  },
  autoFilledText: { fontSize: 9, fontWeight: FontWeight.bold, color: '#000', letterSpacing: 0.8 },
  gpsSub: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 17, marginTop: -Spacing.xs },
  gpsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  propaneCell: { width: '47%' },
  propaneActive: {
    borderColor: 'rgba(255,140,0,0.5)',
    backgroundColor: 'rgba(255,140,0,0.08)',
  },
  gpsNote: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 6,
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: Radius.md, padding: Spacing.sm,
  },
  gpsNoteText: { flex: 1, fontSize: 11, color: Colors.textMuted, lineHeight: 16 },

  emptyGps: {
    marginHorizontal: Spacing.md, marginTop: Spacing.sm,
    alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(255,140,0,0.04)',
    borderRadius: Radius.xl, borderWidth: 1, borderColor: 'rgba(255,140,0,0.15)',
    padding: Spacing.xl * 1.5,
  },
  emptyGpsTitle: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.textSecondary },
  emptyGpsSub: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', lineHeight: 19 },
  previewBanner: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 8,
    marginHorizontal: Spacing.md, marginBottom: Spacing.sm,
    backgroundColor: 'rgba(30,111,255,0.08)',
    borderRadius: Radius.lg, padding: Spacing.sm,
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.25)',
  },
  previewBannerText: {
    flex: 1, fontSize: FontSize.xs, color: Colors.blueBright, lineHeight: 17,
  },

  saveRow: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: 'rgba(0,0,0,0.80)', borderTopWidth: 1, borderTopColor: Colors.border,
    paddingHorizontal: Spacing.md, paddingTop: Spacing.md,
    zIndex: 10,
  },
  saveBtn: {
    backgroundColor: Colors.blueBright, borderRadius: Radius.full, paddingVertical: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45, shadowRadius: 12, elevation: 6,
  },
  saveBtnPressed: {
    shadowOpacity: 0.8, shadowRadius: 22, elevation: 12, transform: [{ scale: 0.98 }],
  },
  saveBtnDisabled: {
    backgroundColor: Colors.bgCardAlt, shadowOpacity: 0, elevation: 0,
    borderWidth: 1, borderColor: Colors.border,
  },
  saveBtnSaved: { backgroundColor: Colors.success, shadowColor: Colors.success },
  saveBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#000' },
});

const gpsStyles = StyleSheet.create({
  fieldWrap: { width: '47%' },
  fieldTop: { flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 5 },
  fieldLabel: {
    fontSize: FontSize.xs, fontWeight: FontWeight.bold,
    color: Colors.orange, letterSpacing: 0.8,
  },
  fieldValue: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(10,28,60,0.85)',
    borderWidth: 1, borderColor: 'rgba(255,140,0,0.3)',
    borderRadius: Radius.md, paddingHorizontal: Spacing.sm, paddingVertical: 10,
    minHeight: 42,
  },
  fieldValueEmpty: {
    borderColor: 'rgba(255,255,255,0.08)',
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  fieldValueText: {
    flex: 1, fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.textPrimary,
  },
  fieldValueTextEmpty: { color: Colors.textMuted, fontWeight: FontWeight.regular },
  fieldUnit: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.semibold },
  fieldNote: { fontSize: 10, color: Colors.blueBright, marginTop: 3, fontWeight: FontWeight.semibold },
});

const pickerStyles = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end' },
  overlayBg: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.75)' },
  sheet: {
    backgroundColor: '#060D1F',
    borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    borderTopWidth: 2, borderColor: '#1E6FFF',
    maxHeight: '65%', paddingBottom: 32,
    shadowColor: '#1E6FFF', shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.5, shadowRadius: 24, elevation: 18,
  },
  handle: {
    width: 36, height: 4, backgroundColor: Colors.border,
    borderRadius: 2, alignSelf: 'center', marginTop: 12, marginBottom: 4,
  },
  header: {
    flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  title: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  subtitle: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 3, lineHeight: 16 },
  item: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: 13,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  itemSelected: { backgroundColor: 'rgba(255,215,0,0.06)' },
  itemText: { fontSize: FontSize.base, color: Colors.textSecondary, fontWeight: FontWeight.medium },
  itemTextSelected: { color: Colors.gold, fontWeight: FontWeight.bold },
  itemHint: { fontSize: 11, color: Colors.blueBright, marginTop: 2, fontWeight: FontWeight.semibold },
});
