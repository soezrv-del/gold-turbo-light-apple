import { View, Text, StyleSheet, ScrollView, Pressable, ActivityIndicator, Platform, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { useSubscriptionContext } from '@/contexts/SubscriptionContext';
import {
  PRODUCT_IDS,
  TIER_LABELS,
  TIER_PRICES,
  type ProductId,
} from '@/hooks/useSubscription';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';

// ─── FEATURE LISTS ────────────────────────────────────────────────────────────

const CONSUMER_FEATURES = [
  'Full RV specs database (37 brands · 169+ models)',
  'AI-powered RvGrok chat companion',
  'RvTow towing calculator with trim-level ratings',
  'RvTrips GPS route planning & campground finder',
  'RvCal trip calendar & maintenance tracker',
  'VIN decoder & NHTSA recall lookup',
  'Owner reviews & market pricing',
  'Up to 10 saved RV reports/month',
];

const PROFESSIONAL_FEATURES = [
  'Everything in Consumer, plus:',
  'Unlimited RV reports & comparisons',
  'Dealer-grade appraisal data & trade-in values',
  'Priority AI processing (RvGrok)',
  'Professional PDF report exports',
  'White-label report branding (coming soon)',
  'Dealership tools & bulk lookup',
  'Dedicated support line',
];

// ─── SUB COMPONENTS ───────────────────────────────────────────────────────────

function FeatureRow({ text, highlight }: { text: string; highlight?: boolean }) {
  return (
    <View style={styles.featureRow}>
      <MaterialIcons
        name={highlight ? 'star' : 'check-circle'}
        size={16}
        color={highlight ? Colors.gold : Colors.green}
      />
      <Text style={[styles.featureText, highlight && { color: Colors.gold }]}>{text}</Text>
    </View>
  );
}

interface PlanCardProps {
  productId: ProductId;
  label: string;
  price: string;
  color: string;
  features: string[];
  isActive: boolean;
  isBest?: boolean;
  purchasing: boolean;
  onSubscribe: () => void;
}

function PlanCard({
  productId, label, price, color, features, isActive, isBest, purchasing, onSubscribe,
}: PlanCardProps) {
  return (
    <View style={[styles.planCard, { borderColor: color + '55' }, isActive && { borderColor: color, borderWidth: 2 }]}>
      {isBest && (
        <View style={[styles.bestBadge, { backgroundColor: color }]}>
          <Text style={styles.bestBadgeText}>MOST POPULAR</Text>
        </View>
      )}
      {isActive && (
        <View style={[styles.activeBadge, { backgroundColor: color + '22', borderColor: color + '66' }]}>
          <MaterialIcons name="verified" size={13} color={color} />
          <Text style={[styles.activeBadgeText, { color }]}>CURRENT PLAN</Text>
        </View>
      )}

      <View style={styles.planHeader}>
        <View>
          <Text style={[styles.planLabel, { color }]}>{label}</Text>
          <Text style={styles.planPrice}>{price}</Text>
          <Text style={styles.planBilling}>Billed monthly · Cancel anytime</Text>
        </View>
        <View style={[styles.planIcon, { backgroundColor: color + '18', borderColor: color + '44' }]}>
          <MaterialIcons
            name={productId === PRODUCT_IDS.PROFESSIONAL ? 'business' : 'person'}
            size={24}
            color={color}
          />
        </View>
      </View>

      <View style={styles.featureList}>
        {features.map((f, i) => (
          <FeatureRow key={i} text={f} highlight={i === 0 && productId === PRODUCT_IDS.PROFESSIONAL} />
        ))}
      </View>

      <Pressable
        style={({ pressed }) => [
          styles.subscribeBtn,
          { backgroundColor: isActive ? color + '22' : color },
          pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
          isActive && { borderWidth: 1, borderColor: color },
        ]}
        onPress={onSubscribe}
        disabled={isActive || purchasing}
      >
        {purchasing ? (
          <ActivityIndicator size="small" color={isActive ? color : '#000'} />
        ) : (
          <>
            <MaterialIcons
              name={isActive ? 'check-circle' : 'lock-open'}
              size={18}
              color={isActive ? color : '#000'}
            />
            <Text style={[styles.subscribeBtnText, isActive && { color }]}>
              {isActive ? 'Active' : 'Subscribe'}
            </Text>
          </>
        )}
      </Pressable>
    </View>
  );
}

// ─── MAIN SCREEN ──────────────────────────────────────────────────────────────

export default function SubscriptionScreen() {
  const insets = useSafeAreaInsets();
  const { tier, isActive, loading, purchasing, error, subscribe, restorePurchases } = useSubscriptionContext();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Hero backdrop */}
      <View style={styles.heroBackdrop}>
        <Image
          source={require('@/assets/entegra-hero.png')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          transition={400}
        />
        <LinearGradient
          colors={['rgba(8,8,8,0.60)', 'rgba(8,8,8,0.30)', 'rgba(8,8,8,0.40)']}
          style={StyleSheet.absoluteFill}
        />
      </View>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerBadge}>
          <MaterialIcons name="workspace-premium" size={16} color={Colors.gold} />
          <Text style={styles.headerBadgeText}>RvFOX SUBSCRIPTION</Text>
        </View>
        <Text style={styles.headerTitle}>Choose Your Plan</Text>
        <Text style={styles.headerSub}>Unlock the full power of RvFOX Pro</Text>
      </View>

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Colors.gold} />
          <Text style={styles.loadingText}>Loading plans from App Store…</Text>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + Spacing.xl }}
        >
          {/* Current Status */}
          {isActive && (
            <View style={styles.activeStatusCard}>
              <MaterialIcons name="verified" size={20} color={Colors.green} />
              <View style={{ flex: 1 }}>
                <Text style={styles.activeStatusTitle}>Active Subscription</Text>
                <Text style={styles.activeStatusSub}>{TIER_LABELS[tier]} · Renews monthly</Text>
              </View>
            </View>
          )}

          {error ? (
            <View style={styles.errorCard}>
              <MaterialIcons name="error-outline" size={16} color={Colors.red} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          {/* Consumer Plan */}
          <PlanCard
            productId={PRODUCT_IDS.CONSUMER}
            label="Consumer"
            price={TIER_PRICES['rvfox.consumer.monthly']}
            color={Colors.blueBright}
            features={CONSUMER_FEATURES}
            isActive={tier === 'consumer'}
            purchasing={purchasing}
            onSubscribe={() => subscribe(PRODUCT_IDS.CONSUMER)}
          />

          {/* Professional Plan */}
          <PlanCard
            productId={PRODUCT_IDS.PROFESSIONAL}
            label="Professional"
            price={TIER_PRICES['rvfox.professional.monthly']}
            color={Colors.gold}
            features={PROFESSIONAL_FEATURES}
            isActive={tier === 'professional'}
            isBest
            purchasing={purchasing}
            onSubscribe={() => subscribe(PRODUCT_IDS.PROFESSIONAL)}
          />

          {/* Restore + Legal */}
          <View style={styles.restoreRow}>
            <Pressable
              style={({ pressed }) => [styles.restoreBtn, pressed && { opacity: 0.7 }]}
              onPress={restorePurchases}
            >
              <MaterialIcons name="restore" size={16} color={Colors.blueBright} />
              <Text style={styles.restoreBtnText}>Restore Purchases</Text>
            </Pressable>
          </View>

          <View style={styles.legalBox}>
            <Text style={styles.legalText}>
              Payment will be charged to your Apple ID account at confirmation of purchase. Subscription automatically renews unless canceled at least 24 hours before the end of the current period. You can manage and cancel your subscription in your App Store account settings.
            </Text>
            <View style={styles.legalLinks}>
              <Pressable onPress={() => Linking.openURL('https://rvfox.app/terms')}>
                <Text style={styles.legalLink}>Terms of Service</Text>
              </Pressable>
              <Text style={styles.legalDot}>·</Text>
              <Pressable onPress={() => Linking.openURL('https://rvfox.app/privacy')}>
                <Text style={styles.legalLink}>Privacy Policy</Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      )}
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.black },
  heroBackdrop: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 0,
  },

  header: {
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.sm,
    paddingBottom: Spacing.lg,
    gap: 6,
    zIndex: 2,
  },
  headerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(0,104,192,0.12)',
    borderWidth: 1,
    borderColor: Colors.borderBlue,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: Radius.full,
    marginBottom: 4,
  },
  headerBadgeText: {
    fontSize: 11,
    fontWeight: FontWeight.bold,
    color: Colors.blueBright,
    letterSpacing: 1.2,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: FontWeight.extrabold,
    color: Colors.textPrimary,
    textAlign: 'center',
  },
  headerSub: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    textAlign: 'center',
  },

  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md, zIndex: 2 },
  loadingText: { color: Colors.textSecondary, fontSize: FontSize.sm },

  activeStatusCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(74,222,128,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(74,222,128,0.3)',
    borderRadius: Radius.lg,
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  activeStatusTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: Colors.green,
  },
  activeStatusSub: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    marginTop: 2,
  },

  errorCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    backgroundColor: 'rgba(255,68,68,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,68,68,0.3)',
    borderRadius: Radius.md,
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  errorText: { color: Colors.red, fontSize: FontSize.sm, flex: 1 },

  planCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(0,0,0,0.42)',
    borderRadius: Radius.xl,
    borderWidth: 1,
    padding: Spacing.lg,
    gap: Spacing.md,
    position: 'relative',
    overflow: 'visible',
    zIndex: 2,
  },
  bestBadge: {
    position: 'absolute',
    top: -12,
    alignSelf: 'center',
    paddingHorizontal: 16,
    paddingVertical: 4,
    borderRadius: Radius.full,
  },
  bestBadgeText: {
    fontSize: 10,
    fontWeight: FontWeight.bold,
    color: '#000',
    letterSpacing: 1.2,
  },
  activeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: Radius.full,
    borderWidth: 1,
    marginBottom: -Spacing.xs,
  },
  activeBadgeText: {
    fontSize: 10,
    fontWeight: FontWeight.bold,
    letterSpacing: 1,
  },
  planHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  planLabel: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  planPrice: {
    fontSize: 28,
    fontWeight: FontWeight.extrabold,
    color: Colors.textPrimary,
    lineHeight: 32,
  },
  planBilling: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    marginTop: 3,
  },
  planIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  featureList: { gap: 10 },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  featureText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    flex: 1,
    lineHeight: 20,
  },

  subscribeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: Radius.full,
    marginTop: Spacing.xs,
  },
  subscribeBtnText: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: '#000',
  },

  restoreRow: {
    alignItems: 'center',
    marginBottom: Spacing.md,
    zIndex: 2,
  },
  restoreBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  restoreBtnText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.semibold,
    color: Colors.blueBright,
  },

  legalBox: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
    gap: 10,
    zIndex: 2,
  },
  legalText: {
    fontSize: 11,
    color: Colors.textMuted,
    textAlign: 'center',
    lineHeight: 17,
  },
  legalLinks: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  legalLink: {
    fontSize: 11,
    color: Colors.blueBright,
    fontWeight: FontWeight.semibold,
  },
  legalDot: {
    fontSize: 11,
    color: Colors.textMuted,
  },
});
