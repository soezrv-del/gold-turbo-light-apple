import {
  View, Text, StyleSheet, TextInput, Pressable, Animated,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator,
} from 'react-native';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { useAlert, getSupabaseClient } from '@/template';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const { showAlert } = useAlert();
  const router = useRouter();

  const logoScale = useRef(new Animated.Value(0.82)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(logoScale, { toValue: 1, tension: 75, friction: 10, useNativeDriver: true }),
      Animated.timing(logoOpacity, { toValue: 1, duration: 420, useNativeDriver: true }),
    ]).start();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);

  const cleanPhone = (raw: string) => raw.replace(/\D/g, '');

  const handleAccess = async () => {
    const cleaned = cleanPhone(phone);
    if (cleaned.length < 7) {
      showAlert('Invalid Number', 'Please enter a valid phone number.');
      return;
    }

    setLoading(true);
    try {
      const supabase = getSupabaseClient();

      // 1. Check whitelist — try exact, then with leading 1, then without leading 1
      const variants = [cleaned];
      if (!cleaned.startsWith('1') && cleaned.length === 10) {
        variants.push('1' + cleaned);
      } else if (cleaned.startsWith('1') && cleaned.length === 11) {
        variants.push(cleaned.slice(1));
      }

      const { data: allowed, error: lookupErr } = await supabase
        .from('allowed_phones')
        .select('contact_name, phone_number')
        .in('phone_number', variants)
        .limit(1)
        .maybeSingle();

      if (lookupErr || !allowed) {
        showAlert(
          'Access Denied',
          'This number is not on the authorized list.\nContact pro@rvfox.app to request access.'
        );
        setLoading(false);
        return;
      }

      // 2. Check for an existing session tied to this phone number
      //    so we don't create a new anonymous user on every login attempt
      let session = (await supabase.auth.getSession()).data?.session ?? null;

      // If there's already a session, verify the phone number matches user_metadata
      if (session) {
        const meta = session.user?.user_metadata ?? {};
        const sessionPhone = meta.phone_number as string | undefined;
        // If the stored phone doesn't match, sign out and create a fresh session
        if (sessionPhone && sessionPhone !== allowed.phone_number) {
          await supabase.auth.signOut();
          session = null;
        }
      }

      // Only create a new anonymous session if we don't have a valid one
      if (!session) {
        const { data: anonData, error: anonErr } = await supabase.auth.signInAnonymously({
          options: {
            data: {
              display_name: allowed.contact_name,
              phone_number: allowed.phone_number,
            },
          },
        });

        if (anonErr || !anonData?.session) {
          showAlert('Sign In Error', anonErr?.message || 'Could not create session. Please try again.');
          setLoading(false);
          return;
        }
        session = anonData.session;
      }

      // Explicitly set the session so AuthProvider picks it up on all platforms
      await supabase.auth.setSession({
        access_token: session.access_token,
        refresh_token: session.refresh_token,
      });

      // Check if NDA already accepted for this specific user
      const { data: profile } = await supabase
        .from('user_profiles')
        .select('nda_accepted_at, username')
        .eq('id', session.user.id)
        .maybeSingle();

      // Persist the contact name as username if not already set
      const contactName = allowed.contact_name?.trim();
      if (contactName && !profile?.username) {
        await supabase
          .from('user_profiles')
          .upsert(
            { id: session.user.id, username: contactName },
            { onConflict: 'id' }
          );
      }

      setLoading(false);

      // Show personalised welcome if returning user with NDA done
      const firstName = contactName?.split(' ')[0] ?? '';
      const isReturning = !!profile?.nda_accepted_at;

      if (isReturning && firstName) {
        showAlert('Welcome back!', `Good to see you, ${firstName}.`);
      }

      const destination = isReturning ? '/(tabs)' : '/nda';
      router.replace(destination as any);

    } catch (e: any) {
      showAlert('Error', e?.message || 'Unexpected error. Please try again.');
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { paddingTop: insets.top }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      {/* Hero backdrop */}
      <View style={styles.heroBackdrop}>
        <Image
          source={require('@/assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.3 }}
          transition={400}
        />
        <LinearGradient
          colors={['rgba(30,46,64,0.72)', 'rgba(20,38,72,0.35)', 'rgba(20,38,72,0.28)', 'rgba(18,28,50,0.85)']}
          locations={[0, 0.2, 0.6, 1]}
          style={StyleSheet.absoluteFill}
        />
      </View>
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Logo */}
        <View style={styles.logoArea}>
          <Animated.View style={{ transform: [{ scale: logoScale }], opacity: logoOpacity }}>
            <View style={styles.logoWrap}>
              <Image
                source={require('@/assets/rvfox-icon.jpg')}
                style={styles.logoSprite}
                contentFit="cover"
              />
            </View>
          </Animated.View>
          <Text style={styles.appName}>RvFOX Pro</Text>
          <Text style={styles.appSub}>Professional Edition</Text>
          <View style={styles.taglineBadge}>
            <MaterialIcons name="verified" size={12} color={Colors.gold} />
            <Text style={styles.taglineText}>Verified & True</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <MaterialIcons name="phone-iphone" size={22} color={Colors.gold} />
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>Professional Access</Text>
              <Text style={styles.cardSub}>Enter your authorized phone number to continue</Text>
            </View>
          </View>

          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>PHONE NUMBER</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g. 15415203022"
              placeholderTextColor={Colors.textMuted}
              keyboardType="phone-pad"
              value={phone}
              onChangeText={setPhone}
              returnKeyType="go"
              contextMenuHidden={false}
              onSubmitEditing={handleAccess}
            />
            <Text style={styles.fieldHint}>Digits only · no spaces or dashes</Text>
          </View>

          <Pressable
            style={({ pressed }) => [styles.primaryBtn, pressed && { opacity: 0.85 }]}
            onPress={handleAccess}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#000" />
            ) : (
              <>
                <MaterialIcons name="verified-user" size={20} color="#000000" />
                <Text style={styles.primaryBtnText}>Access RvFOX Pro</Text>
              </>
            )}
          </Pressable>

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>Authorized professionals only</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.infoRow}>
            <MaterialIcons name="lock" size={14} color={Colors.textMuted} />
            <Text style={styles.infoText}>
              Access is restricted to the RvFOX Pro authorized partner list. Your number is verified against our secure database — no password required.
            </Text>
          </View>
        </View>

        {/* Pro note */}
        <View style={styles.proNote}>
          <MaterialIcons name="business" size={14} color={Colors.textMuted} />
          <Text style={styles.proNoteText}>
            Not on the list?{' '}
            <Text style={styles.proNoteLink}>pro@rvfox.app</Text>
            {' '}to request professional access.
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A2A3A' },
  heroBackdrop: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 0,
  },
  scroll: {
    flexGrow: 1,
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.xl,
    zIndex: 2,
  },

  logoArea: {
    alignItems: 'center',
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.lg,
    gap: Spacing.xs,
  },
  logoWrap: {
    width: 90,
    height: 90,
    borderRadius: 45,
    overflow: 'hidden',
    marginBottom: Spacing.sm,
    borderWidth: 2,
    borderColor: 'rgba(168,188,207,0.75)',
    shadowColor: 'rgba(77,166,255,0.60)',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 18,
    elevation: 8,
  },
  logoSprite: {
    width: 180,
    height: 180,
    transform: [{ translateX: 0 }, { translateY: 0 }],
  },
  appName: {
    fontSize: FontSize.h1,
    fontWeight: FontWeight.extrabold,
    color: Colors.textPrimary,
    letterSpacing: 2,
  },
  appSub: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.medium,
    color: Colors.blueBright,
    letterSpacing: 1,
  },
  taglineBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0,104,192,0.12)',
    borderWidth: 1,
    borderColor: Colors.borderBlue,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: Radius.full,
    marginTop: Spacing.xs,
  },
  taglineText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: Colors.silverBright,
    letterSpacing: 1.5,
  },

  card: {
    backgroundColor: 'rgba(27,44,64,0.70)',
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: 'rgba(168,188,207,0.28)',
    padding: Spacing.md,
    gap: Spacing.md,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
  },
  cardTitle: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: Colors.textPrimary,
  },
  cardSub: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    marginTop: 2,
    lineHeight: 18,
  },

  fieldGroup: { gap: Spacing.xs },
  fieldLabel: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
    letterSpacing: 1.2,
  },
  fieldHint: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    marginTop: 2,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: 16,
    color: Colors.textPrimary,
    fontSize: FontSize.lg,
    letterSpacing: 2,
  },

  primaryBtn: {
    backgroundColor: '#1B3C7A',
    borderRadius: Radius.full,
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: 'rgba(168,188,207,0.35)',
    shadowColor: '#1B3C7A',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.55,
    shadowRadius: 10,
    elevation: 5,
  },
  primaryBtnText: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: '#E8EEF4',
  },

  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginVertical: -Spacing.xs,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: Colors.border,
  },
  dividerText: {
    fontSize: FontSize.xs,
    color: Colors.textDim,
    letterSpacing: 0.5,
  },

  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.xs,
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: Radius.md,
    padding: Spacing.sm,
  },
  infoText: {
    flex: 1,
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    lineHeight: 18,
  },

  proNote: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.xs,
    marginTop: Spacing.lg,
    paddingHorizontal: Spacing.xs,
  },
  proNoteText: {
    flex: 1,
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    lineHeight: 18,
  },
  proNoteLink: {
    color: Colors.blueBright,
    fontWeight: FontWeight.medium,
  },
});
