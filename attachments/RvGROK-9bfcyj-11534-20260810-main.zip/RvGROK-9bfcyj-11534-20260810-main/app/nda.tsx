import {
  View, Text, StyleSheet, ScrollView, Pressable,
  ActivityIndicator, NativeSyntheticEvent, NativeScrollEvent,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { useState, useRef } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuth, useAlert, getSupabaseClient } from '@/template';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';

const NDA_VERSION = '1.0 · July 2026';

const NDA_SECTIONS = [
  {
    title: '1. Purpose',
    body: 'This Non-Disclosure Agreement ("Agreement") is entered into between you ("Authorized User") and RvFOX Pro / David Hansen ("Company") governing access to the RvFOX Pro Professional Edition platform, including all proprietary data, tools, pricing intelligence, valuation methodologies, lender integrations, and AI-powered features.',
  },
  {
    title: '2. Confidential Information',
    body: 'Confidential Information includes, without limitation: proprietary RV specification data, market pricing models, lender network terms and APR data, underwriting methodologies, valuation algorithms, confidence scoring systems, dealer inventory analytics, software architecture, unreleased features, usage data, client lists, and any business information designated as confidential by the Company.',
  },
  {
    title: '3. Obligations',
    body: 'You agree to: (a) hold all Confidential Information in strict confidence; (b) not disclose Confidential Information to any third party without prior written consent; (c) use Confidential Information solely for authorized professional workflows within the RvFOX Pro platform; (d) immediately notify the Company of any unauthorized disclosure or suspected breach; (e) not reverse-engineer, decompile, or attempt to extract underlying data models or algorithms.',
  },
  {
    title: '4. Authorized Use',
    body: 'Professional access is granted for legitimate business purposes only — including RV valuation, inventory management, loan origination support, and buyer research. Sharing login credentials, exporting bulk data, or reselling platform output without written authorization is strictly prohibited. Each seat license is issued to a named individual and is non-transferable.',
  },
  {
    title: '5. Intellectual Property',
    body: 'All content, data, algorithms, and platform components remain the exclusive property of RvFOX Pro / David Hansen. This Agreement does not convey any ownership rights. The names RvFOX Pro, RvFax, RvCal, RvTow, RvGrok, RvTrips, and "Verified & True" are proprietary marks. Unauthorized use of Company marks is prohibited.',
  },
  {
    title: '6. Data Handling',
    body: 'The Company processes user and client data in accordance with its Privacy Policy (rvfax.ai/privacy) and applicable law including CCPA. You agree not to input any personally identifiable information of third parties into the platform without proper authorization. All client reports generated through the platform must include appropriate disclaimers regarding AI-estimated data.',
  },
  {
    title: '7. NHTSA & Third-Party Data',
    body: 'Recall and complaint data sourced from NHTSA.gov is public information. Market pricing data may be sourced from third-party providers. AI-generated specifications are estimates and are clearly marked with confidence scores. Authorized Users must independently verify all data before relying on it for valuation, underwriting, or purchase decisions. Always verify recalls at nhtsa.gov.',
  },
  {
    title: '8. Term & Termination',
    body: 'This Agreement remains in effect for the duration of your Professional subscription and survives termination with respect to Confidential Information disclosed during the subscription period. The Company may terminate professional access at any time for material breach. Upon termination, you must cease all use of the platform and destroy any downloaded Confidential Information.',
  },
  {
    title: '9. Limitation of Liability',
    body: 'Platform data and AI outputs are provided "as is" without warranty of any kind. The Company is not liable for decisions made based on platform data. Total liability shall not exceed fees paid in the twelve (12) months preceding the claim. This limitation applies to the fullest extent permitted by applicable law.',
  },
  {
    title: '10. Governing Law',
    body: 'This Agreement is governed by the laws of the State of Florida, Hillsborough County, without regard to conflict of law principles. Any disputes shall be resolved by binding arbitration in Hillsborough County, Florida. For questions, contact: david@rvfax.ai',
  },
];

export default function NdaScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const { showAlert } = useAlert();

  const [hasScrolledToBottom, setHasScrolledToBottom] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const { layoutMeasurement, contentOffset, contentSize } = e.nativeEvent;
    const distanceFromBottom = contentSize.height - contentOffset.y - layoutMeasurement.height;
    if (distanceFromBottom < 80 && !hasScrolledToBottom) {
      setHasScrolledToBottom(true);
    }
  };

  const handleAccept = async () => {
    if (!hasScrolledToBottom) {
      showAlert('Please Read the Agreement', 'Scroll to the bottom to read the full NDA before accepting.');
      return;
    }
    if (!accepted) {
      showAlert('Acknowledgment Required', 'Please check the box to confirm you have read and agree to the NDA.');
      return;
    }

    setLoading(true);
    const supabase = getSupabaseClient();

    // Always get the session directly — do NOT rely on useAuth() which may be null
    // for anonymous users navigated directly to this screen
    const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
    const userId = sessionData?.session?.user?.id ?? user?.id;

    if (!userId) {
      showAlert('Session Expired', 'Please go back and enter your phone number again.');
      setLoading(false);
      router.replace('/login');
      return;
    }

    // Pull the contact_name from user metadata (set during anonymous sign-in)
    const userMeta = sessionData?.session?.user?.user_metadata ?? {};
    const contactName = (userMeta.display_name as string | undefined)?.trim() ?? '';

    // Upsert — creates the row if missing, updates it if it exists
    const upsertPayload: Record<string, unknown> = {
      id: userId,
      nda_accepted_at: new Date().toISOString(),
      nda_version: NDA_VERSION,
    };
    // Save contact name as username for first-time users
    if (contactName) upsertPayload.username = contactName;

    const { error: upsertErr } = await supabase
      .from('user_profiles')
      .upsert(upsertPayload, { onConflict: 'id' });

    if (upsertErr) {
      setLoading(false);
      showAlert('Error', `Failed to record agreement: ${upsertErr.message}`);
      return;
    }

    // Re-set the session explicitly so AuthRouter sees an authenticated user
    // when (tabs) loads — prevents bounce-back to login
    if (sessionData?.session) {
      await supabase.auth.setSession({
        access_token: sessionData.session.access_token,
        refresh_token: sessionData.session.refresh_token,
      });
    }

    setLoading(false);

    const firstName = contactName.split(' ')[0];
    if (firstName) {
      showAlert('Welcome to RvFOX Pro!', `Thanks for signing, ${firstName}. You now have full access.`);
    }

    router.replace('/(tabs)');
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Hero backdrop */}
      <View style={styles.heroBackdrop}>
        <Image
          source={require('@/assets/entegra-hero.png')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          transition={400}
        />
        <LinearGradient
          colors={['rgba(8,8,8,0.70)', 'rgba(8,8,8,0.55)', 'rgba(8,8,8,0.65)']}
          style={StyleSheet.absoluteFill}
        />
      </View>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <MaterialIcons name="policy" size={22} color={Colors.gold} />
          <View>
            <Text style={styles.headerTitle}>Non-Disclosure Agreement</Text>
            <Text style={styles.headerSub}>RvFOX Pro Professional · Version {NDA_VERSION}</Text>
          </View>
        </View>
      </View>

      {/* Scroll indicator */}
      {!hasScrolledToBottom && (
        <View style={styles.scrollHint}>
          <MaterialIcons name="keyboard-arrow-down" size={14} color={Colors.gold} />
          <Text style={styles.scrollHintText}>Scroll to read the full agreement before accepting</Text>
        </View>
      )}

      {/* NDA Content */}
      <ScrollView
        style={styles.scrollArea}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={true}
        onScroll={handleScroll}
        scrollEventThrottle={100}
      >
        {/* Preamble */}
        <View style={styles.preamble}>
          <Text style={styles.preambleTitle}>PROFESSIONAL ACCESS AGREEMENT</Text>
          <Text style={styles.preambleText}>
            By accessing RvFOX Pro Professional Edition, you agree to be bound by this Non-Disclosure and Authorized Use Agreement. This is a legally binding document. Please read it carefully before accepting.
          </Text>
          <Text style={styles.preambleText}>
            <Text style={styles.highlight}>Effective upon acceptance.</Text> This agreement applies to all Professional tier users including dealers, appraisers, lenders, and brokers.
          </Text>
        </View>

        {/* Sections */}
        {NDA_SECTIONS.map((section, i) => (
          <View key={i} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Text style={styles.sectionBody}>{section.body}</Text>
          </View>
        ))}

        {/* End marker */}
        <View style={styles.endMarker}>
          <MaterialIcons name="check-circle-outline" size={24} color={Colors.green} />
          <Text style={styles.endMarkerText}>End of Agreement</Text>
          <Text style={styles.endMarkerSub}>
            Questions? Contact david@rvfax.ai before accepting.
          </Text>
        </View>
      </ScrollView>

      {/* Accept Footer */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + Spacing.md }]}>
        {/* Checkbox */}
        <Pressable
          style={styles.checkboxRow}
          onPress={() => hasScrolledToBottom && setAccepted(!accepted)}
        >
          <View style={[
            styles.checkbox,
            accepted && styles.checkboxChecked,
            !hasScrolledToBottom && styles.checkboxDisabled,
          ]}>
            {accepted && <MaterialIcons name="check" size={14} color="#000000" />}
          </View>
          <Text style={[styles.checkboxLabel, !hasScrolledToBottom && { color: Colors.textDim }]}>
            I have read the full agreement and I agree to the Non-Disclosure Agreement and Terms of Professional Access.
          </Text>
        </Pressable>

        {/* Date/User line */}
        <Text style={styles.userLine}>
          {user?.email} · {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
        </Text>

        {/* Accept Button */}
        <Pressable
          style={({ pressed }) => [
            styles.acceptBtn,
            (!hasScrolledToBottom || !accepted) && styles.acceptBtnDisabled,
            pressed && hasScrolledToBottom && accepted && { opacity: 0.85 },
          ]}
          onPress={handleAccept}
          disabled={loading}
        >
          {loading
            ? <ActivityIndicator color="#000" />
            : <>
                <MaterialIcons name="verified" size={20} color={(!hasScrolledToBottom || !accepted) ? Colors.textMuted : '#000000'} />
                <Text style={[styles.acceptBtnText, (!hasScrolledToBottom || !accepted) && { color: Colors.textMuted }]}>
                  Accept & Access RvFOX Pro
                </Text>
              </>
          }
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.black },
  heroBackdrop: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 0,
  },

  header: {
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.sm,
    paddingBottom: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    zIndex: 2,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  headerTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: Colors.textPrimary,
  },
  headerSub: {
    fontSize: FontSize.xs,
    color: Colors.textSecondary,
    marginTop: 1,
  },

  scrollHint: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    paddingVertical: 8,
    backgroundColor: 'rgba(0,104,192,0.08)',
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderBlue,
    zIndex: 2,
  },
  scrollHintText: {
    fontSize: FontSize.xs,
    color: Colors.blueBright,
    fontWeight: FontWeight.medium,
  },

  scrollArea: { flex: 1, zIndex: 2 },
  scrollContent: {
    padding: Spacing.md,
    gap: Spacing.md,
    paddingBottom: Spacing.xl,
  },

  preamble: {
    backgroundColor: 'rgba(26,111,212,0.08)',
    borderWidth: 1,
    borderColor: Colors.borderBlue,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    gap: Spacing.sm,
  },
  preambleTitle: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.extrabold,
    color: Colors.blueBright,
    letterSpacing: 1.5,
    textAlign: 'center',
  },
  preambleText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    lineHeight: 20,
  },
  highlight: {
    color: Colors.gold,
    fontWeight: FontWeight.semibold,
  },

  section: {
    gap: Spacing.xs,
    paddingBottom: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  sectionTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: Colors.blueBright,
    marginBottom: 2,
  },
  sectionBody: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    lineHeight: 21,
  },

  endMarker: {
    alignItems: 'center',
    paddingVertical: Spacing.xl,
    gap: Spacing.sm,
  },
  endMarkerText: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: Colors.green,
  },
  endMarkerSub: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
  },

  // Footer
  footer: {
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    backgroundColor: 'rgba(0,0,0,0.75)',
    gap: Spacing.sm,
    zIndex: 2,
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: Colors.textMuted,
    backgroundColor: 'transparent',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
    flexShrink: 0,
  },
  checkboxChecked: {
    backgroundColor: Colors.blueBright,
    borderColor: Colors.blueBright,
  },
  checkboxDisabled: {
    borderColor: Colors.textDim,
    opacity: 0.4,
  },
  checkboxLabel: {
    flex: 1,
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    lineHeight: 19,
  },
  userLine: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  acceptBtn: {
    backgroundColor: Colors.blueBright,
    borderRadius: Radius.full,
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
  },
  acceptBtnDisabled: {
    backgroundColor: Colors.bgCardAlt,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  acceptBtnText: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: '#000000',
  },
});
