
import {
  View, Text, StyleSheet, Pressable, ScrollView, RefreshControl,
  Modal, FlatList, TouchableOpacity, ActivityIndicator, Alert, Linking, TextInput, KeyboardAvoidingView, Platform, Dimensions,
} from 'react-native';
import React, { useState, useCallback, useEffect, useRef } from 'react';
import Animated, { useSharedValue, useAnimatedStyle, withSpring, withTiming, withRepeat } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import { RV_DATA, YEARS, CLASSIC_BRANDS } from '@/constants/rvData';
// MAKES is derived live so rvDataExtra brands (Brinkley, Coach House, etc.) are included
const MAKES = Object.keys(RV_DATA).sort();
// Computed live so every rvDataExtra addition is counted automatically
const TOTAL_MODELS = Object.values(RV_DATA).reduce(
  (total, models) => total + Object.keys(models).length, 0
);

// ─── RV TYPE COLOUR PALETTE — unique visual identity per class ────────────────
const TYPE_PALETTE: Record<string, { gradient: readonly [string, string, string]; accent: string }> = {
  'Class A Gas':    { gradient: ['#0A1628', '#0F2A4A', '#133A6A'], accent: '#60A5FA' },
  'Class A Diesel': { gradient: ['#12103A', '#1E1B5A', '#2D28A0'], accent: '#A78BFA' },
  'Class B+':       { gradient: ['#0A1F40', '#173560', '#1D4ED8'], accent: '#7EC8E3' },
  'Class B':        { gradient: ['#022920', '#064E3B', '#085C47'], accent: '#34D399' },
  'Class C':        { gradient: ['#0F1B40', '#1C2E6A', '#2840A6'], accent: '#93C5FD' },
  'Super C':        { gradient: ['#2D0707', '#450A0A', '#6B1010'], accent: '#FCA5A5' },
  'Fifth Wheel':    { gradient: ['#0F1E38', '#1A2C50', '#1E3563'], accent: '#A8BCCF' },
  'Travel Trailer': { gradient: ['#0A180F', '#122B1A', '#164228'], accent: '#86EFAC' },
  'Toy Hauler':     { gradient: ['#1F1200', '#3B2000', '#5A3200'], accent: '#FCD34D' },
  'Truck Camper':   { gradient: ['#0F1115', '#1C1F26', '#222A35'], accent: '#9CA3AF' },
};
function getTypeColors(rvType: string) {
  for (const [key, val] of Object.entries(TYPE_PALETTE)) {
    if (rvType === key || rvType.startsWith(key)) return val;
  }
  if (rvType.includes('Super C'))   return TYPE_PALETTE['Super C'];
  if (rvType.includes('Diesel'))    return TYPE_PALETTE['Class A Diesel'];
  if (rvType.includes('Class B+'))  return TYPE_PALETTE['Class B+'];
  if (rvType.includes('Class B'))   return TYPE_PALETTE['Class B'];
  if (rvType.includes('Class C'))   return TYPE_PALETTE['Class C'];
  if (rvType.includes('Fifth') || rvType.includes('5th')) return TYPE_PALETTE['Fifth Wheel'];
  if (rvType.includes('Travel'))    return TYPE_PALETTE['Travel Trailer'];
  if (rvType.includes('Toy'))       return TYPE_PALETTE['Toy Hauler'];
  if (rvType.includes('Truck'))     return TYPE_PALETTE['Truck Camper'];
  return TYPE_PALETTE['Class A Gas'];
}
// ─── TYPE-SPECIFIC RV IMAGES ─────────────────────────────────────────────────
const TYPE_IMAGES = {
  classa:        require('@/assets/rv-classa.jpg'),
  classb:        require('@/assets/rv-classb.jpg'),
  classc:        require('@/assets/rv-classc.jpg'),
  traveltrailer: require('@/assets/rv-traveltrailer.jpg'),
  fifthwheel:    require('@/assets/rv-fifthwheel.jpg'),
};
function getTypeImage(rvType: string) {
  if (rvType === 'Class B' || rvType === 'Class B+') return TYPE_IMAGES.classb;
  if (rvType.includes('Class C')) return TYPE_IMAGES.classc;
  if (rvType.includes('Travel Trailer') || rvType.includes('Truck Camper')) return TYPE_IMAGES.traveltrailer;
  if (rvType.includes('Fifth Wheel') || rvType.includes('Toy Hauler')) return TYPE_IMAGES.fifthwheel;
  return TYPE_IMAGES.classa;
}
import SearchWizard from '@/components/feature/SearchWizard';
import type { RVSpec } from '@/constants/rvData';
import { computeRating } from '@/constants/ratingData';
import { generateAndShareRVReport } from '@/services/pdfService';
import { useAuth, getSupabaseClient } from '@/template';
import { CameraView, useCameraPermissions } from 'expo-camera';

// Safe camera hook — returns null stubs on web to prevent crash
function useSafeCameraPermissions() {
  if (Platform.OS === 'web') {
    return [null, async () => ({ granted: false })] as const;
  }
  // eslint-disable-next-line react-hooks/rules-of-hooks
  return useCameraPermissions();
}

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface RVResult {
  year: string;
  make: string;
  model: string;
  floorplan: string;
  data: RVSpec;
  saved: boolean;
}

interface RecentSearch {
  id: string;
  label: string;
  sub: string;
  year: string;
  make: string;
  model: string;
  floorplan: string;
}

// ─── VIN DECODE RESULT TYPE ─────────────────────────────────────────────────────

interface VinDecodeResult {
  vin: string;
  valid: boolean;
  errorText: string;
  year: string;
  make: string;
  model: string;
  trim: string;
  series: string;
  vehicleType: string;
  bodyClass: string;
  engineDisplacement: string;
  engineCylinders: string;
  engineHP: string;
  fuelType: string;
  driveType: string;
  transmissionStyle: string;
  transmissionSpeeds: string;
  gvwr: string;
  manufacturer: string;
  plantCountry: string;
  plantCity: string;
  plantState: string;
  abs: string;
  airBags: string;
}

// ─── VIN DECODER MODAL ───────────────────────────────────────────────────────

interface NhtsaRecall {
  component: string;
  summary: string;
  consequence: string;
  remedy: string;
  date: string;
  campaignNumber: string;
}

function VinDecoderModal({
  visible, onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [vin, setVin] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VinDecodeResult | null>(null);
  const [error, setError] = useState('');
  const [recalls, setRecalls] = useState<NhtsaRecall[]>([]);
  const [recallCount, setRecallCount] = useState<number | null>(null);
  const [recallLoading, setRecallLoading] = useState(false);
  const [expandedRecall, setExpandedRecall] = useState<number | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [cameraPermission, requestCameraPermission] = useSafeCameraPermissions();

  const clean = vin.trim().toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, '');
  const isReady = clean.length === 17;

  const handleDecode = useCallback(async () => {
    setLoading(true);
    setError('');
    setResult(null);
    setRecalls([]);
    setRecallCount(null);
    setExpandedRecall(null);
    try {
      const supabase = getSupabaseClient();
      const { data, error: fnErr } = await supabase.functions.invoke('vin-decoder', {
        body: { vin: clean },
      });
      if (fnErr) {
        setError('Decode failed. Check the VIN and try again.');
        return;
      }
      if (data?.error) {
        setError(data.error);
        return;
      }
      const decoded = data as VinDecodeResult;
      setResult(decoded);

      if (decoded.make && decoded.model && decoded.year) {
        setRecallLoading(true);
        try {
          const { data: nhtsaData } = await supabase.functions.invoke('nhtsa-lookup', {
            body: { make: decoded.make, model: decoded.model, year: decoded.year },
          });
          if (nhtsaData) {
            setRecallCount(nhtsaData.recallCount ?? 0);
            setRecalls(nhtsaData.recalls ?? []);
          }
        } catch {
          setRecallCount(0);
        } finally {
          setRecallLoading(false);
        }
      }
    } catch {
      setError('Could not reach the VIN service. Check your connection.');
    } finally {
      setLoading(false);
    }
  }, [clean]);

  const handleClose = () => {
    setVin('');
    setResult(null);
    setError('');
    setRecalls([]);
    setRecallCount(null);
    setExpandedRecall(null);
    setShowScanner(false);
    onClose();
  };

  const isRV = result && (
    result.bodyClass?.toLowerCase().includes('motorhome') ||
    result.bodyClass?.toLowerCase().includes('motor home') ||
    result.bodyClass?.toLowerCase().includes('coach') ||
    result.vehicleType?.toLowerCase().includes('incomplete') ||
    (result as any).busType?.toLowerCase().includes('motorhome')
  );

  function formatRecallDate(raw: string): string {
    if (!raw) return '';
    const match = raw.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (match) return `${match[1].padStart(2,'0')}/${match[2].padStart(2,'0')}/${match[3]}`;
    const d = new Date(raw);
    if (!isNaN(d.getTime())) {
      return d.toLocaleDateString('en-AU', { day: '2-digit', month: '2-digit', year: 'numeric' });
    }
    return raw;
  }

  const assemblyParts = [result?.plantCity, result?.plantState, result?.plantCountry]
    .filter(Boolean).join(', ');

  const engineLabel = [result?.engineDisplacement ? result.engineDisplacement + 'L' : '',
    result?.engineCylinders ? result.engineCylinders + '-cyl' : '',
    result?.engineHP ? result.engineHP + 'HP' : ''].filter(Boolean).join(' ');

  const { width: screenW } = Dimensions.get('window');

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.8)' }}
      >
        <View style={vinModal.sheet}>
          <View style={vinModal.handle} />

          <View style={vinModal.header}>
            <Pressable onPress={handleClose} style={vinModal.closeBtn} hitSlop={8}>
              <MaterialIcons name="close" size={20} color={Colors.textSecondary} />
            </Pressable>
            <View style={vinModal.headerCenter}>
              <MaterialIcons name="qr-code-scanner" size={16} color={Colors.blueBright} />
              <Text style={vinModal.title}>VIN Decoder</Text>
            </View>
            <View style={{ width: 36 }} />
          </View>

          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

            <View style={vinModal.inputSection}>
              <View style={vinModal.inputRow}>
                <TextInput
                  style={[vinModal.input, isReady && { borderColor: Colors.blueBright }]}
                  value={vin}
                  onChangeText={t => setVin(t.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/gi, '').slice(0, 17))}
                  placeholder="Enter 17-character VIN"
                  placeholderTextColor={Colors.textMuted}
                  autoCorrect={false}
                  maxLength={17}
                />
                <View style={vinModal.charCount}>
                  <Text style={[vinModal.charCountText, isReady && { color: Colors.green }]}>
                    {clean.length}/17
                  </Text>
                </View>
              </View>

              <View style={vinModal.actionRow}>
                <Pressable
                  style={({ pressed }) => [
                    vinModal.decodeBtn,
                    { flex: 1 },
                    !isReady && vinModal.decodeBtnDisabled,
                    pressed && isReady && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                  ]}
                  onPress={handleDecode}
                  disabled={!isReady || loading}
                >
                  {loading ? (
                    <ActivityIndicator color={Colors.silverBright} size="small" />
                  ) : (
                    <>
                      <MaterialIcons name="search" size={18} color={!isReady ? Colors.textMuted : Colors.silverBright} />
                      <Text style={[vinModal.decodeBtnText, !isReady && { color: Colors.textMuted }]}>
                        Decode VIN
                      </Text>
                    </>
                  )}
                </Pressable>

                <Pressable
                  style={({ pressed }) => [vinModal.scanBtn, pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] }]}
                  onPress={async () => {
                    if (Platform.OS === 'web') {
                      Alert.alert('Not Available', 'Camera scanning is only available on iOS and Android.');
                      return;
                    }
                    if (!cameraPermission?.granted) {
                      const res = await requestCameraPermission();
                      if (!res.granted) {
                        Alert.alert('Camera Access Required', 'Please allow camera access in Settings to scan VIN barcodes.');
                        return;
                      }
                    }
                    setShowScanner(true);
                  }}
                >
                  <MaterialIcons name="qr-code-scanner" size={20} color={Colors.blueBright} />
                  <Text style={vinModal.scanBtnText}>Scan</Text>
                </Pressable>
              </View>

              <View style={vinModal.scanHintRow}>
                <MaterialIcons name="info-outline" size={11} color={Colors.textDim} />
                <Text style={vinModal.scanHintText}>
                  Tap Scan to read the VIN barcode from the dashboard, door jamb, or registration
                </Text>
              </View>
            </View>

            {!!error && (
              <View style={vinModal.errorCard}>
                <MaterialIcons name="error-outline" size={16} color={Colors.red} />
                <Text style={vinModal.errorText}>{error}</Text>
              </View>
            )}

            {result && (
              <View style={vinModal.results}>
                <View style={vinModal.identityCard}>
                  <View style={vinModal.identityTopRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={vinModal.identityYear}>{result.year}</Text>
                      <Text style={vinModal.identityName}>{result.make} {result.model}</Text>
                      {(result.trim || result.series) ? (
                        <Text style={vinModal.identityTrim}>{result.trim || result.series}</Text>
                      ) : null}
                    </View>
                    {recallLoading ? (
                      <View style={vinModal.recallLoadingBadge}>
                        <ActivityIndicator size="small" color={Colors.blueBright} style={{ transform: [{ scale: 0.7 }] }} />
                      </View>
                    ) : recallCount !== null ? (
                      recallCount > 0 ? (
                        <View style={vinModal.recallCountBadge}>
                          <MaterialIcons name="warning" size={13} color="#000" />
                          <Text style={vinModal.recallCountText}>{recallCount} Recall{recallCount > 1 ? 's' : ''}</Text>
                        </View>
                      ) : (
                        <View style={vinModal.noRecallBadge}>
                          <MaterialIcons name="verified" size={13} color={Colors.green} />
                          <Text style={vinModal.noRecallText}>No Recalls</Text>
                        </View>
                      )
                    ) : null}
                  </View>

                  <View style={vinModal.identityBadges}>
                    {result.bodyClass ? (
                      <View style={vinModal.badge}>
                        <Text style={vinModal.badgeText}>{result.bodyClass}</Text>
                      </View>
                    ) : null}
                    {isRV ? (
                      <View style={[vinModal.badge, { backgroundColor: 'rgba(74,222,128,0.15)', borderColor: 'rgba(74,222,128,0.4)' }]}>
                        <MaterialIcons name="verified" size={11} color={Colors.green} />
                        <Text style={[vinModal.badgeText, { color: Colors.green }]}>RV Verified</Text>
                      </View>
                    ) : null}
                  </View>

                  <View style={vinModal.vinChip}>
                    <Text style={vinModal.vinChipLabel}>VIN</Text>
                    <Text style={vinModal.vinChipText}>{result.vin}</Text>
                  </View>
                </View>

                <View style={vinModal.sectionBlock}>
                  <Text style={vinModal.sectionBlockTitle}>VEHICLE DETAILS</Text>
                  <View style={vinModal.detailGrid}>
                    {result.bodyClass ? (
                      <View style={vinModal.detailCell}>
                        <Text style={vinModal.detailCellLabel}>Body Class</Text>
                        <Text style={vinModal.detailCellValue}>{result.bodyClass}</Text>
                      </View>
                    ) : null}
                    {result.vehicleType ? (
                      <View style={vinModal.detailCell}>
                        <Text style={vinModal.detailCellLabel}>Vehicle Type</Text>
                        <Text style={vinModal.detailCellValue}>{result.vehicleType}</Text>
                      </View>
                    ) : null}
                    {engineLabel ? (
                      <View style={vinModal.detailCell}>
                        <Text style={vinModal.detailCellLabel}>Engine</Text>
                        <Text style={vinModal.detailCellValue}>{engineLabel}</Text>
                      </View>
                    ) : null}
                    {result.fuelType ? (
                      <View style={vinModal.detailCell}>
                        <Text style={vinModal.detailCellLabel}>Fuel Type</Text>
                        <Text style={[vinModal.detailCellValue, { color: Colors.green }]}>{result.fuelType}</Text>
                      </View>
                    ) : null}
                    {result.gvwr ? (
                      <View style={vinModal.detailCell}>
                        <Text style={vinModal.detailCellLabel}>GVWR</Text>
                        <Text style={vinModal.detailCellValue}>{result.gvwr}</Text>
                      </View>
                    ) : null}
                    {result.manufacturer ? (
                      <View style={vinModal.detailCell}>
                        <Text style={vinModal.detailCellLabel}>Manufacturer</Text>
                        <Text style={vinModal.detailCellValue}>{result.manufacturer}</Text>
                      </View>
                    ) : null}
                    {result.driveType ? (
                      <View style={vinModal.detailCell}>
                        <Text style={vinModal.detailCellLabel}>Drive Type</Text>
                        <Text style={vinModal.detailCellValue}>{result.driveType}</Text>
                      </View>
                    ) : null}
                    {result.transmissionStyle ? (
                      <View style={vinModal.detailCell}>
                        <Text style={vinModal.detailCellLabel}>Transmission</Text>
                        <Text style={vinModal.detailCellValue}>
                          {[result.transmissionStyle, result.transmissionSpeeds ? result.transmissionSpeeds + '-spd' : ''].filter(Boolean).join(' ')}
                        </Text>
                      </View>
                    ) : null}
                  </View>
                </View>

                {assemblyParts ? (
                  <View style={vinModal.assemblyCard}>
                    <Text style={vinModal.detailCellLabel}>Assembly</Text>
                    <Text style={vinModal.assemblyValue}>{assemblyParts.toUpperCase()}</Text>
                  </View>
                ) : null}

                {recallCount !== null && recallCount > 0 && recalls.length > 0 ? (
                  <View style={vinModal.recallSection}>
                    <View style={vinModal.recallSectionHeader}>
                      <MaterialIcons name="warning" size={14} color={Colors.orange} />
                      <Text style={vinModal.recallSectionTitle}>
                        {recallCount} NHTSA RECALL{recallCount > 1 ? 'S' : ''} ON RECORD
                      </Text>
                    </View>
                    {recalls.map((r, i) => (
                      <Pressable
                        key={i}
                        style={({ pressed }) => [vinModal.recallItem, pressed && { opacity: 0.8 }]}
                        onPress={() => setExpandedRecall(expandedRecall === i ? null : i)}
                      >
                        <View style={vinModal.recallItemMain}>
                          <View style={vinModal.recallItemLeft}>
                            <Text style={vinModal.recallComponent} numberOfLines={expandedRecall === i ? 0 : 1}>
                              {r.component}
                            </Text>
                            <Text style={vinModal.recallDate}>{formatRecallDate(r.date)}</Text>
                            {expandedRecall === i && r.summary ? (
                              <Text style={vinModal.recallSummary}>{r.summary}</Text>
                            ) : null}
                            {expandedRecall === i && r.remedy ? (
                              <View style={vinModal.recallRemedyRow}>
                                <MaterialIcons name="build" size={11} color={Colors.green} />
                                <Text style={vinModal.recallRemedy}>{r.remedy}</Text>
                              </View>
                            ) : null}
                          </View>
                          <MaterialIcons
                            name={expandedRecall === i ? 'keyboard-arrow-up' : 'keyboard-arrow-right'}
                            size={18}
                            color={Colors.orange}
                          />
                        </View>
                      </Pressable>
                    ))}
                  </View>
                ) : recallCount === 0 ? (
                  <View style={vinModal.noRecallSection}>
                    <MaterialIcons name="verified" size={16} color={Colors.green} />
                    <Text style={vinModal.noRecallSectionText}>No NHTSA recalls on record</Text>
                  </View>
                ) : null}

                <Pressable
                  style={({ pressed }) => [vinModal.nhtsaBtn, pressed && { opacity: 0.75 }]}
                  onPress={() => Linking.openURL(`https://www.nhtsa.gov/vehicle/${result.vin}`)}
                >
                  <MaterialIcons name="open-in-new" size={14} color={Colors.blueBright} />
                  <Text style={vinModal.nhtsaBtnText}>Verify this VIN on NHTSA.gov</Text>
                </Pressable>

                <Pressable
                  style={({ pressed }) => [vinModal.lookupBtn, pressed && { opacity: 0.88, transform: [{ scale: 0.98 }] }]}
                  onPress={() => { handleClose(); }}
                >
                  <MaterialIcons name="description" size={18} color={Colors.silverBright} />
                  <View style={{ flex: 1 }}>
                    <Text style={vinModal.lookupBtnTitle}>Look Up This RV</Text>
                    <Text style={vinModal.lookupBtnSub}>{result.year} {result.make} {result.model} · Full Report</Text>
                  </View>
                  <MaterialIcons name="arrow-forward" size={18} color={Colors.silverBright} />
                </Pressable>

                <View style={vinModal.disclaimer}>
                  <MaterialIcons name="info-outline" size={11} color={Colors.textMuted} />
                  <Text style={vinModal.disclaimerText}>
                    Data sourced from NHTSA vPIC public database. Not all fields are available for all vehicles.
                  </Text>
                </View>
              </View>
            )}

            <View style={{ height: 32 }} />
          </ScrollView>
        </View>
      </KeyboardAvoidingView>

      {showScanner && (
        <Modal visible={showScanner} transparent={false} animationType="slide" onRequestClose={() => setShowScanner(false)}>
          <View style={vinModal.scannerContainer}>
            <CameraView
              style={StyleSheet.absoluteFill}
              facing="back"
              barcodeScannerSettings={{ barcodeTypes: ['code39', 'code128', 'datamatrix', 'pdf417', 'qr'] }}
              onBarcodeScanned={({ data }) => {
                const cleaned = data.replace(/[^A-HJ-NPR-Z0-9]/gi, '').toUpperCase().slice(0, 17);
                if (cleaned.length >= 10) {
                  setVin(cleaned);
                  setShowScanner(false);
                }
              }}
            />
            <View style={StyleSheet.absoluteFill} pointerEvents="none">
              <View style={{ flex: 1.2, backgroundColor: 'rgba(0,0,0,0.72)' }} />
              <View style={{ flexDirection: 'row', height: 90 }}>
                <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.72)' }} />
                <View style={{ width: screenW * 0.82, position: 'relative' }}>
                  <View style={[vinModal.scanCorner, { top: 0, left: 0, borderRightWidth: 0, borderBottomWidth: 0 }]} />
                  <View style={[vinModal.scanCorner, { top: 0, right: 0, borderLeftWidth: 0, borderBottomWidth: 0 }]} />
                  <View style={[vinModal.scanCorner, { bottom: 0, left: 0, borderRightWidth: 0, borderTopWidth: 0 }]} />
                  <View style={[vinModal.scanCorner, { bottom: 0, right: 0, borderLeftWidth: 0, borderTopWidth: 0 }]} />
                </View>
                <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.72)' }} />
              </View>
              <View style={{ flex: 2, backgroundColor: 'rgba(0,0,0,0.72)' }} />
            </View>

            <View style={vinModal.scannerBottomUi}>
              <Text style={vinModal.scannerHint}>Align the VIN barcode within the frame</Text>
              <Text style={vinModal.scannerHint2}>Usually on the dashboard, door jamb, or title document</Text>
              <Pressable
                style={({ pressed }) => [vinModal.scannerCloseBtn, pressed && { opacity: 0.8 }]}
                onPress={() => setShowScanner(false)}
              >
                <MaterialIcons name="close" size={18} color="#000" />
                <Text style={vinModal.scannerCloseBtnText}>Cancel Scan</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      )}
    </Modal>
  );
}

// ─── SESSION CACHES ───────────────────────────────────────────────────────────
// Keyed by `make|model|year` — persists for the JS bundle session lifetime
const nhtsaRecallCache = new Map<string, number>();

interface CachedMV { tradeIn: number; retailHigh: number; }
const mvCache = new Map<string, CachedMV>();

// ─── DROPDOWN MODAL ───────────────────────────────────────────────────────────

function DropdownModal({
  visible, title, items, selected, onSelect, onClose, allowFreeText = false,
}: {
  visible: boolean;
  title: string;
  items: string[];
  selected: string;
  onSelect: (val: string) => void;
  onClose: () => void;
  allowFreeText?: boolean;
}) {
  const [query, setQuery] = useState('');

  const sheetScale   = useSharedValue(0.95);
  const sheetOpacity = useSharedValue(0);

  const animatedSheetStyle = useAnimatedStyle(() => ({
    transform: [{ scale: sheetScale.value }],
    opacity: sheetOpacity.value,
  }));

  useEffect(() => {
    if (visible) {
      setQuery('');
      sheetScale.value   = 0.95;
      sheetOpacity.value = 0;
      sheetScale.value   = withSpring(1, { damping: 22, stiffness: 320 });
      sheetOpacity.value = withTiming(1, { duration: 200 });
    }
  }, [visible, sheetOpacity, sheetScale]);

  const filtered = query.trim()
    ? items.filter(i => i.toLowerCase().includes(query.toLowerCase()))
    : items;

  const showManualEntry = allowFreeText && query.trim().length > 0 &&
    !items.some(i => i.toLowerCase() === query.trim().toLowerCase());

  const handleConfirmManual = () => {
    const val = query.trim();
    if (val) { onSelect(val); onClose(); setQuery(''); }
  };

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.75)' }}
      >
        <Animated.View style={[styles.modalSheet, animatedSheetStyle]}>
          <View style={styles.modalHandle} />
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>{title}</Text>
            <Pressable onPress={onClose} hitSlop={8}>
              <MaterialIcons name="close" size={22} color={Colors.textSecondary} />
            </Pressable>
          </View>

          <View style={styles.modalSearchRow}>
            <MaterialIcons name="search" size={16} color={Colors.textMuted} />
            <TextInput
              style={styles.modalSearchInput}
              placeholder={allowFreeText ? 'Search or type to enter manually...' : 'Search...'}
              placeholderTextColor={Colors.textMuted}
              value={query}
              onChangeText={setQuery}
              returnKeyType={allowFreeText ? 'done' : 'search'}
              onSubmitEditing={allowFreeText ? handleConfirmManual : undefined}
              autoCorrect={false}
            />
            {query.length > 0 && (
              <Pressable onPress={() => setQuery('')} hitSlop={8}>
                <MaterialIcons name="close" size={14} color={Colors.textMuted} />
              </Pressable>
            )}
          </View>

          {showManualEntry && (
            <Pressable
              style={({ pressed }) => [styles.modalManualEntry, pressed && { opacity: 0.8 }]}
              onPress={handleConfirmManual}
            >
              <MaterialIcons name="edit" size={15} color={Colors.blueBright} />
              <Text style={styles.modalManualEntryText}>
                Use <Text style={{ color: Colors.blueBright, fontWeight: FontWeight.bold }}>"{query.trim()}"</Text>
              </Text>
              <MaterialIcons name="arrow-forward" size={14} color={Colors.blueBright} />
            </Pressable>
          )}

          <FlatList
            data={filtered}
            keyExtractor={i => i}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            ListEmptyComponent={
              <View style={styles.modalEmpty}>
                <MaterialIcons name="search-off" size={24} color={Colors.textDim} />
                <Text style={styles.modalEmptyText}>
                  {allowFreeText ? 'No matches — type above to enter manually' : 'No matches found'}
                </Text>
              </View>
            }
            renderItem={({ item }) => (
              <TouchableOpacity
                style={[styles.modalItem, item === selected && styles.modalItemSelected]}
                onPress={() => { onSelect(item); onClose(); setQuery(''); }}
                activeOpacity={0.7}
              >
                <Text style={[styles.modalItemText, item === selected && styles.modalItemTextSelected]}>
                  {item}
                </Text>
                {item === selected && (
                  <MaterialIcons name="check" size={18} color={Colors.blueBright} />
                )}
              </TouchableOpacity>
            )}
          />
        </Animated.View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── RV RESULT CARD ───────────────────────────────────────────────────────────

function RVCard({
  result, onToggleSave, onGeneratePDF, onViewDetails, onOpenCal, onOpenGrok,
  featured = false,
}: {
  result: RVResult;
  onToggleSave: () => void;
  onGeneratePDF: () => void;
  onViewDetails: () => void;
  onOpenCal: (price: number) => void;
  onOpenGrok: () => void;
  featured?: boolean;
}) {
  const { data } = result;

  // ── NHTSA recall count ─────────────────────────────────────────────────────
  const [liveRecalls, setLiveRecalls] = useState<number | null>(null);
  const [recallLoading, setRecallLoading] = useState(true);

  // ── Market value pills ─────────────────────────────────────────────────────
  const [mv, setMv] = useState<CachedMV | null>(null);
  const [mvLoading, setMvLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const cacheKey = `${result.make}|${result.model}|${result.year}`;

    // ── Market Value (parallel, non-blocking) ─────────────────────────────
    if (mvCache.has(cacheKey)) {
      setMv(mvCache.get(cacheKey)!);
      setMvLoading(false);
    } else {
      (async () => {
        try {
          const supabase = getSupabaseClient();
          const { data: mvData, error: mvErr } = await supabase.functions.invoke('rv-market-value', {
            body: { year: result.year, make: result.make, model: result.model, floorplan: result.floorplan || undefined },
          });
          if (!cancelled && !mvErr && mvData?.tradeIn && mvData?.retailHigh) {
            const cached: CachedMV = { tradeIn: mvData.tradeIn, retailHigh: mvData.retailHigh };
            mvCache.set(cacheKey, cached);
            setMv(cached);
          }
        } catch { /* non-fatal */ } finally {
          if (!cancelled) setMvLoading(false);
        }
      })();
    }

    // ── NHTSA Recalls ──────────────────────────────────────────────────────
    if (nhtsaRecallCache.has(cacheKey)) {
      setLiveRecalls(nhtsaRecallCache.get(cacheKey)!);
      setRecallLoading(false);
    } else {
      (async () => {
        try {
          const supabase = getSupabaseClient();
          const { data: nhtsaData, error } = await supabase.functions.invoke('nhtsa-lookup', {
            body: { make: result.make, model: result.model, year: result.year },
          });
          if (!cancelled && !error && nhtsaData) {
            const count = nhtsaData.recallCount ?? 0;
            nhtsaRecallCache.set(cacheKey, count);
            setLiveRecalls(count);
          }
        } catch { /* fall back to static */ } finally {
          if (!cancelled) setRecallLoading(false);
        }
      })();
    }

    return () => { cancelled = true; };
  }, [result.make, result.model, result.year]);

  const displayRecalls = liveRecalls !== null ? liveRecalls : data.recalls;
  const hasRecall = displayRecalls > 0;

  return (
    <View style={styles.rvCard}>
      <Pressable onPress={onViewDetails}>
        <View style={[styles.rvCardImageWrapper, featured && styles.rvCardImageWrapperFeatured]}>
          <Image
            source={getTypeImage(data.type)}
            style={StyleSheet.absoluteFill}
            contentFit="cover"
            contentPosition={{ x: 0.5, y: 0.5 }}
            transition={200}
          />
          <LinearGradient
            colors={['rgba(0,0,0,0.06)', 'rgba(0,0,0,0.70)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <View style={styles.rvCardTypeBadge}>
            <Text style={styles.rvCardTypeText}>{data.type}</Text>
          </View>
          {recallLoading ? (
            <View style={styles.noRecallBadge}>
              <ActivityIndicator size="small" color={Colors.blueBright} style={{ transform: [{ scale: 0.6 }] }} />
              <Text style={styles.noRecallBadgeText}>Loading...</Text>
            </View>
          ) : hasRecall ? (
            <View style={styles.recallBadge}>
              <MaterialIcons name="warning" size={11} color="#000" />
              <Text style={styles.recallBadgeText}>{displayRecalls} Recall{displayRecalls > 1 ? 's' : ''}</Text>
            </View>
          ) : (
            <View style={styles.noRecallBadge}>
              <MaterialIcons name="verified" size={11} color={Colors.green} />
              <Text style={[styles.noRecallBadgeText, { color: Colors.green }]}>No Recalls</Text>
            </View>
          )}
          <View style={styles.tapHint}>
            <MaterialIcons name="info" size={10} color="rgba(255,255,255,0.6)" />
            <Text style={styles.tapHintText}>Tap for full details</Text>
          </View>
          {featured && (
            <View style={styles.featuredBadge}>
              <MaterialIcons name="star" size={10} color="#000" />
              <Text style={styles.featuredBadgeText}>TOP RESULT</Text>
            </View>
          )}
        </View>
      </Pressable>

      <View style={styles.rvCardBody}>
        <Pressable onPress={onViewDetails}>
          <View style={styles.rvCardTitleRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rvCardYear}>{result.year}</Text>
              <Text style={styles.rvCardName} numberOfLines={1}>
                {result.make} {result.model}
              </Text>
              {result.floorplan ? (
                <Text style={styles.rvCardFloorplan}>Floorplan: {result.floorplan}</Text>
              ) : null}
            </View>
            <Pressable onPress={onToggleSave} style={styles.heartBtn} hitSlop={8}>
              <MaterialIcons
                name={result.saved ? 'favorite' : 'favorite-border'}
                size={22}
                color={result.saved ? Colors.red : Colors.textMuted}
              />
            </Pressable>
          </View>
        </Pressable>

        {/* Rating + Live Market Value Pills */}
        <View style={styles.rvCardRatingRow}>
          <MaterialIcons name="star" size={featured ? 18 : 14} color={featured ? Colors.gold : Colors.silver} />
          <Text style={[styles.rvCardRating, featured && styles.rvCardRatingFeatured]}>
            {computeRating(result.make, result.model, result.year).toFixed(1)}
          </Text>
          <View style={styles.mvPillRow}>
            {mvLoading ? (
              <ActivityIndicator size="small" color={Colors.textMuted} style={{ transform: [{ scale: 0.55 }] }} />
            ) : mv ? (
              <>
                <View style={styles.mvPillGray}>
                  <Text style={styles.mvPillGrayText}>Trade-In ${(mv.tradeIn / 1000).toFixed(0)}k</Text>
                </View>
                <View style={styles.mvPillGreen}>
                  <Text style={styles.mvPillGreenText}>Retail ${(mv.retailHigh / 1000).toFixed(0)}k</Text>
                </View>
              </>
            ) : null}
          </View>
        </View>

        <View style={styles.specsGrid}>
          <SpecChip icon="straighten" label={`${data.lengthRange[0]}–${data.lengthRange[1]} ft`} />
          <SpecChip icon="hotel" label={`Sleeps ${data.sleeps}`} />
          <SpecChip icon="view-carousel" label={`${data.slideouts} slides`} />
          <SpecChip icon={data.fuelType === 'Diesel' ? 'local-gas-station' : 'ev-station'} label={data.fuelType} />
          {data.engine ? <SpecChip icon="settings" label={data.engine} wide /> : null}
          {data.chassis ? <SpecChip icon="directions-bus" label={data.chassis} wide /> : null}
        </View>

        <View style={styles.floorplanRow}>
          <Text style={styles.floorplanLabel}>Available Floorplans:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 4 }}>
            <View style={{ flexDirection: 'row', gap: 6 }}>
              {data.floorplans.map(fp => (
                <View key={fp} style={styles.fpChip}>
                  <Text style={styles.fpChipText}>{fp}</Text>
                </View>
              ))}
            </View>
          </ScrollView>
        </View>

        {hasRecall && (
          <View style={styles.recallWarning}>
            <MaterialIcons name="warning" size={14} color={Colors.orange} />
            <Text style={styles.recallWarningText}>
              {displayRecalls} active NHTSA recall{displayRecalls > 1 ? 's' : ''} — verify at nhtsa.gov
            </Text>
          </View>
        )}

        <View style={styles.rvCardActions}>
          <Pressable
            style={({ pressed }) => [styles.detailsBtn, pressed && styles.detailsBtnPressed]}
            onPress={onViewDetails}
          >
            <MaterialIcons name="info" size={15} color="#000" />
            <Text style={styles.detailsBtnText}>Details</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [styles.reportBtn, pressed && styles.reportBtnPressed]}
            onPress={onGeneratePDF}
          >
            <MaterialIcons name="picture-as-pdf" size={15} color="#000" />
            <Text style={styles.reportBtnText}>PDF</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [styles.calBtn, pressed && { opacity: 0.75, transform: [{ scale: 0.97 }] }]}
            onPress={() => onOpenCal(mv?.retailHigh ?? data.msrpRange[0])}
          >
            <Text style={styles.calBtnText}>RvCal</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [styles.grokBtn, pressed && { opacity: 0.75, transform: [{ scale: 0.97 }] }]}
            onPress={onOpenGrok}
          >
            <Text style={styles.grokBtnText}>RvGrok</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

function SpecChip({ icon, label, wide }: { icon: string; label: string; wide?: boolean }) {
  return (
    <View style={[styles.specChip, wide && styles.specChipWide]}>
      <MaterialIcons name={icon as any} size={11} color={Colors.blueBright} />
      <Text style={styles.specChipText} numberOfLines={1}>{label}</Text>
    </View>
  );
}

// ─── SHIMMER SKELETON ─────────────────────────────────────────────────────────

function ShimmerCard() {
  const shimmerOpacity = useSharedValue(0.28);

  useEffect(() => {
    shimmerOpacity.value = withRepeat(
      withTiming(0.68, { duration: 800 }),
      -1,
      true
    );
  }, [shimmerOpacity]);

  const shimmerStyle = useAnimatedStyle(() => ({
    opacity: shimmerOpacity.value,
  }));

  return (
    <Animated.View style={[shimmerStyles.card, shimmerStyle]}>
      <View style={shimmerStyles.imageBlock} />
      <View style={shimmerStyles.body}>
        <View style={shimmerStyles.titleLine} />
        <View style={[shimmerStyles.titleLine, { width: '55%', marginTop: 6 }]} />
        <View style={shimmerStyles.chipsRow}>
          <View style={shimmerStyles.chip} />
          <View style={shimmerStyles.chip} />
          <View style={shimmerStyles.chip} />
        </View>
        <View style={shimmerStyles.actionRow}>
          <View style={[shimmerStyles.actionBtn, { flex: 2 }]} />
          <View style={[shimmerStyles.actionBtn, { flex: 1 }]} />
          <View style={[shimmerStyles.actionBtn, { flex: 1 }]} />
        </View>
      </View>
    </Animated.View>
  );
}

// ─── ANIMATED RV CARD ENTRY ───────────────────────────────────────────────────

function AnimatedRVCard({
  index, result, featured, onToggleSave, onGeneratePDF, onViewDetails, onOpenCal, onOpenGrok,
}: {
  index: number;
  result: RVResult;
  featured?: boolean;
  onToggleSave: () => void;
  onGeneratePDF: () => void;
  onViewDetails: () => void;
  onOpenCal: (price: number) => void;
  onOpenGrok: () => void;
}) {
  const translateY = useSharedValue(28);
  const opacity = useSharedValue(0);

  useEffect(() => {
    const delay = Math.min(index * 80, 400);
    const timer = setTimeout(() => {
      translateY.value = withSpring(0, { damping: 22, stiffness: 300 });
      opacity.value = withTiming(1, { duration: 350 });
    }, delay);
    return () => clearTimeout(timer);
  }, [index, opacity, translateY]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }));

  return (
    <Animated.View style={animStyle}>
      <RVCard
        result={result}
        featured={featured}
        onToggleSave={onToggleSave}
        onGeneratePDF={onGeneratePDF}
        onViewDetails={onViewDetails}
        onOpenCal={onOpenCal}
        onOpenGrok={onOpenGrok}
      />
    </Animated.View>
  );
}

// ─── PHONE ENTRY MODAL ───────────────────────────────────────────────────────

function PhoneEntryModal({
  visible, onSave, onClose, saving,
}: {
  visible: boolean;
  onSave: (phone: string) => Promise<void>;
  onClose: () => void;
  saving: boolean;
}) {
  const [rawPhone, setRawPhone] = useState('');

  const formatted = rawPhone.replace(/\D/g, '').replace(/^(\d{3})(\d{3})(\d{4})$/, '($1) $2-$3');
  const digits = rawPhone.replace(/\D/g, '');
  const isValid = digits.length === 10;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.75)' }}
      >
        <View style={phoneModal.sheet}>
          <View style={phoneModal.handle} />
          <View style={phoneModal.iconWrap}>
            <MaterialIcons name="phone" size={28} color={Colors.blueBright} />
          </View>
          <Text style={phoneModal.title}>Enter Your Phone Number</Text>
          <Text style={phoneModal.sub}>
            Your phone number is used to verify dealer access.{"\n"}Enter the number your administrator registered.
          </Text>
          <TextInput
            style={phoneModal.input}
            value={rawPhone}
            onChangeText={setRawPhone}
            placeholder="(555) 000-0000"
            placeholderTextColor={Colors.textMuted}
            keyboardType="phone-pad"
            maxLength={14}
          />
          {rawPhone.length > 0 && (
            <Text style={[phoneModal.preview, isValid && { color: Colors.green }]}>
              {isValid ? formatted : `${digits.length}/10 digits`}
            </Text>
          )}
          <Pressable
            style={({ pressed }) => [
              phoneModal.saveBtn,
              !isValid && phoneModal.saveBtnDisabled,
              pressed && isValid && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
            onPress={() => isValid && onSave(digits)}
            disabled={!isValid || saving}
          >
            {saving ? (
              <ActivityIndicator color="#000" size="small" />
            ) : (
              <Text style={phoneModal.saveBtnText}>Verify Access</Text>
            )}
          </Pressable>
          <Pressable onPress={onClose} style={{ marginTop: 8 }} hitSlop={8}>
            <Text style={phoneModal.cancelText}>Cancel — sign out and try later</Text>
          </Pressable>
          <View style={phoneModal.infoRow}>
            <MaterialIcons name="info-outline" size={12} color={Colors.textMuted} />
            <Text style={phoneModal.infoText}>
              Not registered? Contact contact@rvfox.app to request access.
            </Text>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── ACCESS GATE ─────────────────────────────────────────────────────────────

type AccessStatus = 'loading' | 'allowed' | 'denied';

function AccessDeniedCard({ phone }: { phone: string }) {
  return (
    <View style={gate.container}>
      <View style={gate.lockCircle}>
        <MaterialIcons name="lock" size={40} color={Colors.red} />
      </View>
      <Text style={gate.title}>Access Restricted</Text>
      <Text style={gate.sub}>
        Your phone number is not on the authorized access list for RvFax.
      </Text>
      {phone ? (
        <View style={gate.phoneBadge}>
          <MaterialIcons name="phone" size={14} color={Colors.textMuted} />
          <Text style={gate.phoneText}>{phone}</Text>
        </View>
      ) : null}
      <View style={gate.divider} />
      <Text style={gate.contactLabel}>Need access? Contact us:</Text>
      <Pressable
        style={({ pressed }) => [gate.emailBtn, pressed && gate.emailBtnPressed]}
        onPress={() => Linking.openURL('mailto:contact@rvfox.app')}
      >
        <MaterialIcons name="email" size={18} color="#000" />
        <Text style={gate.emailBtnText}>contact@rvfox.app</Text>
      </Pressable>
      <View style={gate.infoRow}>
        <MaterialIcons name="info-outline" size={12} color={Colors.textMuted} />
        <Text style={gate.infoText}>
          Your dealer or administrator can add your number to the allow list.
        </Text>
      </View>
    </View>
  );
}

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

export default function RvFaxScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();

  const [accessStatus, setAccessStatus] = useState<AccessStatus>('loading');
  const [userPhone, setUserPhone] = useState('');
  const [showPhoneModal, setShowPhoneModal] = useState(false);
  const [savingPhone, setSavingPhone] = useState(false);

  const [coachCount, setCoachCount] = useState(0);
  useEffect(() => {
    const target = TOTAL_MODELS;
    const steps = 48;
    const intervalMs = Math.round(1600 / steps);
    let step = 0;
    const timer = setInterval(() => {
      step++;
      if (step >= steps) {
        setCoachCount(target);
        clearInterval(timer);
      } else {
        const progress = Math.sin((step / steps) * (Math.PI / 2));
        setCoachCount(Math.round(progress * target));
      }
    }, intervalMs);
    return () => clearInterval(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const runAccessCheck = useCallback(async (phone: string) => {
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('allowed_phones')
        .select('id')
        .eq('phone_number', phone)
        .maybeSingle();
      setAccessStatus(!error && data ? 'allowed' : 'denied');
    } catch {
      setAccessStatus('denied');
    }
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function checkAccess() {
      setAccessStatus('loading');
      if (!user) {
        if (!cancelled) setAccessStatus('denied');
        return;
      }
      try {
        const supabase = getSupabaseClient();
        const { data: profile } = await supabase
          .from('user_profiles')
          .select('phone')
          .eq('id', user.id)
          .maybeSingle();
        const phone: string = profile?.phone ?? '';
        if (!cancelled) setUserPhone(phone);
        if (!phone) {
          if (!cancelled) { setAccessStatus('loading'); setShowPhoneModal(true); }
          return;
        }
        if (!cancelled) await runAccessCheck(phone);
      } catch {
        if (!cancelled) setAccessStatus('denied');
      }
    }

    checkAccess();
    return () => { cancelled = true; };
  }, [user, runAccessCheck]);

  const handleSavePhone = useCallback(async (digits: string) => {
    setSavingPhone(true);
    try {
      const supabase = getSupabaseClient();
      const { error } = await supabase
        .from('user_profiles')
        .update({ phone: digits })
        .eq('id', user!.id);
      if (error) { Alert.alert('Error', 'Could not save phone number. Please try again.'); return; }
      setUserPhone(digits);
      setShowPhoneModal(false);
      await runAccessCheck(digits);
    } catch {
      Alert.alert('Error', 'Could not save phone number. Please try again.');
    } finally {
      setSavingPhone(false);
    }
  }, [user, runAccessCheck]);

  const [refreshing, setRefreshing] = useState(false);
  const [vinModalOpen, setVinModalOpen] = useState(false);
  const [year, setYear] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [floorplan, setFloorplan] = useState('');
  const [yearModalOpen, setYearModalOpen] = useState(false);

  type EraFilter = 'all' | 'classic' | 'recent' | 'modern';
  const [eraFilter, setEraFilter] = useState<EraFilter>('all');

  const ERA_OPTIONS: { id: EraFilter; label: string; range: string; color: string }[] = [
    { id: 'all',     label: 'All Years',    range: '2000–2026', color: Colors.blueBright },
    { id: 'classic', label: 'Classic Era',   range: '2000–2005', color: '#F4C430' },
    { id: 'recent',  label: 'Recent Era',    range: '2006–2010', color: '#FF8C00' },
    { id: 'modern',  label: 'Modern Era',    range: '2011+',     color: '#00E676' },
  ];

  const filteredYears = React.useMemo(() => {
    if (eraFilter === 'classic') return YEARS.filter(y => parseInt(y) >= 2000 && parseInt(y) <= 2005);
    if (eraFilter === 'recent')  return YEARS.filter(y => parseInt(y) >= 2006 && parseInt(y) <= 2010);
    if (eraFilter === 'modern')  return YEARS.filter(y => parseInt(y) >= 2011);
    return YEARS;
  }, [eraFilter]);

  const filteredMakes = React.useMemo(() => {
    if (eraFilter === 'classic') return MAKES;
    if (eraFilter === 'recent' || eraFilter === 'modern') return MAKES.filter(m => !CLASSIC_BRANDS.includes(m));
    return MAKES;
  }, [eraFilter]);

  const [makeModalOpen, setMakeModalOpen] = useState(false);
  const [modelModalOpen, setModelModalOpen] = useState(false);
  const [floorplanModalOpen, setFloorplanModalOpen] = useState(false);
  const [results, setResults] = useState<RVResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [savedRVs, setSavedRVs] = useState<RVResult[]>([]);
  const [recentSearches, setRecentSearches] = useState<RecentSearch[]>([]);
  const [wizardExternalSearch, setWizardExternalSearch] = useState<{
    year: string; make: string; model: string; floorplan: string; _ts: number;
  } | null>(null);
  const scrollRef = useRef<ScrollView>(null);
  const resultsY  = useRef(0);

  const availableModels = make ? Object.keys(RV_DATA[make] || {}).sort() : [];
  const availableFloorplans = make && model ? (RV_DATA[make]?.[model]?.floorplans ?? []) : [];

  const handleSearch = useCallback(() => {
    if (!make && !model) return;
    setSearching(true);
    setHasSearched(true);
    setTimeout(() => {
      const foundResults: RVResult[] = [];
      const makesToSearch = make ? [make] : MAKES;
      const searchYear = year ? parseInt(year, 10) : null;
      for (const m of makesToSearch) {
        const modelsMap = RV_DATA[m];
        if (!modelsMap) continue;
        const modelsToSearch = model ? [model] : Object.keys(modelsMap);
        for (const mod of modelsToSearch) {
          const spec = modelsMap[mod];
          if (!spec) continue;
          if (searchYear) {
            if (spec.yearStart && searchYear < spec.yearStart) continue;
            if (spec.yearEnd && searchYear > spec.yearEnd) continue;
          }
          foundResults.push({
            year: year || '2025', make: m, model: mod, floorplan: floorplan || '',
            data: spec, saved: savedRVs.some(s => s.make === m && s.model === mod),
          });
        }
      }
      setResults(foundResults.slice(0, 8));
      setSearching(false);
      const label = `${year || 'Any'} ${make || 'Any'} ${model || 'Any'}`.trim();
      const sub = floorplan || 'All floorplans';
      setRecentSearches(prev =>
        [{ id: Date.now().toString(), label, sub,
           year: year || '', make: make || '', model: model || '', floorplan: floorplan || '' },
         ...prev.filter(r => r.label !== label)].slice(0, 5)
      );
    }, 800);
  }, [year, make, model, floorplan, savedRVs]);

  const toggleSave = useCallback((result: RVResult) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    setSavedRVs(prev => {
      const exists = prev.some(s => s.make === result.make && s.model === result.model && s.year === result.year);
      if (exists) return prev.filter(s => !(s.make === result.make && s.model === result.model && s.year === result.year));
      return [{ ...result, saved: true }, ...prev];
    });
    setResults(prev => prev.map(r =>
      r.make === result.make && r.model === result.model ? { ...r, saved: !r.saved } : r
    ));
  }, []);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    nhtsaRecallCache.clear();
    mvCache.clear();
    if (hasSearched && results.length > 0) setResults(prev => [...prev]);
    setTimeout(() => setRefreshing(false), 1000);
  }, [hasSearched, results.length]);

  const DropdownField = ({
    label, value, placeholder, onPress, optional,
  }: {
    label: string; value: string; placeholder: string; onPress: () => void; optional?: boolean;
  }) => (
    <View style={styles.inputGroup}>
      <Text style={styles.inputLabel}>
        {label}{optional ? <Text style={styles.optionalText}> OPTIONAL</Text> : null}
      </Text>
      <Pressable
        style={({ pressed }) => [
          styles.dropdownInput,
          value ? styles.dropdownInputFilled : null,
          pressed ? styles.dropdownInputPressed : null,
        ]}
        onPress={onPress}
      >
        <Text style={[styles.dropdownInputText, !value && styles.dropdownPlaceholder]}>
          {value || placeholder}
        </Text>
        <MaterialIcons name="keyboard-arrow-down" size={18} color={value ? Colors.silver : Colors.textMuted} />
      </Pressable>
    </View>
  );

  const HeaderBar = () => (
    <View style={styles.header}>
      <View style={styles.headerLeft}>
        <View style={styles.headerLogoWrap}>
          <Image source={require('@/assets/rvfox-icon.jpg')} style={styles.headerLogoSprite} contentFit="cover" />
        </View>
        <View>
          <Text style={styles.headerTitle}>RvFax</Text>
          <Text style={styles.headerSub}>VERIFIED & TRUE</Text>
        </View>
      </View>
      <View style={styles.aiBadge}>
        <MaterialIcons name="auto-awesome" size={13} color={Colors.blueBright} />
        <Text style={styles.aiBadgeText}>AI-Powered</Text>
      </View>
    </View>
  );

  if (accessStatus === 'loading') {
    return (
      <View style={[styles.container, { paddingTop: insets.top, alignItems: 'center', justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color={Colors.blueBright} />
        <Text style={{ color: Colors.textMuted, fontSize: FontSize.sm, marginTop: 12 }}>Checking access...</Text>
        <PhoneEntryModal
          visible={showPhoneModal}
          onSave={handleSavePhone}
          onClose={() => { setShowPhoneModal(false); setAccessStatus('denied'); }}
          saving={savingPhone}
        />
      </View>
    );
  }

  if (accessStatus === 'denied') {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <HeaderBar />
        <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: Spacing.md }}>
          <AccessDeniedCard phone={userPhone} />
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.heroBackdrop}>
        <Image
          source={require('@/assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.5 }}
          transition={400}
        />
        <LinearGradient
          colors={[
            'rgba(30,46,64,0.70)',
            'rgba(20,38,72,0.28)',
            'rgba(20,38,72,0.22)',
            'rgba(30,46,64,0.40)',
            'rgba(18,28,50,0.76)',
          ]}
          locations={[0, 0.18, 0.5, 0.82, 1]}
          style={StyleSheet.absoluteFill}
        />
      </View>

      <HeaderBar />

      <ScrollView ref={scrollRef} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }} refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={Colors.blueBright} colors={[Colors.blueBright]} />
      }>
        <Pressable
          style={({ pressed }) => [styles.vinBadge, pressed && styles.vinBadgePressed]}
          onPress={() => setVinModalOpen(true)}
        >
          <View style={styles.vinBadgeLeft}>
            <View style={styles.vinBadgeIcon}>
              <MaterialIcons name="qr-code-scanner" size={20} color="#000" />
            </View>
            <View>
              <Text style={styles.vinBadgeTitle}>VIN Decoder</Text>
              <Text style={styles.vinBadgeSub}>Free · NHTSA · Any vehicle</Text>
            </View>
          </View>
          <View style={styles.vinBadgeRight}>
            <Text style={styles.vinBadgeTag}>17-CHAR VIN</Text>
            <MaterialIcons name="arrow-forward-ios" size={12} color="rgba(0,0,0,0.5)" />
          </View>
        </Pressable>

        <View style={styles.statBanner}>
          <View style={styles.statBannerItem}>
            <Text style={styles.statBannerValue}>{coachCount.toLocaleString()}+</Text>
            <Text style={styles.statBannerLabel}>Coaches</Text>
          </View>
          <View style={styles.statBannerDivider} />
          <View style={styles.statBannerItem}>
            <View style={styles.statBannerIconRow}>
              <MaterialIcons name="warning" size={13} color={Colors.orange} />
              <Text style={[styles.statBannerValue, { color: Colors.orange }]}>NHTSA</Text>
            </View>
            <Text style={styles.statBannerLabel}>Recall Data</Text>
          </View>
          <View style={styles.statBannerDivider} />
          <View style={styles.statBannerItem}>
            <View style={styles.statBannerIconRow}>
              <MaterialIcons name="auto-awesome" size={13} color={Colors.blueBright} />
              <Text style={[styles.statBannerValue, { color: Colors.blueBright }]}>Live</Text>
            </View>
            <Text style={styles.statBannerLabel}>Market Data</Text>
          </View>
        </View>

        <SearchWizard
          externalSearch={wizardExternalSearch}
          onSearch={(wizYear, wizMake, wizModel, wizFP) => {
            setYear(wizYear);
            setMake(wizMake);
            setModel(wizModel);
            setFloorplan(wizFP);
            setSearching(true);
            setHasSearched(true);
            setTimeout(() => {
              const foundResults: RVResult[] = [];
              const makesToSearch = wizMake ? [wizMake] : MAKES;
              const sYear = wizYear ? parseInt(wizYear, 10) : null;
              for (const m of makesToSearch) {
                const modelsMap = RV_DATA[m];
                if (!modelsMap) continue;
                const modelsToSearch = wizModel ? [wizModel] : Object.keys(modelsMap);
                for (const mod of modelsToSearch) {
                  const spec = modelsMap[mod];
                  if (!spec) continue;
                  if (sYear) {
                    if (spec.yearStart && sYear < spec.yearStart) continue;
                    if (spec.yearEnd   && sYear > spec.yearEnd)   continue;
                  }
                  foundResults.push({
                    year: wizYear || '2025', make: m, model: mod,
                    floorplan: wizFP || '',
                    data: spec,
                    saved: savedRVs.some(s => s.make === m && s.model === mod),
                  });
                }
              }
              setResults(foundResults.slice(0, 8));
              setSearching(false);
              const lbl = `${wizYear || 'Any'} ${wizMake || 'Any'} ${wizModel || 'Any'}`.trim();
              setRecentSearches(prev =>
                [{ id: Date.now().toString(), label: lbl, sub: wizFP || 'All floorplans',
                   year: wizYear, make: wizMake, model: wizModel, floorplan: wizFP },
                 ...prev.filter(r => r.label !== lbl)].slice(0, 5)
              );
              setTimeout(() => {
                scrollRef.current?.scrollTo({ y: Math.max(0, resultsY.current - 16), animated: true });
              }, 700);
            }, 600);
          }}
        />

        {/* Hidden legacy search */}
        <View style={[styles.searchCard, { display: 'none' }]}>
          <Text style={styles.searchCardTitle}>Search Any RV</Text>
          <View style={styles.eraSection}>
            <Text style={styles.eraLabel}>YEAR RANGE</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.eraChipRow}>
              {ERA_OPTIONS.map(era => {
                const active = eraFilter === era.id;
                return (
                  <Pressable
                    key={era.id}
                    style={({ pressed }) => [
                      styles.eraChip,
                      active && { backgroundColor: era.color, borderColor: era.color },
                      pressed && !active && { opacity: 0.7 },
                    ]}
                    onPress={() => {
                      setEraFilter(era.id);
                      if (year) {
                        const y = parseInt(year);
                        if (era.id === 'classic' && (y < 2000 || y > 2005)) setYear('');
                        if (era.id === 'recent'  && (y < 2006 || y > 2010)) setYear('');
                        if (era.id === 'modern'  && y < 2011)                setYear('');
                      }
                      if ((era.id === 'recent' || era.id === 'modern') && CLASSIC_BRANDS.includes(make)) {
                        setMake('');
                        setModel('');
                        setFloorplan('');
                      }
                    }}
                  >
                    <Text style={[styles.eraChipLabel, active && { color: '#000' }]}>{era.label}</Text>
                    <Text style={[styles.eraChipRange, active && { color: 'rgba(0,0,0,0.60)' }]}>{era.range}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <DropdownField label="YEAR" value={year} placeholder={eraFilter === 'classic' ? '2000–2005' : eraFilter === 'recent' ? '2006–2010' : '2026'} onPress={() => setYearModalOpen(true)} />
            </View>
            <View style={{ flex: 2 }}>
              <DropdownField label="MAKE" value={make} placeholder="Newmar, Tiffin..." onPress={() => setMakeModalOpen(true)} />
            </View>
          </View>
          <DropdownField label="MODEL" value={model} placeholder={make ? `Select ${make} model` : 'King Aire, Allegro Bus...'} onPress={() => { if (make) setModelModalOpen(true); }} />
          <DropdownField label="FLOORPLAN" value={floorplan} placeholder="45OPP, 37TS..." onPress={() => { if (make && model) setFloorplanModalOpen(true); }} optional />
          <Pressable
            style={({ pressed }) => [
              styles.lookupButton,
              (!make && !model) && styles.lookupButtonDisabled,
              (pressed && (make || model)) ? styles.lookupButtonPressed : null,
            ]}
            onPress={handleSearch}
            disabled={searching || (!make && !model)}
          >
            {searching ? (
              <ActivityIndicator color="#000" size="small" />
            ) : (
              <>
                <MaterialIcons name="search" size={20} color={(!make && !model) ? Colors.textMuted : '#000000'} />
                <Text style={[styles.lookupButtonText, (!make && !model) && { color: Colors.textMuted }]}>Lookup RV Specs</Text>
              </>
            )}
          </Pressable>
        </View>

        {hasSearched && (
          <View style={styles.section} onLayout={e => { resultsY.current = e.nativeEvent.layout.y; }}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionTitleRow}>
                <MaterialIcons name="search" size={14} color={Colors.blueBright} />
                <Text style={styles.sectionTitle}>RESULTS</Text>
                {results.length > 0 && (
                  <View style={styles.countBadge}>
                    <Text style={styles.countText}>{results.length}</Text>
                  </View>
                )}
              </View>
            </View>
            {searching && (
              <>
                <ShimmerCard />
                <ShimmerCard />
                <ShimmerCard />
              </>
            )}
            {results.length === 0 && !searching && (
              <View style={styles.emptyState}>
                <MaterialIcons name="search-off" size={32} color={Colors.textDim} />
                <Text style={styles.emptyText}>No RVs found</Text>
                <Text style={styles.emptySubText}>Try a different make or model</Text>
              </View>
            )}
            {!searching && results.map((r, i) => (
              <AnimatedRVCard
                key={`${r.make}-${r.model}-${i}`}
                index={i}
                result={r}
                featured={i === 0}
                onToggleSave={() => toggleSave(r)}
                onViewDetails={() => router.push({
                  pathname: '/rv-detail',
                  params: { year: r.year, make: r.make, model: r.model, floorplan: r.floorplan },
                })}
                onGeneratePDF={async () => {
                  try {
                    await generateAndShareRVReport({ ...r.data, year: r.year, make: r.make, model: r.model, floorplan: r.floorplan });
                  } catch {
                    Alert.alert('PDF Error', 'Could not generate report. Please try again.');
                  }
                }}
                onOpenCal={(price) => router.push({
                  pathname: '/(tabs)/rvcal',
                  params: { msrp: String(price) },
                })}
                onOpenGrok={() => router.push({
                  pathname: '/(tabs)/rvgrok',
                  params: {
                    prefill: r.floorplan
                      ? `Tell me everything about the ${r.year} ${r.make} ${r.model} floorplan ${r.floorplan} — specs, layout details, pricing, known issues, towing, storage, maintenance, and what owners are saying about this specific floorplan.`
                      : `Tell me everything about the ${r.year} ${r.make} ${r.model} — specs, pricing, known issues, best floorplans, towing, maintenance, and what owners are saying.`,
                  },
                })}
              />
            ))}
          </View>
        )}

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleRow}>
              <MaterialIcons name="favorite" size={14} color={Colors.red} />
              <Text style={styles.sectionTitle}>SAVED RVs</Text>
              {savedRVs.length > 0 && (
                <View style={[styles.countBadge, { backgroundColor: Colors.red }]}>
                  <Text style={styles.countText}>{savedRVs.length}</Text>
                </View>
              )}
            </View>
            {savedRVs.length > 0 && (
              <Pressable onPress={() => setSavedRVs([])}>
                <Text style={styles.linkText}>Clear all</Text>
              </Pressable>
            )}
          </View>
          {savedRVs.length === 0 ? (
            <View style={styles.emptyState}>
              <MaterialIcons name="bookmark-border" size={32} color={Colors.textDim} />
              <Text style={styles.emptyText}>No saved RVs yet</Text>
              <Text style={styles.emptySubText}>Search and tap the heart to save</Text>
            </View>
          ) : (
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={{ flexDirection: 'row', gap: 12, paddingRight: Spacing.md }}>
                {savedRVs.map((rv, i) => (
                  <Pressable
                    key={i}
                    style={styles.savedCard}
                    onPress={() => router.push({
                      pathname: '/rv-detail',
                      params: { year: rv.year, make: rv.make, model: rv.model, floorplan: rv.floorplan },
                    })}
                  >
                    <View style={styles.savedCardImage}>
                      <Image
                        source={getTypeImage(rv.data.type)}
                        style={StyleSheet.absoluteFill}
                        contentFit="cover"
                        contentPosition={{ x: 0.5, y: 0.5 }}
                        transition={200}
                      />
                      <LinearGradient
                        colors={['rgba(0,0,0,0.0)', 'rgba(0,0,0,0.55)']}
                        style={StyleSheet.absoluteFill}
                        pointerEvents="none"
                      />
                    </View>
                    <View style={styles.savedCardTypeBadge}>
                      <Text style={styles.savedCardTypeText}>{rv.data.type.split(' ')[0]}</Text>
                    </View>
                    <View style={styles.savedCardBody}>
                      <Text style={styles.savedCardYear}>{rv.year}</Text>
                      <Text style={styles.savedCardName} numberOfLines={2}>{rv.make} {rv.model}</Text>
                      <View style={styles.savedCardRating}>
                        <MaterialIcons name="star" size={11} color={Colors.silver} />
                        <Text style={styles.savedCardRatingText}>{computeRating(rv.make, rv.model, rv.year).toFixed(1)}</Text>
                      </View>
                      <View style={styles.savedCardActions}>
                        <Pressable
                          style={({ pressed }) => [styles.savedReportBtn, pressed && { opacity: 0.75 }]}
                          onPress={async (e) => {
                            e.stopPropagation?.();
                            try {
                              await generateAndShareRVReport({ ...rv.data, year: rv.year, make: rv.make, model: rv.model, floorplan: rv.floorplan });
                            } catch {
                              Alert.alert('PDF Error', 'Could not generate report.');
                            }
                          }}
                        >
                          <MaterialIcons name="picture-as-pdf" size={12} color="#000" />
                          <Text style={styles.savedReportText}>Report</Text>
                        </Pressable>
                        <Pressable
                          onPress={(e) => {
                            e.stopPropagation?.();
                            setSavedRVs(prev => prev.filter((_, j) => j !== i));
                          }}
                          hitSlop={6}
                        >
                          <View style={styles.savedHeartBtn}>
                            <MaterialIcons name="favorite" size={14} color={Colors.red} />
                          </View>
                        </Pressable>
                      </View>
                    </View>
                  </Pressable>
                ))}
              </View>
            </ScrollView>
          )}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleRow}>
              <MaterialIcons name="history" size={14} color={Colors.blueBright} />
              <Text style={styles.sectionTitle}>RECENT SEARCHES</Text>
            </View>
            {recentSearches.length > 0 && (
              <Pressable onPress={() => setRecentSearches([])}>
                <Text style={styles.linkText}>Clear</Text>
              </Pressable>
            )}
          </View>
          {recentSearches.length === 0 ? (
            <View style={styles.emptyState}>
              <MaterialIcons name="manage-search" size={28} color={Colors.textDim} />
              <Text style={styles.emptyText}>No recent searches</Text>
            </View>
          ) : (
            <View style={{ gap: 8 }}>
              {recentSearches.map(rs => (
                <Pressable
                  key={rs.id}
                  style={({ pressed }) => [styles.recentItem, pressed && { opacity: 0.7 }]}
                  onPress={() => {
                    setWizardExternalSearch({
                      year: rs.year || '',
                      make: rs.make || '',
                      model: rs.model || '',
                      floorplan: rs.floorplan || '',
                      _ts: Date.now(),
                    });
                  }}
                >
                  <MaterialIcons name="manage-search" size={18} color={Colors.blueBright} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.recentLabel}>{rs.label}</Text>
                    <Text style={styles.recentSub}>{rs.sub}</Text>
                  </View>
                  <Pressable onPress={() => setRecentSearches(prev => prev.filter(r => r.id !== rs.id))} hitSlop={8}>
                    <MaterialIcons name="close" size={16} color={Colors.textMuted} />
                  </Pressable>
                </Pressable>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      <VinDecoderModal visible={vinModalOpen} onClose={() => setVinModalOpen(false)} />
      <DropdownModal visible={yearModalOpen} title="Select Year" items={filteredYears} selected={year}
        onSelect={setYear} onClose={() => setYearModalOpen(false)} allowFreeText />
      <DropdownModal visible={makeModalOpen} title="Select Make" items={filteredMakes} selected={make}
        onSelect={(val) => { setMake(val); setModel(''); setFloorplan(''); }} onClose={() => setMakeModalOpen(false)} allowFreeText />
      <DropdownModal visible={modelModalOpen} title={`Select ${make} Model`} items={availableModels} selected={model}
        onSelect={(val) => { setModel(val); setFloorplan(''); }} onClose={() => setModelModalOpen(false)} allowFreeText />
      <DropdownModal visible={floorplanModalOpen} title="Select Floorplan" items={availableFloorplans} selected={floorplan}
        onSelect={setFloorplan} onClose={() => setFloorplanModalOpen(false)} allowFreeText />
    </View>
  );
}

// ─── STYLES ─────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A2A3A' },
  heroBackdrop: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, zIndex: 2,
    backgroundColor: 'rgba(27,44,64,0.62)',
    borderBottomWidth: 1, borderBottomColor: 'rgba(168,188,207,0.18)',
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerLogoWrap: {
    width: 40, height: 40, borderRadius: 20, overflow: 'hidden',
    borderWidth: 1.5, borderColor: 'rgba(168,188,207,0.60)',
  },
  headerLogoSprite: { width: 40, height: 40 },
  headerTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary, letterSpacing: 0.5 },
  headerSub: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.textMuted, letterSpacing: 1.5 },
  aiBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(27,60,122,0.40)', borderWidth: 1,
    borderColor: 'rgba(168,188,207,0.45)', paddingHorizontal: 10, paddingVertical: 5,
    borderRadius: Radius.full,
  },
  aiBadgeText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: '#A8BCCF' },
  vinBadge: {
    marginHorizontal: Spacing.md, marginBottom: Spacing.sm, borderRadius: Radius.lg,
    overflow: 'hidden', backgroundColor: '#1B3C7A', flexDirection: 'row',
    alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.md, paddingVertical: 12, zIndex: 2,
    borderWidth: 1, borderColor: 'rgba(168,188,207,0.35)',
    shadowColor: '#1B3C7A', shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.55, shadowRadius: 10, elevation: 5,
  },
  vinBadgePressed: { opacity: 0.88, transform: [{ scale: 0.98 }] },
  vinBadgeLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  vinBadgeIcon: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: 'rgba(168,188,207,0.15)', alignItems: 'center', justifyContent: 'center',
  },
  vinBadgeTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: '#E8EEF4' },
  vinBadgeSub: { fontSize: FontSize.xs, color: 'rgba(168,188,207,0.70)', fontWeight: FontWeight.medium },
  vinBadgeRight: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  vinBadgeTag: { fontSize: 9, fontWeight: FontWeight.bold, color: 'rgba(168,188,207,0.60)', letterSpacing: 0.5 },
  statBanner: {
    marginHorizontal: Spacing.md, marginBottom: Spacing.sm,
    backgroundColor: 'rgba(27,60,122,0.55)', borderRadius: Radius.xl,
    borderWidth: 1.5, borderColor: 'rgba(168,188,207,0.40)',
    flexDirection: 'row', alignItems: 'center', paddingVertical: 12, zIndex: 2,
    shadowColor: '#1B3C7A', shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.40, shadowRadius: 12, elevation: 4,
  },
  statBannerItem: { flex: 1, alignItems: 'center', gap: 3 },
  statBannerIconRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statBannerValue: { fontSize: FontSize.base, fontWeight: FontWeight.extrabold, color: '#FFFFFF', letterSpacing: 0.3 },
  statBannerLabel: { fontSize: 10, color: Colors.textMuted, fontWeight: FontWeight.medium, letterSpacing: 0.3 },
  statBannerDivider: { width: 1, height: 32, backgroundColor: 'rgba(168,188,207,0.30)' },
  searchCard: {
    marginHorizontal: Spacing.md, marginBottom: Spacing.sm,
    backgroundColor: 'rgba(27,60,122,0.28)', borderRadius: Radius.xl,
    padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(168,188,207,0.22)',
    zIndex: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3, shadowRadius: 12, elevation: 8, gap: Spacing.sm,
  },
  eraSection: { gap: 6 },
  eraLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: 'rgba(255,255,255,0.60)', letterSpacing: 1.2 },
  eraChipRow: { flexDirection: 'row', gap: 8, paddingVertical: 2 },
  eraChip: {
    paddingHorizontal: 12, paddingVertical: 7, borderRadius: Radius.full,
    backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.18)', alignItems: 'center', minWidth: 80,
  },
  eraChipLabel: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 0.3, textAlign: 'center' },
  eraChipRange: { fontSize: 9, color: Colors.textDim, marginTop: 1, textAlign: 'center' },
  searchCardTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, color: '#FFFFFF', letterSpacing: 0.3 },
  row: { flexDirection: 'row', gap: Spacing.sm },
  inputGroup: { marginBottom: Spacing.sm },
  inputLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: '#FFFFFF', letterSpacing: 1, marginBottom: 5 },
  optionalText: { color: 'rgba(255,255,255,0.45)', fontWeight: FontWeight.medium },
  dropdownInput: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.bgCardAlt, borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 13, gap: 8,
  },
  dropdownInputFilled: {
    borderColor: Colors.borderBlue, backgroundColor: 'rgba(0,104,192,0.06)',
    shadowColor: Colors.blue, shadowOpacity: 0.25, shadowRadius: 8, elevation: 3,
  },
  dropdownInputPressed: { borderColor: Colors.borderBlueBright, backgroundColor: 'rgba(0,104,192,0.1)' },
  dropdownInputText: { flex: 1, fontSize: FontSize.md, fontWeight: FontWeight.medium, color: '#FFFFFF' },
  dropdownPlaceholder: { color: 'rgba(255,255,255,0.50)', fontWeight: FontWeight.regular },
  lookupButton: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    backgroundColor: '#1B3C7A', borderRadius: Radius.md, paddingVertical: 15, marginTop: 4,
    borderWidth: 1, borderColor: 'rgba(168,188,207,0.35)',
    shadowColor: '#1B3C7A', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.60, shadowRadius: 10, elevation: 6,
  },
  lookupButtonDisabled: { backgroundColor: Colors.bgCardAlt, shadowOpacity: 0, elevation: 0, borderWidth: 1, borderColor: Colors.border },
  lookupButtonPressed: { opacity: 0.85, transform: [{ scale: 0.98 }] },
  lookupButtonText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#E8EEF4' },
  section: {
    marginHorizontal: Spacing.md, marginBottom: Spacing.md, zIndex: 2,
    backgroundColor: 'rgba(27,44,64,0.38)', borderRadius: Radius.xl, padding: Spacing.sm,
    borderWidth: 1, borderColor: 'rgba(168,188,207,0.14)',
  },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.sm },
  sectionTitleRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  sectionTitle: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 1.5 },
  countBadge: {
    backgroundColor: Colors.blue, borderRadius: Radius.full, minWidth: 18, height: 18,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4,
  },
  countText: { fontSize: 9, fontWeight: FontWeight.bold, color: '#fff' },
  linkText: { fontSize: FontSize.sm, color: Colors.blueBright, fontWeight: FontWeight.medium },
  rvCard: {
    backgroundColor: 'rgba(27,44,64,0.55)', borderRadius: Radius.xl, marginBottom: Spacing.md,
    overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(168,188,207,0.28)',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.5, shadowRadius: 12, elevation: 8,
  },
  rvCardImageWrapper: { height: 180, backgroundColor: '#0A0A12', position: 'relative' },
  rvCardImageWrapperFeatured: { height: 240 },
  cardHeroContent: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  cardHeroInitial: { fontSize: 120, fontWeight: '900', lineHeight: 128, letterSpacing: -6 },
  cardHeroMakeName: { position: 'absolute', bottom: 14, left: 14, fontSize: 10, fontWeight: '800', letterSpacing: 4 },
  featuredBadge: {
    position: 'absolute', bottom: 10, left: 10, flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.gold, borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 4,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.5, shadowRadius: 6, elevation: 4,
  },
  featuredBadgeText: { fontSize: 10, fontWeight: FontWeight.extrabold, color: '#000', letterSpacing: 0.6 },
  rvCardTypeBadge: {
    position: 'absolute', top: 10, left: 10,
    backgroundColor: 'rgba(0,104,192,0.85)', borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 3,
  },
  rvCardTypeText: { fontSize: 10, fontWeight: FontWeight.bold, color: '#fff', letterSpacing: 0.5 },
  recallBadge: {
    position: 'absolute', top: 10, right: 10, flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: Colors.warning, borderRadius: Radius.sm, paddingHorizontal: 7, paddingVertical: 3,
  },
  recallBadgeText: { fontSize: 10, fontWeight: FontWeight.bold, color: '#000' },
  noRecallBadge: {
    position: 'absolute', top: 10, right: 10, flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: 'rgba(0,0,0,0.65)', borderRadius: Radius.sm, paddingHorizontal: 7, paddingVertical: 3,
    borderWidth: 1, borderColor: 'rgba(58,181,114,0.4)',
  },
  noRecallBadgeText: { fontSize: 10, fontWeight: FontWeight.bold, color: Colors.textSecondary },
  tapHint: { position: 'absolute', bottom: 8, right: 10, flexDirection: 'row', alignItems: 'center', gap: 3 },
  tapHintText: { fontSize: 9, color: 'rgba(255,255,255,0.45)' },
  rvCardBody: { padding: Spacing.md },
  rvCardTitleRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 8 },
  rvCardYear: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright, letterSpacing: 1 },
  rvCardName: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, color: '#FFFFFF', marginTop: 1 },
  rvCardFloorplan: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },
  heartBtn: { padding: 4 },
  rvCardRatingRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 10 },
  rvCardRating: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.silver, marginRight: 6 },
  rvCardPrice: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.green },
  rvCardRatingFeatured: { fontSize: 20, color: Colors.gold, fontWeight: FontWeight.extrabold },
  rvCardPriceFeatured: { fontSize: FontSize.base, fontWeight: FontWeight.extrabold, color: Colors.green },
  // ── Market Value Pills ────────────────────────────────────────────────────
  mvPillRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginLeft: 4, flex: 1 },
  mvPillGray: {
    backgroundColor: 'rgba(168,188,207,0.12)', borderWidth: 1,
    borderColor: 'rgba(168,188,207,0.35)', borderRadius: Radius.full,
    paddingHorizontal: 7, paddingVertical: 3,
  },
  mvPillGrayText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.silver, letterSpacing: 0.3 },
  mvPillGreen: {
    backgroundColor: 'rgba(74,222,128,0.10)', borderWidth: 1,
    borderColor: 'rgba(74,222,128,0.35)', borderRadius: Radius.full,
    paddingHorizontal: 7, paddingVertical: 3,
  },
  mvPillGreenText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.green, letterSpacing: 0.3 },
  specsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 },
  specChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(27,60,122,0.18)', borderWidth: 1,
    borderColor: 'rgba(168,188,207,0.30)', borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 4,
  },
  specChipWide: { flex: 1 },
  specChipText: { fontSize: FontSize.xs, fontWeight: FontWeight.medium, color: Colors.textSecondary },
  floorplanRow: { marginBottom: 10 },
  floorplanLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.textMuted, letterSpacing: 0.5 },
  fpChip: {
    backgroundColor: 'rgba(188,185,186,0.08)', borderWidth: 1,
    borderColor: Colors.borderSilver, borderRadius: Radius.sm, paddingHorizontal: 10, paddingVertical: 4,
  },
  fpChipText: { fontSize: FontSize.xs, color: Colors.silver, fontWeight: FontWeight.semibold },
  recallWarning: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(200,146,42,0.1)', borderRadius: Radius.sm,
    paddingHorizontal: 10, paddingVertical: 7, marginBottom: 10,
    borderWidth: 1, borderColor: 'rgba(200,146,42,0.3)',
  },
  recallWarningText: { flex: 1, fontSize: FontSize.xs, color: Colors.warning, fontWeight: FontWeight.medium },
  rvCardActions: { flexDirection: 'row', gap: 8, marginTop: 4 },
  detailsBtn: {
    flex: 2, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5,
    backgroundColor: '#1B3C7A', borderRadius: Radius.md, paddingVertical: 10,
    borderWidth: 1, borderColor: 'rgba(168,188,207,0.30)',
    shadowColor: '#1B3C7A', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.55, shadowRadius: 6, elevation: 4,
  },
  detailsBtnPressed: { opacity: 0.8, transform: [{ scale: 0.97 }] },
  detailsBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: '#A8BCCF' },
  reportBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5,
    backgroundColor: 'rgba(168,188,207,0.18)', borderWidth: 1,
    borderColor: 'rgba(168,188,207,0.45)', borderRadius: Radius.md, paddingVertical: 10,
  },
  reportBtnPressed: { opacity: 0.8, transform: [{ scale: 0.97 }] },
  reportBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: '#A8BCCF' },
  calBtn: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(188,185,186,0.12)', borderWidth: 1,
    borderColor: Colors.borderSilver, borderRadius: Radius.md, paddingVertical: 10,
  },
  calBtnText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.silver },
  grokBtn: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(0,104,192,0.12)', borderWidth: 1,
    borderColor: Colors.borderBlue, borderRadius: Radius.md, paddingVertical: 10,
  },
  grokBtnText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright },
  savedCard: {
    width: 160, backgroundColor: 'transparent', borderRadius: Radius.lg,
    overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
  },
  savedCardImage: { width: '100%', height: 100, backgroundColor: '#0A0A12', overflow: 'hidden' },
  savedCardTypeBadge: {
    position: 'absolute', top: 8, left: 8,
    backgroundColor: 'rgba(0,104,192,0.85)', borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2,
  },
  savedCardTypeText: { fontSize: 9, fontWeight: FontWeight.bold, color: '#fff' },
  savedCardBody: { padding: Spacing.sm },
  savedCardYear: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright, letterSpacing: 1 },
  savedCardName: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: '#FFFFFF', marginTop: 2, lineHeight: 17 },
  savedCardRating: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 5 },
  savedCardRatingText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.silver },
  savedCardPrice: { fontSize: FontSize.xs, color: Colors.green, fontWeight: FontWeight.semibold, marginTop: 3 },
  savedCardActions: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 },
  savedReportBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.silver, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 5,
  },
  savedReportText: { fontSize: 10, fontWeight: FontWeight.bold, color: '#000' },
  savedHeartBtn: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(184,58,58,0.12)', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(184,58,58,0.3)',
  },
  recentItem: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(27,60,122,0.18)', borderRadius: Radius.md,
    padding: Spacing.sm + 2, borderWidth: 1, borderColor: 'rgba(168,188,207,0.20)',
  },
  recentLabel: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: '#FFFFFF' },
  recentSub: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 1 },
  modalSheet: {
    backgroundColor: Colors.bgDeep, borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    borderTopWidth: 2, borderColor: Colors.borderBlue, maxHeight: '90%',
    paddingHorizontal: Spacing.md, paddingTop: 8,
    shadowColor: Colors.blue, shadowOffset: { width: 0, height: -6 }, shadowOpacity: 0.35, shadowRadius: 24, elevation: 20,
  },
  modalHandle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.sm, marginTop: 4 },
  modalHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: Spacing.sm,
  },
  modalTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, color: '#FFFFFF' },
  modalSearchRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.lg, paddingHorizontal: Spacing.md, paddingVertical: 10, marginBottom: Spacing.sm,
  },
  modalSearchInput: { flex: 1, fontSize: FontSize.md, color: Colors.textPrimary },
  modalManualEntry: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(0,104,192,0.08)', borderWidth: 1, borderColor: Colors.borderBlue,
    borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 10, marginBottom: 8,
  },
  modalManualEntryText: { flex: 1, fontSize: FontSize.sm, color: Colors.textSecondary },
  modalItem: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: 14, paddingHorizontal: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  modalItemSelected: { backgroundColor: 'rgba(0,104,192,0.08)' },
  modalItemText: { fontSize: FontSize.md, color: 'rgba(255,255,255,0.80)', fontWeight: FontWeight.medium },
  modalItemTextSelected: { color: Colors.blueBright, fontWeight: FontWeight.bold },
  modalEmpty: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  modalEmptyText: { fontSize: FontSize.sm, color: Colors.textMuted },
  emptyState: {
    alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm,
    backgroundColor: 'transparent', borderRadius: Radius.lg,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)',
  },
  emptyText: { fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: '#FFFFFF' },
  emptySubText: { fontSize: FontSize.sm, color: Colors.textMuted },
});

// ─── VIN MODAL STYLES ────────────────────────────────────────────────────────

const vinModal = StyleSheet.create({
  sheet: {
    backgroundColor: Colors.bgDeep, borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    borderTopWidth: 2, borderColor: Colors.borderBlue, maxHeight: '92%',
    paddingHorizontal: Spacing.md, paddingTop: 8,
    shadowColor: Colors.blue, shadowOffset: { width: 0, height: -6 }, shadowOpacity: 0.35, shadowRadius: 24, elevation: 20,
  },
  handle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.sm, marginTop: 4 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: Spacing.sm,
  },
  headerCenter: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  closeBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.06)', alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, color: '#FFFFFF' },
  inputSection: { paddingVertical: Spacing.sm },
  inputRow: { position: 'relative', marginBottom: Spacing.sm },
  input: {
    backgroundColor: Colors.bgCard, borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 13, paddingRight: 52,
    fontSize: FontSize.md, color: '#FFFFFF', fontWeight: FontWeight.bold, letterSpacing: 2,
  },
  charCount: { position: 'absolute', right: Spacing.md, top: 0, bottom: 0, justifyContent: 'center' },
  charCountText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textMuted, letterSpacing: 0.5 },
  actionRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: 8 },
  decodeBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: Colors.blue, borderRadius: Radius.md, paddingVertical: 13,
    shadowColor: Colors.blue, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.4, shadowRadius: 8, elevation: 5,
  },
  decodeBtnDisabled: { backgroundColor: Colors.bgCardAlt, shadowOpacity: 0, elevation: 0, borderWidth: 1, borderColor: Colors.border },
  decodeBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.silverBright },
  scanBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: 'rgba(0,104,192,0.12)', borderWidth: 1.5, borderColor: Colors.borderBlueBright,
    borderRadius: Radius.md, paddingVertical: 13, paddingHorizontal: 18,
  },
  scanBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.blueBright },
  scanHintRow: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 4 },
  scanHintText: { flex: 1, fontSize: FontSize.xs, color: Colors.textDim, lineHeight: 15 },
  errorCard: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(184,58,58,0.1)', borderWidth: 1, borderColor: 'rgba(184,58,58,0.3)',
    borderRadius: Radius.md, padding: Spacing.md, marginBottom: Spacing.sm,
  },
  errorText: { flex: 1, fontSize: FontSize.sm, color: Colors.red, fontWeight: FontWeight.medium },
  results: { gap: Spacing.sm },
  identityCard: {
    backgroundColor: Colors.bgCard, borderRadius: Radius.lg, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.borderSilver, gap: Spacing.sm,
  },
  identityTopRow: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm },
  identityYear: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright, letterSpacing: 2, marginBottom: 2 },
  identityName: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: '#FFFFFF' },
  identityTrim: { fontSize: FontSize.sm, color: Colors.textSecondary, marginTop: 2 },
  recallLoadingBadge: { backgroundColor: 'rgba(0,104,192,0.1)', borderRadius: Radius.sm, padding: 6, borderWidth: 1, borderColor: Colors.borderBlue },
  recallCountBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: Colors.warning, borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 5 },
  recallCountText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: '#000' },
  noRecallBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: 'rgba(58,181,114,0.12)', borderRadius: Radius.sm,
    paddingHorizontal: 8, paddingVertical: 5, borderWidth: 1, borderColor: 'rgba(58,181,114,0.3)',
  },
  noRecallText: { fontSize: FontSize.xs, fontWeight: FontWeight.medium, color: Colors.green },
  identityBadges: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  badge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(188,185,186,0.08)', borderRadius: Radius.sm,
    paddingHorizontal: 8, paddingVertical: 4, borderWidth: 1, borderColor: Colors.borderSilver,
  },
  badgeText: { fontSize: FontSize.xs, fontWeight: FontWeight.medium, color: Colors.textSecondary },
  vinChip: { backgroundColor: Colors.bgCardAlt, borderRadius: Radius.sm, padding: Spacing.sm, flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  vinChipLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright, letterSpacing: 1 },
  vinChipText: { flex: 1, fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: '#FFFFFF', letterSpacing: 1.5 },
  sectionBlock: { gap: Spacing.sm },
  sectionBlockTitle: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 1.5 },
  detailGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  detailCell: { width: '47%', backgroundColor: Colors.bgCard, borderRadius: Radius.sm, padding: Spacing.sm, borderWidth: 1, borderColor: Colors.border, gap: 3 },
  detailCellLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textMuted, letterSpacing: 0.5 },
  detailCellValue: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  assemblyCard: { backgroundColor: Colors.bgCard, borderRadius: Radius.sm, padding: Spacing.sm, borderWidth: 1, borderColor: Colors.border, gap: 3 },
  assemblyValue: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.silver, letterSpacing: 1 },
  recallSection: { backgroundColor: 'rgba(200,146,42,0.06)', borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(200,146,42,0.25)', gap: 8 },
  recallSectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  recallSectionTitle: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.warning, letterSpacing: 1 },
  recallItem: { backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: Radius.sm, padding: Spacing.sm, borderWidth: 1, borderColor: 'rgba(200,146,42,0.2)' },
  recallItemMain: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  recallItemLeft: { flex: 1, gap: 3 },
  recallComponent: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  recallDate: { fontSize: FontSize.xs, color: Colors.textMuted },
  recallSummary: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 16, marginTop: 4 },
  recallRemedyRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 4, marginTop: 4 },
  recallRemedy: { flex: 1, fontSize: FontSize.xs, color: Colors.green, lineHeight: 16 },
  noRecallSection: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(58,181,114,0.08)', borderRadius: Radius.md, padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(58,181,114,0.25)' },
  noRecallSectionText: { fontSize: FontSize.sm, fontWeight: FontWeight.medium, color: Colors.green },
  nhtsaBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.borderBlue, backgroundColor: 'rgba(0,104,192,0.06)' },
  nhtsaBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.medium, color: Colors.blueBright },
  lookupBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.blue, borderRadius: Radius.md, padding: Spacing.md,
    shadowColor: Colors.blue, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.4, shadowRadius: 10, elevation: 5,
  },
  lookupBtnTitle: { fontSize: FontSize.base, fontWeight: FontWeight.extrabold, color: Colors.silverBright },
  lookupBtnSub: { fontSize: FontSize.xs, color: 'rgba(188,185,186,0.6)', marginTop: 1 },
  disclaimer: { flexDirection: 'row', alignItems: 'flex-start', gap: 5, paddingHorizontal: 4 },
  disclaimerText: { flex: 1, fontSize: FontSize.xs, color: Colors.textDim, lineHeight: 15 },
  scannerContainer: { flex: 1, backgroundColor: '#000' },
  scanCorner: { position: 'absolute', width: 22, height: 22, borderWidth: 3, borderColor: Colors.blueBright },
  scannerBottomUi: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: Spacing.xl, alignItems: 'center', gap: Spacing.sm },
  scannerHint: { fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: '#fff', textAlign: 'center' },
  scannerHint2: { fontSize: FontSize.sm, color: 'rgba(255,255,255,0.6)', textAlign: 'center' },
  scannerCloseBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: Colors.silver,
    borderRadius: Radius.full, paddingHorizontal: 24, paddingVertical: 13, marginTop: Spacing.sm,
    shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 5,
  },
  scannerCloseBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#000' },
});

// ─── SHIMMER STYLES ─────────────────────────────────────────────────────────

const shimmerStyles = StyleSheet.create({
  card: { backgroundColor: 'rgba(27,44,64,0.55)', borderRadius: Radius.xl, marginBottom: Spacing.md, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(168,188,207,0.18)' },
  imageBlock: { height: 180, backgroundColor: 'rgba(168,188,207,0.08)' },
  body: { padding: Spacing.md, gap: 10 },
  titleLine: { height: 16, backgroundColor: 'rgba(168,188,207,0.12)', borderRadius: 4, width: '78%' },
  chipsRow: { flexDirection: 'row', gap: 8 },
  chip: { height: 22, width: 82, backgroundColor: 'rgba(168,188,207,0.10)', borderRadius: Radius.sm },
  actionRow: { flexDirection: 'row', gap: 8 },
  actionBtn: { height: 38, backgroundColor: 'rgba(168,188,207,0.08)', borderRadius: Radius.md },
});

// ─── PHONE MODAL STYLES ─────────────────────────────────────────────────────

const phoneModal = StyleSheet.create({
  sheet: {
    backgroundColor: Colors.bgDeep, borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    borderTopWidth: 2, borderColor: Colors.borderBlue,
    paddingHorizontal: Spacing.lg, paddingBottom: 32, paddingTop: 8, alignItems: 'center',
    shadowColor: Colors.blue, shadowOffset: { width: 0, height: -6 }, shadowOpacity: 0.35, shadowRadius: 24, elevation: 20,
  },
  handle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, marginBottom: Spacing.md, marginTop: 4 },
  iconWrap: {
    width: 64, height: 64, borderRadius: 32, backgroundColor: 'rgba(0,104,192,0.1)',
    borderWidth: 1.5, borderColor: Colors.borderBlue, alignItems: 'center', justifyContent: 'center',
    marginBottom: Spacing.md, shadowColor: Colors.blueBright, shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3, shadowRadius: 12, elevation: 5,
  },
  title: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary, textAlign: 'center', marginBottom: Spacing.sm },
  sub: { fontSize: FontSize.sm, color: Colors.textSecondary, textAlign: 'center', lineHeight: 20, marginBottom: Spacing.md },
  input: {
    width: '100%', backgroundColor: Colors.bgCard, borderWidth: 1.5, borderColor: Colors.borderBlue,
    borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 15,
    fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: '#FFFFFF', letterSpacing: 2, textAlign: 'center', marginBottom: 8,
  },
  preview: { fontSize: FontSize.sm, color: Colors.textMuted, marginBottom: Spacing.md, fontWeight: FontWeight.medium },
  saveBtn: {
    width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: Colors.blueBright, borderRadius: Radius.md, paddingVertical: 16, marginTop: 4,
    shadowColor: Colors.blue, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.4, shadowRadius: 10, elevation: 5,
  },
  saveBtnDisabled: { backgroundColor: Colors.bgCardAlt, shadowOpacity: 0, elevation: 0, borderWidth: 1, borderColor: Colors.border },
  saveBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#000' },
  cancelText: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: FontWeight.medium },
  infoRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 5, marginTop: Spacing.md, paddingHorizontal: 8 },
  infoText: { flex: 1, fontSize: FontSize.xs, color: Colors.textMuted, lineHeight: 16, textAlign: 'center' },
});

// ─── ACCESS GATE STYLES ───────────────────────────────────────────────────────

const gate = StyleSheet.create({
  container: {
    backgroundColor: 'rgba(22,22,24,0.96)', borderRadius: Radius.xxl, padding: Spacing.lg,
    alignItems: 'center', borderWidth: 1, borderColor: Colors.borderSilver,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.5, shadowRadius: 12, elevation: 8,
  },
  lockCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(184,58,58,0.1)', borderWidth: 1.5, borderColor: 'rgba(184,58,58,0.3)', alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.md },
  title: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary, textAlign: 'center', marginBottom: Spacing.sm },
  sub: { fontSize: FontSize.sm, color: Colors.textSecondary, textAlign: 'center', lineHeight: 20, marginBottom: Spacing.md },
  phoneBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: Colors.bgCardAlt, borderRadius: Radius.full, paddingHorizontal: 14, paddingVertical: 8, borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.md },
  phoneText: { fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: Colors.textSecondary, letterSpacing: 1 },
  divider: { width: '100%', height: 1, backgroundColor: Colors.border, marginVertical: Spacing.md },
  contactLabel: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary, marginBottom: Spacing.sm },
  emailBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, backgroundColor: Colors.blueBright, borderRadius: Radius.md, paddingVertical: 14, paddingHorizontal: Spacing.xl, shadowColor: Colors.blue, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.4, shadowRadius: 8, elevation: 5 },
  emailBtnPressed: { opacity: 0.85, transform: [{ scale: 0.97 }] },
  emailBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#000' },
  infoRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 5, marginTop: Spacing.md, paddingHorizontal: 8 },
  infoText: { flex: 1, fontSize: FontSize.xs, color: Colors.textMuted, lineHeight: 16, textAlign: 'center' },
});
