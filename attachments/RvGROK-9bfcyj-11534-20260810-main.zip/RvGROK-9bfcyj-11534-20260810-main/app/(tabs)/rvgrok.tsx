
import {
  View, Text, StyleSheet, TextInput, Pressable, FlatList,
  KeyboardAvoidingView, Platform, ActivityIndicator, ScrollView, Modal,
  Alert, Animated, LayoutAnimation,
} from 'react-native';
import { useState, useRef, useCallback, useEffect } from 'react';

// ─── MIC TEST RESULT TYPE ────────────────────────────────────────────────────
interface MicTestResult {
  permissionGranted: boolean;
  highQuality: 'success' | 'failed' | 'pending';
  lowQuality: 'success' | 'failed' | 'skipped';
  highQualityError: string | null;
  lowQualityError: string | null;
  recordingUri: string | null;
  durationMs: number;
}
import AsyncStorage from '@react-native-async-storage/async-storage';

// expo-av for recording (STT) and audio playback (TTS)
let Audio: typeof import('expo-av').Audio | null = null;
try { Audio = require('expo-av').Audio; } catch { Audio = null; }
// expo-file-system for writing TTS audio to temp files
let FileSystem: typeof import('expo-file-system') | null = null;
try { FileSystem = require('expo-file-system'); } catch { FileSystem = null; }
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams } from 'expo-router';
import { getSupabaseClient, useAuth } from '@/template';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';

// ─── RUBY RED PALETTE (Entegra General) ───────────────────────────────────────
const Ruby = {
  primary:      '#C01F2E',
  bright:       '#D42535',
  glow:         '#E03040',
  dim:          '#7A1220',
  border:       'rgba(192,31,46,0.45)',
  borderBright: 'rgba(212,37,53,0.70)',
  surface:      'rgba(192,31,46,0.08)',
  surfaceMid:   'rgba(192,31,46,0.14)',
};

// ─── VOICE TYPES ─────────────────────────────────────────────────────────────

interface XaiVoice {
  id: string;
  name: string;
  description: string;
  gender: string;
  preview: string;
}

const VOICE_STORAGE_KEY = '@rvgrok_selected_voice';
const AGENT_MODE_KEY    = '@rvgrok_agent_mode';
const VOICE_SPEED_KEY   = '@rvgrok_voice_speed';
const VOICE_MODE_KEY    = '@rvgrok_voice_mode';
const DEFAULT_VOICE     = 'altair';

const SPEED_OPTIONS = [
  { label: 'Slow',   value: 0.75 },
  { label: 'Normal', value: 1.0  },
  { label: 'Fast',   value: 1.4  },
];

// ── REALTIME VOICE (xAI Realtime WebSocket via Cloudflare Worker ephemeral token) ──
const CLOUDFLARE_WORKER_URL = 'https://rv-assistant.soezrv.workers.dev/get-ephemeral-token';
const XAI_REALTIME_URL      = 'wss://api.x.ai/v1/realtime?model=grok-voice-latest';

// ─── TYPES ────────────────────────────────────────────────────────────────────

type MessageRole = 'user' | 'assistant';

export interface AgentStep {
  step: number;
  tool: string;
  input: Record<string, unknown>;
  result?: string;
  status: 'running' | 'done';
}

interface Message {
  id: string;
  role: MessageRole;
  content: string;
  streaming?: boolean;
  timestamp: Date;
  agentSteps?: AgentStep[];
  isAgentMode?: boolean;
}

interface ChatSession {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  messages: Message[];
}

// ─── STARTER PROMPTS ─────────────────────────────────────────────────────────

const STARTER_PROMPTS = [
  { icon: 'price-check',     label: 'Value a trade-in',  prompt: 'What factors most affect a 2022 Class A diesel trade-in value right now?' },
  { icon: 'warning',         label: 'Check recalls',     prompt: 'What are the most common NHTSA recalls for Thor Motor Coach in the last 3 years?' },
  { icon: 'calculate',       label: 'Loan breakdown',    prompt: 'Break down the financing on a $185,000 RV at 7.5% APR over 180 months with 20% down.' },
  { icon: 'compare-arrows',  label: 'Compare models',    prompt: 'Compare the Newmar Dutch Star vs Tiffin Phaeton for a full-time RV buyer with a $350k budget.' },
  { icon: 'build',           label: 'Maintenance tips',  prompt: 'What is the annual maintenance schedule for a Cummins ISL diesel coach?' },
  { icon: 'local-shipping',  label: 'Towing match',      prompt: 'What trucks can safely tow a 38-foot fifth wheel with a 16,000 lb GVWR?' },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function formatRelativeTime(dateStr: string): string {
  const now = Date.now();
  const then = new Date(dateStr).getTime();
  const diff = Math.floor((now - then) / 1000);
  if (diff < 60) return 'Just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

// ─── AGENT TOOL DISPLAY META ─────────────────────────────────────────────────

const TOOL_LABELS: Record<string, { label: string; icon: string; color: string }> = {
  analyze_requirements:      { label: 'Analyzing Requirements',  icon: 'manage-search', color: '#4DA6FF' },
  search_rv_models:          { label: 'Searching RV Models',     icon: 'search',        color: '#9B59F5' },
  get_model_details:         { label: 'Fetching Model Details',  icon: 'info',          color: '#00E676' },
  check_market_availability: { label: 'Checking Market Data',    icon: 'trending-up',   color: '#FFD700' },
};

// ─── AGENT STEPS CARD ────────────────────────────────────────────────────────

function AgentStepsCard({ steps }: { steps: AgentStep[] }) {
  const [expanded, setExpanded] = useState(false);
  if (!steps || steps.length === 0) return null;

  const doneCount  = steps.filter(s => s.status === 'done').length;
  const totalCount = steps.length;
  const allDone    = doneCount === totalCount && totalCount > 0;

  return (
    <View style={agentStyles.card}>
      <Pressable
        style={({ pressed }) => [agentStyles.cardHeader, pressed && { opacity: 0.8 }]}
        onPress={() => {
          LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setExpanded(p => !p);
        }}
      >
        <View style={agentStyles.headerLeft}>
          <View style={agentStyles.agentBadge}>
            <MaterialIcons name="auto-awesome" size={11} color={Ruby.bright} />
            <Text style={agentStyles.agentBadgeText}>AGENT</Text>
          </View>
          <Text style={agentStyles.headerTitle}>
            {allDone
              ? `Research complete · ${totalCount} step${totalCount !== 1 ? 's' : ''}`
              : `Running · ${doneCount}/${totalCount} steps`}
          </Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          {!allDone && <ActivityIndicator size="small" color={Ruby.bright} style={{ transform: [{ scale: 0.7 }] }} />}
          <MaterialIcons
            name={expanded ? 'keyboard-arrow-up' : 'keyboard-arrow-down'}
            size={16}
            color={Colors.textMuted}
          />
        </View>
      </Pressable>

      {expanded && (
        <View style={agentStyles.stepsWrap}>
          {steps.map((step) => {
            const meta = TOOL_LABELS[step.tool] ?? { label: step.tool, icon: 'build', color: '#888' };
            let resultPreview = '';
            if (step.result) {
              try {
                const parsed = JSON.parse(step.result);
                const keys = Object.keys(parsed).slice(0, 2);
                resultPreview = keys.map(k => {
                  const v = parsed[k];
                  return `${k}: ${typeof v === 'object' ? JSON.stringify(v).slice(0, 40) : String(v).slice(0, 40)}`;
                }).join(' · ');
              } catch {
                resultPreview = String(step.result).slice(0, 80);
              }
            }
            return (
              <View key={step.step} style={agentStyles.stepRow}>
                <View style={[agentStyles.stepIcon, { backgroundColor: meta.color + '18' }]}>
                  {step.status === 'running' ? (
                    <ActivityIndicator size="small" color={meta.color} style={{ transform: [{ scale: 0.75 }] }} />
                  ) : (
                    <MaterialIcons name={meta.icon as any} size={13} color={meta.color} />
                  )}
                </View>
                <View style={agentStyles.stepBody}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    <Text style={[agentStyles.stepLabel, { color: meta.color }]}>{meta.label}</Text>
                    {step.status === 'done' && (
                      <MaterialIcons name="check-circle" size={11} color={Colors.green} />
                    )}
                  </View>
                  {resultPreview ? (
                    <Text style={agentStyles.stepResult} numberOfLines={2}>{resultPreview}</Text>
                  ) : null}
                </View>
                <Text style={agentStyles.stepNum}>#{step.step}</Text>
              </View>
            );
          })}
        </View>
      )}
    </View>
  );
}

// ─── VOICE SELECTOR PANEL ────────────────────────────────────────────────────

function VoiceSelectorPanel({
  visible, voices, loading, selectedId, onClose, onSelect, onPreview, previewingId,
  voiceMode, onVoiceModeChange, playbackSpeed, onSpeedChange,
}: {
  visible: boolean; voices: XaiVoice[]; loading: boolean; selectedId: string;
  onClose: () => void; onSelect: (id: string) => void;
  onPreview: (voice: XaiVoice) => void; previewingId: string | null;
  voiceMode: boolean; onVoiceModeChange: (v: boolean) => void;
  playbackSpeed: number; onSpeedChange: (s: number) => void;
}) {
  const insets = useSafeAreaInsets();
  const GENDER_ICON: Record<string, string> = { female: 'person', male: 'person', neutral: 'record-voice-over' };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={voiceStyles.overlay}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={[voiceStyles.panel, { paddingBottom: insets.bottom + 16 }]}>
          <View style={voiceStyles.handle} />
          <View style={voiceStyles.header}>
            <MaterialIcons name="record-voice-over" size={18} color={Ruby.bright} />
            <Text style={voiceStyles.headerTitle}>RvGrok Voice</Text>
            <Text style={voiceStyles.headerSub}>Choose how RvGrok sounds</Text>
            <Pressable style={voiceStyles.closeBtn} onPress={onClose} hitSlop={8}>
              <MaterialIcons name="close" size={18} color={Colors.textSecondary} />
            </Pressable>
          </View>
          {/* ── Voice Mode Toggle ── */}
          <Pressable
            style={({ pressed }) => [voiceStyles.settingsRow, pressed && { opacity: 0.75 }]}
            onPress={() => onVoiceModeChange(!voiceMode)}
          >
            <View style={voiceStyles.settingsLeft}>
              <MaterialIcons name="mic" size={14} color={voiceMode ? Ruby.bright : Colors.textMuted} />
              <View style={{ flex: 1 }}>
                <Text style={[voiceStyles.settingsLabel, voiceMode && { color: Ruby.bright }]}>Voice Mode</Text>
                <Text style={voiceStyles.settingsHint}>Auto-play AI responses after every message</Text>
              </View>
            </View>
            <View style={[voiceStyles.toggleTrack, voiceMode && voiceStyles.toggleTrackOn]}>
              <View style={[voiceStyles.toggleThumb, voiceMode && voiceStyles.toggleThumbOn]} />
            </View>
          </Pressable>

          {/* ── Playback Speed ── */}
          <View style={voiceStyles.speedSection}>
            <Text style={voiceStyles.speedLabel}>PLAYBACK SPEED</Text>
            <View style={voiceStyles.speedRow}>
              {SPEED_OPTIONS.map(opt => (
                <Pressable
                  key={opt.value}
                  style={({ pressed }) => [voiceStyles.speedBtn, playbackSpeed === opt.value && voiceStyles.speedBtnActive, pressed && { opacity: 0.7 }]}
                  onPress={() => onSpeedChange(opt.value)}
                >
                  <Text style={[voiceStyles.speedBtnText, playbackSpeed === opt.value && voiceStyles.speedBtnTextActive]}>{opt.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          <Text style={voiceStyles.voiceListLabel}>VOICE</Text>

          {loading ? (
            <View style={voiceStyles.loadingWrap}>
              <ActivityIndicator color={Ruby.bright} />
              <Text style={voiceStyles.loadingText}>Loading voices...</Text>
            </View>
          ) : (
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.sm, paddingBottom: 8 }}>
              {voices.map(v => {
                const isSelected = selectedId === v.id;
                const isPreviewing = previewingId === v.id;
                return (
                  <Pressable
                    key={v.id}
                    style={({ pressed }) => [voiceStyles.voiceRow, isSelected && voiceStyles.voiceRowActive, pressed && { opacity: 0.8 }]}
                    onPress={() => onSelect(v.id)}
                  >
                    <View style={[voiceStyles.voiceAvatar, isSelected && voiceStyles.voiceAvatarActive]}>
                      <MaterialIcons name={(GENDER_ICON[v.gender] ?? 'record-voice-over') as any} size={18} color={isSelected ? '#fff' : Ruby.bright} />
                    </View>
                    <View style={voiceStyles.voiceBody}>
                      <View style={voiceStyles.voiceNameRow}>
                        <Text style={[voiceStyles.voiceName, isSelected && { color: Ruby.bright }]}>{v.name}</Text>
                        <View style={voiceStyles.genderChip}><Text style={voiceStyles.genderChipText}>{v.gender}</Text></View>
                        {isSelected && (
                          <View style={voiceStyles.selectedBadge}>
                            <MaterialIcons name="check" size={10} color="#fff" />
                            <Text style={voiceStyles.selectedBadgeText}>Active</Text>
                          </View>
                        )}
                      </View>
                      <Text style={voiceStyles.voiceDesc} numberOfLines={1}>{v.description}</Text>
                    </View>
                    <Pressable onPress={() => onPreview(v)} hitSlop={8}
                      style={({ pressed }) => [voiceStyles.previewBtn, isPreviewing && voiceStyles.previewBtnActive, pressed && { opacity: 0.7 }]}>
                      <MaterialIcons name={isPreviewing ? 'stop' : 'play-arrow'} size={16} color={isPreviewing ? '#fff' : Ruby.bright} />
                    </Pressable>
                  </Pressable>
                );
              })}
            </ScrollView>
          )}
          <View style={voiceStyles.footer}>
            <MaterialIcons name="info-outline" size={12} color={Colors.textDim} />
            <Text style={voiceStyles.footerText}>Voices powered by xAI · Tap a voice to select, play to preview</Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ─── MESSAGE BUBBLE ───────────────────────────────────────────────────────────

function MessageBubble({ message, onSpeak, speakingId }: {
  message: Message;
  onSpeak: (id: string, text: string) => void;
  speakingId: string | null;
}) {
  const isUser       = message.role === 'user';
  const isSpeaking   = speakingId === message.id;
  const hasAgentSteps = !isUser && message.isAgentMode && (message.agentSteps?.length ?? 0) > 0;
  const pulseAnim    = useRef(new Animated.Value(1)).current;
  const loopRef      = useRef<Animated.CompositeAnimation | null>(null);

  useEffect(() => {
    if (isSpeaking) {
      loopRef.current = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.25, duration: 600, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1.0,  duration: 600, useNativeDriver: true }),
        ])
      );
      loopRef.current.start();
    } else {
      loopRef.current?.stop();
      pulseAnim.setValue(1);
    }
    return () => { loopRef.current?.stop(); };
  }, [isSpeaking, pulseAnim]);

  return (
    <View style={[styles.messageRow, isUser && styles.messageRowUser]}>
      {!isUser && (
        <View style={styles.assistantAvatar}>
          <Image
            source={require('../../assets/rvfox-icon.jpg')}
            style={{ width: 32, height: 32, borderRadius: 16 }}
            contentFit="cover"
          />
        </View>
      )}

      <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAssistant]}>
        {/* Agent steps above message text */}
        {hasAgentSteps && <AgentStepsCard steps={message.agentSteps!} />}

        {!isUser && (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 2 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <Text style={styles.bubbleSender}>RvGrok · AI</Text>
              {message.isAgentMode && (
                <View style={agentStyles.agentBadgeInline}>
                  <MaterialIcons name="auto-awesome" size={9} color={Ruby.bright} />
                  <Text style={agentStyles.agentBadgeInlineText}>Agent</Text>
                </View>
              )}
            </View>
            {!message.streaming && message.content ? (
              <Pressable
                onPress={() => onSpeak(message.id, message.content)}
                hitSlop={8}
                style={({ pressed }) => [ttsBtn.btn, isSpeaking && ttsBtn.btnActive, pressed && { opacity: 0.7 }]}
              >
                <Animated.View style={{ transform: [{ scale: isSpeaking ? pulseAnim : 1 }] }}>
                  <MaterialIcons name={isSpeaking ? 'stop' : 'volume-up'} size={14} color={isSpeaking ? '#fff' : Ruby.bright} />
                </Animated.View>
              </Pressable>
            ) : null}
          </View>
        )}

        <Text style={[styles.bubbleText, isUser && styles.bubbleTextUser]}>
          {message.content}
        </Text>
        {message.streaming && (
          <View style={styles.streamingDots}>
            <View style={[styles.dot, styles.dot1]} />
            <View style={[styles.dot, styles.dot2]} />
            <View style={[styles.dot, styles.dot3]} />
          </View>
        )}
        <Text style={[styles.bubbleTime, isUser && styles.bubbleTimeUser]}>
          {message.timestamp instanceof Date
            ? message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            : new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    </View>
  );
}

// ─── HISTORY PANEL ───────────────────────────────────────────────────────────

function HistoryPanel({
  visible, sessions, loading, onClose, onLoad, onDelete, onNewChat,
}: {
  visible: boolean; sessions: ChatSession[]; loading: boolean;
  onClose: () => void; onLoad: (session: ChatSession) => void;
  onDelete: (id: string) => void; onNewChat: () => void;
}) {
  const insets = useSafeAreaInsets();

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={histStyles.overlay}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={[histStyles.panel, { paddingBottom: insets.bottom + 16 }]}>
          <View style={histStyles.handle} />
          <View style={histStyles.header}>
            <View style={histStyles.headerLeft}>
              <MaterialIcons name="history" size={18} color={Ruby.bright} />
              <Text style={histStyles.headerTitle}>Chat History</Text>
              {sessions.length > 0 && (
                <View style={histStyles.countBadge}>
                  <Text style={histStyles.countText}>{sessions.length}</Text>
                </View>
              )}
            </View>
            <Pressable style={({ pressed }) => [histStyles.closeBtn, pressed && { opacity: 0.6 }]} onPress={onClose} hitSlop={8}>
              <MaterialIcons name="close" size={18} color={Colors.textSecondary} />
            </Pressable>
          </View>
          <Pressable style={({ pressed }) => [histStyles.newChatBtn, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]} onPress={() => { onNewChat(); onClose(); }}>
            <MaterialIcons name="add" size={18} color="#fff" />
            <Text style={histStyles.newChatBtnText}>New Chat</Text>
          </Pressable>
          {loading ? (
            <View style={histStyles.emptyWrap}>
              <ActivityIndicator color={Ruby.bright} />
              <Text style={histStyles.emptyText}>Loading history...</Text>
            </View>
          ) : sessions.length === 0 ? (
            <View style={histStyles.emptyWrap}>
              <MaterialIcons name="chat-bubble-outline" size={36} color={Colors.textDim} />
              <Text style={histStyles.emptyText}>No saved chats yet</Text>
              <Text style={histStyles.emptySubText}>Your conversations will appear here</Text>
            </View>
          ) : (
            <FlatList
              data={sessions} keyExtractor={s => s.id}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ paddingBottom: 8 }}
              renderItem={({ item }) => (
                <Pressable
                  style={({ pressed }) => [histStyles.sessionItem, pressed && histStyles.sessionItemPressed]}
                  onPress={() => { onLoad(item); onClose(); }}
                >
                  <View style={histStyles.sessionIcon}><MaterialIcons name="chat" size={16} color={Ruby.bright} /></View>
                  <View style={histStyles.sessionBody}>
                    <Text style={histStyles.sessionTitle} numberOfLines={1}>{item.title}</Text>
                    <View style={histStyles.sessionMeta}>
                      <Text style={histStyles.sessionTime}>{formatRelativeTime(item.updated_at)}</Text>
                      <Text style={histStyles.sessionCount}>{item.messages?.length ?? 0} message{(item.messages?.length ?? 0) !== 1 ? 's' : ''}</Text>
                    </View>
                  </View>
                  <Pressable
                    style={({ pressed }) => [histStyles.deleteBtn, pressed && { opacity: 0.6 }]}
                    onPress={() => Alert.alert('Delete Chat', 'Remove this conversation?', [
                      { text: 'Cancel', style: 'cancel' },
                      { text: 'Delete', style: 'destructive', onPress: () => onDelete(item.id) },
                    ])}
                    hitSlop={8}
                  >
                    <MaterialIcons name="delete-outline" size={16} color={Colors.textMuted} />
                  </Pressable>
                </Pressable>
              )}
            />
          )}
        </View>
      </View>
    </Modal>
  );
}

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

export default function RvGrokScreen() {
  const insets = useSafeAreaInsets();
  const { prefill } = useLocalSearchParams<{ prefill?: string }>();
  const { user } = useAuth();

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeModel, setActiveModel] = useState<string | null>(null);
  const flatListRef = useRef<FlatList>(null);
  const didPrefill = useRef(false);

  // ── AGENT MODE ────────────────────────────────────────────────────────────
  const [agentMode, setAgentMode] = useState(false);
  const agentModeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    AsyncStorage.getItem(AGENT_MODE_KEY).then(v => {
      const on = v === 'true';
      setAgentMode(on);
      agentModeAnim.setValue(on ? 1 : 0);
    }).catch(() => {});
  }, []);

  const toggleAgentMode = useCallback(() => {
    const next = !agentMode;
    setAgentMode(next);
    Animated.timing(agentModeAnim, { toValue: next ? 1 : 0, duration: 260, useNativeDriver: false }).start();
    AsyncStorage.setItem(AGENT_MODE_KEY, String(next)).catch(() => {});
  }, [agentMode, agentModeAnim]);

  const agentBtnBg = agentModeAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['rgba(192,31,46,0.08)', 'rgba(192,31,46,0.30)'],
  });
  const agentBtnBorder = agentModeAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['rgba(192,31,46,0.28)', 'rgba(212,37,53,0.85)'],
  });

  // ── VOICE LIBRARY ─────────────────────────────────────────────────────────
  const [selectedVoice, setSelectedVoice] = useState<string>(DEFAULT_VOICE);
  const [voices, setVoices] = useState<XaiVoice[]>([]);
  const [voicesLoading, setVoicesLoading] = useState(false);
  const [voicePanelOpen, setVoicePanelOpen] = useState(false);
  const [previewingVoiceId, setPreviewingVoiceId] = useState<string | null>(null);
  const previewSoundRef = useRef<any>(null);
  const recordingRef = useRef<any>(null);

  useEffect(() => {
    AsyncStorage.getItem(VOICE_STORAGE_KEY).then(v => { if (v) setSelectedVoice(v); }).catch(() => {});
    AsyncStorage.getItem(VOICE_MODE_KEY).then(v => { if (v === 'true') setVoiceMode(true); }).catch(() => {});
    AsyncStorage.getItem(VOICE_SPEED_KEY).then(v => { const n = parseFloat(v ?? ''); if (!isNaN(n)) setPlaybackSpeed(n); }).catch(() => {});
  }, []);

  const fetchVoices = useCallback(async () => {
    if (voices.length > 0) return;
    setVoicesLoading(true);
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.functions.invoke('xai-voices', {});
      if (!error && data?.voices) setVoices(data.voices as XaiVoice[]);
    } catch { /* silent */ } finally { setVoicesLoading(false); }
  }, [voices.length]);

  const handleSelectVoice = useCallback((id: string) => {
    setSelectedVoice(id);
    AsyncStorage.setItem(VOICE_STORAGE_KEY, id).catch(() => {});
  }, []);

  const stopPreview = useCallback(async () => {
    if (previewSoundRef.current) {
      try { await previewSoundRef.current.stopAsync(); } catch { /* ignore */ }
      try { await previewSoundRef.current.unloadAsync(); } catch { /* ignore */ }
      previewSoundRef.current = null;
    }
    setPreviewingVoiceId(null);
  }, []);

  const handlePreviewVoice = useCallback(async (voice: XaiVoice) => {
    if (!Audio || !FileSystem) { Alert.alert('Not Available', 'Voice preview requires a full app build.'); return; }
    if (previewingVoiceId === voice.id) { await stopPreview(); return; }
    await stopPreview();
    setPreviewingVoiceId(voice.id);
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.functions.invoke('xai-tts', { body: { text: `Hi, I am ${voice.name}. Your RvGrok voice.`, voice: voice.id } });
      if (error || !data?.audio) {
        setPreviewingVoiceId(null);
        const errMsg = error?.message ?? 'No audio returned';
        Alert.alert('Preview Failed', `Could not preview voice: ${errMsg.slice(0, 150)}`);
        return;
      }
      const uri = FileSystem.cacheDirectory + `preview_${voice.id}.mp3`;
      await FileSystem.writeAsStringAsync(uri, data.audio, { encoding: FileSystem.EncodingType.Base64 });
      await Audio.setAudioModeAsync({ playsInSilentModeIOS: true, allowsRecordingIOS: false, staysActiveInBackground: false });
      const { sound } = await Audio.Sound.createAsync({ uri }, { shouldPlay: true });
      previewSoundRef.current = sound;
      sound.setOnPlaybackStatusUpdate((s: any) => { if (s.didJustFinish) { setPreviewingVoiceId(null); sound.unloadAsync().catch(() => {}); previewSoundRef.current = null; } });
    } catch (e: any) {
      setPreviewingVoiceId(null);
      Alert.alert('Preview Failed', e?.message ?? 'Could not preview voice.');
    }
  }, [previewingVoiceId, stopPreview]);

  // ── TTS ───────────────────────────────────────────────────────────────────
  // ── VOICE SESSION STATE ──
  const [voiceMode, setVoiceMode]               = useState(false);
  const [playbackSpeed, setPlaybackSpeed]       = useState(1.0);
  const [pendingVoiceSend, setPendingVoiceSend] = useState<string | null>(null);
  const voiceTriggered = useRef(false);
  const abortRef       = useRef<AbortController | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const ttsSound = useRef<any>(null);
  const handleSpeakRef = useRef<(id: string, text: string) => void>(() => {});
  const [isRecording, setIsRecording] = useState(false);
  const wsRef             = useRef<WebSocket | null>(null);
  const [realtimeStatus, setRealtimeStatus] = useState<string | null>(null);

  const stopTTS = useCallback(async () => {
    if (ttsSound.current) {
      try { await ttsSound.current.stopAsync(); } catch { /* ignore */ }
      try { await ttsSound.current.unloadAsync(); } catch { /* ignore */ }
      ttsSound.current = null;
    }
    setSpeakingId(null);
    // Reset audio session to neutral so iOS can cleanly acquire the recording session next
    if (Audio) {
      try {
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: false,
          playsInSilentModeIOS: true,
          staysActiveInBackground: false,
        });
      } catch { /* ignore */ }
    }
  }, []);

  // ── STOP ALL (mic + fetch + TTS) ────────────────────────────────────────────
  const handleStop = useCallback(async () => {
    // 1. Stop mic
    if (isRecording) {
      setIsRecording(false);
      if (recordingRef.current) {
        try { await recordingRef.current.stopAndUnloadAsync(); } catch { /* ignore */ }
        recordingRef.current = null;
      }
      try { await Audio?.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true }); } catch { /* ignore */ }
    }
    // 2. Cancel in-flight request
    abortRef.current?.abort();
    abortRef.current = null;
    setPendingVoiceSend(null);
    voiceTriggered.current = false;
    // 3. Stop TTS
    await stopTTS();
    setIsLoading(false);
    // 4. Close realtime WebSocket if open
    if (wsRef.current) {
      console.log('realtime: handleStop — closing WebSocket');
      wsRef.current.close();
      wsRef.current = null;
    }
    setRealtimeStatus(null);
  }, [isRecording, stopTTS]);

  const handleSpeak = useCallback(async (msgId: string, text: string) => {
    if (!Audio || !FileSystem) { Alert.alert('Not Available', 'TTS requires a full app build.'); return; }
    if (speakingId === msgId) { await stopTTS(); return; }
    await stopTTS();
    setSpeakingId(msgId);
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.functions.invoke('xai-tts', { body: { text: text.slice(0, 2000), voice: selectedVoice } });
      if (error) {
        setSpeakingId(null);
        const { FunctionsHttpError } = await import('@supabase/supabase-js');
        let msg = error.message ?? 'TTS request failed';
        if (error instanceof FunctionsHttpError) {
          try { msg = await error.context.text(); } catch { /* use message */ }
        }
        Alert.alert('Voice Error', `Could not generate speech.\n\n${msg.slice(0, 200)}`);
        return;
      }
      if (!data?.audio) {
        setSpeakingId(null);
        Alert.alert('Voice Error', 'No audio returned from the server. Please try again.');
        return;
      }
      const uri = FileSystem.cacheDirectory + `tts_${msgId}.mp3`;
      await FileSystem.writeAsStringAsync(uri, data.audio, { encoding: FileSystem.EncodingType.Base64 });
      await Audio.setAudioModeAsync({ playsInSilentModeIOS: true, allowsRecordingIOS: false, staysActiveInBackground: false });
      const { sound } = await Audio.Sound.createAsync({ uri }, { shouldPlay: false });
      ttsSound.current = sound;
      if (playbackSpeed !== 1.0) {
        try { await sound.setRateAsync(playbackSpeed, true); } catch { /* unsupported on some devices */ }
      }
      await sound.playAsync();
      sound.setOnPlaybackStatusUpdate((s: any) => {
        if (s.didJustFinish) {
          setSpeakingId(null);
          sound.unloadAsync().catch(() => {});
          ttsSound.current = null;
          // Reset session so mic can be acquired cleanly after playback completes
          Audio?.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true, staysActiveInBackground: false }).catch(() => {});
        }
      });
    } catch (e: any) {
      setSpeakingId(null);
      Alert.alert('Voice Error', e?.message ?? 'Unexpected TTS error. Please try again.');
    }
  }, [speakingId, selectedVoice, stopTTS, playbackSpeed]);

  // Stable ref so sendMessage can call handleSpeak without circular dep
  useEffect(() => { handleSpeakRef.current = handleSpeak; }, [handleSpeak]);

  useEffect(() => {
    return () => {
      stopTTS();
      stopPreview();
      if (wsRef.current) { wsRef.current.close(); wsRef.current = null; }
    };
  }, []);

  // ── MIC TEST MODE ─────────────────────────────────────────────────────────
  const [micTestVisible, setMicTestVisible] = useState(false);
  // Idle breathing animation
  useEffect(() => {
    if (messages.length === 0) {
      avatarBreathLoopRef.current = Animated.loop(
        Animated.sequence([
          Animated.timing(avatarBreathAnim, { toValue: 1.055, duration: 2400, useNativeDriver: true }),
          Animated.timing(avatarBreathAnim, { toValue: 0.970, duration: 2000, useNativeDriver: true }),
          Animated.timing(avatarBreathAnim, { toValue: 1.000, duration: 1800, useNativeDriver: true }),
        ])
      );
      avatarBreathLoopRef.current.start();
      badgeShimmerLoopRef.current = Animated.loop(
        Animated.sequence([
          Animated.timing(badgeShimmerAnim, { toValue: 1.0,  duration: 1700, useNativeDriver: true }),
          Animated.timing(badgeShimmerAnim, { toValue: 0.48, duration: 1700, useNativeDriver: true }),
        ])
      );
      badgeShimmerLoopRef.current.start();
    } else {
      avatarBreathLoopRef.current?.stop();
      badgeShimmerLoopRef.current?.stop();
      avatarBreathAnim.setValue(1);
      badgeShimmerAnim.setValue(0.72);
    }
    return () => {
      avatarBreathLoopRef.current?.stop();
      badgeShimmerLoopRef.current?.stop();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages.length]);
  const [micTestRunning, setMicTestRunning] = useState(false);
  const [micTestResult, setMicTestResult] = useState<MicTestResult | null>(null);

  const runMicTest = useCallback(async () => {
    if (!Audio || !FileSystem) {
      Alert.alert('Not Available', 'Mic test requires a full app build (not web preview).');
      return;
    }
    setMicTestRunning(true);
    setMicTestResult(null);
    const result: MicTestResult = {
      permissionGranted: false,
      highQuality: 'pending',
      lowQuality: 'skipped',
      highQualityError: null,
      lowQualityError: null,
      recordingUri: null,
      durationMs: 0,
    };
    try {
      // Step 1: Request permission
      const { granted } = await Audio.requestPermissionsAsync();
      result.permissionGranted = granted;
      if (!granted) { setMicTestResult(result); setMicTestRunning(false); return; }

      // Stop any active TTS
      await stopTTS();

      // Step 2: Configure audio session
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
        interruptionModeIOS: (Audio.InterruptionModeIOS?.DoNotMix ?? 1),
        shouldDuckAndroid: false,
        interruptionModeAndroid: (Audio.InterruptionModeAndroid?.DoNotMix ?? 1),
        playThroughEarpieceAndroid: false,
      });
      await new Promise<void>(r => setTimeout(r, 300));

      // Step 3: Try HIGH_QUALITY for 2s
      const startMs = Date.now();
      let testRec: any = null;
      try {
        const { recording } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
        testRec = recording;
        result.highQuality = 'success';
      } catch (e: any) {
        result.highQuality = 'failed';
        result.highQualityError = e?.message ?? String(e);
      }

      // If HIGH failed, try LOW
      if (result.highQuality === 'failed') {
        result.lowQuality = 'pending' as any;
        await new Promise<void>(r => setTimeout(r, 200));
        try {
          const { recording } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.LOW_QUALITY);
          testRec = recording;
          result.lowQuality = 'success';
        } catch (e2: any) {
          result.lowQuality = 'failed';
          result.lowQualityError = e2?.message ?? String(e2);
        }
      }

      // Record for 2 seconds then stop
      if (testRec) {
        await new Promise<void>(r => setTimeout(r, 2000));
        try {
          await testRec.stopAndUnloadAsync();
          result.recordingUri = testRec.getURI();
        } catch { /* ignore */ }
      }
      result.durationMs = Date.now() - startMs;

      // Reset audio mode
      try { await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true }); } catch { /* ignore */ }
    } catch (e: any) {
      result.highQualityError = e?.message ?? 'Unknown test error';
    }
    setMicTestResult(result);
    setMicTestRunning(false);
  }, [stopTTS]);

  // ── RECORDING ─────────────────────────────────────────────────────────────
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const pulseLoop = useRef<Animated.CompositeAnimation | null>(null);
  // Idle avatar breathing + badge shimmer (empty state only)
  const avatarBreathAnim    = useRef(new Animated.Value(1)).current;
  const badgeShimmerAnim    = useRef(new Animated.Value(0.72)).current;
  const avatarBreathLoopRef = useRef<Animated.CompositeAnimation | null>(null);
  const badgeShimmerLoopRef = useRef<Animated.CompositeAnimation | null>(null);

  useEffect(() => {
    if (isRecording) {
      pulseLoop.current = Animated.loop(Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.35, duration: 550, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1.0,  duration: 550, useNativeDriver: true }),
      ]));
      pulseLoop.current.start();
    } else { pulseLoop.current?.stop(); pulseAnim.setValue(1); }
    return () => { pulseLoop.current?.stop(); };
  }, [isRecording, pulseAnim]);

  const handleMicPress = useCallback(async () => {
    if (!Audio || !FileSystem) { Alert.alert('Voice Input', 'Requires a full app build.'); return; }
    if (Platform.OS === 'web') { Alert.alert('Not Available', 'Voice input is only available on iOS/Android.'); return; }

    if (isRecording) {
      // Stop recording first, then grab URI
      setIsRecording(false);
      const rec = recordingRef.current;
      recordingRef.current = null;
      if (!rec) return;
      try {
        await rec.stopAndUnloadAsync();
        // Reset audio mode back to playback after recording stops
        await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true });
        const uri = rec.getURI();
        if (!uri) return;
        const base64Audio = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
        if (!base64Audio || base64Audio.length < 100) return; // too short — no speech captured
        const supabase = getSupabaseClient();
        // Route to xAI Realtime WebSocket (ephemeral token via Cloudflare Worker)
        void handleRealtimeVoice(base64Audio);
      } catch (e) { console.warn('STT stop error:', e); }
      return;
    }

    // Start recording
    // Stop any active TTS first — iOS cannot record while the audio session is in playback mode
    await stopTTS();

    // Ensure no stale recording is still holding the audio session
    if (recordingRef.current) {
      try { await recordingRef.current.stopAndUnloadAsync(); } catch { /* ignore */ }
      recordingRef.current = null;
    }

    try {
      const { granted } = await Audio.requestPermissionsAsync();
      if (!granted) { Alert.alert('Mic Access Required', 'Allow microphone access in Settings to use voice input.'); return; }

      // Configure audio session for recording.
      // Use numeric 1 (DoNotMix) instead of enum — enum may be undefined in expo-av SDK 52.
      // NOTE: no staysActiveInBackground — conflicts with iOS recording session category.
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
        interruptionModeIOS: (Audio.InterruptionModeIOS?.DoNotMix ?? 1),
        shouldDuckAndroid: false,
        interruptionModeAndroid: (Audio.InterruptionModeAndroid?.DoNotMix ?? 1),
        playThroughEarpieceAndroid: false,
      });
      // Give iOS 300 ms to fully release playback session and acquire record session.
      await new Promise<void>(resolve => setTimeout(resolve, 300));

      // Try HIGH_QUALITY first; fall back to LOW_QUALITY with extra delay on constrained devices.
      let recording: any;
      try {
        const result = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
        recording = result.recording;
      } catch (hqErr: any) {
        console.warn('STT HIGH_QUALITY failed:', hqErr?.message ?? hqErr);
        await new Promise<void>(resolve => setTimeout(resolve, 200));
        const result = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.LOW_QUALITY);
        recording = result.recording;
      }

      recordingRef.current = recording;
      setIsRecording(true);
    } catch (e: any) {
      console.warn('STT start error:', e?.message ?? e);
      // Reset audio session back to playback if recording failed
      try { await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true }); } catch { /* ignore */ }
      // Build a diagnostic-friendly error message
      const errMsg = (e as any)?.message ?? String(e) ?? 'Unknown error';
      const platformHint = Platform.OS === 'ios'
        ? 'iOS audio session could not be acquired. Try: force-quit other audio apps, toggle silent mode off, or restart the app.'
        : 'Android mic unavailable. Ensure no other app is using the mic and retry.';
      Alert.alert(
        'Microphone Error',
        `${platformHint}\n\nDetails: ${errMsg}\n\nTip: Long-press the voice icon to run a mic diagnostic.`,
        [{ text: 'OK' }]
      );
    }
  }, [isRecording, stopTTS]);

  // ── SESSIONS ──────────────────────────────────────────────────────────────
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [loadingSessions, setLoadingSessions] = useState(false);

  const firstName = user?.username && !user.username.startsWith('user_') ? user.username.split(' ')[0] : null;

  const fetchSessions = useCallback(async () => {
    if (!user) return;
    setLoadingSessions(true);
    try {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase.from('rvgrok_sessions').select('id, title, created_at, updated_at, messages').eq('user_id', user.id).order('updated_at', { ascending: false }).limit(50);
      if (!error && data) setSessions(data as ChatSession[]);
    } catch { /* silent */ } finally { setLoadingSessions(false); }
  }, [user]);

  useEffect(() => { if (user) fetchSessions(); }, [user, fetchSessions]);

  const saveSession = useCallback(async (msgs: Message[], existingId: string | null) => {
    if (!user || msgs.length === 0) return existingId;
    const title = msgs.find(m => m.role === 'user')?.content.slice(0, 60) ?? 'New Chat';
    const serialized = msgs.map(m => ({ ...m, timestamp: m.timestamp instanceof Date ? m.timestamp.toISOString() : m.timestamp }));
    try {
      const supabase = getSupabaseClient();
      if (existingId) {
        await supabase.from('rvgrok_sessions').update({ title, messages: serialized, updated_at: new Date().toISOString() }).eq('id', existingId).eq('user_id', user.id);
        return existingId;
      } else {
        const { data, error } = await supabase.from('rvgrok_sessions').insert({ user_id: user.id, title, messages: serialized }).select('id').single();
        if (!error && data) return (data as { id: string }).id;
      }
    } catch { /* silent */ }
    return existingId;
  }, [user]);

  const deleteSession = useCallback(async (id: string) => {
    setSessions(prev => prev.filter(s => s.id !== id));
    if (sessionId === id) { setMessages([]); setSessionId(null); }
    try { const supabase = getSupabaseClient(); await supabase.from('rvgrok_sessions').delete().eq('id', id).eq('user_id', user!.id); } catch { /* silent */ }
  }, [sessionId, user]);

  const loadSession = useCallback((session: ChatSession) => {
    const revived: Message[] = (session.messages ?? []).map(m => ({ ...m, timestamp: new Date(m.timestamp as any) }));
    setMessages(revived); setSessionId(session.id);
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: false }), 150);
  }, []);

  const startNewChat = useCallback(() => {
    setMessages([]); setSessionId(null); setInput(''); didPrefill.current = false; fetchSessions();
  }, [fetchSessions]);

  const scrollToBottom = useCallback(() => {
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
  }, []);

  // ── REALTIME VOICE HANDLER ────────────────────────────────────────────────
  const handleRealtimeVoice = useCallback(async (base64Audio: string) => {
    console.log('realtime: starting voice flow — base64 length =', base64Audio.length);
    setRealtimeStatus('Connecting…');

    // Add placeholder messages immediately
    const userMsgId = `u-rt-${Date.now()}`;
    const asstMsgId = `a-rt-${Date.now()}`;
    const userMsg: Message = { id: userMsgId, role: 'user',      content: '🎤 Voice message…',  timestamp: new Date() };
    const asstMsg: Message = { id: asstMsgId, role: 'assistant', content: '',                   streaming: true, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg, asstMsg]);
    scrollToBottom();

    try {
      // ── Step 1: Fetch ephemeral token from Cloudflare Worker ──────────────
      console.log('realtime: fetching ephemeral token from', CLOUDFLARE_WORKER_URL);
      const tokenResp = await fetch(CLOUDFLARE_WORKER_URL);
      console.log('realtime: Worker HTTP status =', tokenResp.status);
      if (!tokenResp.ok) throw new Error(`Worker returned HTTP ${tokenResp.status}`);

      const tokenBody = await tokenResp.json();
      console.log('realtime: Worker response keys =', Object.keys(tokenBody ?? {}).join(', '));

      // Support both response shapes the Worker may return
      const token: string = tokenBody?.value || tokenBody?.client_secret?.value;

      if (!token) throw new Error('No usable token in Worker response: ' + JSON.stringify(tokenBody).slice(0, 120));
      console.log('realtime: ephemeral token received, length =', token.length);

      // ── Step 2: Open WebSocket with xai-client-secret subprotocol ────────
      const subprotocol = 'xai-client-secret.' + token;
      console.log('realtime: opening WebSocket to', XAI_REALTIME_URL);
      console.log('realtime: subprotocol prefix = xai-client-secret.<token>');

      const ws = new WebSocket(XAI_REALTIME_URL, [subprotocol]);
      wsRef.current = ws;

      let asstText = '';

      ws.onopen = () => {
        console.log('realtime: WebSocket OPENED');
        setRealtimeStatus('Streaming…');

        // Configure session
        const sessionConfig = {
          type: 'session.update',
          session: {
            modalities: ['text', 'audio'],
            instructions: 'You are RvGrok, a professional RV intelligence assistant built into RvFOX Pro. Answer questions about RVs, towing, specs, pricing, recalls, and maintenance concisely and accurately.',
            voice: selectedVoice,
            input_audio_format: 'pcm16',
            output_audio_format: 'pcm16',
            input_audio_transcription: { model: 'whisper-1' },
            turn_detection: null,
          },
        };
        console.log('realtime: sending session.update (voice =', selectedVoice, ')');
        ws.send(JSON.stringify(sessionConfig));

        // ── Step 3: Stream recorded audio as base64 PCM16 chunks ───────────
        const CHUNK = 16384; // 16 KB per chunk
        let chunkCount = 0;
        for (let i = 0; i < base64Audio.length; i += CHUNK) {
          ws.send(JSON.stringify({
            type: 'input_audio_buffer.append',
            audio: base64Audio.slice(i, i + CHUNK),
          }));
          chunkCount++;
        }
        console.log('realtime: sent', chunkCount, 'audio buffer chunks (', base64Audio.length, 'chars total)');

        // ── Step 4: Commit buffer and request response ──────────────────────
        ws.send(JSON.stringify({ type: 'input_audio_buffer.commit' }));
        console.log('realtime: input_audio_buffer.commit sent');

        ws.send(JSON.stringify({ type: 'response.create' }));
        console.log('realtime: response.create sent — waiting for Grok…');
        setRealtimeStatus('Processing…');
      };

      ws.onmessage = (evt) => {
        try {
          const msg = JSON.parse(evt.data as string);
          console.log('realtime: event =', msg.type);

          switch (msg.type) {
            case 'session.created':
              console.log('realtime: session.created — id =', msg.session?.id);
              break;
            case 'session.updated':
              console.log('realtime: session.updated');
              break;
            case 'input_audio_buffer.committed':
              console.log('realtime: audio buffer committed — item_id =', msg.item_id);
              break;
            case 'conversation.item.input_audio_transcription.completed':
              console.log('realtime: user transcript =', (msg.transcript ?? '').slice(0, 120));
              setMessages(prev => prev.map(m =>
                m.id === userMsgId ? { ...m, content: msg.transcript || '🎤 Voice message' } : m));
              break;
            case 'response.audio_transcript.delta':
              asstText += msg.delta ?? '';
              setMessages(prev => prev.map(m =>
                m.id === asstMsgId ? { ...m, content: asstText, streaming: true } : m));
              scrollToBottom();
              break;
            case 'response.audio_transcript.done':
              asstText = msg.transcript ?? asstText;
              console.log('realtime: assistant audio transcript done =', asstText.slice(0, 120));
              setMessages(prev => prev.map(m =>
                m.id === asstMsgId ? { ...m, content: asstText, streaming: false } : m));
              break;
            case 'response.text.delta':
              asstText += msg.delta ?? '';
              setMessages(prev => prev.map(m =>
                m.id === asstMsgId ? { ...m, content: asstText, streaming: true } : m));
              scrollToBottom();
              break;
            case 'response.text.done':
              asstText = msg.text ?? asstText;
              console.log('realtime: text done =', asstText.slice(0, 120));
              setMessages(prev => prev.map(m =>
                m.id === asstMsgId ? { ...m, content: asstText, streaming: false } : m));
              break;
            case 'response.audio.delta':
              // PCM16 audio delta — acknowledged but not played (TTS pipeline handles voice output)
              break;
            case 'response.audio.done':
              console.log('realtime: audio stream done');
              break;
            case 'response.done':
              console.log('realtime: response.done — full turn complete');
              setRealtimeStatus(null);
              if (asstText) {
                const finalMsgs = [userMsg, { ...asstMsg, content: asstText, streaming: false }];
                setMessages(prev => {
                  const updated = prev.map(m => m.id === asstMsgId ? { ...m, content: asstText, streaming: false } : m);
                  saveSession(updated, sessionId).then(newId => {
                    if (newId && newId !== sessionId) setSessionId(newId);
                    fetchSessions();
                  }).catch(() => {});
                  return updated;
                });
                if (voiceMode && asstText) handleSpeakRef.current(asstMsgId, asstText);
              }
              ws.close();
              break;
            case 'error':
              console.error('realtime: server error =', JSON.stringify(msg.error ?? msg).slice(0, 300));
              setRealtimeStatus(null);
              setMessages(prev => prev.map(m =>
                m.id === asstMsgId
                  ? { ...m, content: `Realtime error: ${msg.error?.message ?? JSON.stringify(msg.error ?? 'Unknown')}`, streaming: false }
                  : m));
              break;
            default:
              console.log('realtime: unhandled event type =', msg.type, '| keys =', Object.keys(msg).join(', '));
          }
        } catch (parseErr) {
          console.error('realtime: failed to parse server message =', parseErr);
        }
      };

      ws.onerror = () => {
        console.error('realtime: WebSocket onerror fired — see network logs for details');
        setRealtimeStatus(null);
        setMessages(prev => prev.map(m =>
          m.id === asstMsgId ? { ...m, content: 'WebSocket connection error — check console logs.', streaming: false } : m));
      };

      ws.onclose = (evt) => {
        console.log('realtime: WebSocket CLOSED — code =', evt.code, '| reason =', (evt.reason ?? '(none)').slice(0, 100));
        wsRef.current = null;
        setRealtimeStatus(null);
      };

    } catch (err: any) {
      console.error('realtime: fatal error =', err?.message ?? String(err));
      setRealtimeStatus(null);
      if (wsRef.current) { wsRef.current.close(); wsRef.current = null; }
      setMessages(prev => prev.map(m =>
        m.id === asstMsgId ? { ...m, content: `Connection failed: ${err?.message ?? 'Unknown error'}`, streaming: false } : m));
    }
  }, [selectedVoice, voiceMode, sessionId, saveSession, fetchSessions, scrollToBottom]);

  // ── SEND MESSAGE ──────────────────────────────────────────────────────────
  const sendMessage = useCallback(async (text?: string) => {
    const messageText = (text ?? input).trim();
    if (!messageText || isLoading) return;
    setInput('');

    const userMsg: Message = { id: `u-${Date.now()}`, role: 'user', content: messageText, timestamp: new Date() };
    const assistantMsgId = `a-${Date.now()}`;
    const assistantMsg: Message = {
      id: assistantMsgId, role: 'assistant', content: '', streaming: true,
      timestamp: new Date(), isAgentMode: agentMode, agentSteps: [],
    };

    const updatedMessages = [...messages, userMsg, assistantMsg];
    setMessages(updatedMessages);
    setIsLoading(true);
    scrollToBottom();

    try {
      const history = [...messages, userMsg].slice(-10).map(m => ({ role: m.role, content: m.content }));
      const supabase = getSupabaseClient();
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData?.session?.access_token;

      const endpoint = agentMode ? 'rvgrok-agent' : 'rvgrok-chat';

      // AbortController so Stop button can cancel mid-stream
      const controller = new AbortController();
      abortRef.current = controller;

      const response = await fetch(
        `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/${endpoint}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token ?? process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY}`,
            'apikey': process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '',
          },
          body: JSON.stringify({ messages: history }),
          signal: controller.signal,
        }
      );

      abortRef.current = null;
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const modelUsed = response.headers.get('X-Model-Used');
      if (modelUsed) setActiveModel(modelUsed);
      if (agentMode) setActiveModel('grok-4.5 · Agent');

      const reader = response.body?.getReader();
      let fullContent = '';
      const liveSteps: AgentStep[] = [];

      const processLine = (line: string) => {
        if (!line.startsWith('data: ')) return;
        const raw = line.slice(6).trim();
        if (raw === '[DONE]') return;
        try {
          const parsed = JSON.parse(raw);

          if (agentMode) {
            if (parsed.type === 'step') {
              const idx = liveSteps.findIndex(s => s.step === parsed.step);
              const stepObj: AgentStep = {
                step: parsed.step, tool: parsed.tool,
                input: parsed.input ?? {}, result: parsed.result, status: parsed.status,
              };
              if (idx >= 0) { liveSteps[idx] = stepObj; } else { liveSteps.push(stepObj); }
              setMessages(prev => prev.map(m => m.id === assistantMsgId
                ? { ...m, agentSteps: [...liveSteps], streaming: true } : m));
              scrollToBottom();
              return;
            }
            if (parsed.type === 'delta') {
              const delta = parsed.content ?? '';
              if (delta) {
                fullContent += delta;
                setMessages(prev => prev.map(m => m.id === assistantMsgId
                  ? { ...m, content: fullContent, agentSteps: [...liveSteps], streaming: true } : m));
                scrollToBottom();
              }
              return;
            }
            return; // ignore agent_start / agent_error events
          }

          // Regular chat streaming
          const delta = parsed.choices?.[0]?.delta?.content ?? '';
          if (delta) {
            fullContent += delta;
            setMessages(prev => prev.map(m => m.id === assistantMsgId ? { ...m, content: fullContent, streaming: true } : m));
            scrollToBottom();
          }
        } catch { /* skip */ }
      };

      if (reader) {
        const decoder = new TextDecoder();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          for (const line of chunk.split('\n')) processLine(line);
        }
      } else {
        const fullText = await response.text();
        for (const line of fullText.split('\n')) processLine(line);
      }

      const finalMessages = [...messages, userMsg, {
        id: assistantMsgId,
        role: 'assistant' as MessageRole,
        content: fullContent || (agentMode ? 'Agent completed research. No summary generated.' : 'Unable to generate a response. Please try again.'),
        streaming: false,
        timestamp: new Date(),
        isAgentMode: agentMode,
        agentSteps: [...liveSteps],
      }];

      setMessages(finalMessages);

      // Auto-speak: voice-triggered turn OR voice mode enabled
      const shouldSpeak = voiceTriggered.current || voiceMode;
      voiceTriggered.current = false;
      if (shouldSpeak && fullContent && !controller.signal.aborted) {
        handleSpeakRef.current(assistantMsgId, fullContent);
      }

      const newId = await saveSession(finalMessages, sessionId);
      if (newId && newId !== sessionId) setSessionId(newId);
      fetchSessions();

    } catch (err: any) {
      setMessages(prev => prev.map(m => m.id === assistantMsgId
        ? { ...m, content: `Error: ${err?.message ?? 'Failed to connect'}. Please try again.`, streaming: false } : m));
      voiceTriggered.current = false;
    } finally {
      setIsLoading(false);
      scrollToBottom();
    }
  }, [input, messages, isLoading, scrollToBottom, sessionId, saveSession, fetchSessions, agentMode, voiceMode]);

  // Auto-send voice transcript once sendMessage is in scope
  useEffect(() => {
    if (!pendingVoiceSend || isLoading || isRecording) return;
    const text = pendingVoiceSend;
    setPendingVoiceSend(null);
    sendMessage(text);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingVoiceSend, isLoading, isRecording]);

  // When arriving from rv-detail, just pre-fill a short greeting — don't auto-send the full RV summary
  useEffect(() => {
    if (prefill && !didPrefill.current) {
      didPrefill.current = true;
      // Extract RV name from prefill ("Tell me everything about the YEAR MAKE MODEL — ...") 
      const match = prefill.match(/about the (.+?) —/);
      const rvName = match ? match[1] : '';
      const greeting = rvName ? `How can I help with your ${rvName}?` : 'How can I help you today?';
      // Pre-fill input with context but show greeting as initial assistant message
      const welcomeMsg: Message = {
        id: `w-${Date.now()}`,
        role: 'assistant',
        content: greeting,
        timestamp: new Date(),
      };
      setMessages([welcomeMsg]);
      // Put the full prefill in the input box so user can send or edit it
      setInput(prefill);
    }
  }, [prefill]);

  return (
    <KeyboardAvoidingView
      style={[styles.container, { paddingTop: insets.top }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? insets.top : 0}
    >
      {/* RUBY HERO BACKDROP */}
      <View style={styles.heroBackdrop}>
        <Image source={require('../../assets/backscreen.jpg')} style={StyleSheet.absoluteFill} contentFit="cover" contentPosition={{ x: 0.5, y: 0.15 }} transition={400} />
        <LinearGradient colors={['rgba(30,46,64,0.70)', 'rgba(20,38,72,0.28)', 'rgba(20,38,72,0.22)', 'rgba(30,46,64,0.40)', 'rgba(18,28,50,0.76)']} locations={[0, 0.18, 0.5, 0.82, 1]} style={StyleSheet.absoluteFill} />
      </View>

      {/* HEADER */}
      <View style={styles.header}>
        <Pressable style={({ pressed }) => [styles.historyBtn, pressed && { opacity: 0.6 }]} onPress={() => { fetchSessions(); setHistoryOpen(true); }} hitSlop={8}>
          <MaterialIcons name="history" size={20} color={Ruby.bright} />
          {sessions.length > 0 && (
            <View style={styles.historyCountDot}>
              <Text style={styles.historyCountDotText}>{sessions.length > 99 ? '99' : sessions.length}</Text>
            </View>
          )}
        </Pressable>

        <View style={styles.headerCenter}>
          <View style={styles.headerIconWrap}>
            <Image source={require('../../assets/rvfox-icon.jpg')} style={{ width: 40, height: 40, borderRadius: 20 }} contentFit="cover" />
          </View>
          <View>
            <Text style={styles.headerTitle}>RvGrok</Text>
            <Text style={styles.headerSub}>AI RV Expert · RvFOX Pro</Text>
          </View>
        </View>

        <View style={styles.headerRight}>
          <View style={styles.onlineDot} />
          {/* Agent Mode toggle */}
          <Pressable style={({ pressed }) => [pressed && { opacity: 0.75 }]} onPress={toggleAgentMode} hitSlop={6}>
            <Animated.View style={[styles.agentToggleBtn, { backgroundColor: agentBtnBg, borderColor: agentBtnBorder }]}>
              <MaterialIcons name="auto-awesome" size={13} color={agentMode ? Ruby.bright : Colors.textMuted} />
              <Text style={[styles.agentToggleText, agentMode && { color: Ruby.bright }]}>Agent</Text>
            </Animated.View>
          </Pressable>
          {/* Voice selector */}
          <Pressable style={({ pressed }) => [styles.voiceBtn, pressed && { opacity: 0.7 }]} onPress={() => { fetchVoices(); setVoicePanelOpen(true); }} hitSlop={8}>
            <MaterialIcons name="record-voice-over" size={16} color={Ruby.bright} />
          </Pressable>
          {messages.length > 0 && (
            <Pressable style={({ pressed }) => [styles.clearBtn, pressed && { opacity: 0.6 }]} onPress={startNewChat} hitSlop={8}>
              <MaterialIcons name="add-comment" size={18} color={Colors.textSecondary} />
            </Pressable>
          )}
          {/* Mic test — long-press the mic icon in header */}
          <Pressable
            style={({ pressed }) => [styles.micTestBtn, pressed && { opacity: 0.6 }]}
            onPress={() => { setMicTestVisible(true); }}
            hitSlop={8}
          >
            <MaterialIcons name="mic-none" size={16} color={Colors.textMuted} />
            <MaterialIcons name="science" size={10} color={Colors.textDim} style={{ marginLeft: -4, marginTop: -8 }} />
          </Pressable>
        </View>
      </View>

      <View style={styles.headerDivider} />

      {sessionId && messages.length > 0 && (
        <View style={styles.sessionStrip}>
          <MaterialIcons name="chat" size={11} color={Ruby.bright} />
          <Text style={styles.sessionStripText} numberOfLines={1}>
            {messages.find(m => m.role === 'user')?.content.slice(0, 50) ?? 'Current session'}
          </Text>
          {agentMode && (
            <View style={agentStyles.sessionBadge}>
              <MaterialIcons name="auto-awesome" size={9} color={Ruby.bright} />
              <Text style={agentStyles.sessionBadgeText}>Agent</Text>
            </View>
          )}
        </View>
      )}

      {/* MESSAGES OR EMPTY STATE */}
      {messages.length === 0 ? (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.emptyContainer} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <View style={styles.emptyHero}>
            <Animated.View style={[styles.emptyAvatarOuter, { transform: [{ scale: avatarBreathAnim }] }]}>
              <View style={styles.emptyAvatarInner}>
                <Image source={require('../../assets/rvfox-icon.jpg')} style={{ width: 56, height: 56, borderRadius: 28 }} contentFit="cover" />
              </View>
            </Animated.View>
            <Text style={styles.emptyTitle}>RvGrok · AI Expert</Text>
            <Text style={styles.emptySubtitle}>
              {firstName ? `Hey ${firstName}, what can I help you with today?` : 'Your professional RV intelligence companion.'}
              {'\n'}Ask anything about specs, pricing, financing, recalls, or towing.
            </Text>
            <Animated.View style={[styles.emptyBadge, { opacity: badgeShimmerAnim }]}>
              <MaterialIcons name="auto-awesome" size={12} color={Ruby.bright} />
              <Text style={styles.emptyBadgeText}>
                {activeModel ? `Powered by xAI · ${activeModel.replace('grok-', 'Grok ').replace('-', '.')}` : 'Powered by xAI · Grok 4.5'}
              </Text>
            </Animated.View>
            {agentMode && (
              <View style={agentStyles.agentModeHeroBadge}>
                <MaterialIcons name="auto-awesome" size={14} color={Ruby.bright} />
                <Text style={agentStyles.agentModeHeroText}>Agent Mode Active — Multi-Step Research</Text>
              </View>
            )}
          </View>

          {agentMode ? (
            <>
              <Text style={[styles.starterLabel, { textAlign: 'center', marginBottom: Spacing.sm }]}>AGENT QUERY EXAMPLES</Text>
              <View style={agentStyles.agentSuggestions}>
                {[
                  'Find me a 2022–2023 Newmar Dutch Star under $350k with under 20k miles',
                  'Compare Tiffin Allegro Bus vs Entegra Cornerstone for a full-time couple on $500k budget',
                  'Best Class A diesel under $200k with 3 slides and a king bed — top 3 options',
                ].map((q, i) => (
                  <Pressable key={i} style={({ pressed }) => [agentStyles.agentQueryChip, pressed && { opacity: 0.75 }]} onPress={() => sendMessage(q)}>
                    <MaterialIcons name="auto-awesome" size={12} color={Ruby.bright} />
                    <Text style={agentStyles.agentQueryText} numberOfLines={2}>{q}</Text>
                    <MaterialIcons name="arrow-forward" size={13} color={Colors.textMuted} />
                  </Pressable>
                ))}
              </View>
            </>
          ) : (
            <>
              <Text style={styles.starterLabel}>SUGGESTED QUESTIONS</Text>
              <View style={styles.starterGrid}>
                {STARTER_PROMPTS.map((sp, i) => (
                  <Pressable key={i} style={({ pressed }) => [styles.starterCard, pressed && styles.starterCardPressed]} onPress={() => sendMessage(sp.prompt)}>
                    <MaterialIcons name={sp.icon as any} size={18} color={Ruby.bright} />
                    <Text style={styles.starterCardText}>{sp.label}</Text>
                    <MaterialIcons name="arrow-forward" size={14} color={Colors.textMuted} />
                  </Pressable>
                ))}
              </View>
            </>
          )}

          <Text style={styles.disclaimerText}>
            AI-generated content is for informational purposes only. Always verify data before use in transactions.
          </Text>
        </ScrollView>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={m => m.id}
          renderItem={({ item }) => <MessageBubble message={item} onSpeak={handleSpeak} speakingId={speakingId} />}
          contentContainerStyle={styles.messageList}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={scrollToBottom}
          keyboardShouldPersistTaps="handled"
        />
      )}

      {/* INPUT BAR */}
      <View style={[styles.inputBar, { paddingBottom: insets.bottom + Spacing.sm }]}>
        {/* Persistent STOP bar — visible whenever session is active */}
        {(isRecording || isLoading || speakingId !== null) && (
          <Pressable
            style={({ pressed }) => [styles.stopBar, pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] }]}
            onPress={handleStop}
          >
            <View style={styles.stopBarIcon}>
              <MaterialIcons name="stop" size={18} color="#fff" />
            </View>
            <Text style={styles.stopBarLabel}>
              {isRecording ? 'Recording — tap to stop & send'
                : isLoading ? 'Processing — tap to cancel'
                : 'Speaking — tap to stop audio'}
            </Text>
            <Text style={styles.stopBarHint}>STOP</Text>
          </Pressable>
        )}

        {realtimeStatus !== null && (
          <View style={styles.realtimeStrip}>
            <ActivityIndicator size="small" color="#4DA6FF" style={{ transform: [{ scale: 0.75 }] }} />
            <Text style={styles.realtimeText}>{realtimeStatus}</Text>
            <Pressable onPress={handleStop} hitSlop={8}><Text style={styles.recordingStop}>Stop</Text></Pressable>
          </View>
        )}
        {isRecording && (
          <View style={styles.recordingStrip}>
            <View style={styles.recordingDot} />
            <Text style={styles.recordingText}>Listening… tap Stop when done</Text>
            <Pressable onPress={() => handleStop()} hitSlop={8}><Text style={styles.recordingStop}>Stop</Text></Pressable>
          </View>
        )}

        <View style={[styles.inputRow, isRecording && styles.inputRowRecording]}>
          <TextInput
            style={styles.textInput}
            placeholder={isRecording ? 'Listening…' : agentMode ? 'Ask Agent to research anything...' : 'Ask RvGrok anything about RVs...'}
            placeholderTextColor={isRecording ? Ruby.bright : Colors.textMuted}
            value={input} onChangeText={setInput}
            multiline maxLength={1000} returnKeyType="send"
            blurOnSubmit={false} contextMenuHidden={false}
            onSubmitEditing={() => sendMessage()}
          />
          <Pressable style={({ pressed }) => [styles.micButton, isRecording && styles.micButtonActive, pressed && !isRecording && { opacity: 0.7 }]} onPress={handleMicPress} hitSlop={4}>
            <Animated.View style={{ transform: [{ scale: isRecording ? pulseAnim : 1 }] }}>
              <MaterialIcons name={isRecording ? 'mic' : 'mic-none'} size={20} color={isRecording ? '#FFFFFF' : Colors.textSecondary} />
            </Animated.View>
          </Pressable>
          <Pressable
            style={({ pressed }) => [styles.sendButton, (!input.trim() || isLoading) && styles.sendButtonDisabled, pressed && input.trim() && !isLoading && styles.sendButtonPressed]}
            onPress={() => sendMessage()} disabled={!input.trim() || isLoading}
          >
            {isLoading ? <ActivityIndicator size="small" color={Ruby.bright} /> : <MaterialIcons name="send" size={20} color={input.trim() ? Ruby.bright : Colors.textDim} />}
          </Pressable>
        </View>

        {agentMode && (
          <View style={agentStyles.agentBar}>
            <MaterialIcons name="auto-awesome" size={11} color={Ruby.bright} />
            <Text style={agentStyles.agentBarText}>Agent Mode · Multi-step RV research with Grok 4.5</Text>
            <Pressable onPress={toggleAgentMode} hitSlop={8}><Text style={agentStyles.agentBarOff}>Off</Text></Pressable>
          </View>
        )}

        <Text style={styles.inputHint}>
          {isRecording ? 'Voice input active · tap mic to stop' : agentMode ? 'Agent researches multiple sources for you' : 'Professional RV intelligence · RvFOX Pro'}
        </Text>
      </View>

      <VoiceSelectorPanel
        visible={voicePanelOpen} voices={voices} loading={voicesLoading} selectedId={selectedVoice}
        onClose={() => { setVoicePanelOpen(false); stopPreview(); }}
        onSelect={handleSelectVoice} onPreview={handlePreviewVoice} previewingId={previewingVoiceId}
        voiceMode={voiceMode}
        onVoiceModeChange={(v) => { setVoiceMode(v); AsyncStorage.setItem(VOICE_MODE_KEY, String(v)).catch(() => {}); }}
        playbackSpeed={playbackSpeed}
        onSpeedChange={(s) => { setPlaybackSpeed(s); AsyncStorage.setItem(VOICE_SPEED_KEY, String(s)).catch(() => {}); }}
      />
      <HistoryPanel visible={historyOpen} sessions={sessions} loading={loadingSessions} onClose={() => setHistoryOpen(false)} onLoad={loadSession} onDelete={deleteSession} onNewChat={startNewChat} />

      {/* ── MIC TEST MODAL ── */}
      <Modal visible={micTestVisible} transparent animationType="slide" onRequestClose={() => setMicTestVisible(false)}>
        <View style={micTest.overlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setMicTestVisible(false)} />
          <View style={[micTest.panel, { paddingBottom: insets.bottom + 16 }]}>
            <View style={micTest.handle} />
            <View style={micTest.header}>
              <MaterialIcons name="science" size={18} color={Ruby.bright} />
              <Text style={micTest.headerTitle}>Microphone Diagnostics</Text>
              <Pressable style={micTest.closeBtn} onPress={() => setMicTestVisible(false)} hitSlop={8}>
                <MaterialIcons name="close" size={18} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <Text style={micTest.desc}>
              Runs a 2-second test recording to verify your microphone and audio session are working correctly.
            </Text>

            {/* Run test button */}
            {!micTestRunning && (
              <Pressable
                style={({ pressed }) => [micTest.runBtn, pressed && { opacity: 0.85 }]}
                onPress={runMicTest}
              >
                <MaterialIcons name="play-arrow" size={18} color="#000" />
                <Text style={micTest.runBtnText}>Run Mic Test (2s)</Text>
              </Pressable>
            )}

            {micTestRunning && (
              <View style={micTest.runningWrap}>
                <ActivityIndicator color={Ruby.bright} size="large" />
                <Text style={micTest.runningText}>Testing microphone... speak now</Text>
              </View>
            )}

            {micTestResult && !micTestRunning && (
              <View style={micTest.results}>
                {/* Permission */}
                <View style={micTest.resultRow}>
                  <MaterialIcons
                    name={micTestResult.permissionGranted ? 'check-circle' : 'cancel'}
                    size={18}
                    color={micTestResult.permissionGranted ? Colors.green : Colors.red}
                  />
                  <View style={{ flex: 1 }}>
                    <Text style={micTest.resultLabel}>Microphone Permission</Text>
                    <Text style={[micTest.resultValue, { color: micTestResult.permissionGranted ? Colors.green : Colors.red }]}>
                      {micTestResult.permissionGranted ? 'Granted' : 'DENIED — go to Settings > Privacy > Microphone'}
                    </Text>
                  </View>
                </View>

                {/* HIGH quality */}
                <View style={micTest.resultRow}>
                  <MaterialIcons
                    name={micTestResult.highQuality === 'success' ? 'check-circle' : 'warning'}
                    size={18}
                    color={micTestResult.highQuality === 'success' ? Colors.green : Colors.orange}
                  />
                  <View style={{ flex: 1 }}>
                    <Text style={micTest.resultLabel}>HIGH Quality Recording</Text>
                    <Text style={[micTest.resultValue, { color: micTestResult.highQuality === 'success' ? Colors.green : Colors.orange }]}>
                      {micTestResult.highQuality === 'success' ? 'Works' : micTestResult.highQualityError ?? 'Failed'}
                    </Text>
                  </View>
                </View>

                {/* LOW quality (only if HIGH failed) */}
                {micTestResult.highQuality !== 'success' && (
                  <View style={micTest.resultRow}>
                    <MaterialIcons
                      name={micTestResult.lowQuality === 'success' ? 'check-circle' : micTestResult.lowQuality === 'skipped' ? 'remove-circle' : 'cancel'}
                      size={18}
                      color={micTestResult.lowQuality === 'success' ? Colors.green : micTestResult.lowQuality === 'skipped' ? Colors.textMuted : Colors.red}
                    />
                    <View style={{ flex: 1 }}>
                      <Text style={micTest.resultLabel}>LOW Quality Fallback</Text>
                      <Text style={[micTest.resultValue, { color: micTestResult.lowQuality === 'success' ? Colors.green : micTestResult.lowQuality === 'skipped' ? Colors.textMuted : Colors.red }]}>
                        {micTestResult.lowQuality === 'skipped' ? 'Skipped' : micTestResult.lowQuality === 'success' ? 'Works (voice will use fallback)' : micTestResult.lowQualityError ?? 'Failed'}
                      </Text>
                    </View>
                  </View>
                )}

                {/* URI / duration */}
                <View style={micTest.resultRow}>
                  <MaterialIcons
                    name={micTestResult.recordingUri ? 'fiber-manual-record' : 'info-outline'}
                    size={18}
                    color={micTestResult.recordingUri ? Colors.blueBright : Colors.textMuted}
                  />
                  <View style={{ flex: 1 }}>
                    <Text style={micTest.resultLabel}>Recording File</Text>
                    <Text style={[micTest.resultValue, { color: micTestResult.recordingUri ? Colors.blueBright : Colors.textMuted }]} numberOfLines={1}>
                      {micTestResult.recordingUri ? `Saved (${micTestResult.durationMs}ms)` : 'No file created'}
                    </Text>
                  </View>
                </View>

                {/* Summary verdict */}
                <View style={[
                  micTest.verdict,
                  { borderColor: (micTestResult.highQuality === 'success' || micTestResult.lowQuality === 'success') ? 'rgba(74,222,128,0.35)' : 'rgba(255,68,68,0.35)' },
                  { backgroundColor: (micTestResult.highQuality === 'success' || micTestResult.lowQuality === 'success') ? 'rgba(74,222,128,0.07)' : 'rgba(255,68,68,0.07)' },
                ]}>
                  <MaterialIcons
                    name={(micTestResult.highQuality === 'success' || micTestResult.lowQuality === 'success') ? 'check-circle' : 'error'}
                    size={20}
                    color={(micTestResult.highQuality === 'success' || micTestResult.lowQuality === 'success') ? Colors.green : Colors.red}
                  />
                  <Text style={[
                    micTest.verdictText,
                    { color: (micTestResult.highQuality === 'success' || micTestResult.lowQuality === 'success') ? Colors.green : Colors.red },
                  ]}>
                    {(micTestResult.highQuality === 'success' || micTestResult.lowQuality === 'success')
                      ? 'Microphone is working. Voice input should function on-device.'
                      : micTestResult.permissionGranted
                        ? 'Recording failed. Another app may be using the mic. Force-quit other audio apps and rebuild.'
                        : 'Permission denied. Enable microphone in iOS Settings > Privacy > Microphone.'}
                  </Text>
                </View>

                <Pressable
                  style={({ pressed }) => [micTest.runBtn, { marginTop: 4, backgroundColor: 'rgba(192,31,46,0.15)', borderWidth: 1, borderColor: Ruby.border }, pressed && { opacity: 0.8 }]}
                  onPress={runMicTest}
                >
                  <MaterialIcons name="refresh" size={16} color={Ruby.bright} />
                  <Text style={[micTest.runBtnText, { color: Ruby.bright }]}>Run Again</Text>
                </Pressable>
              </View>
            )}

            <View style={micTest.footer}>
              <MaterialIcons name="info-outline" size={12} color={Colors.textDim} />
              <Text style={micTest.footerText}>Test only available on-device (TestFlight/App Store). Live Preview does not support microphone.</Text>
            </View>
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

// ─── HISTORY PANEL STYLES ─────────────────────────────────────────────────────

const histStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'flex-end' },
  panel: { backgroundColor: '#0E0507', borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl, borderTopWidth: 2, borderColor: Ruby.border, maxHeight: '75%', paddingHorizontal: Spacing.md, paddingTop: 8, shadowColor: Ruby.primary, shadowOffset: { width: 0, height: -6 }, shadowOpacity: 0.40, shadowRadius: 20, elevation: 20 },
  handle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.sm },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: Spacing.sm },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  headerTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  countBadge: { backgroundColor: Ruby.primary, borderRadius: Radius.full, minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  countText: { fontSize: 10, fontWeight: FontWeight.bold, color: '#fff' },
  closeBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.07)', alignItems: 'center', justifyContent: 'center' },
  newChatBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, backgroundColor: Ruby.primary, borderRadius: Radius.full, paddingVertical: 13, marginBottom: Spacing.sm, shadowColor: Ruby.primary, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.45, shadowRadius: 10, elevation: 5 },
  newChatBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#fff' },
  emptyWrap: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  emptyText: { fontSize: FontSize.md, color: Colors.textSecondary, fontWeight: FontWeight.semibold },
  emptySubText: { fontSize: FontSize.sm, color: Colors.textMuted },
  sessionItem: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: 13, paddingHorizontal: Spacing.sm, borderRadius: Radius.lg, marginBottom: 4, borderWidth: 1, borderColor: 'rgba(192,31,46,0.18)', backgroundColor: 'rgba(255,255,255,0.02)' },
  sessionItemPressed: { backgroundColor: Ruby.surface, borderColor: Ruby.border },
  sessionIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  sessionBody: { flex: 1, gap: 3 },
  sessionTitle: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  sessionMeta: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  sessionTime: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium },
  sessionCount: { fontSize: FontSize.xs, color: Colors.textDim },
  deleteBtn: { width: 30, height: 30, borderRadius: 15, backgroundColor: 'rgba(255,68,68,0.08)', borderWidth: 1, borderColor: 'rgba(255,68,68,0.2)', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
});

// ─── MAIN STYLES ──────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A2A3A' },
  heroBackdrop: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, paddingBottom: Spacing.md, zIndex: 2 },
  historyBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  historyCountDot: { position: 'absolute', top: -3, right: -3, minWidth: 16, height: 16, borderRadius: 8, backgroundColor: Ruby.primary, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3, borderWidth: 1.5, borderColor: Colors.black },
  historyCountDotText: { fontSize: 8, fontWeight: FontWeight.bold, color: '#fff' },
  headerCenter: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerIconWrap: { width: 42, height: 42, borderRadius: 21, backgroundColor: Ruby.surface, borderWidth: 1.5, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center', shadowColor: Ruby.bright, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.35, shadowRadius: 10, elevation: 6, overflow: 'hidden' },
  headerTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.extrabold, color: '#FFFFFF', letterSpacing: 0.5 },
  headerSub: { fontSize: FontSize.xs, color: Colors.textSecondary, marginTop: 1 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  onlineDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Ruby.bright, shadowColor: Ruby.bright, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.9, shadowRadius: 5, elevation: 2 },
  clearBtn: { padding: Spacing.xs },
  micTestBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(192,31,46,0.08)', borderWidth: 1, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center' },
  agentToggleBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: Radius.full, borderWidth: 1, paddingHorizontal: 9, paddingVertical: 5 },
  agentToggleText: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.textMuted, letterSpacing: 0.3 },
  stopBar: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: 'rgba(192,31,46,0.22)', borderWidth: 1.5, borderColor: Ruby.borderBright, borderRadius: Radius.lg, paddingHorizontal: Spacing.md, paddingVertical: 10, marginBottom: Spacing.xs, shadowColor: Ruby.bright, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.40, shadowRadius: 10, elevation: 5 },
  stopBarIcon: { width: 30, height: 30, borderRadius: 15, backgroundColor: Ruby.primary, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  stopBarLabel: { flex: 1, fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: '#FFFFFF' },
  stopBarHint: { fontSize: 11, fontWeight: FontWeight.extrabold, color: Ruby.bright, letterSpacing: 1.5 },
  voiceBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center' },
  headerDivider: { height: 1, backgroundColor: Ruby.border, marginHorizontal: Spacing.md, opacity: 0.5, zIndex: 2 },
  sessionStrip: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: Spacing.md, paddingVertical: 6, backgroundColor: Ruby.surface, borderBottomWidth: 1, borderBottomColor: Ruby.border, zIndex: 2 },
  sessionStripText: { flex: 1, fontSize: 10, color: Colors.textMuted, fontWeight: FontWeight.medium },
  emptyContainer: { padding: Spacing.md, paddingTop: Spacing.lg, paddingBottom: Spacing.xl, zIndex: 2 },
  emptyHero: { alignItems: 'center', marginBottom: Spacing.xl, gap: Spacing.sm },
  emptyAvatarOuter: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: Ruby.surface,
    borderWidth: 1.5,
    borderColor: Ruby.border,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Ruby.bright,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.55,
    shadowRadius: 30,
    elevation: 12,
    marginBottom: Spacing.sm,
  },
  emptyAvatarInner: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: Ruby.surfaceMid,
    borderWidth: 2,
    borderColor: Ruby.borderBright,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    shadowColor: Ruby.glow,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.70,
    shadowRadius: 14,
    elevation: 8,
  },
  emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: '#FFFFFF', letterSpacing: 0.5 },
  emptySubtitle: { fontSize: FontSize.sm, color: Colors.textSecondary, textAlign: 'center', lineHeight: 20, paddingHorizontal: Spacing.md },
  emptyBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.full, marginTop: Spacing.xs },
  emptyBadgeText: { fontSize: FontSize.xs, color: Ruby.bright, fontWeight: FontWeight.semibold },
  starterLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 1.5, marginBottom: Spacing.sm, zIndex: 2 },
  starterGrid: { gap: Spacing.sm, zIndex: 2 },
  starterCard: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: 'rgba(0,0,0,0.28)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.14)', borderRadius: Radius.lg, paddingHorizontal: Spacing.md, paddingVertical: 14 },
  starterCardPressed: { backgroundColor: Ruby.surface, borderColor: Ruby.border },
  starterCardText: { flex: 1, fontSize: FontSize.md, fontWeight: FontWeight.medium, color: 'rgba(255,255,255,0.85)' },
  disclaimerText: { fontSize: FontSize.xs, color: Colors.textDim, textAlign: 'center', lineHeight: 17, marginTop: Spacing.xl, paddingHorizontal: Spacing.md },
  messageList: { padding: Spacing.md, paddingBottom: Spacing.md, gap: Spacing.md, zIndex: 2 },
  messageRow: { flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.sm, maxWidth: '100%' },
  messageRowUser: { justifyContent: 'flex-end' },
  assistantAvatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden' },
  bubble: { maxWidth: '82%', borderRadius: Radius.lg, padding: Spacing.sm + 4, gap: 4 },
  bubbleUser: { backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, borderBottomRightRadius: Radius.sm, shadowColor: Ruby.primary, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.25, shadowRadius: 8, elevation: 3 },
  bubbleAssistant: { backgroundColor: 'rgba(0,0,0,0.38)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', borderBottomLeftRadius: Radius.sm },
  bubbleSender: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Ruby.bright, letterSpacing: 0.5, marginBottom: 2 },
  bubbleText: { fontSize: FontSize.md, color: 'rgba(255,255,255,0.85)', lineHeight: 22 },
  bubbleTextUser: { color: '#FFFFFF' },
  bubbleTime: { fontSize: 10, color: Colors.textMuted, alignSelf: 'flex-end', marginTop: 2 },
  bubbleTimeUser: { color: 'rgba(212,37,53,0.55)' },
  streamingDots: { flexDirection: 'row', gap: 4, paddingTop: 4, paddingLeft: 2 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Ruby.bright, opacity: 0.6 },
  dot1: { opacity: 0.4 }, dot2: { opacity: 0.65 }, dot3: { opacity: 0.9 },
  inputBar: { borderTopWidth: 1, borderTopColor: 'rgba(192,31,46,0.30)', backgroundColor: 'rgba(6,2,2,0.90)', paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, gap: Spacing.xs, zIndex: 2, shadowColor: Ruby.primary, shadowOffset: { width: 0, height: -4 }, shadowOpacity: 0.20, shadowRadius: 14, elevation: 10 },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.sm, backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.18)', borderRadius: Radius.xl, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm },
  textInput: { flex: 1, fontSize: FontSize.md, color: '#FFFFFF', maxHeight: 120, paddingTop: Platform.OS === 'ios' ? 2 : 0, lineHeight: 22 },
  sendButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  sendButtonDisabled: { shadowOpacity: 0, elevation: 0, backgroundColor: 'rgba(255,255,255,0.03)', borderColor: Colors.border },
  sendButtonPressed: { backgroundColor: Ruby.surfaceMid, shadowColor: Ruby.bright, shadowOpacity: 0.6, shadowRadius: 12, elevation: 6, transform: [{ scale: 0.95 }] },
  inputHint: { fontSize: 10, color: Colors.textDim, textAlign: 'center', letterSpacing: 0.3, paddingBottom: 2 },
  micButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.14)', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  micButtonActive: { backgroundColor: Ruby.primary, borderColor: Ruby.borderBright, shadowColor: Ruby.bright, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.75, shadowRadius: 12, elevation: 8 },
  inputRowRecording: { borderColor: Ruby.borderBright, backgroundColor: 'rgba(192,31,46,0.06)' },
  recordingStrip: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 8, marginBottom: Spacing.xs },
  recordingDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Ruby.bright },
  recordingText: { flex: 1, fontSize: FontSize.xs, color: 'rgba(255,255,255,0.80)', fontWeight: FontWeight.medium },
  recordingStop: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Ruby.bright, letterSpacing: 0.5 },
  realtimeStrip: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: 'rgba(77,166,255,0.10)', borderWidth: 1, borderColor: 'rgba(77,166,255,0.35)', borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 8, marginBottom: Spacing.xs },
  realtimeText: { flex: 1, fontSize: FontSize.xs, color: '#87BFFF', fontWeight: FontWeight.medium },
});

// ─── VOICE SELECTOR STYLES ─────────────────────────────────────────────────────

const voiceStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.70)', justifyContent: 'flex-end' },
  panel: { backgroundColor: '#0E0507', borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl, borderTopWidth: 2, borderColor: Ruby.border, maxHeight: '80%', paddingHorizontal: Spacing.md, paddingTop: 8, shadowColor: Ruby.primary, shadowOffset: { width: 0, height: -6 }, shadowOpacity: 0.45, shadowRadius: 22, elevation: 22 },
  handle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.sm },
  header: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingBottom: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: Spacing.sm, position: 'relative' },
  headerTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  headerSub: { fontSize: FontSize.xs, color: Colors.textMuted, flex: 1 },
  closeBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.07)', alignItems: 'center', justifyContent: 'center', marginLeft: 'auto' },
  loadingWrap: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  loadingText: { fontSize: FontSize.sm, color: Colors.textMuted },
  voiceRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: 13, paddingHorizontal: Spacing.sm, borderRadius: Radius.lg, borderWidth: 1, borderColor: 'rgba(192,31,46,0.18)', backgroundColor: 'rgba(255,255,255,0.02)' },
  voiceRowActive: { backgroundColor: Ruby.surface, borderColor: Ruby.border },
  voiceAvatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: Ruby.surface, borderWidth: 1.5, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  voiceAvatarActive: { backgroundColor: Ruby.primary, borderColor: Ruby.bright },
  voiceBody: { flex: 1, gap: 3 },
  voiceNameRow: { flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' },
  voiceName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  genderChip: { backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: Radius.full, paddingHorizontal: 6, paddingVertical: 2, borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)' },
  genderChipText: { fontSize: 9, color: Colors.textMuted, fontWeight: FontWeight.semibold },
  selectedBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: Ruby.primary, borderRadius: Radius.full, paddingHorizontal: 7, paddingVertical: 2 },
  selectedBadgeText: { fontSize: 9, fontWeight: FontWeight.bold, color: '#fff' },
  voiceDesc: { fontSize: FontSize.xs, color: Colors.textMuted },
  previewBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  previewBtnActive: { backgroundColor: Ruby.primary, borderColor: Ruby.borderBright, shadowColor: Ruby.bright, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.75, shadowRadius: 10, elevation: 6 },
  settingsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, paddingHorizontal: Spacing.sm, borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(192,31,46,0.18)', backgroundColor: 'rgba(255,255,255,0.02)', marginBottom: Spacing.xs },
  settingsLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flex: 1, marginRight: 12 },
  settingsLabel: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  settingsHint: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },
  toggleTrack: { width: 44, height: 24, borderRadius: 12, backgroundColor: Colors.bgCardAlt, borderWidth: 1, borderColor: Colors.border, padding: 2, justifyContent: 'center' },
  toggleTrackOn: { backgroundColor: Ruby.primary, borderColor: Ruby.borderBright },
  toggleThumb: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#888888', alignSelf: 'flex-start' },
  toggleThumbOn: { backgroundColor: '#ffffff', alignSelf: 'flex-end' },
  speedSection: { marginBottom: Spacing.sm },
  speedLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 1.5, marginBottom: Spacing.xs },
  speedRow: { flexDirection: 'row', gap: Spacing.xs },
  speedBtn: { flex: 1, paddingVertical: 8, borderRadius: Radius.md, backgroundColor: Colors.bgCardAlt, borderWidth: 1, borderColor: Colors.border, alignItems: 'center' },
  speedBtnActive: { backgroundColor: Ruby.surface, borderColor: Ruby.borderBright },
  speedBtnText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.textMuted },
  speedBtnTextActive: { color: Ruby.bright, fontWeight: FontWeight.bold },
  voiceListLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 1.5, marginBottom: Spacing.xs },
  footer: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingTop: Spacing.sm, borderTopWidth: 1, borderTopColor: Colors.border, marginTop: 4 },
  footerText: { flex: 1, fontSize: 10, color: Colors.textDim, lineHeight: 15 },
});

// ─── AGENT MODE STYLES ─────────────────────────────────────────────────────────

const agentStyles = StyleSheet.create({
  card: { backgroundColor: 'rgba(192,31,46,0.07)', borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(192,31,46,0.28)', marginBottom: Spacing.sm, overflow: 'hidden' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.sm, paddingVertical: 9 },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 7, flex: 1 },
  headerTitle: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.medium, flex: 1 },
  agentBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, borderRadius: Radius.full, paddingHorizontal: 6, paddingVertical: 2 },
  agentBadgeText: { fontSize: 9, fontWeight: FontWeight.extrabold, color: Ruby.bright, letterSpacing: 0.8 },
  agentBadgeInline: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, borderRadius: Radius.full, paddingHorizontal: 5, paddingVertical: 1 },
  agentBadgeInlineText: { fontSize: 8, fontWeight: FontWeight.bold, color: Ruby.bright, letterSpacing: 0.5 },
  stepsWrap: { borderTopWidth: 1, borderTopColor: 'rgba(192,31,46,0.22)', paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs, gap: 8 },
  stepRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, paddingVertical: 5 },
  stepIcon: { width: 26, height: 26, borderRadius: 8, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  stepBody: { flex: 1, gap: 2 },
  stepLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold },
  stepResult: { fontSize: 10, color: Colors.textMuted, lineHeight: 14 },
  stepNum: { fontSize: 9, color: Colors.textDim, alignSelf: 'flex-start', marginTop: 6, flexShrink: 0 },
  agentModeHeroBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: 'rgba(192,31,46,0.14)', borderWidth: 1.5, borderColor: Ruby.border, paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.full, shadowColor: Ruby.bright, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.35, shadowRadius: 10, elevation: 5 },
  agentModeHeroText: { fontSize: FontSize.xs, color: Ruby.bright, fontWeight: FontWeight.bold },
  agentSuggestions: { width: '100%', gap: Spacing.xs },
  agentQueryChip: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: 'rgba(192,31,46,0.08)', borderWidth: 1, borderColor: Ruby.border, borderRadius: Radius.lg, paddingHorizontal: Spacing.md, paddingVertical: 13 },
  agentQueryText: { flex: 1, fontSize: FontSize.sm, color: 'rgba(255,255,255,0.80)', fontWeight: FontWeight.medium, lineHeight: 18 },
  agentBar: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(192,31,46,0.08)', borderRadius: Radius.sm, paddingHorizontal: Spacing.sm, paddingVertical: 5, borderWidth: 1, borderColor: 'rgba(192,31,46,0.25)' },
  agentBarText: { flex: 1, fontSize: 10, color: Ruby.bright, fontWeight: FontWeight.semibold },
  agentBarOff: { fontSize: 10, color: Colors.textMuted, textDecorationLine: 'underline' },
  sessionBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: Ruby.surface, borderWidth: 1, borderColor: Ruby.border, borderRadius: Radius.full, paddingHorizontal: 6, paddingVertical: 2 },
  sessionBadgeText: { fontSize: 9, fontWeight: FontWeight.bold, color: Ruby.bright },
});

// ─── MIC TEST MODAL STYLES ───────────────────────────────────────────────────────

const micTest = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.72)', justifyContent: 'flex-end' },
  panel: { backgroundColor: '#0D0205', borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl, borderTopWidth: 2, borderColor: Ruby.border, maxHeight: '85%', paddingHorizontal: Spacing.md, paddingTop: 8, shadowColor: Ruby.primary, shadowOffset: { width: 0, height: -6 }, shadowOpacity: 0.45, shadowRadius: 22, elevation: 22 },
  handle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.sm },
  header: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: Spacing.sm },
  headerTitle: { flex: 1, fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  closeBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.07)', alignItems: 'center', justifyContent: 'center' },
  desc: { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20, marginBottom: Spacing.md },
  runBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, backgroundColor: Ruby.primary, borderRadius: Radius.full, paddingVertical: 14, marginBottom: Spacing.md, shadowColor: Ruby.primary, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.45, shadowRadius: 10, elevation: 5 },
  runBtnText: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#fff' },
  runningWrap: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  runningText: { fontSize: FontSize.sm, color: Ruby.bright, fontWeight: FontWeight.semibold },
  results: { gap: Spacing.sm, marginBottom: Spacing.sm },
  resultRow: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: Colors.border },
  resultLabel: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary, marginBottom: 2 },
  resultValue: { fontSize: FontSize.xs, lineHeight: 16 },
  verdict: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, borderWidth: 1, borderRadius: Radius.lg, padding: Spacing.sm, marginTop: 4 },
  verdictText: { flex: 1, fontSize: FontSize.sm, fontWeight: FontWeight.semibold, lineHeight: 20 },
  footer: { flexDirection: 'row', alignItems: 'flex-start', gap: 5, paddingTop: Spacing.sm, borderTopWidth: 1, borderTopColor: Colors.border, marginTop: 4 },
  footerText: { flex: 1, fontSize: 10, color: Colors.textDim, lineHeight: 15 },
});

// ─── TTS BUTTON STYLES ─────────────────────────────────────────────────────────

const ttsBtn = StyleSheet.create({
  btn: { width: 26, height: 26, borderRadius: 13, backgroundColor: 'rgba(212,37,53,0.10)', borderWidth: 1, borderColor: 'rgba(212,37,53,0.35)', alignItems: 'center', justifyContent: 'center' },
  btnActive: { backgroundColor: Ruby.primary, borderColor: Ruby.borderBright, shadowColor: Ruby.bright, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.80, shadowRadius: 10, elevation: 6 },
});
