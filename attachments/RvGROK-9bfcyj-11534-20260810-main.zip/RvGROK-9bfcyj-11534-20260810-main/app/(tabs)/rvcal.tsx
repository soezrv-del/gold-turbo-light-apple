import {
  View, Text, StyleSheet, ScrollView, TextInput, Pressable,
  Platform, Dimensions, Linking, PanResponder, Alert, ActivityIndicator,
} from 'react-native';
import { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import { generateAndShareLoanReport } from '@/services/pdfService';
import type { LoanReportData, RVReportData } from '@/services/pdfService';

// ─── TRADE-IN TAX CREDIT RULES BY STATE ─────────────────────────────────────
// Most US states apply sales tax only to (sale price - trade-in value).
// These states DO give trade-in tax credit (taxable = price - trade-in):
// States where trade-in value is DEDUCTED from the taxable selling price.
// Buyer pays tax on (selling price − trade-in value), not the full selling price.
// Sources: each state DMV / revenue dept; verified 2025.
const TRADE_IN_TAX_CREDIT_STATES = new Set([
  // No sales tax — deduction irrelevant but included for completeness
  'AK','DE','MT','NH','OR',
  // West
  'AZ','CO','ID','NM','NV','UT','WA','WY',
  // Midwest
  'IA','IL','IN','KS','MN','MO','ND','NE','OH','SD','WI',
  // South
  'AL','AR','FL','GA','LA','MS','NC','OK','SC','TN','TX','WV',
  // Northeast
  'CT','MA','ME','NJ','NY','PA','RI','VT',
]);
// States that DO NOT give trade-in credit (tax on full selling price):
//   CA — no trade-in deduction
//   DC — no trade-in deduction
//   HI — no trade-in deduction
//   KY — no trade-in deduction
//   MD — no trade-in deduction
//   MI — no trade-in deduction
//   VA — no trade-in deduction

// ─── GREEN NEON PALETTE (Entegra Green) ───────────────────────────────────────
const Green = {
  primary:      '#00C853',   // main neon green
  bright:       '#00E676',   // highlight
  glow:         '#69F0AE',   // glow/active states
  dim:          '#007A33',   // dark green for borders
  border:       'rgba(0,200,83,0.40)',
  borderBright: 'rgba(0,230,118,0.65)',
  surface:      'rgba(0,200,83,0.08)',
  surfaceMid:   'rgba(0,200,83,0.14)',
};

// ─── ZIP → STATE TAX DATA ────────────────────────────────────────────────────

const ZIP_TO_STATE: Record<string, { state: string; code: string; tax: number; regBase: number }> = {
  // DC — 200-205
  '200': { state: 'District of Columbia', code: 'DC', tax: 6.00, regBase: 180 },
  '202': { state: 'District of Columbia', code: 'DC', tax: 6.00, regBase: 180 },
  '203': { state: 'District of Columbia', code: 'DC', tax: 6.00, regBase: 180 },
  '204': { state: 'District of Columbia', code: 'DC', tax: 6.00, regBase: 180 },
  '205': { state: 'District of Columbia', code: 'DC', tax: 6.00, regBase: 180 },
  // Alaska
  '995': { state: 'Alaska', code: 'AK', tax: 0.00, regBase: 100 },
  '996': { state: 'Alaska', code: 'AK', tax: 0.00, regBase: 100 },
  '997': { state: 'Alaska', code: 'AK', tax: 0.00, regBase: 100 },
  '998': { state: 'Alaska', code: 'AK', tax: 0.00, regBase: 100 },
  '999': { state: 'Alaska', code: 'AK', tax: 0.00, regBase: 100 },
  // Alabama — 350-369
  '350': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '351': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '352': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '353': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '354': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '355': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '356': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '357': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '358': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '359': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '360': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '361': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '362': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '363': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '364': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '365': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '366': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '367': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '368': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '369': { state: 'Alabama', code: 'AL', tax: 2.00, regBase: 60 },
  '850': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '851': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '852': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '853': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '855': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '856': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '857': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '859': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '860': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '863': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '864': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  '865': { state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  // Arkansas — 716-729
  '716': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '717': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '718': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '719': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '720': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '721': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '722': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '723': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '724': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '725': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '726': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '727': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '728': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '729': { state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  '900': { state: 'California', code: 'CA', tax: 7.25, regBase: 250 },
  '901': { state: 'California', code: 'CA', tax: 10.25, regBase: 280 },
  '902': { state: 'California', code: 'CA', tax: 9.50, regBase: 270 },
  '903': { state: 'California', code: 'CA', tax: 9.50, regBase: 270 },
  '904': { state: 'California', code: 'CA', tax: 9.50, regBase: 270 },
  '905': { state: 'California', code: 'CA', tax: 10.25, regBase: 285 },
  '906': { state: 'California', code: 'CA', tax: 10.25, regBase: 285 },
  '907': { state: 'California', code: 'CA', tax: 10.25, regBase: 285 },
  '908': { state: 'California', code: 'CA', tax: 10.25, regBase: 285 },
  '912': { state: 'California', code: 'CA', tax: 10.25, regBase: 280 },
  '913': { state: 'California', code: 'CA', tax: 9.00, regBase: 260 },
  '920': { state: 'California', code: 'CA', tax: 7.75, regBase: 250 },
  '921': { state: 'California', code: 'CA', tax: 7.75, regBase: 250 },
  '922': { state: 'California', code: 'CA', tax: 7.75, regBase: 250 },
  '941': { state: 'California', code: 'CA', tax: 8.625, regBase: 265 },
  '945': { state: 'California', code: 'CA', tax: 9.25, regBase: 275 },
  '800': { state: 'Colorado', code: 'CO', tax: 2.90, regBase: 45 },
  '801': { state: 'Colorado', code: 'CO', tax: 8.81, regBase: 60 },
  '802': { state: 'Colorado', code: 'CO', tax: 2.90, regBase: 45 },
  '060': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '061': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '197': { state: 'Delaware', code: 'DE', tax: 0.00, regBase: 50 },
  '198': { state: 'Delaware', code: 'DE', tax: 0.00, regBase: 50 },
  '199': { state: 'Delaware', code: 'DE', tax: 0.00, regBase: 50 },
  '320': { state: 'Florida', code: 'FL', tax: 6.00, regBase: 250 },
  '321': { state: 'Florida', code: 'FL', tax: 6.00, regBase: 250 },
  '322': { state: 'Florida', code: 'FL', tax: 6.00, regBase: 250 },
  '325': { state: 'Florida', code: 'FL', tax: 6.00, regBase: 250 },
  '326': { state: 'Florida', code: 'FL', tax: 6.00, regBase: 250 },
  '327': { state: 'Florida', code: 'FL', tax: 8.00, regBase: 270 },
  '328': { state: 'Florida', code: 'FL', tax: 7.50, regBase: 270 },
  '329': { state: 'Florida', code: 'FL', tax: 7.50, regBase: 265 },
  '330': { state: 'Florida', code: 'FL', tax: 7.00, regBase: 265 },
  '331': { state: 'Florida', code: 'FL', tax: 7.00, regBase: 265 },
  '332': { state: 'Florida', code: 'FL', tax: 7.00, regBase: 265 },
  '333': { state: 'Florida', code: 'FL', tax: 7.00, regBase: 265 },
  '334': { state: 'Florida', code: 'FL', tax: 7.50, regBase: 265 },
  '335': { state: 'Florida', code: 'FL', tax: 7.50, regBase: 265 },
  '336': { state: 'Florida', code: 'FL', tax: 7.50, regBase: 265 },
  '337': { state: 'Florida', code: 'FL', tax: 7.50, regBase: 265 },
  '338': { state: 'Florida', code: 'FL', tax: 7.50, regBase: 265 },
  '339': { state: 'Florida', code: 'FL', tax: 7.00, regBase: 265 },
  '341': { state: 'Florida', code: 'FL', tax: 6.50, regBase: 255 },
  '342': { state: 'Florida', code: 'FL', tax: 6.50, regBase: 255 },
  '346': { state: 'Florida', code: 'FL', tax: 6.00, regBase: 250 },
  '347': { state: 'Florida', code: 'FL', tax: 6.50, regBase: 255 },
  '349': { state: 'Florida', code: 'FL', tax: 6.00, regBase: 250 },
  // Georgia — 300-319
  '300': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '301': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '302': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '303': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '304': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '305': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '306': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '307': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '308': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '309': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '310': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '311': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '312': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '313': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '314': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '315': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '316': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '317': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '318': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '319': { state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  '967': { state: 'Hawaii', code: 'HI', tax: 4.00, regBase: 45 },
  '968': { state: 'Hawaii', code: 'HI', tax: 4.00, regBase: 45 },
  // Idaho — 832-838
  '832': { state: 'Idaho', code: 'ID', tax: 6.00, regBase: 45 },
  '833': { state: 'Idaho', code: 'ID', tax: 6.00, regBase: 45 },
  '834': { state: 'Idaho', code: 'ID', tax: 6.00, regBase: 45 },
  '835': { state: 'Idaho', code: 'ID', tax: 6.00, regBase: 45 },
  '836': { state: 'Idaho', code: 'ID', tax: 6.00, regBase: 45 },
  '837': { state: 'Idaho', code: 'ID', tax: 6.00, regBase: 45 },
  '838': { state: 'Idaho', code: 'ID', tax: 6.00, regBase: 45 },
  '600': { state: 'Illinois', code: 'IL', tax: 10.25, regBase: 175 },
  '601': { state: 'Illinois', code: 'IL', tax: 10.25, regBase: 175 },
  '602': { state: 'Illinois', code: 'IL', tax: 10.25, regBase: 175 },
  '606': { state: 'Illinois', code: 'IL', tax: 6.25, regBase: 160 },
  '610': { state: 'Illinois', code: 'IL', tax: 8.00, regBase: 165 },
  // Indiana — 460-479
  '460': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '461': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '462': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '463': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '464': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '465': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '466': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '467': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '468': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '469': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '470': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '471': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '472': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '473': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '474': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '475': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '476': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '477': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '478': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  '479': { state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  // Iowa — 500-528
  '500': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '501': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '502': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '503': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '504': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '505': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '506': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '507': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '508': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '509': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '510': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '511': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '512': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '513': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '514': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '515': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '516': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '520': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '521': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '522': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '523': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '524': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '525': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '526': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '527': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  '528': { state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  // Kansas — 660-679
  '660': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '661': { state: 'Kansas', code: 'KS', tax: 8.95, regBase: 60 },
  '662': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '664': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '665': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '666': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '667': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '668': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '669': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '670': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '671': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '672': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '673': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '674': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '675': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '676': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '677': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '678': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  '679': { state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  // Kentucky — 400-427
  '400': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '401': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '402': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '403': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '404': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '405': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '406': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '407': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '408': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '409': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '410': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '411': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '412': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '413': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '414': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '415': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '416': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '417': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '418': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '420': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '421': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '422': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '423': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '424': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '425': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '426': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  '427': { state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  // Louisiana — 700-714
  '700': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '701': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '703': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '704': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '705': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '706': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '707': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '708': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '710': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '711': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '712': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '713': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  '714': { state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  // Maine — 039-049
  '039': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '040': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '041': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '042': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '043': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '044': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '045': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '046': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '047': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '048': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  '049': { state: 'Maine', code: 'ME', tax: 5.50, regBase: 80 },
  // Maryland — 206-219
  '206': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '207': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '208': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '209': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '210': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '211': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '212': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '214': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '215': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '216': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '217': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '218': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  '219': { state: 'Maryland', code: 'MD', tax: 6.00, regBase: 130 },
  // Massachusetts — 010-027
  '010': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '011': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '012': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '013': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '014': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '015': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '016': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '017': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '018': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '019': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '020': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '021': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '022': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '023': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '024': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '025': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '026': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  '027': { state: 'Massachusetts', code: 'MA', tax: 6.25, regBase: 120 },
  // Michigan — 480-499
  '480': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '481': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '482': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '483': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '484': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '485': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '486': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '487': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '488': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '489': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '490': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '491': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '492': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '493': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '494': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '495': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '496': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '497': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '498': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '499': { state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  '550': { state: 'Minnesota', code: 'MN', tax: 6.875, regBase: 85 },
  '551': { state: 'Minnesota', code: 'MN', tax: 6.875, regBase: 85 },
  '553': { state: 'Minnesota', code: 'MN', tax: 7.875, regBase: 90 },
  // Mississippi — 386-397
  '386': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '387': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '388': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '389': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '390': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '391': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '392': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '393': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '394': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '395': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '396': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  '397': { state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  // Missouri — 630-658
  '630': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '631': { state: 'Missouri', code: 'MO', tax: 9.679, regBase: 60 },
  '633': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '634': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '635': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '636': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '637': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '638': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '639': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '640': { state: 'Missouri', code: 'MO', tax: 9.10, regBase: 58 },
  '641': { state: 'Missouri', code: 'MO', tax: 9.10, regBase: 58 },
  '644': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '645': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '646': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '647': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '648': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '650': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '651': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '652': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '653': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '654': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '655': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '656': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '657': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  '658': { state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  // Montana — 590-599
  '590': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '591': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '592': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '593': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '594': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '595': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '596': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '597': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '598': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  '599': { state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  // Nebraska — 680-693
  '680': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '681': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '683': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '684': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '685': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '686': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '687': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '688': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '689': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '690': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '691': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '692': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '693': { state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  '889': { state: 'Nevada', code: 'NV', tax: 8.375, regBase: 180 },
  '890': { state: 'Nevada', code: 'NV', tax: 8.375, regBase: 180 },
  '891': { state: 'Nevada', code: 'NV', tax: 8.375, regBase: 180 },
  // New Hampshire — 030-038
  '030': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  '031': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  '032': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  '033': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  '034': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  '035': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  '036': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  '037': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  '038': { state: 'New Hampshire', code: 'NH', tax: 0.00, regBase: 60 },
  // New Jersey — 070-089
  '070': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '071': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '072': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '073': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '074': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '075': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '076': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '077': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '078': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '079': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '080': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '081': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '082': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '083': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '084': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '085': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '086': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '087': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '088': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  '089': { state: 'New Jersey', code: 'NJ', tax: 6.625, regBase: 145 },
  // New Mexico — 870-884
  '870': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '871': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '872': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '873': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '874': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '875': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '877': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '878': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '879': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '880': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '881': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '882': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '883': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  '884': { state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  // New York — 100-149
  '100': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '101': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '102': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '103': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '104': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '105': { state: 'New York', code: 'NY', tax: 8.375, regBase: 180 },
  '106': { state: 'New York', code: 'NY', tax: 8.375, regBase: 180 },
  '107': { state: 'New York', code: 'NY', tax: 8.375, regBase: 180 },
  '108': { state: 'New York', code: 'NY', tax: 8.375, regBase: 180 },
  '109': { state: 'New York', code: 'NY', tax: 8.375, regBase: 180 },
  '110': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '111': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '112': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '113': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '114': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '115': { state: 'New York', code: 'NY', tax: 8.875, regBase: 185 },
  '116': { state: 'New York', code: 'NY', tax: 8.625, regBase: 180 },
  '117': { state: 'New York', code: 'NY', tax: 8.625, regBase: 180 },
  '118': { state: 'New York', code: 'NY', tax: 8.625, regBase: 180 },
  '119': { state: 'New York', code: 'NY', tax: 8.625, regBase: 180 },
  '120': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '121': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '122': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '123': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '124': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '125': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '126': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '127': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '128': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '129': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '130': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '131': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '132': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '133': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '134': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '135': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '136': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '137': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '138': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '139': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '140': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '141': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '142': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '143': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '144': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '145': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '146': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '147': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '148': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  '149': { state: 'New York', code: 'NY', tax: 8.00, regBase: 175 },
  // North Carolina — 270-289
  '270': { state: 'North Carolina', code: 'NC', tax: 3.00, regBase: 35 },
  '271': { state: 'North Carolina', code: 'NC', tax: 3.00, regBase: 35 },
  '272': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '273': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '274': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '275': { state: 'North Carolina', code: 'NC', tax: 7.25, regBase: 58 },
  '276': { state: 'North Carolina', code: 'NC', tax: 7.25, regBase: 58 },
  '277': { state: 'North Carolina', code: 'NC', tax: 7.25, regBase: 58 },
  '278': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '279': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '280': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '281': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '282': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '283': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '284': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '285': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '286': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '287': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '288': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  '289': { state: 'North Carolina', code: 'NC', tax: 7.00, regBase: 55 },
  // North Dakota — 580-588
  '580': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  '581': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  '582': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  '583': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  '584': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  '585': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  '586': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  '587': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  '588': { state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  // Ohio — 430-458
  '430': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '431': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '432': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '433': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '434': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '435': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '436': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '437': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '438': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '439': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '440': { state: 'Ohio', code: 'OH', tax: 7.75, regBase: 92 },
  '441': { state: 'Ohio', code: 'OH', tax: 8.00, regBase: 93 },
  '442': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '443': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '444': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '445': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '446': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '447': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '448': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '449': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '450': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '451': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '452': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '453': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '454': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '455': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '456': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '457': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  '458': { state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  // Oklahoma — 730-749
  '730': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '731': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '734': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '735': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '736': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '737': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '738': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '739': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '740': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '741': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '743': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '744': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '745': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '746': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '747': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '748': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '749': { state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  '970': { state: 'Oregon', code: 'OR', tax: 0.00, regBase: 75 },
  '971': { state: 'Oregon', code: 'OR', tax: 0.00, regBase: 75 },
  '972': { state: 'Oregon', code: 'OR', tax: 0.00, regBase: 75 },
  '973': { state: 'Oregon', code: 'OR', tax: 0.00, regBase: 75 },
  '974': { state: 'Oregon', code: 'OR', tax: 0.00, regBase: 75 },
  '975': { state: 'Oregon', code: 'OR', tax: 0.00, regBase: 75 },
  // Pennsylvania — 150-196
  '150': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '151': { state: 'Pennsylvania', code: 'PA', tax: 8.00, regBase: 100 },
  '152': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '153': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '154': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '155': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '156': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '157': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '158': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '159': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '160': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '161': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '162': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '163': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '164': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '165': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '166': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '167': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '168': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '169': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '170': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '171': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '172': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '173': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '174': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '175': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '176': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '177': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '178': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '179': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '180': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '181': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '182': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '183': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '184': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '185': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '186': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '187': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '188': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '189': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '190': { state: 'Pennsylvania', code: 'PA', tax: 8.00, regBase: 100 },
  '191': { state: 'Pennsylvania', code: 'PA', tax: 8.00, regBase: 100 },
  '192': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '193': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '194': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '195': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  '196': { state: 'Pennsylvania', code: 'PA', tax: 6.00, regBase: 95 },
  // Rhode Island — 028-029
  '028': { state: 'Rhode Island', code: 'RI', tax: 7.00, regBase: 120 },
  '029': { state: 'Rhode Island', code: 'RI', tax: 7.00, regBase: 120 },
  // South Carolina — 290-299
  '290': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '291': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '292': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '293': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '294': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '295': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '296': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '297': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '298': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  '299': { state: 'South Carolina', code: 'SC', tax: 5.00, regBase: 60 },
  // South Dakota — 570-577
  '570': { state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  '571': { state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  '572': { state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  '573': { state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  '574': { state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  '575': { state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  '576': { state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  '577': { state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  // Tennessee — 370-385
  '370': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '371': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '372': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '373': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '374': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '375': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '376': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '377': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '378': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '379': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '380': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '381': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '382': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '383': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '384': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '385': { state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  '750': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '751': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '752': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '753': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '760': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '761': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '770': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '771': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '772': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '775': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '776': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '778': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '780': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '781': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '782': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '783': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '785': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '786': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '787': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '788': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '789': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '790': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '791': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '793': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '794': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '795': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '796': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '797': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '798': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '799': { state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  '840': { state: 'Utah', code: 'UT', tax: 6.85, regBase: 70 },
  '841': { state: 'Utah', code: 'UT', tax: 7.25, regBase: 75 },
  '842': { state: 'Utah', code: 'UT', tax: 6.85, regBase: 70 },
  '843': { state: 'Utah', code: 'UT', tax: 6.85, regBase: 70 },
  '844': { state: 'Utah', code: 'UT', tax: 6.85, regBase: 70 },
  '845': { state: 'Utah', code: 'UT', tax: 6.85, regBase: 70 },
  '846': { state: 'Utah', code: 'UT', tax: 6.85, regBase: 70 },
  '847': { state: 'Utah', code: 'UT', tax: 6.85, regBase: 70 },
  // Vermont — 050-059
  '050': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  '051': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  '052': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  '053': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  '054': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  '056': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  '057': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  '058': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  '059': { state: 'Vermont', code: 'VT', tax: 6.00, regBase: 85 },
  // Connecticut — 060-069
  '060': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '061': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '062': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '063': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '064': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '065': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '066': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '067': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '068': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '069': { state: 'Connecticut', code: 'CT', tax: 6.35, regBase: 140 },
  '220': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '221': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '222': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '223': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '224': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '225': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '226': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '227': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '228': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '229': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '230': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '231': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '232': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '233': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '234': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '235': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '236': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '237': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '238': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '239': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '240': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '241': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '242': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '243': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '244': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '245': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '246': { state: 'Virginia', code: 'VA', tax: 6.00, regBase: 95 },
  '980': { state: 'Washington', code: 'WA', tax: 10.25, regBase: 185 },
  '981': { state: 'Washington', code: 'WA', tax: 10.25, regBase: 185 },
  '982': { state: 'Washington', code: 'WA', tax: 10.25, regBase: 185 },
  '983': { state: 'Washington', code: 'WA', tax: 10.25, regBase: 185 },
  '984': { state: 'Washington', code: 'WA', tax: 10.25, regBase: 185 },
  '985': { state: 'Washington', code: 'WA', tax: 10.25, regBase: 185 },
  '986': { state: 'Washington', code: 'WA', tax: 8.10, regBase: 175 },
  '988': { state: 'Washington', code: 'WA', tax: 8.10, regBase: 175 },
  '989': { state: 'Washington', code: 'WA', tax: 8.10, regBase: 175 },
  '990': { state: 'Washington', code: 'WA', tax: 8.90, regBase: 180 },
  '991': { state: 'Washington', code: 'WA', tax: 8.90, regBase: 180 },
  '992': { state: 'Washington', code: 'WA', tax: 8.90, regBase: 180 },
  '993': { state: 'Washington', code: 'WA', tax: 8.90, regBase: 180 },
  '994': { state: 'Washington', code: 'WA', tax: 8.90, regBase: 180 },
  '247': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '248': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '249': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '250': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '251': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '252': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '253': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '254': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '255': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '256': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '257': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '258': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '259': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '260': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '261': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '262': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '263': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '264': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '265': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '266': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '267': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '268': { state: 'West Virginia', code: 'WV', tax: 6.00, regBase: 70 },
  '530': { state: 'Wisconsin', code: 'WI', tax: 5.00, regBase: 110 },
  '531': { state: 'Wisconsin', code: 'WI', tax: 5.00, regBase: 110 },
  '532': { state: 'Wisconsin', code: 'WI', tax: 5.00, regBase: 110 },
  '534': { state: 'Wisconsin', code: 'WI', tax: 5.50, regBase: 115 },
  '535': { state: 'Wisconsin', code: 'WI', tax: 5.00, regBase: 110 },
  '537': { state: 'Wisconsin', code: 'WI', tax: 5.50, regBase: 115 },
  '538': { state: 'Wisconsin', code: 'WI', tax: 5.50, regBase: 115 },
  '820': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '821': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '822': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '823': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '824': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '825': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '826': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '827': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '828': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '829': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '830': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  '831': { state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
};

// ─── LENDERS ──────────────────────────────────────────────────────────────────

const LENDERS = [
  {
    name: 'LightStream by Truist',
    aprLow: 7.49, aprHigh: 10.49,
    minMonths: 24, maxMonths: 180,
    minLoan: 5000,
    perks: ['No fees', 'Rate Beat Program', 'Same-day funding'],
    logo: 'account-balance',
    logoColor: '#00E676',
    badge: 'Best Match',
    url: 'https://www.lightstream.com/rv-loans',
  },
  {
    name: 'Southeast Financial',
    aprLow: 7.99, aprHigh: 11.99,
    minMonths: 12, maxMonths: 180,
    minLoan: 10000,
    perks: ['RV specialist', '180-month terms', 'Fast approval'],
    logo: 'account-balance',
    logoColor: Colors.silverBright,
    badge: null,
    url: 'https://www.southeastfinancial.org/rv-loans',
  },
  {
    name: 'Bank of America',
    aprLow: 8.24, aprHigh: 12.24,
    minMonths: 12, maxMonths: 72,
    minLoan: 10000,
    perks: ['Preferred rewards discount', 'Direct deposit bonus', 'No origination fee'],
    logo: 'account-balance',
    logoColor: Colors.silverDeep,
    badge: null,
    url: 'https://www.bankofamerica.com/auto-loans/rv-boat-loans/',
  },
  {
    name: 'Alliance Credit Union',
    aprLow: 7.74, aprHigh: 13.49,
    minMonths: 12, maxMonths: 180,
    minLoan: 5000,
    perks: ['RV specialist lender', 'Member-owned credit union rates', 'Pre-approval in minutes'],
    logo: 'account-balance',
    logoColor: '#00E676',
    badge: null,
    url: 'https://www.alliancecu.com/loans/recreational-vehicles',
  },
];

// ─── CREDIT SCORE TIERS ──────────────────────────────────────────────────────

const CREDIT_TIERS = [
  { id: '580', label: '580–619', desc: 'Fair',      color: '#FF4444', aprOffset: 3.50 },
  { id: '620', label: '620–679', desc: 'Good',      color: '#FF8C00', aprOffset: 2.00 },
  { id: '680', label: '680–719', desc: 'Very Good', color: '#5B9FFF', aprOffset: 0.75 },
  { id: '720', label: '720+',    desc: 'Excellent', color: '#00C853', aprOffset: 0.00 },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────

// State-wide fallback: maps first digit(s) to state for complete coverage
// This ensures any valid US ZIP returns the right state even if prefix not explicitly listed
const ZIP_RANGE_FALLBACK: Array<{ min: number; max: number; state: string; code: string; tax: number; regBase: number }> = [
  { min: 1,   max: 27,  state: 'Massachusetts',      code: 'MA', tax: 6.25,  regBase: 120 },
  { min: 28,  max: 29,  state: 'Rhode Island',         code: 'RI', tax: 7.00,  regBase: 120 },
  { min: 30,  max: 38,  state: 'New Hampshire',        code: 'NH', tax: 0.00,  regBase: 60  },
  { min: 39,  max: 49,  state: 'Maine',                code: 'ME', tax: 5.50,  regBase: 80  },
  { min: 50,  max: 59,  state: 'Vermont',              code: 'VT', tax: 6.00,  regBase: 85  },
  { min: 60,  max: 69,  state: 'Connecticut',          code: 'CT', tax: 6.35,  regBase: 140 },
  { min: 70,  max: 89,  state: 'New Jersey',           code: 'NJ', tax: 6.625, regBase: 145 },
  { min: 100, max: 149, state: 'New York',             code: 'NY', tax: 8.00,  regBase: 175 },
  { min: 150, max: 196, state: 'Pennsylvania',         code: 'PA', tax: 6.00,  regBase: 95  },
  { min: 197, max: 199, state: 'Delaware',             code: 'DE', tax: 0.00,  regBase: 50  },
  { min: 200, max: 205, state: 'District of Columbia', code: 'DC', tax: 6.00,  regBase: 180 },
  { min: 206, max: 219, state: 'Maryland',             code: 'MD', tax: 6.00,  regBase: 130 },
  { min: 220, max: 246, state: 'Virginia',             code: 'VA', tax: 6.00,  regBase: 95  },
  { min: 247, max: 268, state: 'West Virginia',        code: 'WV', tax: 6.00,  regBase: 70  },
  { min: 270, max: 289, state: 'North Carolina',       code: 'NC', tax: 3.00,  regBase: 35  },
  { min: 290, max: 299, state: 'South Carolina',       code: 'SC', tax: 5.00,  regBase: 60  },
  { min: 300, max: 319, state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  { min: 320, max: 349, state: 'Florida', code: 'FL', tax: 6.00, regBase: 250 },
  { min: 350, max: 369, state: 'Alabama', code: 'AL', tax: 4.00, regBase: 60 },
  { min: 370, max: 385, state: 'Tennessee', code: 'TN', tax: 9.75, regBase: 80 },
  { min: 386, max: 397, state: 'Mississippi', code: 'MS', tax: 7.00, regBase: 60 },
  { min: 398, max: 399, state: 'Georgia', code: 'GA', tax: 7.00, regBase: 90 },
  { min: 400, max: 427, state: 'Kentucky', code: 'KY', tax: 6.00, regBase: 60 },
  { min: 430, max: 458, state: 'Ohio', code: 'OH', tax: 7.50, regBase: 90 },
  { min: 460, max: 479, state: 'Indiana', code: 'IN', tax: 7.00, regBase: 65 },
  { min: 480, max: 499, state: 'Michigan', code: 'MI', tax: 6.00, regBase: 100 },
  { min: 500, max: 528, state: 'Iowa', code: 'IA', tax: 6.00, regBase: 55 },
  { min: 530, max: 549, state: 'Wisconsin', code: 'WI', tax: 5.00, regBase: 110 },
  { min: 550, max: 567, state: 'Minnesota', code: 'MN', tax: 6.875, regBase: 85 },
  { min: 570, max: 577, state: 'South Dakota', code: 'SD', tax: 4.50, regBase: 45 },
  { min: 580, max: 588, state: 'North Dakota', code: 'ND', tax: 5.00, regBase: 40 },
  { min: 590, max: 599, state: 'Montana', code: 'MT', tax: 0.00, regBase: 35 },
  { min: 600, max: 629, state: 'Illinois', code: 'IL', tax: 6.25, regBase: 160 },
  { min: 630, max: 658, state: 'Missouri', code: 'MO', tax: 4.225, regBase: 50 },
  { min: 660, max: 679, state: 'Kansas', code: 'KS', tax: 6.50, regBase: 50 },
  { min: 680, max: 693, state: 'Nebraska', code: 'NE', tax: 7.00, regBase: 55 },
  { min: 700, max: 714, state: 'Louisiana', code: 'LA', tax: 9.45, regBase: 100 },
  { min: 716, max: 729, state: 'Arkansas', code: 'AR', tax: 6.50, regBase: 75 },
  { min: 730, max: 749, state: 'Oklahoma', code: 'OK', tax: 4.50, regBase: 55 },
  { min: 750, max: 799, state: 'Texas', code: 'TX', tax: 8.25, regBase: 150 },
  { min: 800, max: 816, state: 'Colorado', code: 'CO', tax: 2.90, regBase: 45 },
  { min: 820, max: 831, state: 'Wyoming', code: 'WY', tax: 4.00, regBase: 50 },
  { min: 832, max: 838, state: 'Idaho', code: 'ID', tax: 6.00, regBase: 45 },
  { min: 840, max: 847, state: 'Utah', code: 'UT', tax: 6.85, regBase: 70 },
  { min: 850, max: 865, state: 'Arizona', code: 'AZ', tax: 5.60, regBase: 120 },
  { min: 870, max: 884, state: 'New Mexico', code: 'NM', tax: 4.875, regBase: 70 },
  { min: 889, max: 898, state: 'Nevada', code: 'NV', tax: 8.375, regBase: 180 },
  { min: 900, max: 961, state: 'California', code: 'CA', tax: 7.25, regBase: 250 },
  { min: 967, max: 968, state: 'Hawaii', code: 'HI', tax: 4.00, regBase: 45 },
  { min: 970, max: 979, state: 'Oregon', code: 'OR', tax: 0.00, regBase: 75 },
  { min: 980, max: 994, state: 'Washington', code: 'WA', tax: 10.25, regBase: 185 },
  { min: 995, max: 999, state: 'Alaska', code: 'AK', tax: 0.00, regBase: 100 },
];

function lookupZip(zip: string) {
  if (zip.length < 3) return null;
  const prefix3 = zip.slice(0, 3);
  const prefix5 = zip.length >= 5 ? zip.slice(0, 5) : null;
  // Exact prefix match first
  if (prefix5 && ZIP_TO_STATE[prefix5]) return ZIP_TO_STATE[prefix5];
  if (ZIP_TO_STATE[prefix3]) return ZIP_TO_STATE[prefix3];
  // Range fallback — ensures any valid US ZIP resolves
  const num = parseInt(prefix3, 10);
  if (!isNaN(num)) {
    for (const r of ZIP_RANGE_FALLBACK) {
      if (num >= r.min && num <= r.max) {
        return { state: r.state, code: r.code, tax: r.tax, regBase: r.regBase };
      }
    }
  }
  return null;
}

function calcMonthlyPayment(principal: number, annualRate: number, months: number): number {
  if (principal <= 0 || months <= 0) return 0;
  if (annualRate === 0) return principal / months;
  const r = annualRate / 100 / 12;
  return (principal * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1);
}

function fmt(n: number) {
  return n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function fmtDec(n: number) {
  return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ─── PRICE SLIDER ─────────────────────────────────────────────────────────────

const SCREEN_W = Dimensions.get('window').width;
const SLIDER_TRACK_W = SCREEN_W - 32 - 32 - 32;

const PRICE_MIN = 10000;
const PRICE_MAX = 500000;

function PriceSlider({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const trackWidth = useRef(SLIDER_TRACK_W);
  const trackPageX = useRef(0);
  const ratio = (value - PRICE_MIN) / (PRICE_MAX - PRICE_MIN);
  const thumbLeft = Math.max(0, Math.min(trackWidth.current - 28, ratio * trackWidth.current));
  const PRESETS = [10, 50, 100, 150, 200, 250, 300, 400, 500];

  const calcValue = (pageX: number) => {
    const x = pageX - trackPageX.current;
    const w = trackWidth.current;
    const r = Math.max(0, Math.min(1, x / w));
    onChange(Math.round(PRICE_MIN + r * (PRICE_MAX - PRICE_MIN)));
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (evt) => calcValue(evt.nativeEvent.pageX),
      onPanResponderMove: (evt) => calcValue(evt.nativeEvent.pageX),
    })
  ).current;

  return (
    <View style={{ gap: Spacing.sm }}>
      <View style={sliderStyles.valueRow}>
        <View style={sliderStyles.valueBubble}>
          <Text style={sliderStyles.valueBubbleText}>${fmt(value / 1000)}k</Text>
        </View>
        <Text style={sliderStyles.rangeHint}>drag or tap to set price</Text>
        <View style={[sliderStyles.valueBubble, sliderStyles.valueBubbleRight]}>
          <Text style={[sliderStyles.valueBubbleText, { color: Colors.textMuted }]}>$500k</Text>
        </View>
      </View>
      <View
        style={sliderStyles.trackTouchable}
        onLayout={e => {
          trackWidth.current = e.nativeEvent.layout.width;
          // Capture absolute page offset so pageX math is correct
        }}
        ref={(ref: any) => {
          if (ref) {
            ref.measure((_x: number, _y: number, _w: number, _h: number, px: number) => {
              trackPageX.current = px;
            });
          }
        }}
        {...panResponder.panHandlers}
      >
        <View style={sliderStyles.track}>
          <View style={[sliderStyles.fill, { width: thumbLeft + 14 }]} />
          <View style={[sliderStyles.thumb, { left: thumbLeft }]} />
        </View>
      </View>
      <View style={sliderStyles.minMaxRow}>
        <Text style={sliderStyles.minMaxText}>$10k</Text>
        <Text style={sliderStyles.minMaxText}>drag to set price</Text>
        <Text style={sliderStyles.minMaxText}>$500k</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={sliderStyles.presetRow}>
        {PRESETS.map(p => (
          <Pressable
            key={p}
            style={({ pressed }) => [sliderStyles.presetChip, value / 1000 === p && sliderStyles.presetChipActive, pressed && { opacity: 0.7 }]}
            onPress={() => onChange(p * 1000)}
          >
            <Text style={[sliderStyles.presetChipText, value / 1000 === p && sliderStyles.presetChipTextActive]}>
              ${p}k
            </Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const sliderStyles = StyleSheet.create({
  valueRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  valueBubble: {
    backgroundColor: '#00C853',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: Radius.full,
  },
  valueBubbleRight: {
    backgroundColor: Colors.bgCardAlt,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  valueBubbleText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: '#000000',
  },
  rangeHint: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
  },
  track: {
    height: 8,
    backgroundColor: Colors.bgCardAlt,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: Colors.border,
    position: 'relative',
    justifyContent: 'center',
  },
  fill: {
    position: 'absolute',
    left: 0,
    height: 8,
    backgroundColor: '#00C853',
    borderRadius: 4,
    opacity: 0.6,
  },
  thumb: {
    position: 'absolute',
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#00C853',
    top: -10,
    borderWidth: 3,
    borderColor: '#000000',
    shadowColor: '#00C853',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 4,
  },
  trackTouchable: {
    paddingVertical: 14,
    marginVertical: -14,
  },
  minMaxRow: { flexDirection: 'row', justifyContent: 'space-between' },
  minMaxText: { fontSize: 10, color: Colors.textDim },
  presetRow: { flexDirection: 'row', gap: Spacing.xs, paddingVertical: 4 },
  presetChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: Radius.full,
    backgroundColor: Colors.bgCardAlt,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  presetChipActive: {
    backgroundColor: '#00C853',
    borderColor: '#00A844',
  },
  presetChipText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
    color: Colors.textSecondary,
  },
  presetChipTextActive: { color: '#000' },
});

// ─── APR SLIDER ───────────────────────────────────────────────────────────────

const APR_MIN = 4;
const APR_MAX = 25;

function AprSlider({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const trackWidth = useRef(SLIDER_TRACK_W);
  const trackPageX = useRef(0);
  const ratio = (value - APR_MIN) / (APR_MAX - APR_MIN);
  const thumbLeft = Math.max(0, Math.min(trackWidth.current - 28, ratio * trackWidth.current));

  const calcValue = (pageX: number) => {
    const x = pageX - trackPageX.current;
    const w = trackWidth.current;
    const r = Math.max(0, Math.min(1, x / w));
    const raw = APR_MIN + r * (APR_MAX - APR_MIN);
    onChange(Math.round(raw * 4) / 4); // snap to 0.25 increments
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (evt) => calcValue(evt.nativeEvent.pageX),
      onPanResponderMove: (evt) => calcValue(evt.nativeEvent.pageX),
    })
  ).current;

  return (
    <View style={{ gap: Spacing.sm }}>
      <View style={sliderStyles.valueRow}>
        <View style={[sliderStyles.valueBubble, { backgroundColor: '#00C853' }]}>
          <Text style={[sliderStyles.valueBubbleText, { fontSize: FontSize.base, color: '#000000' }]}>{fmtDec(value)}%</Text>
          <Text style={[sliderStyles.valueBubbleText, { fontSize: 9, color: 'rgba(0,0,0,0.65)' }]}>APR</Text>
        </View>
        <Text style={sliderStyles.rangeHint}>drag or tap to set rate</Text>
      </View>
      <View
        style={sliderStyles.trackTouchable}
        onLayout={e => { trackWidth.current = e.nativeEvent.layout.width; }}
        ref={(ref: any) => {
          if (ref) {
            ref.measure((_x: number, _y: number, _w: number, _h: number, px: number) => {
              trackPageX.current = px;
            });
          }
        }}
        {...panResponder.panHandlers}
      >
        <View style={sliderStyles.track}>
          <View style={[sliderStyles.fill, { width: thumbLeft + 14, backgroundColor: '#00C853' }]} />
          <View style={[sliderStyles.thumb, { left: thumbLeft, backgroundColor: '#00C853', borderColor: '#000', shadowColor: '#00C853' }]} />
        </View>
      </View>
      <View style={sliderStyles.minMaxRow}>
        <Text style={sliderStyles.minMaxText}>{APR_MIN}% LOW</Text>
        <Text style={sliderStyles.minMaxText}>drag to set rate</Text>
        <Text style={[sliderStyles.minMaxText, { color: Colors.silverDeep }]}>{APR_MAX}% HIGH</Text>
      </View>
    </View>
  );
}

// ─── DOWN PAYMENT SELECTOR ────────────────────────────────────────────────────

const DOWN_OPTIONS = [10, 15, 20, 30];

function DownSelector({
  selected,
  onSelect,
  price,
}: {
  selected: number;
  onSelect: (p: number) => void;
  price: number;
}) {
  return (
    <View style={downStyles.row}>
      {DOWN_OPTIONS.map(p => {
        const active = selected === p;
        const amount = Math.round((p / 100) * price);
        return (
          <Pressable
            key={p}
            style={({ pressed }) => [
              downStyles.card,
              active && downStyles.cardActive,
              pressed && !active && { opacity: 0.7 },
            ]}
            onPress={() => onSelect(p)}
          >
            {active && <Text style={downStyles.activeLabel}>Active</Text>}
            <Text style={[downStyles.pct, active && downStyles.pctActive]}>{p}%</Text>
            <Text style={[downStyles.amount, active && downStyles.amountActive]}>${fmt(amount)}</Text>
            <Text style={[downStyles.mo, active && { color: '#00E676' }]}>/mo</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const downStyles = StyleSheet.create({
  row: { flexDirection: 'row', gap: Spacing.sm },
  card: {
    flex: 1,
    borderRadius: Radius.md,
    backgroundColor: Colors.bgCardAlt,
    borderWidth: 1.5,
    borderColor: Colors.border,
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 4,
    gap: 2,
    position: 'relative',
  },
  cardActive: {
    backgroundColor: 'rgba(0,200,83,0.12)',
    borderColor: '#00C853',
    shadowColor: '#00C853',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  activeLabel: {
    position: 'absolute',
    top: -9,
    fontSize: 9,
    fontWeight: FontWeight.bold,
    color: '#fff',
    backgroundColor: '#00C853',
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 4,
    overflow: 'hidden',
  },
  pct: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.extrabold,
    color: Colors.textSecondary,
  },
  pctActive: { color: '#00E676' },
  amount: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
    color: Colors.textMuted,
    textAlign: 'center',
  },
  amountActive: { color: '#00E676' },
  mo: {
    fontSize: 9,
    color: Colors.textDim,
  },
});

// ─── CREDIT SCORE SELECTOR ─────────────────────────────────────────────────

function CreditScoreSelector({ selected, onSelect }: { selected: string; onSelect: (id: string) => void }) {
  return (
    <View style={creditSelectorStyles.row}>
      {CREDIT_TIERS.map(tier => {
        const active = selected === tier.id;
        return (
          <Pressable
            key={tier.id}
            style={({ pressed }) => [
              creditSelectorStyles.card,
              active && { borderColor: tier.color, backgroundColor: tier.color + '18', shadowColor: tier.color, shadowOpacity: 0.28, shadowRadius: 8, elevation: 3 },
              pressed && !active && { opacity: 0.7 },
            ]}
            onPress={() => onSelect(tier.id)}
          >
            <Text style={[creditSelectorStyles.scoreLabel, active && { color: tier.color }]}>{tier.label}</Text>
            <Text style={[creditSelectorStyles.scoreDesc, active && { color: tier.color, opacity: 0.85 }]}>{tier.desc}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const creditSelectorStyles = StyleSheet.create({
  row: { flexDirection: 'row', gap: Spacing.xs },
  card: {
    flex: 1, borderRadius: Radius.md,
    backgroundColor: Colors.bgCardAlt,
    borderWidth: 1.5, borderColor: Colors.border,
    alignItems: 'center', paddingVertical: 10, paddingHorizontal: 4, gap: 2,
    shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0, shadowRadius: 0,
  },
  scoreLabel: {
    fontSize: 11, fontWeight: FontWeight.extrabold,
    color: Colors.textSecondary, textAlign: 'center', letterSpacing: 0.2,
  },
  scoreDesc: {
    fontSize: 9, color: Colors.textDim, textAlign: 'center', fontWeight: FontWeight.semibold,
  },
});

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

const TERMS = [84, 120, 144, 180, 240];
const TERM_LABELS = ['7yr', '10yr', '12yr', '15yr', '20yr'];

export default function RvCalScreen() {
  const insets = useSafeAreaInsets();
  const { msrp } = useLocalSearchParams<{ msrp?: string }>();

  // ── All state declarations first (before any useEffect) ──────────────
  const [priceText, setPriceText] = useState('215000');
  const [zipText, setZipText] = useState('');
  const [tradeValue, setTradeValue] = useState('');
  const [tradeOwed, setTradeOwed] = useState('');
  const [downPct, setDownPct] = useState(20);
  const [aprValue, setAprValue] = useState(7.5);
  const [termMonths, setTermMonths] = useState(180);
  const [vehicleAge, setVehicleAge] = useState('0');
  const [creditScore, setCreditScore] = useState<string>('720');
  const [pdfLoading, setPdfLoading] = useState(false);

  useEffect(() => {
    if (msrp) {
      const n = parseInt(msrp, 10);
      if (!isNaN(n) && n > 0) setPriceText(String(n));
    }
  }, [msrp]);

  // Auto-suggest APR based on credit score tier
  useEffect(() => {
    const suggestions: Record<string, number> = { '580': 13.5, '620': 11.0, '680': 9.0, '720': 7.5 };
    const suggested = suggestions[creditScore];
    if (suggested !== undefined) setAprValue(suggested);
  }, [creditScore]);

  const price = useMemo(() => {
    const n = parseFloat(priceText.replace(/,/g, ''));
    return isNaN(n) ? 0 : Math.max(PRICE_MIN, Math.min(PRICE_MAX, n));
  }, [priceText]);

  const zipInfo = useMemo(() => lookupZip(zipText), [zipText]);

  const tradeVal = useMemo(() => {
    const n = parseFloat(tradeValue.replace(/,/g, ''));
    return isNaN(n) ? 0 : n;
  }, [tradeValue]);

  const tradeOw = useMemo(() => {
    const n = parseFloat(tradeOwed.replace(/,/g, ''));
    return isNaN(n) ? 0 : n;
  }, [tradeOwed]);

  const negativeEquity = Math.max(0, tradeOw - tradeVal);
  const tradeNetCredit = Math.max(0, tradeVal - tradeOw);
  const creditTier = CREDIT_TIERS.find(t => t.id === creditScore) ?? CREDIT_TIERS[3];

  const taxRate = zipInfo?.tax ?? 0;
  // Trade-in tax credit: most states tax only (sale price - trade-in value), not full price
  const stateCode = zipInfo?.code ?? '';
  // Tax credit is based on the FULL trade-in allowance (tradeVal), not net equity.
  // In credit states: taxable amount = selling price − trade-in value.
  // The loan payoff does not affect what the state taxes.
  const tradeInTaxCredit = TRADE_IN_TAX_CREDIT_STATES.has(stateCode) ? tradeVal : 0;
  const taxableAmount = Math.max(0, price - tradeInTaxCredit);
  const salesTax = taxableAmount * (taxRate / 100);
  const regFee = zipInfo ? zipInfo.regBase + Math.floor(price / 10000) * 15 : 0;
  const titleFee = 25;
  const downAmt = Math.round((downPct / 100) * price);
  const amountFinanced = price + salesTax + regFee + titleFee + negativeEquity - downAmt - tradeNetCredit;
  const monthlyPayment = calcMonthlyPayment(amountFinanced, aprValue, termMonths);
  const totalInterest = monthlyPayment * termMonths - amountFinanced;
  const totalPayments = monthlyPayment * termMonths;

  const hasResult = price > 0 && zipInfo !== null;

  const lenderPayments = useMemo(() => {
    const tier = CREDIT_TIERS.find(t => t.id === creditScore) ?? CREDIT_TIERS[3];
    return LENDERS.map(l => {
      const adjLow  = Math.round((l.aprLow  + tier.aprOffset) * 100) / 100;
      const adjHigh = Math.round((l.aprHigh + tier.aprOffset) * 100) / 100;
      const qualifies = amountFinanced >= l.minLoan &&
        !(creditScore === '580' && l.name === 'Bank of America');
      return {
        ...l,
        adjAprLow: adjLow,
        adjAprHigh: adjHigh,
        monthly: calcMonthlyPayment(amountFinanced, (adjLow + adjHigh) / 2, Math.min(termMonths, l.maxMonths)),
        qualifies,
      };
    });
  }, [amountFinanced, termMonths, creditScore]);

  const handleGeneratePDF = async () => {
    setPdfLoading(true);
    try {
      const rv: RVReportData = {
        year: new Date().getFullYear().toString(),
        make: 'RV', model: 'Vehicle', floorplan: '',
        type: 'Motorhome', floorplans: [],
        lengthRange: [35, 45] as [number, number],
        weightRange: [30000, 40000] as [number, number],
        slideouts: 3, sleeps: 6,
        msrpRange: [price, price] as [number, number],
        fuelType: 'Diesel', recalls: 0, rating: 4.5, image: '',
      };
      const loanData: LoanReportData = {
        rv, sellingPrice: price, downPct, downAmt,
        tradeValue: tradeVal > 0 ? tradeVal : undefined,
        tradeOwed: tradeOw > 0 ? tradeOw : undefined,
        amountFinanced, apr: aprValue, termMonths,
        monthlyPayment, totalInterest, totalPayments,
        salesTax, taxRate, regFee: regFee + titleFee,
        stateCode: zipInfo?.code, stateName: zipInfo?.state,
        negativeEquity: negativeEquity > 0 ? negativeEquity : undefined,
        tradeNetCredit: tradeNetCredit > 0 ? tradeNetCredit : undefined,
      };
      await generateAndShareLoanReport(loanData);
    } catch {
      Alert.alert('PDF Error', 'Could not generate report. Please try again.');
    } finally {
      setPdfLoading(false);
    }
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* GREEN NEON ENTEGRA HERO BACKDROP */}
      <View style={styles.heroBackdrop}>
        <Image
          source={require('../../assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.3 }}
          transition={400}
        />
        <LinearGradient
          colors={['rgba(30,46,64,0.70)', 'rgba(20,38,72,0.28)', 'rgba(20,38,72,0.22)', 'rgba(30,46,64,0.40)', 'rgba(18,28,50,0.76)']}
          locations={[0, 0.18, 0.5, 0.82, 1]}
          style={StyleSheet.absoluteFill}
        />
      </View>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>RvCal</Text>
        <View style={styles.stateBadge}>
          <MaterialIcons name="grid-view" size={13} color="#00E676" />
          <Text style={styles.stateBadgeText}>All 50 States</Text>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: insets.bottom + Spacing.xl }}
      >
        {/* Vehicle Details Card */}
        <View style={styles.card}>
          <View style={styles.cardHeaderRow}>
            <MaterialIcons name="directions-car" size={16} color={'#00E676'} />
            <Text style={styles.cardTitle}>Vehicle Details</Text>
          </View>
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>SELLING PRICE *</Text>
            <TextInput
              style={styles.input}
              value={priceText}
              onChangeText={v => {
                const n = parseFloat(v.replace(/,/g, ''));
                if (!isNaN(n)) setPriceText(v);
                else if (v === '' || v === '$') setPriceText('');
              }}
              placeholder="215,000"
              placeholderTextColor={Colors.textMuted}
              keyboardType="numeric"
            />
          </View>
          <PriceSlider value={price} onChange={v => setPriceText(String(v))} />
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>VEHICLE AGE (YEARS)</Text>
            <TextInput
              style={styles.input}
              value={vehicleAge}
              onChangeText={setVehicleAge}
              placeholder="0"
              placeholderTextColor={Colors.textMuted}
              keyboardType="numeric"
            />
          </View>
        </View>

        {/* Location & Tax Card */}
        <View style={styles.card}>
          <View style={styles.cardHeaderRow}>
            <MaterialIcons name="location-on" size={16} color={'#00E676'} />
            <Text style={styles.cardTitle}>Location & Tax</Text>
          </View>
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>CUSTOMER ZIP CODE</Text>
            <TextInput
              style={[styles.input, zipInfo && styles.inputSuccess]}
              value={zipText}
              onChangeText={setZipText}
              placeholder="85001"
              placeholderTextColor={Colors.textMuted}
              keyboardType="numeric"
              maxLength={5}
            />
            <Text style={styles.fieldHint}>Enter ZIP to auto-fill state tax + registration fees</Text>
          </View>
          {zipInfo ? (
            <View style={styles.taxBadge}>
              <MaterialIcons name="check-circle" size={14} color={'#00E676'} />
              <Text style={styles.taxBadgeText}>
                {zipInfo.state} ({zipInfo.code}) — {fmtDec(zipInfo.tax)}% sales tax
              </Text>
            </View>
          ) : zipText.length >= 3 ? (
            <View style={[styles.taxBadge, { backgroundColor: 'rgba(255,68,68,0.08)', borderColor: 'rgba(255,68,68,0.2)' }]}>
              <MaterialIcons name="info-outline" size={14} color={Colors.red} />
              <Text style={[styles.taxBadgeText, { color: Colors.red }]}>ZIP not recognized — using 0% tax</Text>
            </View>
          ) : null}
        </View>

        {/* Trade-In Card */}
        <View style={styles.card}>
          <View style={styles.cardHeaderRow}>
            <MaterialIcons name="swap-horiz" size={16} color={'#00E676'} />
            <Text style={[styles.cardTitle, { color: '#00E676' }]}>Trade-In</Text>
          </View>
          <View style={styles.row}>
            <View style={[styles.fieldGroup, { flex: 1 }]}>
              <Text style={[styles.fieldLabel, { color: '#00E676' }]}>TRADE-IN VALUE</Text>
              <TextInput style={styles.input} value={tradeValue} onChangeText={setTradeValue}
                placeholder="$ 0" placeholderTextColor={Colors.textMuted} keyboardType="numeric" />
            </View>
            <View style={[styles.fieldGroup, { flex: 1 }]}>
              <Text style={[styles.fieldLabel, { color: '#00E676' }]}>TRADE PAYOFF (OWED)</Text>
              <TextInput style={styles.input} value={tradeOwed} onChangeText={setTradeOwed}
                placeholder="$ 0" placeholderTextColor={Colors.textMuted} keyboardType="numeric" />
            </View>
          </View>
          {(tradeVal > 0 || tradeOw > 0) && (
            <View style={styles.equityCard}>
              {negativeEquity > 0 ? (
                <>
                  <View style={styles.equityHeader}>
                    <MaterialIcons name="trending-down" size={14} color={Colors.red} />
                    <Text style={styles.equityTitleNeg}>NEGATIVE EQUITY / ROLLOVER</Text>
                    <Text style={styles.equityAmtNeg}>-${fmt(negativeEquity)}</Text>
                  </View>
                  <View style={styles.equityBarTrack}>
                    <View style={[styles.equityBarFill, {
                      width: `${Math.min(100, (tradeVal / Math.max(tradeVal, tradeOw)) * 100)}%` as any,
                      backgroundColor: '#00E676',
                    }]} />
                  </View>
                  <View style={styles.equityBarLabels}>
                    <Text style={styles.equityBarLabel}>
                      <Text style={{ color: '#00E676' }}>● </Text>Trade Value ${fmt(tradeVal)}
                    </Text>
                    <Text style={styles.equityBarLabel}>
                      Amount Owed ${fmt(tradeOw)}
                      <Text style={{ color: Colors.red }}> ●</Text>
                    </Text>
                  </View>
                  <View style={styles.equityNote}>
                    <MaterialIcons name="info" size={11} color={Colors.textMuted} />
                    <Text style={styles.equityNoteText}>
                      ${fmt(negativeEquity)} negative equity will be added to your loan
                    </Text>
                  </View>
                </>
              ) : (
                <View style={styles.equityHeader}>
                  <MaterialIcons name="trending-up" size={14} color={'#00E676'} />
                  <Text style={styles.equityTitlePos}>TRADE CREDIT</Text>
                  <Text style={styles.equityAmtPos}>+${fmt(tradeNetCredit)}</Text>
                </View>
              )}
            </View>
          )}
        </View>

        {/* Financing Card */}
        <View style={styles.card}>
          <View style={styles.cardHeaderRow}>
            <MaterialIcons name="attach-money" size={16} color={'#00E676'} />
            <Text style={styles.cardTitle}>Financing</Text>
          </View>
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>DOWN PAYMENT</Text>
            <DownSelector selected={downPct} onSelect={setDownPct} price={price} />
            <Text style={styles.fieldHint}>Tap any card to instantly switch down payment</Text>
          </View>
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>CREDIT SCORE RANGE</Text>
            <CreditScoreSelector selected={creditScore} onSelect={setCreditScore} />
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 5 }}>
              <MaterialIcons name="info-outline" size={12} color={creditTier.color} />
              <Text style={[styles.fieldHint, { color: creditTier.color, marginTop: 0 }]}>
                {creditScore === '580' ? 'Some lenders may decline — larger down recommended'
                 : creditScore === '620' ? 'Rates auto-adjusted · standard approval odds'
                 : creditScore === '680' ? 'Preferred rates available · good approval odds'
                 : 'Best available rates · excellent approval odds'}
              </Text>
            </View>
          </View>
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>INTEREST RATE (APR)</Text>
            <AprSlider value={aprValue} onChange={setAprValue} />
          </View>
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>LOAN TERM</Text>
            <View style={styles.termRow}>
              {TERMS.map((t, i) => (
                <Pressable
                  key={t}
                  style={({ pressed }) => [
                    styles.termBtn,
                    termMonths === t && styles.termBtnActive,
                    pressed && termMonths !== t && { opacity: 0.7 },
                  ]}
                  onPress={() => setTermMonths(t)}
                >
                  <Text style={[styles.termText, termMonths === t && styles.termTextActive]}>
                    {TERM_LABELS[i]}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        </View>

        {/* Results */}
        {hasResult ? (
          <>
            <View style={styles.heroCard}>
              <View style={styles.heroTop}>
                <Text style={styles.heroLabel}>EST. MONTHLY PAYMENT</Text>
                <Text style={styles.heroAmount}>${fmt(Math.round(monthlyPayment))}</Text>
                <Text style={styles.heroSub}>/month for {termMonths} months</Text>
              </View>
              <View style={styles.heroStrip}>
                {DOWN_OPTIONS.map(p => {
                  const amt = Math.round((p / 100) * price);
                  const financed = price + salesTax + regFee + titleFee + negativeEquity - amt - tradeNetCredit;
                  const mo = Math.round(calcMonthlyPayment(financed, aprValue, termMonths));
                  const active = p === downPct;
                  return (
                    <Pressable
                      key={p}
                      style={[styles.heroStripCard, active && styles.heroStripCardActive]}
                      onPress={() => setDownPct(p)}
                    >
                      <Text style={[styles.heroStripPct, active && { color: '#00E676' }]}>{p}%</Text>
                      <Text style={[styles.heroStripAmt, active && { color: '#00E676' }]}>${fmt(amt)}</Text>
                      <Text style={[styles.heroStripMo, active && { color: Colors.textPrimary }]}>${fmt(mo)}</Text>
                      <Text style={styles.heroStripMoLabel}>/mo</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>

            <Pressable
              style={({ pressed }) => [styles.pdfBtn, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }, pdfLoading && { opacity: 0.7 }]}
              onPress={handleGeneratePDF}
              disabled={pdfLoading}
            >
              {pdfLoading ? (
                <ActivityIndicator color="#000" size="small" />
              ) : (
                <MaterialIcons name="picture-as-pdf" size={18} color="#000" />
              )}
              <Text style={styles.pdfBtnText}>{pdfLoading ? 'Generating...' : 'Generate PDF Report'}</Text>
            </Pressable>

            <View style={styles.card}>
              <View style={styles.cardHeaderRow}>
                <MaterialIcons name="receipt-long" size={16} color={'#00E676'} />
                <Text style={styles.cardTitle}>Payment Breakdown</Text>
              </View>
              {[
                { label: 'Vehicle Price', value: `$${fmt(price)}`, color: Colors.textPrimary },
                tradeInTaxCredit > 0
                  ? { label: `Sales Tax on Net (${fmtDec(taxRate)}% × $${fmt(Math.round(taxableAmount))})`, value: `$${fmt(Math.round(salesTax))}`, color: Colors.textSecondary }
                  : { label: `Sales Tax (${fmtDec(taxRate)}%)`, value: `$${fmt(Math.round(salesTax))}`, color: Colors.textSecondary },
                { label: 'Registration Fees', value: `$${fmt(regFee)}`, color: Colors.textSecondary },
                negativeEquity > 0 ? { label: 'Negative Equity (added)', value: `+$${fmt(negativeEquity)}`, color: Colors.red } : null,
                tradeNetCredit > 0 ? {
                  label: tradeInTaxCredit > 0
                    ? `Trade-In Credit (${stateCode} tax credit applied)`
                    : `Trade-In Credit (${stateCode} taxes full price)`,
                  value: `-$${fmt(tradeNetCredit)}`,
                  color: '#00E676',
                } : null,
                { label: `Down Payment (${downPct}%)`, value: `-$${fmt(downAmt)}`, color: '#00E676' },
                { label: '', value: '', divider: true },
                { label: 'Amount Financed', value: `$${fmt(Math.round(amountFinanced))}`, color: Colors.textPrimary, bold: true },
                { label: 'Total Interest', value: `$${fmt(Math.round(totalInterest))}`, color: Colors.red },
                { label: 'Total of Payments', value: `$${fmt(Math.round(totalPayments))}`, color: Colors.silverBright, bold: true },
              ]
                .filter(Boolean)
                .map((row: any, i) => {
                  if (row.divider) return <View key={i} style={styles.breakdownDivider} />;
                  return (
                    <View key={i} style={styles.breakdownRow}>
                      <Text style={[styles.breakdownLabel, row.bold && { color: Colors.textPrimary, fontWeight: FontWeight.bold }]}>
                        {row.label}
                      </Text>
                      <Text style={[styles.breakdownValue, { color: row.color }, row.bold && { fontWeight: FontWeight.bold }]}>
                        {row.value}
                      </Text>
                    </View>
                  );
                })}
              <View style={styles.regBreakdownCard}>
                <View style={styles.regBreakdownHeader}>
                  <MaterialIcons name="description" size={13} color={Colors.silver} />
                  <Text style={styles.regBreakdownTitle}>Registration Fee Breakdown</Text>
                </View>
                {[
                  { label: `Registration (${zipInfo?.code ?? ''})`, value: `$${zipInfo?.regBase ?? 0}` },
                  { label: 'Title', value: '$25' },
                  { label: 'Weight/VLF Fee', value: `$${Math.floor(price / 10000) * 15}` },
                ].map((r, i) => (
                  <View key={i} style={styles.regRow}>
                    <Text style={styles.regRowLabel}>{r.label}</Text>
                    <Text style={styles.regRowValue}>{r.value}</Text>
                  </View>
                ))}
              </View>
            </View>

            <Pressable style={styles.lenderHeaderCard} onPress={() => {}}>
              <View style={styles.lenderHeaderLeft}>
                <MaterialIcons name="language" size={18} color={Colors.textPrimary} />
                <View>
                  <Text style={styles.lenderHeaderSub}>LENDER INTELLIGENCE</Text>
                  <Text style={styles.lenderHeaderTitle}>Compare Lenders</Text>
                </View>
              </View>
              <MaterialIcons name="keyboard-arrow-down" size={20} color={Colors.textSecondary} />
            </Pressable>

            {lenderPayments.map((l, i) => (
              <View key={i} style={[styles.lenderCard, i === 0 && styles.lenderCardBest]}>
                {i === 0 && (
                  <View style={styles.bestBadge}>
                    <MaterialIcons name="star" size={11} color="#fff" />
                    <Text style={styles.bestBadgeText}>Best Match</Text>
                  </View>
                )}
                {!l.qualifies && (
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 6, backgroundColor: 'rgba(212,37,53,0.10)', borderRadius: 6, padding: 6, borderWidth: 1, borderColor: 'rgba(212,37,53,0.25)' }}>
                    <MaterialIcons name="block" size={12} color={Colors.red} />
                    <Text style={{ fontSize: 11, color: Colors.red, fontWeight: '600' as const }}>May not qualify at this credit score</Text>
                  </View>
                )}
                <View style={styles.lenderTop}>
                  <View style={[styles.lenderIcon, { borderColor: (l.logoColor as string) + '44' }]}>
                    <MaterialIcons name={l.logo as any} size={18} color={l.logoColor as string} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.lenderName}>{l.name}</Text>
                    <Text style={styles.lenderApr}>{fmtDec(l.adjAprLow ?? l.aprLow)}% – {fmtDec(l.adjAprHigh ?? l.aprHigh)}% APR</Text>
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text style={styles.lenderMonthly}>${fmt(Math.round(l.monthly))}/mo</Text>
                    <Text style={styles.lenderMonthlyLabel}>estimated</Text>
                    <View style={[styles.lenderRatingBadge, { backgroundColor: i === 0 ? 'rgba(0,230,118,0.13)' : Colors.silver + '22' }]}>
                      <Text style={[styles.lenderRatingText, { color: i === 0 ? '#00E676' : Colors.silver }]}>
                        {i === 0 ? 'TOP PICK' : i === 1 ? 'HIGH' : 'MEDIUM'}
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={styles.lenderChips}>
                  <View style={styles.lenderChip}>
                    <MaterialIcons name="access-time" size={11} color={Colors.textMuted} />
                    <Text style={styles.lenderChipText}>{l.minMonths}–{l.maxMonths} mo</Text>
                  </View>
                  <View style={styles.lenderChip}>
                    <MaterialIcons name="attach-money" size={11} color={Colors.textMuted} />
                    <Text style={styles.lenderChipText}>Min ${fmt(l.minLoan)}</Text>
                  </View>
                </View>
                {l.perks.map((p, j) => (
                  <View key={j} style={styles.lenderPerk}>
                    <MaterialIcons name="check" size={13} color={'#00E676'} />
                    <Text style={styles.lenderPerkText}>{p}</Text>
                  </View>
                ))}
                <Pressable
                  style={({ pressed }) => [styles.rateButton, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]}
                  onPress={() => l.url && Linking.openURL(l.url)}
                >
                  <Text style={styles.rateButtonText}>Check My Rate</Text>
                  <MaterialIcons name="open-in-new" size={14} color="#000" />
                </Pressable>
              </View>
            ))}

            <Text style={styles.disclaimer}>
              Estimates only · Always verify with lender · {new Date().getFullYear()} RvFOX Pro
              {tradeInTaxCredit > 0 ? ` · ${stateCode} trade-in tax credit applied` : stateCode && !TRADE_IN_TAX_CREDIT_STATES.has(stateCode) && stateCode !== '' ? ` · ${stateCode} taxes full price (no trade-in credit)` : ''}
            </Text>
          </>
        ) : (
          <View style={styles.resultPlaceholder}>
            <MaterialIcons name="receipt-long" size={36} color={Colors.textDim} />
            <Text style={styles.placeholderText}>Enter selling price + ZIP to calculate</Text>
            <Text style={styles.placeholderSub}>Tax · Registration · Monthly Payment · Lender Comparison</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A2A3A' },
  heroBackdrop: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 0,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.sm,
    paddingBottom: Spacing.md,
    zIndex: 2,
  },
  headerTitle: {
    fontSize: FontSize.xxl,
    fontWeight: FontWeight.extrabold,
    color: '#FFFFFF',
    letterSpacing: 1,
  },
  stateBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0,200,83,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(0,200,83,0.40)',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: Radius.full,
  },
  stateBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
    color: '#00E676',
  },
  card: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(4,8,22,0.82)',
    borderRadius: Radius.xl,
    borderWidth: 1.5,
    borderColor: 'rgba(0,200,83,0.40)',
    padding: Spacing.md,
    gap: Spacing.md,
    zIndex: 2,
    shadowColor: '#00C853',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.18,
    shadowRadius: 14,
    elevation: 4,
  },
  cardHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  cardTitle: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
  },
  row: { flexDirection: 'row', gap: Spacing.sm },
  fieldGroup: { gap: Spacing.xs },
  fieldLabel: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
    letterSpacing: 1.0,
  },
  fieldHint: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    marginTop: 2,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: 12,
    color: '#FFFFFF',
    fontSize: FontSize.md,
  },
  inputSuccess: {
    borderColor: '#00C853',
    backgroundColor: 'rgba(0,200,83,0.05)',
  },
  taxBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0,200,83,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(0,200,83,0.35)',
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 8,
    marginTop: -Spacing.xs,
  },
  taxBadgeText: {
    fontSize: FontSize.sm,
    color: '#00E676',
    fontWeight: FontWeight.semibold,
  },
  equityCard: {
    backgroundColor: 'rgba(255,68,68,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,68,68,0.2)',
    borderRadius: Radius.md,
    padding: Spacing.sm,
    gap: Spacing.sm,
  },
  equityHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  equityTitleNeg: { flex: 1, fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.red, letterSpacing: 1 },
  equityAmtNeg: { fontSize: FontSize.md, fontWeight: FontWeight.extrabold, color: Colors.red },
  equityTitlePos: { flex: 1, fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: '#00E676', letterSpacing: 1 },
  equityAmtPos: { fontSize: FontSize.md, fontWeight: FontWeight.extrabold, color: '#00E676' },
  equityBarTrack: { height: 8, backgroundColor: Colors.red + '33', borderRadius: 4, overflow: 'hidden' },
  equityBarFill: { height: 8, borderRadius: 4 },
  equityBarLabels: { flexDirection: 'row', justifyContent: 'space-between' },
  equityBarLabel: { fontSize: 10, color: Colors.textMuted },
  equityNote: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 5,
    backgroundColor: 'rgba(255,68,68,0.08)',
    borderRadius: Radius.sm,
    padding: Spacing.xs,
  },
  equityNoteText: { flex: 1, fontSize: 11, color: Colors.textSecondary, lineHeight: 16 },
  termRow: { flexDirection: 'row', gap: Spacing.xs },
  termBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: Radius.md,
    backgroundColor: Colors.bgCardAlt,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  termBtnActive: {
    backgroundColor: 'rgba(0,200,83,0.14)',
    borderColor: '#00C853',
    shadowColor: '#00C853',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 3,
  },
  termText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textSecondary },
  termTextActive: { color: '#00E676' },
  heroCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(0,200,83,0.07)',
    borderWidth: 1.5,
    borderColor: 'rgba(0,200,83,0.40)',
    borderRadius: Radius.xl,
    overflow: 'hidden',
    shadowColor: '#00C853',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
    zIndex: 2,
  },
  heroTop: {
    alignItems: 'center',
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,200,83,0.35)',
    gap: 4,
  },
  heroLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: '#00E676', letterSpacing: 2 },
  heroAmount: { fontSize: 42, fontWeight: FontWeight.extrabold, color: '#FFFFFF', letterSpacing: -1 },
  heroSub: { fontSize: FontSize.sm, color: Colors.textSecondary },
  heroStrip: { flexDirection: 'row' },
  heroStripCard: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 4,
    borderRightWidth: 1,
    borderRightColor: Colors.border,
    gap: 1,
  },
  heroStripCardActive: { backgroundColor: 'rgba(0,200,83,0.10)' },
  heroStripPct: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textMuted },
  heroStripAmt: { fontSize: FontSize.xs, color: Colors.textMuted },
  heroStripMo: { fontSize: FontSize.md, fontWeight: FontWeight.extrabold, color: Colors.textSecondary },
  heroStripMoLabel: { fontSize: 9, color: Colors.textDim },
  breakdownRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 7,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  breakdownLabel: { fontSize: FontSize.sm, color: Colors.textSecondary, flex: 1 },
  breakdownValue: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  breakdownDivider: { height: 1, backgroundColor: 'rgba(0,200,83,0.40)', marginVertical: Spacing.xs },
  regBreakdownCard: {
    backgroundColor: Colors.bgCardAlt,
    borderRadius: Radius.md,
    padding: Spacing.sm,
    gap: Spacing.xs,
  },
  regBreakdownHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  regBreakdownTitle: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.silver, letterSpacing: 0.8 },
  regRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 3 },
  regRowLabel: { fontSize: FontSize.xs, color: Colors.textSecondary },
  regRowValue: { fontSize: FontSize.xs, color: Colors.textPrimary, fontWeight: FontWeight.semibold },
  lenderHeaderCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    backgroundColor: 'rgba(0,200,83,0.06)',
    borderWidth: 1.5,
    borderColor: 'rgba(0,200,83,0.40)',
    borderRadius: Radius.xl,
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    zIndex: 2,
  },
  lenderHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  lenderHeaderSub: { fontSize: FontSize.xs, color: Colors.textSecondary, letterSpacing: 1, fontWeight: FontWeight.bold },
  lenderHeaderTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  lenderCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(4,8,22,0.82)',
    borderRadius: Radius.xl,
    borderWidth: 1.5,
    borderColor: 'rgba(0,200,83,0.32)',
    padding: Spacing.md,
    gap: Spacing.sm,
    zIndex: 2,
    shadowColor: '#00C853',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 4,
  },
  lenderCardBest: {
    borderColor: 'rgba(0,200,83,0.40)',
    backgroundColor: 'rgba(0,200,83,0.06)',
  },
  bestBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    backgroundColor: '#00C853',
    borderRadius: Radius.full,
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginBottom: -4,
  },
  bestBadgeText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: '#000' },
  lenderTop: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm },
  lenderIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: Colors.bgCardAlt,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  lenderName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: '#FFFFFF' },
  lenderApr: { fontSize: FontSize.sm, color: Colors.textSecondary, marginTop: 2 },
  lenderMonthly: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: '#FFFFFF' },
  lenderMonthlyLabel: { fontSize: FontSize.xs, color: Colors.textSecondary, textAlign: 'right' },
  lenderRatingBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: Radius.full, marginTop: 2, alignItems: 'center' },
  lenderRatingText: { fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.5 },
  lenderChips: { flexDirection: 'row', gap: Spacing.xs },
  lenderChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(0,0,0,0.25)',
    borderRadius: Radius.full,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  lenderChipText: { fontSize: FontSize.xs, color: Colors.textSecondary },
  lenderPerk: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  lenderPerkText: { fontSize: FontSize.sm, color: Colors.textSecondary },
  rateButton: {
    backgroundColor: '#00C853',
    borderRadius: Radius.full,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    marginTop: 4,
    shadowColor: '#00C853',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 4,
  },
  rateButtonText: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: '#000000' },
  disclaimer: {
    fontSize: FontSize.xs,
    color: Colors.textDim,
    textAlign: 'center',
    marginHorizontal: Spacing.md,
    marginTop: -Spacing.sm,
    marginBottom: Spacing.md,
    lineHeight: 16,
  },
  resultPlaceholder: {
    alignItems: 'center',
    paddingVertical: Spacing.xxl,
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
    zIndex: 2,
  },
  placeholderText: { fontSize: FontSize.md, color: 'rgba(255,255,255,0.80)', fontWeight: FontWeight.medium },
  placeholderSub: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center' },
  pdfBtn: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    backgroundColor: '#00C853',
    borderRadius: Radius.full,
    paddingVertical: 14,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    gap: Spacing.sm,
    shadowColor: '#00C853',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 5,
  },
  pdfBtnText: {
    fontSize: FontSize.base,
    fontWeight: '700' as const,
    color: '#000',
  },
});
