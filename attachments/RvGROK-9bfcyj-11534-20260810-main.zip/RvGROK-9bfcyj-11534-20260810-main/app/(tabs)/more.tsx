
import { View, Text, StyleSheet, ScrollView, Pressable, Linking } from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { useAuth } from '@/template';
import { useSubscriptionContext } from '@/contexts/SubscriptionContext';
import { TIER_LABELS } from '@/hooks/useSubscription';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface MenuRowProps {
  icon: string;
  iconBg: string;
  iconColor: string;
  title: string;
  subtitle: string;
  external?: boolean;
  onPress?: () => void;
}

// ─── COMPONENTS ───────────────────────────────────────────────────────────────

function MenuRow({ icon, iconBg, iconColor, title, subtitle, external, onPress }: MenuRowProps) {
  return (
    <Pressable
      style={({ pressed }) => [styles.menuRow, pressed && { opacity: 0.7, backgroundColor: 'rgba(255,255,255,0.04)' }]}
      onPress={onPress}
    >
      <View style={[styles.menuIconBg, { backgroundColor: iconBg }]}>
        <MaterialIcons name={icon as any} size={18} color={iconColor} />
      </View>
      <View style={styles.menuRowText}>
        <Text style={styles.menuTitle}>{title}</Text>
        <Text style={styles.menuSub}>{subtitle}</Text>
      </View>
      <MaterialIcons
        name={external ? 'open-in-new' : 'chevron-right'}
        size={18}
        color={external ? Colors.blueBright : Colors.textMuted}
      />
    </Pressable>
  );
}

function StatCard({ value, label, icon, color }: {
  value: string; label: string; icon: string; color: string;
}) {
  return (
    <View style={[styles.statCard, { borderColor: color + '50' }]}>
      <View style={[styles.statIconWrap, { backgroundColor: color + '20' }]}>
        <MaterialIcons name={icon as any} size={20} color={color} />
      </View>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

// ─── MAIN SCREEN ──────────────────────────────────────────────────────────────

export default function MoreScreen() {
  const insets = useSafeAreaInsets();
  const { user, logout } = useAuth();
  const router = useRouter();
  const { tier, isActive } = useSubscriptionContext();

  const metaPhone = (user as any)?.user_metadata?.phone_number as string | undefined;
  const formattedPhone = metaPhone
    ? metaPhone.replace(/^1?/, '').replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3')
    : user?.email?.replace('@phone.rvfox.app', '') ?? '—';

  const displayName = user?.username && !user.username.startsWith('user_')
    ? user.username
    : formattedPhone;

  const phoneDisplay = formattedPhone;

  const ndaDate = user
    ? (() => {
        const raw = (user as any).nda_accepted_at;
        if (raw) {
          const d = new Date(raw);
          return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
        }
        return 'Accepted';
      })()
    : '—';

  const memberSince = user?.created_at
    ? new Date(user.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
    : '—';

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* RV PRO PREMIUM BACKDROP */}
      <View style={styles.heroBackdrop}>
        <Image
          source={require('../../assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.3 }}
          transition={400}
        />
        <LinearGradient
          colors={[
            'rgba(30,46,64,0.70)',
            'rgba(20,38,72,0.28)',
            'rgba(20,38,72,0.22)',
            'rgba(30,46,64,0.40)',
            'rgba(18,28,50,0.76)',
          ]}
          locations={[0, 0.18, 0.5, 0.82, 1]}
          style={StyleSheet.absoluteFill}
        />
      </View>

      {/* ── HEADER ── */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerBrand}>RvFOX Pro</Text>
          <Text style={styles.headerTagline}>Know before you buy.</Text>
        </View>
        <View style={styles.versionBadge}>
          <MaterialIcons name="verified" size={13} color={Colors.blueBright} />
          <Text style={styles.versionText}>v2.0 Beta</Text>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + Spacing.xl }}
        style={{ zIndex: 2 }}
      >

        {/* ── PREMIUM PROFILE CARD ── */}
        <View style={styles.profileCard}>
          <View style={styles.profileCardAccent} />
          <View style={styles.profileCardInner}>
            <View style={styles.avatarWrap}>
              <View style={styles.avatarGlowOuter} />
              <View style={styles.avatar}>
                <MaterialIcons name="person" size={34} color={Colors.gold} />
              </View>
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>{displayName}</Text>
              <View style={styles.profileDetailRow}>
                <MaterialIcons name="smartphone" size={13} color={Colors.blueBright} />
                <Text style={styles.profileDetail}>{phoneDisplay}</Text>
              </View>
              <View style={styles.profileDetailRow}>
                <MaterialIcons name="event-available" size={13} color={Colors.blueBright} />
                <Text style={styles.profileDetail}>Member since {memberSince}</Text>
              </View>
            </View>
            <View style={styles.ndaBadge}>
              <MaterialIcons name="verified-user" size={14} color={Colors.blueBright} />
              <View>
                <Text style={styles.ndaBadgeTitle}>NDA Signed</Text>
                <Text style={styles.ndaBadgeDate}>{ndaDate}</Text>
              </View>
            </View>
          </View>
        </View>

        {/* ── RV PROFILE CARD ── */}
        <Pressable
          style={({ pressed }) => [
            styles.rvProfileCard,
            pressed && { opacity: 0.88, transform: [{ scale: 0.99 }] },
          ]}
          onPress={() => router.push('/rv-profile')}
        >
          <View style={styles.rvProfileLeft}>
            <View style={styles.rvProfileIcon}>
              <MaterialIcons name="directions-bus" size={24} color={Colors.blueBright} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rvProfileTitle}>My RV Profile</Text>
              <Text style={styles.rvProfileSub}>Year · Make · Model · VIN Scanner</Text>
            </View>
          </View>
          <View style={styles.rvProfileBadge}>
            <MaterialIcons name="qr-code-scanner" size={14} color={Colors.blueBright} />
            <Text style={styles.rvProfileBadgeText}>VIN SCAN</Text>
          </View>
        </Pressable>

        {/* ── APP STATS ── */}
        <Text style={styles.sectionLabel}>YOUR ACTIVITY</Text>
        <View style={styles.statsRow}>
          <StatCard value="—" label="Searches" icon="search" color={Colors.blueBright} />
          <StatCard value="—" label="Saved RVs" icon="favorite" color={Colors.red} />
          <StatCard value="—" label="Trips" icon="route" color={Colors.green} />
        </View>

        {/* ── PROFESSIONAL DASHBOARD ── */}
        <Pressable
          style={({ pressed }) => [
            styles.proDashCard,
            pressed && { opacity: 0.88, transform: [{ scale: 0.99 }] },
            tier === 'professional' && { borderColor: Colors.blueBright },
          ]}
          onPress={() => router.push('/professional-dashboard')}
        >
          <View style={styles.proDashLeft}>
            <View style={[
              styles.proDashIcon,
              tier === 'professional' && { backgroundColor: 'rgba(0,104,192,0.22)', borderColor: Colors.borderBlue },
            ]}>
              <MaterialIcons
                name="workspace-premium"
                size={22}
                color={tier === 'professional' ? Colors.blueBright : Colors.textMuted}
              />
            </View>
            <View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Text style={styles.proDashTitle}>Professional Dashboard</Text>
                <View style={[
                  styles.proDashTierBadge,
                  tier === 'professional' && { backgroundColor: Colors.blueBright },
                ]}>
                  <Text style={[
                    styles.proDashTierText,
                    tier === 'professional' && { color: '#000' },
                  ]}>PRO</Text>
                </View>
              </View>
              <Text style={styles.proDashSub}>Bulk VIN · Client Reports · Branding</Text>
            </View>
          </View>
          <MaterialIcons
            name="chevron-right"
            size={20}
            color={tier === 'professional' ? Colors.gold : Colors.textMuted}
          />
        </Pressable>

        {/* ── SUBSCRIPTION CARD (PREMIUM CHROME) ── */}
        <Pressable
          style={({ pressed }) => [
            styles.proCard,
            pressed && { opacity: 0.9 },
            isActive && { borderColor: Colors.borderBlueBright },
          ]}
          onPress={() => router.push('/subscription')}
        >
          <LinearGradient
            colors={isActive
              ? ['rgba(0,104,192,0.18)', 'rgba(0,60,130,0.08)']
              : ['rgba(255,215,0,0.10)', 'rgba(180,140,0,0.04)']}
            style={StyleSheet.absoluteFill}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          />
          <View style={styles.proCardLeft}>
            <Text style={[styles.proLabel, isActive && { color: Colors.blueBright }]}>
              {isActive ? 'ACTIVE SUBSCRIPTION' : 'RvFOX SUBSCRIPTION'}
            </Text>
            <Text style={styles.proTitle}>
              {isActive ? TIER_LABELS[tier] : 'Consumer $9.99/mo · Professional $29.99/mo'}
            </Text>
            <Text style={styles.proSub}>
              {isActive ? 'Tap to manage your subscription' : 'Unlock all features · Cancel anytime'}
            </Text>
          </View>
          <View style={[styles.proIconWrap, isActive && { backgroundColor: 'rgba(0,104,192,0.2)', borderColor: Colors.borderBlue }]}>
            <MaterialIcons
              name={isActive ? 'verified' : 'workspace-premium'}
              size={22}
              color={isActive ? Colors.blueBright : Colors.gold}
            />
          </View>
        </Pressable>

        {/* ── LEGAL ── */}
        <Text style={styles.sectionLabel}>LEGAL & PRIVACY</Text>
        <View style={styles.menuGroup}>
          <MenuRow
            icon="lock"
            iconBg="rgba(30,111,255,0.15)"
            iconColor={Colors.blue}
            title="Privacy Policy"
            subtitle="CCPA-compliant · Updated July 2026"
            onPress={() => Linking.openURL('https://rvfox.app/privacy')}
          />
          <MenuRow
            icon="location-on"
            iconBg="rgba(0,200,83,0.12)"
            iconColor={Colors.green}
            title="Location & Privacy Settings"
            subtitle="Location tracking: ON"
          />
          <MenuRow
            icon="location-off"
            iconBg="rgba(255,68,68,0.12)"
            iconColor={Colors.red}
            title="Revoke Location Consent"
            subtitle="Stop collecting location data"
          />
          <MenuRow
            icon="gavel"
            iconBg="rgba(255,255,255,0.06)"
            iconColor={Colors.textSecondary}
            title="Terms & Copyright"
            subtitle="© 2026 RvFOX Pro. All rights reserved."
            onPress={() => Linking.openURL('https://rvfox.app/terms')}
          />
        </View>

        {/* ── SUPPORT ── */}
        <Text style={styles.sectionLabel}>SUPPORT</Text>
        <View style={styles.menuGroup}>
          <MenuRow
            icon="help-outline"
            iconBg="rgba(255,215,0,0.12)"
            iconColor={Colors.gold}
            title="Help & FAQ"
            subtitle="Common questions answered"
          />
          <MenuRow
            icon="feedback"
            iconBg="rgba(255,68,68,0.12)"
            iconColor={Colors.red}
            title="Send Feedback"
            subtitle="Report issues or suggest features"
            onPress={() => Linking.openURL('mailto:feedback@rvfox.app')}
          />
          <MenuRow
            icon="account-balance"
            iconBg="rgba(30,111,255,0.12)"
            iconColor={Colors.blue}
            title="NHTSA.gov — Official Recalls"
            subtitle="Verify recalls directly with government"
            external
            onPress={() => Linking.openURL('https://www.nhtsa.gov/recalls')}
          />
        </View>

        {/* ── COMPANY ── */}
        <Text style={styles.sectionLabel}>COMPANY</Text>
        <View style={styles.menuGroup}>
          <MenuRow
            icon="history-edu"
            iconBg="rgba(255,215,0,0.12)"
            iconColor={Colors.gold}
            title="Our Story"
            subtitle="Born on a dealer lot"
          />
          <MenuRow
            icon="trending-up"
            iconBg="rgba(30,111,255,0.12)"
            iconColor={Colors.blueBright}
            title="Investor Relations"
            subtitle="$50B+ RV market · contact invest@rvfox.app"
            onPress={() => Linking.openURL('mailto:invest@rvfox.app')}
          />
        </View>

        {/* ── QUICK LINKS ── */}
        <View style={styles.quickLinks}>
          <Pressable
            style={({ pressed }) => [styles.quickLink, pressed && { opacity: 0.75 }]}
            onPress={() => Linking.openURL('https://rvfox.app/privacy')}
          >
            <MaterialIcons name="privacy-tip" size={14} color={Colors.blueBright} />
            <Text style={styles.quickLinkText}>Privacy Policy</Text>
          </Pressable>
          <View style={styles.quickLinkDivider} />
          <Pressable
            style={({ pressed }) => [styles.quickLink, pressed && { opacity: 0.75 }]}
            onPress={() => Linking.openURL('https://rvfox.app/terms')}
          >
            <MaterialIcons name="article" size={14} color={Colors.blueBright} />
            <Text style={styles.quickLinkText}>Terms</Text>
          </Pressable>
          <View style={styles.quickLinkDivider} />
          <Pressable
            style={({ pressed }) => [styles.quickLink, pressed && { opacity: 0.75 }]}
            onPress={() => Linking.openURL('mailto:contact@rvfox.app')}
          >
            <MaterialIcons name="email" size={14} color={Colors.gold} />
            <Text style={[styles.quickLinkText, { color: Colors.gold }]}>contact@rvfox.app</Text>
          </Pressable>
        </View>

        {/* ── SIGN OUT ── */}
        <Pressable
          style={({ pressed }) => [
            styles.signOutBtn,
            pressed && { opacity: 0.8, borderColor: Colors.red, backgroundColor: 'rgba(255,68,68,0.12)' },
          ]}
          onPress={logout}
        >
          <MaterialIcons name="logout" size={18} color={Colors.red} />
          <Text style={styles.signOutText}>Sign Out</Text>
        </Pressable>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerTagline}>© 2026 RvFOX Pro · All Rights Reserved</Text>
          <Text style={styles.footerNote}>Recall data sourced from NHTSA.gov (U.S. Government)</Text>
          <Text style={styles.footerNote}>AI specs are estimates — always verify before purchase</Text>
          <Text style={styles.footerNote}>Location data anonymized · CCPA compliant · privacy@rvfox.app</Text>
        </View>
      </ScrollView>
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A2A3A' },
  heroBackdrop: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 0,
  },

  // ── Header ──────────────────────────────────────────────────────
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.sm,
    paddingBottom: Spacing.md,
    zIndex: 2,
  },
  headerBrand: {
    fontSize: FontSize.xxl,
    fontWeight: FontWeight.extrabold,
    color: '#FFFFFF',
    letterSpacing: 1.2,
  },
  headerTagline: {
    fontSize: FontSize.sm,
    color: Colors.silver,
    fontWeight: FontWeight.medium,
    marginTop: 2,
  },
  versionBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0,104,192,0.14)',
    borderWidth: 1,
    borderColor: Colors.borderBlue,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: Radius.full,
    shadowColor: Colors.blue,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 3,
  },
  versionText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
    color: Colors.blueBright,
  },

  // ── Premium Profile Card ─────────────────────────────────────────
  profileCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    borderRadius: Radius.xl,
    borderWidth: 1.5,
    borderColor: 'rgba(30,111,255,0.45)',
    overflow: 'hidden',
    backgroundColor: 'rgba(6,10,28,0.82)',
    shadowColor: '#1E6FFF',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.50,
    shadowRadius: 24,
    elevation: 12,
  },
  profileCardAccent: {
    height: 2,
    backgroundColor: 'transparent',
    borderTopWidth: 2,
    borderTopColor: 'rgba(30,111,255,0.70)',
    shadowColor: Colors.blueBright,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 6,
  },
  profileCardInner: {
    padding: Spacing.md,
    gap: Spacing.md,
  },
  avatarWrap: {
    alignSelf: 'flex-start',
    position: 'relative',
  },
  avatarGlowOuter: {
    position: 'absolute',
    top: -6,
    left: -6,
    right: -6,
    bottom: -6,
    borderRadius: 40,
    borderWidth: 1,
    borderColor: 'rgba(30,111,255,0.25)',
  },
  avatar: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: 'rgba(0,104,192,0.14)',
    borderWidth: 2,
    borderColor: Colors.blueBright,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.blue,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.65,
    shadowRadius: 14,
    elevation: 8,
  },
  profileInfo: { gap: Spacing.xs },
  profileName: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.extrabold,
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },
  profileDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  profileDetail: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
  },
  ndaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: 'rgba(0,104,192,0.12)',
    borderWidth: 1,
    borderColor: Colors.borderBlue,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
  },
  ndaBadgeTitle: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.blueBright,
  },
  ndaBadgeDate: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    marginTop: 1,
  },

  // ── RV Profile Card ──────────────────────────────────────────────
  rvProfileCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(0,104,192,0.10)',
    borderRadius: Radius.xl,
    borderWidth: 1.5,
    borderColor: Colors.borderBlue,
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: Colors.blue,
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.30,
    shadowRadius: 16,
    elevation: 6,
  },
  rvProfileLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    flex: 1,
  },
  rvProfileIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(0,104,192,0.16)',
    borderWidth: 1.5,
    borderColor: Colors.borderBlue,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.blue,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 10,
    elevation: 4,
  },
  rvProfileTitle: {
    fontSize: FontSize.base,
    fontWeight: FontWeight.extrabold,
    color: '#FFFFFF',
    marginBottom: 2,
  },
  rvProfileSub: {
    fontSize: FontSize.xs,
    color: Colors.textSecondary,
  },
  rvProfileBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(0,104,192,0.14)',
    borderRadius: Radius.full,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderWidth: 1,
    borderColor: Colors.borderBlue,
  },
  rvProfileBadgeText: {
    fontSize: 10,
    fontWeight: FontWeight.bold,
    color: Colors.blueBright,
    letterSpacing: 0.8,
  },

  // ── Stats ────────────────────────────────────────────────────────
  statsRow: {
    flexDirection: 'row',
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.lg,
    gap: Spacing.sm,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(6,10,28,0.78)',
    borderRadius: Radius.lg,
    borderWidth: 1.5,
    alignItems: 'center',
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.sm,
    gap: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 4,
  },
  statIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statValue: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.extrabold,
  },
  statLabel: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    fontWeight: FontWeight.medium,
    textAlign: 'center',
  },

  // ── Pro Dashboard Card ───────────────────────────────────────────
  proDashCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(6,10,28,0.78)',
    borderRadius: Radius.xl,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.12)',
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: Spacing.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 5,
  },
  proDashLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    flex: 1,
  },
  proDashIcon: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  proDashTitle: {
    fontSize: FontSize.base,
    fontWeight: FontWeight.extrabold,
    color: '#FFFFFF',
  },
  proDashTierBadge: {
    backgroundColor: 'rgba(255,255,255,0.10)',
    borderRadius: Radius.full,
    paddingHorizontal: 7,
    paddingVertical: 3,
  },
  proDashTierText: {
    fontSize: 9,
    fontWeight: FontWeight.extrabold,
    color: Colors.textMuted,
    letterSpacing: 1,
  },
  proDashSub: {
    fontSize: FontSize.xs,
    color: Colors.textSecondary,
    marginTop: 2,
  },

  // ── Subscription Card (premium chrome) ──────────────────────────
  proCard: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.lg,
    borderWidth: 1.5,
    borderColor: Colors.borderBlue,
    borderRadius: Radius.xl,
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    overflow: 'hidden',
    shadowColor: Colors.blue,
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.28,
    shadowRadius: 14,
    elevation: 6,
  },
  proCardLeft: { flex: 1, gap: 3 },
  proLabel: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: Colors.gold,
    letterSpacing: 1.4,
  },
  proTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
    lineHeight: 20,
  },
  proSub: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
  },
  proIconWrap: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: 'rgba(255,215,0,0.10)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,215,0,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  // ── Section ──────────────────────────────────────────────────────
  sectionLabel: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: 'rgba(255,255,255,0.50)',
    letterSpacing: 1.8,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.xs,
    marginTop: Spacing.sm,
  },
  menuGroup: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(4,8,22,0.85)',
    borderRadius: Radius.xl,
    borderWidth: 1.5,
    borderColor: 'rgba(30,111,255,0.45)',
    overflow: 'hidden',
    shadowColor: '#1E6FFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.28,
    shadowRadius: 16,
    elevation: 6,
  },
  menuRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: 15,
    gap: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.07)',
  },
  menuIconBg: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  menuRowText: { flex: 1 },
  menuTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.semibold,
    color: '#FFFFFF',
    marginBottom: 2,
  },
  menuSub: {
    fontSize: FontSize.xs,
    color: Colors.textSecondary,
  },

  // ── Quick Links ───────────────────────────────────────────────────
  quickLinks: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    backgroundColor: 'rgba(4,8,22,0.85)',
    borderRadius: Radius.xl,
    borderWidth: 1.5,
    borderColor: 'rgba(30,111,255,0.45)',
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    overflow: 'hidden',
    shadowColor: '#1E6FFF',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 4,
  },
  quickLink: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingVertical: 10,
  },
  quickLinkText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
    color: Colors.blueBright,
  },
  quickLinkDivider: {
    width: 1,
    height: 20,
    backgroundColor: 'rgba(255,255,255,0.10)',
  },

  // ── Sign Out ──────────────────────────────────────────────────────
  signOutBtn: {
    marginHorizontal: Spacing.md,
    marginTop: Spacing.sm,
    marginBottom: Spacing.md,
    borderRadius: Radius.full,
    borderWidth: 1.5,
    borderColor: 'rgba(255,68,68,0.35)',
    backgroundColor: 'rgba(255,68,68,0.07)',
    paddingVertical: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    shadowColor: Colors.red,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.20,
    shadowRadius: 10,
    elevation: 4,
  },
  signOutText: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.semibold,
    color: Colors.red,
  },

  // ── Footer ────────────────────────────────────────────────────────
  footer: {
    alignItems: 'center',
    paddingVertical: Spacing.xl,
    paddingHorizontal: Spacing.lg,
    gap: 6,
  },
  footerTagline: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: 'rgba(255,255,255,0.40)',
    textAlign: 'center',
    marginBottom: 4,
  },
  footerNote: {
    fontSize: 11,
    color: Colors.textDim,
    textAlign: 'center',
    lineHeight: 16,
  },
});
