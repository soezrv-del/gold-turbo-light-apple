import { Tabs } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';

// ─── TAB CONFIG ───────────────────────────────────────────────────────────────
const TAB_ACCENT: Record<string, string> = {
  index:   '#4DA6FF',
  rvgrok:  '#D42535',
  rvcal:   '#00C853',
  rvtow:   '#4DA6FF',
  rvtrips: '#00C853',
  more:    '#D42535',
};

const TAB_LABELS: Record<string, string> = {
  index:   'RvFAX',
  rvgrok:  'RvGROK',
  rvcal:   'RvCAL',
  rvtow:   'RvTOW',
  rvtrips: 'RvTRIPS',
  more:    'More',
};

// ─── SAPPHIRE PALETTE ────────────────────────────────────────────────────────
const SAPPHIRE = {
  glow:    '#3B8FFF',
  primary: '#4DA6FF',
  electric:'#60B4FF',
};

// ─── CUSTOM TAB BAR ──────────────────────────────────────────────────────────
function CustomTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const bottomPad = Math.max(insets.bottom, 10);
  const barHeight = bottomPad + 62;

  return (
    /**
     * Outer shell — carries the sapphire halo glow via shadow.
     * iOS: negative shadowOffset.y pushes the glow upward.
     * Android: elevation adds a downward shadow (best we can do natively).
     */
    <View
      style={[
        tabStyles.outerShell,
        { height: barHeight },
      ]}
    >
      {/* Deep navy gradient bar background */}
      <LinearGradient
        colors={['#030B1E', '#050F28', '#030B1E']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={[tabStyles.barBg, { paddingBottom: bottomPad }]}
      >
        {/* Glowing sapphire rim — fades from transparent at edges to bright center */}
        <LinearGradient
          colors={[
            'rgba(77,166,255,0)',
            'rgba(59,143,255,0.88)',
            '#4DAAFF',
            'rgba(59,143,255,0.88)',
            'rgba(77,166,255,0)',
          ]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={tabStyles.sapphireRim}
        />

        {/* Tab pills row */}
        <View style={tabStyles.pillRow}>
          {state.routes.map((route, index) => {
            const isFocused = state.index === index;
            const accent = TAB_ACCENT[route.name] ?? SAPPHIRE.primary;
            const label  = TAB_LABELS[route.name] ?? route.name.toUpperCase();

            const onPress = () => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
              const event = navigation.emit({
                type: 'tabPress',
                target: route.key,
                canPreventDefault: true,
              });
              if (!isFocused && !event.defaultPrevented) {
                navigation.navigate(route.name);
              }
            };

            return (
              <Pressable
                key={route.key}
                onPress={onPress}
                style={({ pressed }) => [
                  tabStyles.pillOuter,
                  // Per-tab sapphire glow when focused
                  isFocused && {
                    shadowColor: accent,
                    shadowOffset: { width: 0, height: 0 },
                    shadowOpacity: 0.72,
                    shadowRadius: 12,
                    elevation: 10,
                  },
                  pressed && {
                    opacity: 0.6,
                    transform: [{ scale: 0.92 }],
                  },
                ]}
              >
                {/* Inner pill — clips the gradients cleanly */}
                <View
                  style={[
                    tabStyles.pillInner,
                    isFocused
                      ? { borderColor: accent + 'CC' }
                      : { borderColor: 'rgba(40,90,200,0.16)' },
                  ]}
                >
                  {/* Gradient fill — active: accent glow; inactive: blue tint */}
                  <LinearGradient
                    colors={
                      isFocused
                        ? [accent + '2E', accent + '0E', 'transparent']
                        : ['rgba(25,55,140,0.12)', 'rgba(15,38,100,0.04)']
                    }
                    start={{ x: 0.5, y: 0 }}
                    end={{ x: 0.5, y: 1 }}
                    style={StyleSheet.absoluteFill}
                  />

                  {/* Sapphire top indicator bar with glow */}
                  {isFocused && (
                    <View
                      style={[
                        tabStyles.topIndicator,
                        {
                          backgroundColor: accent,
                          shadowColor: accent,
                          shadowOffset: { width: 0, height: 3 },
                          shadowOpacity: 1,
                          shadowRadius: 6,
                        },
                      ]}
                    />
                  )}

                  {/* Inner edge glow ring on active tab */}
                  {isFocused && (
                    <View
                      style={[
                        tabStyles.innerRing,
                        { borderColor: accent + '40' },
                      ]}
                    />
                  )}

                  <Text
                    style={[
                      tabStyles.label,
                      {
                        color: isFocused
                          ? accent
                          : 'rgba(77,148,230,0.44)',
                      },
                      isFocused && tabStyles.labelActive,
                    ]}
                    numberOfLines={1}
                  >
                    {label}
                  </Text>
                </View>
              </Pressable>
            );
          })}
        </View>
      </LinearGradient>
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────
const tabStyles = StyleSheet.create({
  outerShell: {
    // Sapphire halo — the shadow radiates upward on iOS
    shadowColor: SAPPHIRE.glow,
    shadowOffset: { width: 0, height: -5 },
    shadowOpacity: 0.60,
    shadowRadius: 20,
    // Android: elevation needed, backgroundColor required for shadow render
    backgroundColor: '#030B1E',
    elevation: 22,
  },
  barBg: {
    flex: 1,
    paddingHorizontal: 6,
    paddingTop: 0,
  },
  sapphireRim: {
    height: 1.5,
    marginBottom: 5,
    borderRadius: 1,
  },
  pillRow: {
    flexDirection: 'row',
    gap: 4,
    flex: 1,
    alignItems: 'center',
  },
  pillOuter: {
    flex: 1,
    minHeight: 38,
  },
  pillInner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    borderWidth: 1.5,
    overflow: 'hidden',
    paddingVertical: 8,
    paddingHorizontal: 2,
    position: 'relative',
  },
  topIndicator: {
    position: 'absolute',
    top: 0,
    left: 10,
    right: 10,
    height: 2,
    borderRadius: 1,
  },
  innerRing: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 10,
    borderWidth: 1,
  },
  label: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  labelActive: {
    fontWeight: '800',
  },
});

// ─── LAYOUT ──────────────────────────────────────────────────────────────────
export default function TabsLayout() {
  return (
    <Tabs
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tabs.Screen name="index"   options={{ title: 'RvFax'   }} />
      <Tabs.Screen name="rvgrok"  options={{ title: 'RvGrok'  }} />
      <Tabs.Screen name="rvcal"   options={{ title: 'RvCal'   }} />
      <Tabs.Screen name="rvtow"   options={{ title: 'RvTow'   }} />
      <Tabs.Screen name="rvtrips" options={{ title: 'RvTrips' }} />
      <Tabs.Screen name="more"    options={{ title: 'More'    }} />
    </Tabs>
  );
}
