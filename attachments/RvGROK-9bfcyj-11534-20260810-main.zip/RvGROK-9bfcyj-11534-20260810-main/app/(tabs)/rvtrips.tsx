/**
 * RvTrips — RV-Aware GPS Navigator
 *
 * Architecture:
 *  - Loads saved RV profile (height/width/length/gvwr) from Supabase on mount
 *  - Uses HERE Routing v8 (truck mode + RV dimension constraints) via edge function
 *  - Falls back to OSRM (free, no key, real roads) then straight-line estimate
 *  - Live GPS turn-by-turn with heading + speed overlay + voice guidance
 *  - Nearby Campgrounds via Overpass API (free, no key)
 */

import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  Dimensions, ActivityIndicator, Alert, Modal, FlatList, Linking,
  Keyboard, KeyboardAvoidingView, Platform, TouchableWithoutFeedback,
} from 'react-native';
import { useState, useCallback, useEffect, useRef } from 'react';
import { useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import MapView, { Marker, Polyline, Callout, PROVIDER_DEFAULT } from 'react-native-maps';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import { getSupabaseClient, useAuth } from '@/template';
import { FunctionsHttpError } from '@supabase/supabase-js';

// ─── expo-location (lazy load — avoids native crash in preview) ───────────────
let Location: typeof import('expo-location') | null = null;
try { Location = require('expo-location'); } catch { Location = null; }

// ─── expo-speech (lazy load — not available in web preview) ─────────────────
let Speech: typeof import('expo-speech') | null = null;
try { Speech = require('expo-speech'); } catch { Speech = null; }

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface RVDimensions {
  heightFt: number;
  widthFt: number;
  lengthFt: number;
  gvwrLbs: number;
  hasPropane: boolean;
  makeModel: string;
}

interface LatLng { latitude: number; longitude: number }

interface RouteStep {
  instruction: string;
  distanceMi: number;
  distanceM: number;
  maneuver: string;
  coords: LatLng;
}

interface RVWarning {
  type: 'bridge' | 'tunnel' | 'weight' | 'propane' | 'width' | 'grade';
  severity: 'critical' | 'caution';
  message: string;
  icon: string;
}

interface RouteResult {
  distanceMi: number;
  durationMin: number;
  polyline: LatLng[];
  steps: RouteStep[];
  warnings: RVWarning[];
  originLabel: string;
  destLabel: string;
  originCoords: LatLng;
  destCoords: LatLng;
  source: 'here' | 'osrm' | 'fallback';
  vehicleConstrained?: boolean;
}

interface Campground {
  id: number;
  name: string;
  lat: number;
  lng: number;
  distanceMi: number;
  hookups: string | null;
  dumpStation: boolean;
  petsAllowed: boolean | null;
  fee: string | null;
  type: 'camp_site' | 'caravan_site';
  website: string | null;
  phone: string | null;
}

// ─── POPULAR RV DESTINATIONS ─────────────────────────────────────────────────

const POPULAR = [
  { label: 'Yellowstone NP, WY',     lat: 44.4280, lng: -110.5885 },
  { label: 'Grand Canyon, AZ',       lat: 36.0544, lng: -112.1401 },
  { label: 'Zion NP, UT',            lat: 37.2982, lng: -113.0263 },
  { label: 'Smoky Mountains, TN',    lat: 35.6532, lng: -83.5070  },
  { label: 'Yosemite, CA',           lat: 37.8651, lng: -119.5383 },
  { label: 'Glacier NP, MT',         lat: 48.7596, lng: -113.7870 },
  { label: 'Acadia NP, ME',          lat: 44.3386, lng: -68.2733  },
  { label: 'Arches NP, UT',          lat: 38.7331, lng: -109.5925 },
  { label: 'Big Sur, CA',            lat: 36.2704, lng: -121.8081 },
  { label: 'Florida Keys, FL',       lat: 24.5551, lng: -81.7800  },
  { label: 'Blue Ridge Pkwy, VA',    lat: 36.4038, lng: -80.9739  },
  { label: 'Sedona, AZ',             lat: 34.8697, lng: -111.7610 },
  { label: 'Moab, UT',               lat: 38.5733, lng: -109.5498 },
  { label: 'Lake Tahoe, CA',         lat: 38.9399, lng: -119.9772 },
  { label: 'Olympic NP, WA',         lat: 47.8021, lng: -123.6044 },
  { label: 'Joshua Tree NP, CA',     lat: 33.8734, lng: -115.9010 },
];

// ─── MAP PALETTE (US Road Map — sky blue / terrain green / white) ────────────
const MapTheme = {
  skyBlue:   '#4A9BD4',
  terrainGreen: '#7AB648',
  white:     '#FFFFFF',
  blueDark:  '#1B5F8C',
  greenDark: '#4A7A28',
  overlay:   'rgba(10,20,30,0.55)',
};

// ─── MAP STYLE (light cartographic) ─────────────────────────────────────────

const DARK_MAP: object[] = [
  { elementType: 'geometry', stylers: [{ color: '#d4e8c2' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#1B5F8C' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#FFFFFF' }] },
  { featureType: 'administrative', elementType: 'geometry.stroke', stylers: [{ color: '#7AB648' }] },
  { featureType: 'landscape', stylers: [{ color: '#c8e0a0' }] },
  { featureType: 'poi', stylers: [{ visibility: 'off' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#FFFFFF' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#f0e080' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#1B5F8C' }] },
  { featureType: 'transit', stylers: [{ visibility: 'off' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#4A9BD4' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#FFFFFF' }] },
];

// ─── MANEUVER → ICON MAPPING ──────────────────────────────────────────────────

function maneuverIcon(maneuver: string): string {
  if (maneuver.includes('left'))    return 'turn-left';
  if (maneuver.includes('right'))   return 'turn-right';
  if (maneuver.includes('u-turn'))  return 'u-turn-left';
  if (maneuver.includes('arrive') || maneuver.includes('destination')) return 'flag';
  if (maneuver.includes('ramp') || maneuver.includes('merge')) return 'merge';
  if (maneuver.includes('roundabout')) return 'roundabout-left';
  if (maneuver.includes('exit'))    return 'exit-to-app';
  return 'straight';
}

// ─── HAVERSINE ────────────────────────────────────────────────────────────────

function haversineMi(a: LatLng, b: LatLng): number {
  const R = 3958.8;
  const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
  const dLng = ((b.longitude - a.longitude) * Math.PI) / 180;
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.latitude * Math.PI) / 180) *
    Math.cos((b.latitude * Math.PI) / 180) *
    Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

// ─── DECODE POLYLINE (precision 1e5) ─────────────────────────────────────────

function decodePolyline(encoded: string): LatLng[] {
  const pts: LatLng[] = [];
  let idx = 0, lat = 0, lng = 0;
  while (idx < encoded.length) {
    let b: number, shift = 0, result = 0;
    do { b = encoded.charCodeAt(idx++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lat += (result & 1) ? ~(result >> 1) : (result >> 1);
    shift = 0; result = 0;
    do { b = encoded.charCodeAt(idx++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lng += (result & 1) ? ~(result >> 1) : (result >> 1);
    pts.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
  }
  return pts;
}

// ─── RV WARNINGS FROM DIMENSIONS ─────────────────────────────────────────────

function computeWarnings(rv: RVDimensions | null, destLabel: string): RVWarning[] {
  if (!rv) return [];
  const warnings: RVWarning[] = [];

  if (rv.heightFt > 13.5) {
    warnings.push({
      type: 'bridge', severity: 'critical', icon: 'warning',
      message: `Your RV is ${rv.heightFt} ft tall. Watch for bridges — federal minimum is 14 ft but many park roads and tunnels are lower. Use RV-specific GPS routing.`,
    });
  } else if (rv.heightFt >= 12.0) {
    warnings.push({
      type: 'bridge', severity: 'caution', icon: 'info',
      message: `Height ${rv.heightFt} ft — verify tunnel and overpass clearances before entering. Most interstates are fine but local roads may not be.`,
    });
  }

  if (rv.widthFt > 8.0) {
    warnings.push({
      type: 'width', severity: 'caution', icon: 'swap-horiz',
      message: `Width ${rv.widthFt} ft — some campground roads and older bridges have width restrictions under 9 ft. Proceed cautiously on narrow roads.`,
    });
  }

  if (rv.gvwrLbs > 26000) {
    warnings.push({
      type: 'weight', severity: 'caution', icon: 'monitor-weight',
      message: `GVWR ${(rv.gvwrLbs / 1000).toFixed(0)}k lbs — weight-restricted bridges (posted 10–20 tons) require detour. Check local bridge load ratings.`,
    });
  }

  if (rv.hasPropane) {
    const propaneDests = ['Smoky Mountains', 'Zion', 'Yosemite', 'Acadia', 'Glacier', 'Olympic'];
    const matchesPropane = propaneDests.some(d => destLabel.toLowerCase().includes(d.toLowerCase()));
    if (matchesPropane) {
      warnings.push({
        type: 'propane', severity: 'critical', icon: 'local-fire-department',
        message: `Propane tanks must be turned OFF when entering tunnels on this route. Some park tunnels (e.g., Newfound Gap Rd, Zion-Mt Carmel) prohibit active propane.`,
      });
    } else {
      warnings.push({
        type: 'propane', severity: 'caution', icon: 'local-fire-department',
        message: 'You have propane on board. Turn it off before tunnels and at propane-restricted campgrounds. Check destination rules in advance.',
      });
    }
  }

  if (rv.lengthFt >= 38) {
    const gradeDests = ['Smoky Mountains', 'Glacier', 'Yosemite', 'Zion', 'Blue Ridge', 'Big Sur', 'Olympic'];
    const matchesGrade = gradeDests.some(d => destLabel.toLowerCase().includes(d.toLowerCase()));
    if (matchesGrade) {
      warnings.push({
        type: 'grade', severity: 'caution', icon: 'terrain',
        message: `Your ${rv.lengthFt} ft RV will encounter mountain grades on this route. Use engine braking on descents, watch for runaway truck ramps, and verify campsite length before arrival.`,
      });
    }
  }

  return warnings;
}

// ─── HERE ROUTING (via edge function) ────────────────────────────────────────

async function fetchHERERoute(
  origin: LatLng,
  dest: LatLng,
  rv: RVDimensions | null
): Promise<RouteResult | null> {
  try {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase.functions.invoke('here-routing', {
      body: {
        origin,
        destination: dest,
        vehicle: rv ? {
          heightFt:   rv.heightFt,
          widthFt:    rv.widthFt,
          lengthFt:   rv.lengthFt,
          gvwrLbs:    rv.gvwrLbs,
          hasPropane: rv.hasPropane,
        } : null,
      },
    });

    if (error) {
      let errMsg = error.message;
      if (error instanceof FunctionsHttpError) {
        try { errMsg = await error.context?.text(); } catch { /* ignore */ }
      }
      console.warn('HERE routing error:', errMsg);
      return null;
    }

    if (!data || !data.polyline || data.polyline.length < 2) return null;

    return {
      distanceMi:  data.distanceMi,
      durationMin: data.durationMin,
      polyline:    data.polyline,
      steps:       data.steps,
      warnings:    [],
      originLabel: 'Your Location',
      destLabel:   '',
      originCoords: origin,
      destCoords:  dest,
      source:      'here',
      vehicleConstrained: data.vehicleConstrained,
    };
  } catch (e) {
    console.warn('fetchHERERoute exception:', e);
    return null;
  }
}

function buildStepInstruction(type: string, modifier: string, name: string): string {
  const street = name ? ` on ${name}` : '';
  switch (type) {
    case 'depart':          return `Head ${modifier || 'forward'}${street}`;
    case 'arrive':          return 'Arrive at your destination';
    case 'turn':
      if (modifier === 'left')         return `Turn left${street}`;
      if (modifier === 'right')        return `Turn right${street}`;
      if (modifier === 'sharp left')   return `Turn sharp left${street}`;
      if (modifier === 'sharp right')  return `Turn sharp right${street}`;
      if (modifier === 'slight left')  return `Keep left${street}`;
      if (modifier === 'slight right') return `Keep right${street}`;
      if (modifier === 'uturn')        return `Make a U-turn${street}`;
      return `Continue${street}`;
    case 'merge':           return `Merge${modifier ? ' ' + modifier : ''}${street}`;
    case 'ramp':
      if (modifier === 'left')  return `Take the ramp on the left${street}`;
      if (modifier === 'right') return `Take the ramp on the right${street}`;
      return `Take the ramp${street}`;
    case 'fork':
      if (modifier?.includes('left'))  return `Keep left at the fork${street}`;
      if (modifier?.includes('right')) return `Keep right at the fork${street}`;
      return `Stay on the road${street}`;
    case 'end of road':
      if (modifier === 'left')  return `At the end of the road, turn left${street}`;
      if (modifier === 'right') return `At the end of the road, turn right${street}`;
      return `At the end of the road${street}`;
    case 'continue':        return `Continue${modifier === 'uturn' ? ' and make a U-turn' : ''}${street}`;
    case 'roundabout':      return `Enter the roundabout${street}`;
    case 'exit roundabout': return `Exit the roundabout${street}`;
    case 'rotary':          return `Enter the rotary${street}`;
    case 'exit rotary':     return `Exit the rotary${street}`;
    default:                return `Continue${street}`;
  }
}

function buildManeuverKey(type: string, modifier: string): string {
  if (type === 'arrive') return 'arrive';
  if (type === 'depart') return 'straight';
  if (modifier === 'left'  || modifier === 'sharp left')  return 'left';
  if (modifier === 'right' || modifier === 'sharp right') return 'right';
  if (modifier === 'uturn')                               return 'u-turn';
  if (type === 'roundabout' || type === 'rotary')         return 'roundabout';
  if (type === 'ramp' && modifier === 'left')             return 'ramp-left';
  if (type === 'ramp' && modifier === 'right')            return 'ramp-right';
  if (type === 'merge')                                   return 'merge';
  return 'straight';
}

async function fetchOSRMRoute(origin: LatLng, dest: LatLng): Promise<RouteResult | null> {
  try {
    const url =
      `https://router.project-osrm.org/route/v1/driving/` +
      `${origin.longitude},${origin.latitude};${dest.longitude},${dest.latitude}` +
      `?steps=true&geometries=polyline&overview=full&annotations=false`;

    const res = await fetch(url, {
      headers: { 'Accept': 'application/json', 'User-Agent': 'RvFaxApp/1.0' },
    });
    if (!res.ok) return null;

    const data = await res.json();
    if (data.code !== 'Ok' || !data.routes?.[0]) return null;

    const route = data.routes[0];
    const leg   = route.legs?.[0];
    if (!leg) return null;

    const distanceMi  = parseFloat((route.distance / 1609.34).toFixed(1));
    const durationMin = Math.round(route.duration / 60);
    const polyline    = decodePolyline(route.geometry);

    const steps: RouteStep[] = (leg.steps ?? []).map((s: any) => {
      const mType      = s.maneuver?.type     ?? 'continue';
      const mModifier  = s.maneuver?.modifier ?? '';
      const streetName = s.name || '';
      const stepLoc    = s.maneuver?.location;
      return {
        instruction: buildStepInstruction(mType, mModifier, streetName),
        distanceMi:  parseFloat((s.distance / 1609.34).toFixed(2)),
        distanceM:   s.distance,
        maneuver:    buildManeuverKey(mType, mModifier),
        coords: stepLoc
          ? { latitude: stepLoc[1], longitude: stepLoc[0] }
          : origin,
      };
    });

    return {
      distanceMi, durationMin, polyline, steps,
      warnings: [],
      originLabel: 'Your Location',
      destLabel: '',
      originCoords: origin,
      destCoords: dest,
      source: 'osrm',
    };
  } catch {
    return null;
  }
}

// ─── FALLBACK ROUTE ───────────────────────────────────────────────────────────

function buildFallbackRoute(
  origin: LatLng, dest: LatLng, originLabel: string, destLabel: string
): RouteResult {
  const straightMi = haversineMi(origin, dest);
  const distanceMi = Math.round(straightMi * 1.28);
  const durationMin = Math.round((distanceMi / 55) * 60);

  const mid = {
    latitude:  (origin.latitude  + dest.latitude)  / 2 + (dest.longitude - origin.longitude) * 0.08,
    longitude: (origin.longitude + dest.longitude) / 2 - (dest.latitude  - origin.latitude)  * 0.08,
  };
  const pts: LatLng[] = [];
  for (let i = 0; i <= 40; i++) {
    const t = i / 40, u = 1 - t;
    pts.push({
      latitude:  u * u * origin.latitude  + 2 * u * t * mid.latitude  + t * t * dest.latitude,
      longitude: u * u * origin.longitude + 2 * u * t * mid.longitude + t * t * dest.longitude,
    });
  }

  return {
    distanceMi, durationMin, polyline: pts,
    steps: [
      { instruction: `Head toward ${destLabel}`, distanceMi, distanceM: distanceMi * 1609.34, maneuver: 'straight', coords: origin },
      { instruction: `Arrive at ${destLabel}`,   distanceMi: 0, distanceM: 0, maneuver: 'arrive', coords: dest },
    ],
    warnings: [], originLabel, destLabel, originCoords: origin, destCoords: dest, source: 'fallback',
  };
}

// ─── GEOCODE ──────────────────────────────────────────────────────────────────

async function geocodeAddress(query: string): Promise<LatLng | null> {
  try {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=1`;
    const res = await fetch(url, { headers: { 'User-Agent': 'RvFaxApp/1.0' } });
    if (!res.ok) return null;
    const data = await res.json();
    if (!data?.[0]) return null;
    return { latitude: parseFloat(data[0].lat), longitude: parseFloat(data[0].lon) };
  } catch { return null; }
}

// ─── OVERPASS CAMPGROUND FETCH ────────────────────────────────────────────────

const OVERPASS_URL = 'https://overpass-api.de/api/interpreter';
const RADIUS_M = 80467; // 50 miles
const MAX_RESULTS = 10;

async function fetchNearbyCampgrounds(pos: LatLng): Promise<Campground[]> {
  const query = `[out:json][timeout:30];
(
  node["tourism"="camp_site"](around:${RADIUS_M},${pos.latitude},${pos.longitude});
  node["tourism"="caravan_site"](around:${RADIUS_M},${pos.latitude},${pos.longitude});
  way["tourism"="camp_site"](around:${RADIUS_M},${pos.latitude},${pos.longitude});
  way["tourism"="caravan_site"](around:${RADIUS_M},${pos.latitude},${pos.longitude});
);
out center 80;`;

  const res = await fetch(OVERPASS_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'RvFaxApp/1.0' },
    body: `data=${encodeURIComponent(query)}`,
  });
  if (!res.ok) throw new Error(`Overpass HTTP ${res.status}`);
  const json = await res.json();

  const results: Campground[] = [];
  for (const el of json.elements ?? []) {
    const lat = el.lat ?? el.center?.lat;
    const lng = el.lon ?? el.center?.lon;
    if (!lat || !lng) continue;

    const tags = el.tags ?? {};
    const name = tags.name || tags['name:en'] || 'Unnamed Campground';
    const distanceMi = haversineMi(pos, { latitude: lat, longitude: lng });
    if (distanceMi > 50) continue;

    let hookups: string | null = null;
    const h = (tags.hookups || '').toLowerCase();
    if (h === 'electrical;water;sewage' || h === 'full' || h === 'yes') {
      hookups = 'Full Hookups';
    } else if (h === 'electrical;water' || h === 'water;electrical') {
      hookups = 'Electric + Water';
    } else if (h === 'electrical' || h === 'electric' || tags.electric_hookup === 'yes') {
      hookups = 'Electric';
    } else if (h === 'water') {
      hookups = 'Water Only';
    }

    const dumpStation =
      tags.sanitary_dump_station === 'yes' ||
      tags.dump_station === 'yes' ||
      tags.waste_disposal === 'yes';

    let petsAllowed: boolean | null = null;
    if (tags.dog === 'yes' || tags.dog === 'leashed' || tags.dogs === 'yes') petsAllowed = true;
    else if (tags.dog === 'no' || tags.dogs === 'no') petsAllowed = false;

    let fee: string | null = null;
    if (tags.fee === 'yes') fee = 'Fee';
    else if (tags.fee === 'no') fee = 'Free';

    // Website — check multiple OSM tag variants
    const rawWebsite = tags.website || tags['contact:website'] || tags.url || null;
    const website = rawWebsite
      ? (rawWebsite.startsWith('http') ? rawWebsite : 'https://' + rawWebsite)
      : null;

    const phone = tags.phone || tags['contact:phone'] || null;

    results.push({
      id: el.id,
      name,
      lat,
      lng,
      distanceMi: parseFloat(distanceMi.toFixed(1)),
      hookups,
      dumpStation,
      petsAllowed,
      fee,
      type: (tags.tourism as 'camp_site' | 'caravan_site') ?? 'camp_site',
      website,
      phone,
    });
  }

  // Sort by distance, return top 6–10 results (prioritise named camps with websites)
  const sorted = results.sort((a, b) => a.distanceMi - b.distanceMi);
  // Prefer camps that have a name (not 'Unnamed') and/or website — move them to front
  const named   = sorted.filter(c => c.name !== 'Unnamed Campground');
  const unnamed = sorted.filter(c => c.name === 'Unnamed Campground');
  return [...named, ...unnamed].slice(0, MAX_RESULTS);
}

// ─── FORMAT HELPERS ───────────────────────────────────────────────────────────

function fmtDuration(min: number): string {
  const h = Math.floor(min / 60), m = min % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

function fmtElapsed(s: number): string {
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${sec}s`;
  return `${sec}s`;
}

// ─── WARNING CARD ─────────────────────────────────────────────────────────────

function WarningCard({ w }: { w: RVWarning }) {
  const isCritical = w.severity === 'critical';
  const bg  = isCritical ? 'rgba(255,68,68,0.08)'  : 'rgba(255,140,0,0.06)';
  const bd  = isCritical ? 'rgba(255,68,68,0.4)'   : 'rgba(255,140,0,0.35)';
  const col = isCritical ? Colors.red              : Colors.orange;
  const lbl = isCritical ? 'CRITICAL'              : 'CAUTION';
  return (
    <View style={[wc.card, { backgroundColor: bg, borderColor: bd }]}>
      <View style={wc.top}>
        <MaterialIcons name={w.icon as any} size={16} color={col} />
        <View style={[wc.badge, { backgroundColor: col }]}>
          <Text style={wc.badgeText}>{lbl}</Text>
        </View>
        <Text style={[wc.typeText, { color: col }]}>
          {w.type.toUpperCase().replace('-', ' ')} RESTRICTION
        </Text>
      </View>
      <Text style={wc.msg}>{w.message}</Text>
    </View>
  );
}
const wc = StyleSheet.create({
  card:      { borderRadius: Radius.lg, borderWidth: 1.5, padding: Spacing.sm, gap: 6, marginBottom: Spacing.sm },
  top:       { flexDirection: 'row', alignItems: 'center', gap: 6 },
  badge:     { borderRadius: Radius.sm, paddingHorizontal: 6, paddingVertical: 2 },
  badgeText: { fontSize: 9, fontWeight: FontWeight.extrabold, color: '#fff', letterSpacing: 0.8 },
  typeText:  { fontSize: FontSize.xs, fontWeight: FontWeight.bold },
  msg:       { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 18 },
});

// ─── STEP CARD ────────────────────────────────────────────────────────────────

function StepCard({ step, index, isNext }: { step: RouteStep; index: number; isNext: boolean }) {
  const icon = maneuverIcon(step.maneuver);
  const isArrive = step.maneuver.includes('arrive') || step.maneuver.includes('destination');
  const col = isArrive ? Colors.gold : isNext ? Colors.blueBright : Colors.textMuted;
  return (
    <View style={[sc.row, isNext && sc.rowNext, isArrive && sc.rowArrive]}>
      <View style={[sc.iconWrap, { backgroundColor: col + '18' }]}>
        <MaterialIcons name={icon as any} size={18} color={col} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[sc.instr, isNext && { color: Colors.textPrimary, fontWeight: FontWeight.bold }]}
          numberOfLines={2}>{step.instruction}</Text>
        {step.distanceMi > 0 && (
          <Text style={[sc.dist, { color: col }]}>
            {step.distanceMi < 0.1
              ? `${Math.round(step.distanceM)} ft`
              : `${step.distanceMi.toFixed(1)} mi`}
          </Text>
        )}
      </View>
      {isNext && (
        <View style={sc.nextBadge}><Text style={sc.nextText}>NEXT</Text></View>
      )}
    </View>
  );
}
const sc = StyleSheet.create({
  row:       { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: 11, paddingHorizontal: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border },
  rowNext:   { backgroundColor: 'rgba(77,166,255,0.06)', borderLeftWidth: 3, borderLeftColor: Colors.blueBright },
  rowArrive: { backgroundColor: 'rgba(255,215,0,0.05)', borderLeftWidth: 3, borderLeftColor: Colors.gold },
  iconWrap:  { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  instr:     { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 19 },
  dist:      { fontSize: FontSize.xs, fontWeight: FontWeight.bold, marginTop: 2 },
  nextBadge: { backgroundColor: Colors.blueBright, borderRadius: Radius.sm, paddingHorizontal: 6, paddingVertical: 3 },
  nextText:  { fontSize: 9, fontWeight: FontWeight.extrabold, color: '#000' },
});

// ─── DESTINATION SEARCH MODAL ─────────────────────────────────────────────────

function DestModal({ visible, onClose, onSelect }: {
  visible: boolean;
  onClose: () => void;
  onSelect: (label: string, coords: LatLng) => void;
}) {
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<Array<{ label: string; coords: LatLng }>>([]);

  const handleSearch = useCallback(async () => {
    if (!query.trim()) return;
    setSearching(true);
    try {
      const coords = await geocodeAddress(query);
      if (coords) {
        setResults([{ label: query, coords }]);
      } else {
        setResults([]);
        Alert.alert('Not Found', 'Could not find that location. Try a city, state, or landmark.');
      }
    } finally { setSearching(false); }
  }, [query]);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={() => { Keyboard.dismiss(); onClose(); }}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1, justifyContent: 'flex-end' }}
        keyboardVerticalOffset={0}
      >
      <View style={dm.overlay}>
        <Pressable style={dm.overlayBg} onPress={() => { Keyboard.dismiss(); onClose(); }} />
        <View style={dm.sheet}>
          <View style={dm.handle} />
          <View style={dm.header}>
            <MaterialIcons name="place" size={18} color={Colors.gold} />
            <Text style={dm.title}>Where to?</Text>
            <Pressable onPress={onClose} hitSlop={8}>
              <MaterialIcons name="close" size={20} color={Colors.textSecondary} />
            </Pressable>
          </View>

          <View style={dm.searchRow}>
            <View style={dm.searchInput}>
              <MaterialIcons name="search" size={18} color={Colors.textMuted} />
              <TextInput
                style={dm.searchField}
                placeholder="City, address, park, campground..."
                placeholderTextColor={Colors.textMuted}
                value={query}
                onChangeText={setQuery}
                onSubmitEditing={handleSearch}
                returnKeyType="search"
              />
              {query.length > 0 && (
                <Pressable onPress={() => { setQuery(''); setResults([]); }} hitSlop={8}>
                  <MaterialIcons name="close" size={16} color={Colors.textMuted} />
                </Pressable>
              )}
            </View>
            <Pressable
              style={[dm.searchBtn, !query.trim() && { opacity: 0.5 }]}
              onPress={handleSearch}
              disabled={!query.trim() || searching}
            >
              {searching
                ? <ActivityIndicator size="small" color="#000" />
                : <MaterialIcons name="search" size={18} color="#000" />
              }
            </Pressable>
          </View>

          {results.length > 0 && (
            <View style={dm.resultsSection}>
              <Text style={dm.sectionLabel}>SEARCH RESULTS</Text>
              {results.map((r, i) => (
                <Pressable key={i} style={({ pressed }) => [dm.destItem, pressed && { opacity: 0.7 }]}
                  onPress={() => { Keyboard.dismiss(); onSelect(r.label, r.coords); onClose(); setQuery(''); setResults([]); }}>
                  <MaterialIcons name="place" size={16} color={Colors.green} />
                  <Text style={dm.destText} numberOfLines={2}>{r.label}</Text>
                  <MaterialIcons name="arrow-forward-ios" size={12} color={Colors.textMuted} />
                </Pressable>
              ))}
            </View>
          )}

          <Text style={[dm.sectionLabel, { paddingHorizontal: Spacing.md, marginTop: Spacing.sm }]}>
            POPULAR RV DESTINATIONS
          </Text>
          <FlatList
            data={POPULAR}
            keyExtractor={i => i.label}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
            onScrollBeginDrag={Keyboard.dismiss}
            renderItem={({ item }) => (
              <Pressable
                style={({ pressed }) => [dm.destItem, pressed && { backgroundColor: 'rgba(74,222,128,0.05)' }]}
                onPress={() => { Keyboard.dismiss(); onSelect(item.label, { latitude: item.lat, longitude: item.lng }); onClose(); setQuery(''); setResults([]); }}
              >
                <FontAwesome5 name="campground" size={13} color={Colors.green} />
                <Text style={dm.destText} numberOfLines={1}>{item.label}</Text>
                <MaterialIcons name="arrow-forward-ios" size={12} color={Colors.textMuted} />
              </Pressable>
            )}
          />
        </View>
      </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const dm = StyleSheet.create({
  overlay:        { flex: 1, justifyContent: 'flex-end' },
  overlayBg:      { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.7)' },
  sheet:          { backgroundColor: '#060D1F', borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl, borderTopWidth: 2, borderTopColor: Colors.blueBright, maxHeight: '85%', paddingBottom: 32, shadowColor: Colors.green, shadowOffset: { width: 0, height: -6 }, shadowOpacity: 0.4, shadowRadius: 20, elevation: 16 },
  handle:         { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginTop: 12, marginBottom: 4 },
  header:         { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border },
  title:          { flex: 1, fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  searchRow:      { flexDirection: 'row', gap: Spacing.sm, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm },
  searchInput:    { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1.5, borderColor: Colors.borderBlue, borderRadius: Radius.lg, paddingHorizontal: Spacing.sm, paddingVertical: 11 },
  searchField:    { flex: 1, fontSize: FontSize.base, color: '#FFFFFF' },
  searchBtn:      { backgroundColor: Colors.blueBright, borderRadius: Radius.lg, width: 48, height: 48, alignItems: 'center', justifyContent: 'center', shadowColor: Colors.blue, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.5, shadowRadius: 8, elevation: 4 },
  sectionLabel:   { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright, letterSpacing: 1.2, paddingHorizontal: Spacing.md, marginBottom: 4 },
  resultsSection: { paddingHorizontal: Spacing.md, marginBottom: Spacing.sm, backgroundColor: 'rgba(0,104,192,0.04)', borderRadius: Radius.lg, marginHorizontal: Spacing.md, borderWidth: 1, borderColor: Colors.borderBlue, overflow: 'hidden' },
  destItem:       { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingHorizontal: Spacing.md, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: Colors.border },
  destText:       { flex: 1, fontSize: FontSize.md, color: '#FFFFFF', fontWeight: FontWeight.medium },
});

// ─── CAMPGROUNDS TAB ──────────────────────────────────────────────────────────

type CampFilter = 'all' | 'hookups' | 'dump' | 'pets';
type CampView = 'list' | 'map';

function CampsTab({
  insetBottom,
  onNavigateTo,
}: {
  insetBottom: number;
  onNavigateTo: (label: string, coords: LatLng) => void;
}) {
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState<string | null>(null);
  const [camps, setCamps]           = useState<Campground[]>([]);
  const [filter, setFilter]         = useState<CampFilter>('all');
  const [userPos, setUserPos]       = useState<LatLng | null>(null);
  const [searched, setSearched]     = useState(false);
  const [viewMode, setViewMode]     = useState<CampView>('list');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const campMapRef = useRef<MapView>(null);

  const handleSearch = useCallback(async () => {
    setError(null);
    setLoading(true);
    setSearched(true);

    let pos: LatLng = { latitude: 39.5, longitude: -98.35 };
    if (Location) {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          const loc = await Location.getCurrentPositionAsync({
            accuracy: (Location as any).Accuracy?.Balanced ?? 3,
          });
          pos = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
        }
      } catch { /* fall through to default center */ }
    }
    setUserPos(pos);

    try {
      const results = await fetchNearbyCampgrounds(pos);
      setCamps(results);
      if (results.length === 0) {
        setError('No campgrounds found within 50 miles. Try from a different location.');
      }
    } catch {
      setError('Could not reach the campground database. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  const filtered: Campground[] =
    filter === 'hookups' ? camps.filter(c => !!c.hookups)
    : filter === 'dump'  ? camps.filter(c => c.dumpStation)
    : filter === 'pets'  ? camps.filter(c => c.petsAllowed === true)
    : camps;

  const FILTERS: { id: CampFilter; label: string; icon: string }[] = [
    { id: 'all',     label: 'All',         icon: 'campground' },
    { id: 'hookups', label: 'Hookups',      icon: 'bolt' },
    { id: 'dump',    label: 'Dump Station', icon: 'water' },
    { id: 'pets',    label: 'Pets OK',      icon: 'paw' },
  ];

  const countFor = (f: CampFilter) =>
    f === 'hookups' ? camps.filter(c => !!c.hookups).length
    : f === 'dump'  ? camps.filter(c => c.dumpStation).length
    : f === 'pets'  ? camps.filter(c => c.petsAllowed === true).length
    : camps.length;

  const fitMapToMarkers = useCallback((pts: Campground[], origin: LatLng | null) => {
    if (!campMapRef.current || pts.length === 0) return;
    const coords: LatLng[] = pts.map(c => ({ latitude: c.lat, longitude: c.lng }));
    if (origin) coords.push(origin);
    setTimeout(() => {
      campMapRef.current?.fitToCoordinates(coords, {
        edgePadding: { top: 60, right: 40, bottom: 60, left: 40 },
        animated: true,
      });
    }, 400);
  }, []);

  return (
    <View style={{ flex: 1 }}>

      {/* ── Search header ── */}
      <View style={cp.searchBar}>
        <View style={{ flex: 1 }}>
          <Text style={cp.searchTitle}>Nearby Campgrounds</Text>
          <Text style={cp.searchSub}>RV parks within 50 miles</Text>
        </View>

        {/* List / Map toggle — only shown after results load */}
        {camps.length > 0 && (
          <View style={cp.viewToggle}>
            <Pressable
              style={[cp.viewToggleBtn, viewMode === 'list' && cp.viewToggleBtnActive]}
              onPress={() => setViewMode('list')}
            >
              <MaterialIcons name="format-list-bulleted" size={15} color={viewMode === 'list' ? '#000' : Colors.textMuted} />
            </Pressable>
            <Pressable
              style={[cp.viewToggleBtn, viewMode === 'map' && cp.viewToggleBtnActive]}
              onPress={() => {
                setViewMode('map');
                fitMapToMarkers(filtered, userPos);
              }}
            >
              <MaterialIcons name="map" size={15} color={viewMode === 'map' ? '#000' : Colors.textMuted} />
            </Pressable>
          </View>
        )}

        <Pressable
          style={({ pressed }) => [cp.searchBtn, loading && { opacity: 0.6 }, pressed && { opacity: 0.8 }]}
          onPress={handleSearch}
          disabled={loading}
        >
          {loading
            ? <ActivityIndicator size="small" color="#000" />
            : <MaterialIcons name="my-location" size={16} color="#000" />
          }
          <Text style={cp.searchBtnText}>{loading ? 'Searching...' : 'Search Near Me'}</Text>
        </Pressable>
      </View>

      {/* ── Filter chips ── */}
      {camps.length > 0 && (
        <View style={cp.filterBarWrap}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: Spacing.md, paddingVertical: 8 }}>
              {FILTERS.map(f => (
                <Pressable
                  key={f.id}
                  style={[cp.chip, filter === f.id && cp.chipActive]}
                  onPress={() => {
                    setFilter(f.id);
                    if (viewMode === 'map') {
                      // re-fit map after filter change
                      const newFiltered = f.id === 'hookups' ? camps.filter(c => !!c.hookups)
                        : f.id === 'dump' ? camps.filter(c => c.dumpStation)
                        : f.id === 'pets' ? camps.filter(c => c.petsAllowed === true)
                        : camps;
                      fitMapToMarkers(newFiltered, userPos);
                    }
                  }}
                >
                  <FontAwesome5 name={f.icon as any} size={11} color={filter === f.id ? '#000' : '#7AB648'} />
                  <Text style={[cp.chipText, filter === f.id && cp.chipTextActive]}>{f.label}</Text>
                  {f.id !== 'all' && (
                    <View style={[cp.chipBadge, filter === f.id && cp.chipBadgeActive]}>
                      <Text style={[cp.chipBadgeText, filter === f.id && { color: '#000' }]}>
                        {countFor(f.id)}
                      </Text>
                    </View>
                  )}
                </Pressable>
              ))}
            </View>
          </ScrollView>
        </View>
      )}

      {/* ── Results meta ── */}
      {camps.length > 0 && (
        <View style={cp.resultsMeta}>
          <MaterialIcons name="place" size={13} color={Colors.green} />
          <Text style={cp.resultsMetaText}>
            {filtered.length} of {camps.length} campgrounds
            {userPos ? ' near your location' : ' near map center'}
            {' '}· OpenStreetMap data
          </Text>
        </View>
      )}

      {/* ── Error ── */}
      {error && !loading && (
        <View style={cp.errorCard}>
          <MaterialIcons name="error-outline" size={18} color={Colors.red} />
          <Text style={cp.errorText}>{error}</Text>
        </View>
      )}

      {/* ── Empty / not searched yet ── */}
      {!searched && !loading && (
        <View style={cp.emptyState}>
          <FontAwesome5 name="campground" size={48} color={Colors.textDim} />
          <Text style={cp.emptyTitle}>Find RV Parks Near You</Text>
          <Text style={cp.emptySub}>
            Tap "Search Near Me" to find campgrounds, RV parks, and campsites within 50 miles using live OpenStreetMap data. Tap any result to navigate directly.
          </Text>
        </View>
      )}

      {/* ── MAP VIEW ── */}
      {viewMode === 'map' && filtered.length > 0 && (
        <View style={{ flex: 1 }}>
          <MapView
            ref={campMapRef}
            style={StyleSheet.absoluteFill}
            provider={PROVIDER_DEFAULT}
            customMapStyle={DARK_MAP}
            initialRegion={
              userPos
                ? { latitude: userPos.latitude, longitude: userPos.longitude, latitudeDelta: 0.8, longitudeDelta: 0.8 }
                : { latitude: 39.5, longitude: -98.35, latitudeDelta: 10, longitudeDelta: 10 }
            }
            showsUserLocation
            showsCompass
            onPress={() => setSelectedId(null)}
          >
            {filtered.map(camp => {
              const isNear     = camp.distanceMi < 10;
              const isMid      = camp.distanceMi < 25;
              const pinColor   = isNear ? Colors.green : isMid ? Colors.gold : Colors.orange;
              const isSelected = camp.id === selectedId;

              return (
                <Marker
                  key={camp.id}
                  coordinate={{ latitude: camp.lat, longitude: camp.lng }}
                  anchor={{ x: 0.5, y: 1 }}
                  onPress={() => setSelectedId(camp.id)}
                >
                  {/* Custom pin */}
                  <View style={[cp.mapPin, { borderColor: pinColor, shadowColor: pinColor }, isSelected && cp.mapPinSelected]}>
                    <FontAwesome5
                      name={camp.type === 'caravan_site' ? 'caravan' : 'campground'}
                      size={isSelected ? 14 : 11}
                      color={pinColor}
                    />
                  </View>
                  <View style={[cp.mapPinTip, { backgroundColor: pinColor }]} />

                  {/* Tooltip callout — tap to navigate */}
                  <Callout
                    tooltip
                    onPress={() => {
                      onNavigateTo(camp.name, { latitude: camp.lat, longitude: camp.lng });
                    }}
                  >
                    <View style={cp.callout}>
                      <Text style={cp.calloutName} numberOfLines={2}>{camp.name}</Text>
                      <View style={cp.calloutMeta}>
                        <MaterialIcons name="place" size={11} color={Colors.green} />
                        <Text style={cp.calloutDist}>{camp.distanceMi} mi away</Text>
                        {camp.fee ? (
                          <Text style={[cp.calloutBadge, { color: camp.fee === 'Free' ? Colors.green : Colors.orange }]}>
                            {camp.fee}
                          </Text>
                        ) : null}
                      </View>
                      {camp.hookups ? (
                        <View style={cp.calloutAmenity}>
                          <MaterialIcons name="bolt" size={11} color={Colors.gold} />
                          <Text style={cp.calloutAmenityText}>{camp.hookups}</Text>
                        </View>
                      ) : null}
                      <View style={{ flexDirection: 'row', gap: 6 }}>
                        <View style={[cp.calloutNavBtn, { flex: 1 }]}>
                          <MaterialIcons name="navigation" size={12} color="#000" />
                          <Text style={cp.calloutNavText}>Navigate</Text>
                        </View>
                        {camp.website ? (
                          <Pressable
                            style={cp.calloutReserveBtn}
                            onPress={(e) => { e.stopPropagation?.(); Linking.openURL(camp.website!); }}
                          >
                            <MaterialIcons name="open-in-new" size={12} color={Colors.gold} />
                            <Text style={cp.calloutReserveText}>Reserve</Text>
                          </Pressable>
                        ) : null}
                      </View>
                    </View>
                  </Callout>
                </Marker>
              );
            })}
          </MapView>

          {/* Distance legend */}
          <View style={cp.mapLegend}>
            <View style={cp.legendRow}>
              <View style={[cp.legendDot, { backgroundColor: Colors.green }]} />
              <Text style={cp.legendText}>{'<'} 10 mi</Text>
            </View>
            <View style={cp.legendRow}>
              <View style={[cp.legendDot, { backgroundColor: Colors.gold }]} />
              <Text style={cp.legendText}>10–25 mi</Text>
            </View>
            <View style={cp.legendRow}>
              <View style={[cp.legendDot, { backgroundColor: Colors.orange }]} />
              <Text style={cp.legendText}>25–50 mi</Text>
            </View>
          </View>

          {/* Results count pill */}
          <View style={cp.mapCount}>
            <MaterialIcons name="holiday-village" size={12} color={Colors.green} />
            <Text style={cp.mapCountText}>{filtered.length} campgrounds</Text>
          </View>
        </View>
      )}

      {/* ── LIST VIEW ── */}
      {viewMode === 'list' && filtered.length > 0 && (
        <FlatList
          data={filtered}
          keyExtractor={item => String(item.id)}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            paddingHorizontal: Spacing.md,
            paddingTop: Spacing.sm,
            paddingBottom: insetBottom + 80,
            gap: Spacing.sm,
          }}
          renderItem={({ item }) => (
            <View style={cp.card}>
              {/* Card header */}
              <View style={cp.cardHeader}>
                <View style={cp.cardIconWrap}>
                  <FontAwesome5
                    name={item.type === 'caravan_site' ? 'caravan' : 'campground'}
                    size={14}
                    color={Colors.green}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={cp.cardName} numberOfLines={2}>{item.name}</Text>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 }}>
                    <MaterialIcons name="place" size={11} color={Colors.green} />
                    <Text style={cp.cardDist}>{item.distanceMi} mi away</Text>
                    <Text style={cp.cardType}>
                      {item.type === 'caravan_site' ? 'RV Park' : 'Campsite'}
                    </Text>
                  </View>
                </View>
                {item.fee && (
                  <View style={[cp.feeBadge, item.fee === 'Free' && cp.feeBadgeFree]}>
                    <Text style={[cp.feeBadgeText, item.fee === 'Free' && { color: Colors.green }]}>
                      {item.fee}
                    </Text>
                  </View>
                )}
              </View>

              {/* Amenity row */}
              <View style={cp.amenityRow}>
                {item.hookups ? (
                  <View style={cp.amenityTag}>
                    <MaterialIcons name="bolt" size={11} color={Colors.gold} />
                    <Text style={[cp.amenityText, { color: Colors.gold }]}>{item.hookups}</Text>
                  </View>
                ) : null}
                {item.dumpStation ? (
                  <View style={cp.amenityTag}>
                    <MaterialIcons name="water" size={11} color={Colors.blueBright} />
                    <Text style={[cp.amenityText, { color: Colors.blueBright }]}>Dump Station</Text>
                  </View>
                ) : null}
                {item.petsAllowed === true ? (
                  <View style={cp.amenityTag}>
                    <FontAwesome5 name="paw" size={10} color="#FF6B8A" />
                    <Text style={[cp.amenityText, { color: '#FF6B8A' }]}>Pets OK</Text>
                  </View>
                ) : item.petsAllowed === false ? (
                  <View style={[cp.amenityTag, { borderColor: 'rgba(255,68,68,0.3)' }]}>
                    <MaterialIcons name="pets" size={11} color={Colors.red} />
                    <Text style={[cp.amenityText, { color: Colors.red }]}>No Pets</Text>
                  </View>
                ) : null}
                {!item.hookups && !item.dumpStation && item.petsAllowed === null && (
                  <Text style={cp.unknownAmenity}>Amenities unknown — verify before arrival</Text>
                )}
              </View>

              {/* Action row: Navigate + Reserve */}
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <Pressable
                  style={({ pressed }) => [cp.navBtn, { flex: 1 }, pressed && { opacity: 0.8 }]}
                  onPress={() => onNavigateTo(item.name, { latitude: item.lat, longitude: item.lng })}
                >
                  <MaterialIcons name="navigation" size={15} color="#000" />
                  <Text style={cp.navBtnText}>Navigate</Text>
                </Pressable>
                <Pressable
                  style={({ pressed }) => [
                    cp.reserveBtn,
                    !item.website && cp.reserveBtnDisabled,
                    pressed && item.website && { opacity: 0.8 },
                  ]}
                  onPress={() => item.website && Linking.openURL(item.website)}
                  disabled={!item.website}
                >
                  <MaterialIcons name="open-in-new" size={14} color={item.website ? Colors.gold : Colors.textMuted} />
                  <Text style={[cp.reserveBtnText, !item.website && { color: Colors.textMuted }]}>
                    Reserve
                  </Text>
                </Pressable>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}

const cp = StyleSheet.create({
  searchBar:          { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, paddingBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: 'rgba(74,155,212,0.35)', backgroundColor: 'rgba(4,10,28,0.80)' },
  searchTitle:        { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#FFFFFF' },
  searchSub:          { fontSize: 11, color: Colors.textMuted, marginTop: 1 },
  searchBtn:          { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: Colors.blueBright, borderRadius: Radius.full, paddingHorizontal: 14, paddingVertical: 10, shadowColor: Colors.blue, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.4, shadowRadius: 8, elevation: 4 },
  searchBtnText:      { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: '#000' },
  // View toggle
  viewToggle:         { flexDirection: 'row', backgroundColor: '#111', borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, padding: 2, gap: 2 },
  viewToggleBtn:      { width: 30, height: 30, borderRadius: Radius.sm, alignItems: 'center', justifyContent: 'center' },
  viewToggleBtnActive:{ backgroundColor: Colors.blueBright },
  // Filter bar
  filterBarWrap:      { borderBottomWidth: 1, borderBottomColor: Colors.border },
  chip:               { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(74,155,212,0.06)', borderWidth: 1, borderColor: 'rgba(74,155,212,0.35)', borderRadius: Radius.full, paddingHorizontal: 12, paddingVertical: 7 },
  chipActive:         { backgroundColor: '#4A9BD4' },
  chipText:           { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.textMuted },
  chipTextActive:     { color: '#000' },
  chipBadge:          { backgroundColor: 'rgba(74,155,212,0.15)', borderRadius: Radius.full, minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
  chipBadgeActive:    { backgroundColor: 'rgba(0,0,0,0.2)' },
  chipBadgeText:      { fontSize: 10, fontWeight: FontWeight.bold, color: '#4A9BD4' },
  // Meta
  resultsMeta:        { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: Spacing.md, paddingVertical: 6 },
  resultsMetaText:    { fontSize: 11, color: Colors.textMuted },
  errorCard:          { flexDirection: 'row', alignItems: 'flex-start', gap: 8, backgroundColor: 'rgba(255,68,68,0.08)', borderWidth: 1, borderColor: 'rgba(255,68,68,0.3)', borderRadius: Radius.lg, margin: Spacing.md, padding: Spacing.md },
  errorText:          { flex: 1, fontSize: FontSize.sm, color: Colors.red, lineHeight: 20 },
  emptyState:         { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md, paddingHorizontal: 40, paddingTop: 60 },
  emptyTitle:         { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#FFFFFF', textAlign: 'center' },
  emptySub:           { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', lineHeight: 21 },
  // Map view
  mapPin:             { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(5,10,5,0.92)', borderWidth: 2, alignItems: 'center', justifyContent: 'center', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.7, shadowRadius: 6, elevation: 4 },
  mapPinSelected:     { width: 40, height: 40, borderRadius: 20, borderWidth: 2.5 },
  mapPinTip:          { width: 6, height: 6, borderRadius: 3, alignSelf: 'center', marginTop: -2 },
  mapLegend:          { position: 'absolute', top: 12, right: 12, backgroundColor: 'rgba(0,0,0,0.82)', borderRadius: Radius.lg, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', padding: 10, gap: 5 },
  legendRow:          { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendDot:          { width: 10, height: 10, borderRadius: 5 },
  legendText:         { fontSize: 10, color: Colors.textSecondary, fontWeight: FontWeight.medium },
  mapCount:           { position: 'absolute', bottom: 16, left: 12, flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(0,0,0,0.82)', borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.borderBlue, paddingHorizontal: 10, paddingVertical: 6 },
  mapCountText:       { fontSize: 11, color: Colors.blueBright, fontWeight: FontWeight.semibold },
  // Callout
  callout:            { backgroundColor: '#0A1520', borderRadius: Radius.lg, borderWidth: 1.5, borderColor: Colors.borderBlue, padding: 12, minWidth: 180, maxWidth: 230, gap: 6, shadowColor: Colors.blue, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 },
  calloutName:        { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary, lineHeight: 19 },
  calloutMeta:        { flexDirection: 'row', alignItems: 'center', gap: 5 },
  calloutDist:        { fontSize: 11, color: Colors.blueBright, fontWeight: FontWeight.semibold, flex: 1 },
  calloutBadge:       { fontSize: 10, fontWeight: FontWeight.bold },
  calloutAmenity:     { flexDirection: 'row', alignItems: 'center', gap: 4 },
  calloutAmenityText: { fontSize: 11, color: Colors.silver },
  calloutNavBtn:      { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: Colors.blueBright, borderRadius: Radius.md, paddingVertical: 8, marginTop: 2 },
  calloutNavText:     { fontSize: 12, fontWeight: FontWeight.bold, color: '#000' },
  // List cards
  card:               { backgroundColor: 'rgba(4,10,28,0.82)', borderRadius: Radius.xl, borderWidth: 1.5, borderColor: 'rgba(74,155,212,0.55)', padding: Spacing.md, gap: Spacing.sm, shadowColor: '#4A9BD4', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 14, elevation: 5 },
  cardHeader:         { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm },
  cardIconWrap:       { width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(0,104,192,0.1)', borderWidth: 1, borderColor: Colors.borderBlue, alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  cardName:           { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#FFFFFF', lineHeight: 21, flex: 1, textShadowColor: 'rgba(0,0,0,0.8)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 3 },
  cardDist:           { fontSize: 11, color: Colors.blueBright, fontWeight: FontWeight.semibold },
  cardType:           { fontSize: 10, color: Colors.textDim, backgroundColor: 'rgba(255,255,255,0.05)', paddingHorizontal: 6, paddingVertical: 2, borderRadius: Radius.sm },
  feeBadge:           { backgroundColor: 'rgba(255,140,0,0.1)', borderWidth: 1, borderColor: 'rgba(255,140,0,0.4)', borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 3 },
  feeBadgeFree:       { backgroundColor: 'rgba(0,104,192,0.08)', borderColor: Colors.borderBlue },
  feeBadgeText:       { fontSize: 10, fontWeight: FontWeight.bold, color: Colors.silver },
  amenityRow:         { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  amenityTag:         { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 4 },
  amenityText:        { fontSize: 11, fontWeight: FontWeight.semibold },
  unknownAmenity:     { fontSize: 11, color: Colors.textDim, fontStyle: 'italic' },
  navBtn:             { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: Colors.blueBright, borderRadius: Radius.lg, paddingVertical: 11, shadowColor: Colors.blue, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.35, shadowRadius: 8, elevation: 4 },
  navBtnText:         { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: '#000' },
  reserveBtn:         { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: 'rgba(188,185,186,0.08)', borderWidth: 1.5, borderColor: Colors.borderSilver, borderRadius: Radius.lg, paddingVertical: 11, paddingHorizontal: 14 },
  reserveBtnDisabled: { borderColor: Colors.border, backgroundColor: 'transparent', opacity: 0.5 },
  reserveBtnText:     { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.silver },
  calloutReserveBtn:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, backgroundColor: 'rgba(188,185,186,0.1)', borderRadius: Radius.md, paddingVertical: 8, paddingHorizontal: 8, borderWidth: 1, borderColor: Colors.borderSilver },
  calloutReserveText: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.silver },
});

// ─── PACKING LIST ─────────────────────────────────────────────────────────────

interface PackingItem { id: string; label: string; category: string; checked: boolean }

const DEFAULT_PACK: PackingItem[] = [
  { id: 's1', label: 'First Aid Kit',            category: 'Safety',   checked: false },
  { id: 's2', label: 'Fire Extinguisher',         category: 'Safety',   checked: false },
  { id: 's3', label: 'Emergency Roadside Kit',    category: 'Safety',   checked: false },
  { id: 's4', label: 'Wheel Chocks',              category: 'Safety',   checked: false },
  { id: 's5', label: 'CO Detector',               category: 'Safety',   checked: false },
  { id: 'h1', label: '50-amp Power Cord',         category: 'Hookups',  checked: false },
  { id: 'h2', label: 'Water Pressure Regulator',  category: 'Hookups',  checked: false },
  { id: 'h3', label: 'Fresh Water Hose',          category: 'Hookups',  checked: false },
  { id: 'h4', label: 'Sewer Hose Kit',            category: 'Hookups',  checked: false },
  { id: 'h5', label: 'Surge Protector',           category: 'Hookups',  checked: false },
  { id: 'k1', label: 'Propane Full',              category: 'Kitchen',  checked: false },
  { id: 'k2', label: 'Pots, Pans, Utensils',      category: 'Kitchen',  checked: false },
  { id: 'k3', label: 'Camp Grill / Griddle',      category: 'Kitchen',  checked: false },
  { id: 't1', label: 'Level Blocks',              category: 'Tools',    checked: false },
  { id: 't2', label: 'Tire Pressure Gauge',       category: 'Tools',    checked: false },
  { id: 't3', label: 'Basic Toolbox',             category: 'Tools',    checked: false },
  { id: 'p1', label: 'Bedding / Sleeping Bags',   category: 'Personal', checked: false },
  { id: 'p2', label: 'Towels & Bath Items',        category: 'Personal', checked: false },
  { id: 'p3', label: 'Medications',               category: 'Personal', checked: false },
  { id: 'p4', label: 'Sunscreen & Bug Spray',     category: 'Personal', checked: false },
  { id: 'p5', label: 'Reservations Confirmed',    category: 'Personal', checked: false },
];

function PackingTab({ insetBottom }: { insetBottom: number }) {
  const [items, setItems] = useState<PackingItem[]>(DEFAULT_PACK);
  const [cat, setCat] = useState('All');
  const toggle = (id: string) => setItems(p => p.map(i => i.id === id ? { ...i, checked: !i.checked } : i));
  const cats = ['All', 'Safety', 'Hookups', 'Kitchen', 'Tools', 'Personal'];
  const filtered = cat === 'All' ? items : items.filter(i => i.category === cat);
  const done = items.filter(i => i.checked).length;
  const pct = items.length > 0 ? done / items.length : 0;
  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insetBottom + 32 }}>
      <View style={{ paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, gap: Spacing.md }}>
        <View style={pkStyle.card}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View>
              <Text style={pkStyle.cardTitle}>Packing Checklist</Text>
              <Text style={pkStyle.cardSub}>{done} of {items.length} items packed</Text>
            </View>
            <View style={pkStyle.pctCircle}>
              <Text style={pkStyle.pctText}>{Math.round(pct * 100)}%</Text>
            </View>
          </View>
          <View style={pkStyle.bar}><View style={[pkStyle.fill, { width: `${pct * 100}%` as any }]} /></View>
          {done === items.length && items.length > 0 && (
            <View style={pkStyle.readyBanner}>
              <MaterialIcons name="check-circle" size={16} color={Colors.green} />
              <Text style={pkStyle.readyText}>You are road-ready!</Text>
            </View>
          )}
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={{ flexDirection: 'row', gap: 8, paddingRight: Spacing.md }}>
            {cats.map(c => (
              <Pressable key={c} style={[pkStyle.chip, cat === c && pkStyle.chipActive]} onPress={() => setCat(c)}>
                <Text style={[pkStyle.chipText, cat === c && pkStyle.chipTextActive]}>{c}</Text>
              </Pressable>
            ))}
          </View>
        </ScrollView>
        <View style={pkStyle.list}>
          {filtered.map((item, idx) => (
            <Pressable key={item.id}
              style={({ pressed }) => [pkStyle.item, item.checked && pkStyle.itemDone, pressed && { opacity: 0.7 }, idx === filtered.length - 1 && { borderBottomWidth: 0 }]}
              onPress={() => toggle(item.id)}
            >
              <View style={[pkStyle.box, item.checked && pkStyle.boxChecked]}>
                {item.checked && <MaterialIcons name="check" size={14} color="#000" />}
              </View>
              <Text style={[pkStyle.itemText, item.checked && pkStyle.itemTextDone]}>{item.label}</Text>
              <Text style={pkStyle.catTag}>{item.category}</Text>
            </Pressable>
          ))}
        </View>
        <Pressable style={pkStyle.resetBtn} onPress={() => setItems(DEFAULT_PACK)}>
          <MaterialIcons name="refresh" size={14} color={Colors.textMuted} />
          <Text style={pkStyle.resetText}>Reset All</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const pkStyle = StyleSheet.create({
  card:           { backgroundColor: 'rgba(4,10,28,0.85)', borderRadius: Radius.xl, borderWidth: 1.5, borderColor: 'rgba(74,155,212,0.55)', padding: Spacing.md, gap: Spacing.sm },
  cardTitle:      { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  cardSub:        { fontSize: FontSize.xs, color: Colors.textSecondary, marginTop: 2 },
  pctCircle:      { width: 52, height: 52, borderRadius: 26, backgroundColor: 'rgba(0,104,192,0.12)', borderWidth: 2, borderColor: Colors.blueBright, alignItems: 'center', justifyContent: 'center' },
  pctText:        { fontSize: FontSize.base, fontWeight: FontWeight.extrabold, color: Colors.blueBright },
  bar:            { height: 8, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: Radius.full, overflow: 'hidden' },
  fill:           { height: '100%', backgroundColor: Colors.blueBright, borderRadius: Radius.full },
  readyBanner:    { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(0,104,192,0.08)', borderRadius: Radius.md, padding: Spacing.sm },
  readyText:      { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.blueBright },
  chip:           { backgroundColor: 'rgba(0,104,192,0.06)', borderWidth: 1, borderColor: Colors.borderBlue, borderRadius: Radius.full, paddingHorizontal: 14, paddingVertical: 7 },
  chipActive:     { backgroundColor: Colors.blueBright },
  chipText:       { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.textMuted },
  chipTextActive: { color: '#000' },
  list:           { backgroundColor: 'rgba(4,10,28,0.90)', borderRadius: Radius.xl, borderWidth: 1, borderColor: 'rgba(74,155,212,0.45)', overflow: 'hidden' },
  item:           { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingHorizontal: Spacing.md, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: Colors.border },
  itemDone:       { backgroundColor: 'rgba(74,222,128,0.04)' },
  box:            { width: 24, height: 24, borderRadius: 6, borderWidth: 1.5, borderColor: Colors.borderBlue, alignItems: 'center', justifyContent: 'center' },
  boxChecked:     { backgroundColor: Colors.blueBright, borderColor: Colors.blueBright },
  itemText:       { flex: 1, fontSize: FontSize.md, color: Colors.textPrimary, fontWeight: FontWeight.medium },
  itemTextDone:   { color: Colors.textMuted, textDecorationLine: 'line-through' },
  catTag:         { fontSize: 10, color: Colors.textMuted },
  resetBtn:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border },
  resetText:      { fontSize: FontSize.sm, color: Colors.textMuted },
});

// ─── MAIN NAVIGATOR SCREEN ────────────────────────────────────────────────────

type NavTab = 'navigate' | 'directions' | 'camps' | 'pack';

export default function RvTripsScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const [dimensions, setDimensions] = useState(() => Dimensions.get('window'));
  useEffect(() => {
    const sub = Dimensions.addEventListener('change', ({ window }) => setDimensions(window));
    return () => sub?.remove();
  }, []);

  const winWidth  = Math.max(1, dimensions.width);
  const winHeight = Math.max(1, dimensions.height);

  // ── RV Profile ──────────────────────────────────────────────────────────
  const [rvProfile, setRvProfile]           = useState<RVDimensions | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(true);

  const loadProfile = useCallback(async () => {
    if (!user) { setLoadingProfile(false); return; }
    try {
      const supabase = getSupabaseClient();
      const { data } = await supabase
        .from('rv_profiles')
        .select('make, model, height, width, length, gvwr, has_propane')
        .eq('user_id', user.id)
        .maybeSingle();
      if (data) {
        const h = parseFloat(data.height || '0') || 0;
        const w = parseFloat(data.width  || '0') || 0;
        const l = parseFloat(data.length || '0') || 0;
        const g = parseFloat(data.gvwr   || '0') || 0;
        if (h > 0 || l > 0 || g > 0) {
          setRvProfile({
            heightFt:   h,
            widthFt:    w,
            lengthFt:   l,
            gvwrLbs:    g,
            hasPropane: data.has_propane ?? false,
            makeModel:  [data.make, data.model].filter(Boolean).join(' '),
          });
        } else {
          setRvProfile(null);
        }
      } else {
        setRvProfile(null);
      }
    } catch { /* non-fatal */ }
    finally { setLoadingProfile(false); }
  }, [user]);

  // Load on mount
  useEffect(() => { loadProfile(); }, [loadProfile]);

  // Re-load every time this tab comes into focus (catches saves from rv-profile screen)
  useFocusEffect(
    useCallback(() => { loadProfile(); }, [loadProfile])
  );

  // ── Navigation state ────────────────────────────────────────────────────
  const [activeTab, setActiveTab]         = useState<NavTab>('navigate');
  const [destModalOpen, setDestModalOpen] = useState(false);
  const [destLabel, setDestLabel]         = useState('');
  const [destCoords, setDestCoords]       = useState<LatLng | null>(null);
  const [routing, setRouting]             = useState(false);
  const [routeResult, setRouteResult]     = useState<RouteResult | null>(null);
  const [routeCamps, setRouteCamps]       = useState<Campground[]>([]);
  const [routeCampsLoading, setRouteCampsLoading] = useState(false);

  // GPS / navigation
  const [navigating, setNavigating]             = useState(false);
  const [currentPos, setCurrentPos]             = useState<LatLng | null>(null);
  const [heading, setHeading]                   = useState<number>(0);
  const [speedMph, setSpeedMph]                 = useState(0);
  const [elapsedSec, setElapsedSec]             = useState(0);
  const [nextStepIdx, setNextStepIdx]           = useState(0);
  const [distToNextMi, setDistToNextMi]         = useState<number | null>(null);
  const [permissionError, setPermissionError]   = useState<string | null>(null);

  // ── Voice guidance ────────────────────────────────────────────────────────
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const voiceEnabledRef = useRef(true);
  const nextStepIdxRef  = useRef(0);
  const announcedRef    = useRef<Record<number, 'pre' | 'now'>>({});
  const routeResultRef  = useRef<RouteResult | null>(null);

  const mapRef     = useRef<MapView>(null);
  const watchRef   = useRef<any>(null);
  const timerRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastPosRef = useRef<LatLng | null>(null);

  useEffect(() => { routeResultRef.current = routeResult; }, [routeResult]);

  const toggleVoice = useCallback(() => {
    const next = !voiceEnabledRef.current;
    voiceEnabledRef.current = next;
    setVoiceEnabled(next);
    if (Speech) {
      if (!next) { Speech.stop(); }
      else { Speech.speak('Voice guidance on', { rate: 0.95, language: 'en-US' }); }
    }
  }, []);

  const speakText = useCallback((text: string) => {
    if (!Speech || !voiceEnabledRef.current) return;
    Speech.stop();
    Speech.speak(text, { rate: 0.95, language: 'en-US' });
  }, []);

  function spokenDist(meters: number): string {
    const mi = meters / 1609.34;
    if (mi < 0.1) return `in ${Math.round(meters)} feet`;
    if (mi < 0.5) return `in ${Math.round(mi * 10) / 10} miles`;
    return `in ${mi.toFixed(1)} miles`;
  }

  // ── Compute Route ───────────────────────────────────────────────────────
  const handlePlanRoute = useCallback(async () => {
    if (!destCoords) return;
    setRouting(true);
    setPermissionError(null);

    let originCoords: LatLng = { latitude: 39.5, longitude: -98.35 };
    let originLabel = 'Your Location';

    if (Location) {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          const pos = await Location.getCurrentPositionAsync({
            accuracy: (Location as any).Accuracy?.Balanced ?? 3,
          });
          originCoords = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
          setCurrentPos(originCoords);
        }
      } catch { /* fall through */ }
    }

    let result = await fetchHERERoute(originCoords, destCoords, rvProfile);
    if (!result) {
      console.log('HERE unavailable, falling back to OSRM...');
      result = await fetchOSRMRoute(originCoords, destCoords);
    }
    if (!result) {
      result = buildFallbackRoute(originCoords, destCoords, originLabel, destLabel);
    } else {
      result.originLabel = originLabel;
      result.destLabel   = destLabel;
    }

    result.warnings = computeWarnings(rvProfile, destLabel);
    setRouteResult(result);
    setNextStepIdx(0);

    if (mapRef.current && result.polyline.length > 1) {
      setTimeout(() => {
        mapRef.current?.fitToCoordinates(result!.polyline, {
          edgePadding: { top: 80, right: 40, bottom: 120, left: 40 },
          animated: true,
        });
      }, 300);
    }

    setActiveTab('navigate');
    setRouting(false);

    // Fetch campgrounds near route midpoint
    if (result && result.polyline.length > 2) {
      const mid = result.polyline[Math.floor(result.polyline.length / 2)];
      setRouteCamps([]);
      setRouteCampsLoading(true);
      fetchNearbyCampgrounds(mid)
        .then(camps => setRouteCamps(camps.slice(0, 6)))
        .catch(() => {})
        .finally(() => setRouteCampsLoading(false));
    }
  }, [destCoords, destLabel, rvProfile]);

  // ── Start Navigation ────────────────────────────────────────────────────
  const startNavigation = useCallback(async () => {
    setPermissionError(null);
    if (!Location) {
      setPermissionError('GPS not available in this preview. Install on device to navigate.');
      return;
    }
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setPermissionError('Location permission required for turn-by-turn navigation.');
        return;
      }
    } catch {
      setPermissionError('Unable to request location permission.');
      return;
    }
    try {
      const initial = await Location.getCurrentPositionAsync({ accuracy: (Location as any).Accuracy?.High ?? 6 });
      const pos = { latitude: initial.coords.latitude, longitude: initial.coords.longitude };
      setCurrentPos(pos);
      lastPosRef.current = pos;
    } catch {
      setPermissionError('Could not get current location. Check device settings.');
      return;
    }

    setNavigating(true);
    setElapsedSec(0);
    setNextStepIdx(0);
    nextStepIdxRef.current = 0;
    announcedRef.current   = {};
    timerRef.current = setInterval(() => setElapsedSec(s => s + 1), 1000);

    const firstRoute = routeResultRef.current;
    if (firstRoute && firstRoute.steps.length > 0) {
      const s0 = firstRoute.steps[0];
      speakText(`Starting navigation. ${s0.instruction}`);
      announcedRef.current[0] = 'now';
    }

    try {
      watchRef.current = await Location.watchPositionAsync(
        { accuracy: (Location as any).Accuracy?.High ?? 6, distanceInterval: 5, timeInterval: 2000 },
        (location: any) => {
          const newPos = { latitude: location.coords.latitude, longitude: location.coords.longitude };
          setCurrentPos(newPos);
          setHeading(location.coords.heading ?? 0);
          setSpeedMph(Math.max(0, (location.coords.speed ?? 0) * 2.23694));

          const route = routeResultRef.current;
          if (route) {
            const steps     = route.steps;
            const curIdx    = nextStepIdxRef.current;
            const announced = announcedRef.current;

            if (curIdx < steps.length - 1) {
              const stepCoords = steps[curIdx].coords;
              const distM      = haversineMi(newPos, stepCoords) * 1609.34;

              if (distM < 60) {
                const newIdx = Math.min(curIdx + 1, steps.length - 1);
                nextStepIdxRef.current = newIdx;
                setNextStepIdx(newIdx);
                setDistToNextMi(null);
                if (!announced[newIdx]) {
                  announced[newIdx] = 'now';
                  const newStep  = steps[newIdx];
                  const isArrive = newStep.maneuver === 'arrive';
                  speakText(isArrive ? 'You have arrived at your destination.' : newStep.instruction);
                }
              } else {
                if (distM <= 400 && !announced[curIdx]) {
                  announced[curIdx] = 'pre';
                  speakText(`${spokenDist(distM)}, ${steps[curIdx].instruction.toLowerCase()}`);
                }
                setDistToNextMi(distM / 1609.34);
              }
            }
          }

          mapRef.current?.animateCamera(
            { center: newPos, heading: location.coords.heading ?? 0, pitch: 45, zoom: 16 },
            { duration: 800 }
          );
          lastPosRef.current = newPos;
        }
      );
    } catch {
      setPermissionError('GPS tracking failed to start.');
      setNavigating(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  }, [speakText]);

  const stopNavigation = useCallback(() => {
    try { watchRef.current?.remove(); } catch { /* ignore */ }
    watchRef.current = null;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    setNavigating(false);
    setSpeedMph(0);
    if (Speech) Speech.stop();
  }, []);

  useEffect(() => {
    return () => {
      try { watchRef.current?.remove(); } catch { /* ignore */ }
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const mapH     = navigating ? winHeight * 0.55 : winHeight * 0.42;
  const nextStep = routeResult?.steps[nextStepIdx] ?? null;
  const nextIcon = nextStep ? maneuverIcon(nextStep.maneuver) : 'straight';
  const hasProfile = rvProfile && (rvProfile.heightFt > 0 || rvProfile.gvwrLbs > 0);

  const TABS: { id: NavTab; icon: string; label: string }[] = [
    { id: 'navigate',   icon: 'navigation',     label: 'Navigate'    },
    { id: 'directions', icon: 'list',            label: 'Directions'  },
    { id: 'camps',      icon: 'holiday-village', label: 'Campgrounds' },
    { id: 'pack',       icon: 'checklist',       label: 'Pack List'   },
  ];

  const handleCampNavigate = useCallback((label: string, coords: LatLng) => {
    setDestLabel(label);
    setDestCoords(coords);
    setRouteResult(null);
    setActiveTab('navigate');
  }, []);

  return (
    <View style={[root.container, { paddingTop: insets.top }]}>

      {/* ── MAP HERO BACKDROP ── */}
      <View style={root.heroBackdrop}>
        <Image
          source={require('../../assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.3 }}
          transition={400}
        />
        <LinearGradient
          colors={['rgba(30,46,64,0.70)', 'rgba(20,38,72,0.28)', 'rgba(20,38,72,0.22)', 'rgba(30,46,64,0.40)', 'rgba(18,28,50,0.76)']}
          locations={[0, 0.18, 0.5, 0.82, 1]}
          style={StyleSheet.absoluteFill}
        />
      </View>

      {/* ── HEADER ── */}
      <View style={root.header}>
        <View style={root.headerLeft}>
          <View style={root.iconWrap}>
            <FontAwesome5 name="route" size={17} color={Colors.blueBright} />
          </View>
          <View>
            <Text style={root.title}>RvTrips</Text>
            <Text style={root.subtitle}>
              {hasProfile
                ? `${rvProfile!.makeModel || 'RV'} · ${rvProfile!.heightFt}ft H · ${rvProfile!.lengthFt}ft L`
                : 'RV-AWARE GPS NAVIGATOR'}
            </Text>
          </View>
        </View>
        {!loadingProfile && !hasProfile && (
          <View style={root.noProfileBadge}>
            <MaterialIcons name="warning" size={12} color={Colors.orange} />
            <Text style={root.noProfileText}>Set RV Profile</Text>
          </View>
        )}
        {hasProfile && (
          <View style={root.profileBadge}>
            <MaterialIcons name="shield" size={12} color={Colors.green} />
            <Text style={root.profileBadgeText}>RV SAFE</Text>
          </View>
        )}
      </View>

      {/* ── TAB BAR ── */}
      <View style={root.tabBar}>
        {TABS.map(tab => (
          <Pressable
            key={tab.id}
            style={[root.tabBtn, activeTab === tab.id && root.tabBtnActive]}
            onPress={() => setActiveTab(tab.id)}
          >
            <MaterialIcons
              name={tab.icon as any} size={13}
              color={activeTab === tab.id ? '#fff' : Colors.textMuted}
            />
            <Text style={[root.tabText, activeTab === tab.id && root.tabTextActive]}>{tab.label}</Text>
            {tab.id === 'directions' && (routeResult?.warnings.length ?? 0) > 0 && (
              <View style={root.warningDot}>
                <Text style={root.warningDotText}>{routeResult!.warnings.length}</Text>
              </View>
            )}
          </Pressable>
        ))}
      </View>

      {/* ══════════════════════════════════════════════════════════════════ */}
      {/*  NAVIGATE TAB                                                      */}
      {/* ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'navigate' && (
        <View style={{ flex: 1 }}>
          <View style={[map.container, { height: mapH, marginHorizontal: Spacing.md }]}>
            <MapView
              ref={mapRef}
              style={StyleSheet.absoluteFill}
              provider={PROVIDER_DEFAULT}
              customMapStyle={DARK_MAP}
              initialRegion={{ latitude: 39.5, longitude: -98.35, latitudeDelta: 30, longitudeDelta: 35 }}
              mapType="standard"
              showsUserLocation={false}
              showsCompass
              showsTraffic={navigating}
              rotateEnabled
              pitchEnabled={navigating}
            >
              {routeResult && (
                <>
                  <Polyline coordinates={routeResult.polyline} strokeColor="rgba(74,155,212,0.2)" strokeWidth={12} />
                  <Polyline coordinates={routeResult.polyline} strokeColor="#4A9BD4" strokeWidth={3} />
                </>
              )}
              {routeResult && (
                <Marker coordinate={routeResult.originCoords} anchor={{ x: 0.5, y: 0.5 }}>
                  <View style={map.originMarker}><View style={map.originDot} /></View>
                </Marker>
              )}
              {destCoords && (
                <Marker coordinate={destCoords} anchor={{ x: 0.5, y: 1 }}>
                  <View style={map.destWrap}>
                    <View style={map.destPin}>
                      <MaterialIcons name="place" size={18} color={Colors.gold} />
                    </View>
                    <View style={map.destLabel}>
                      <Text style={map.destLabelText} numberOfLines={1}>{destLabel.split(',')[0]}</Text>
                    </View>
                  </View>
                </Marker>
              )}
              {currentPos && (
                <Marker coordinate={currentPos} anchor={{ x: 0.5, y: 0.5 }} rotation={heading}>
                  <View style={map.rvMarker}>
                    <FontAwesome5 name="bus" size={16} color={Colors.blueBright} />
                  </View>
                </Marker>
              )}
            </MapView>

            {navigating && (
              <View style={map.speedHUD}>
                <Text style={map.speedVal}>{Math.round(speedMph)}</Text>
                <Text style={map.speedUnit}>mph</Text>
                <View style={map.speedLimitSign}>
                  <Text style={map.speedLimitLabel}>{`SPEED\nLIMIT`}</Text>
                  <Text style={map.speedLimitNum}>55</Text>
                </View>
              </View>
            )}

            {navigating && nextStep && (
              <View style={map.nextTurnHUD}>
                <MaterialIcons name={nextIcon as any} size={28} color={Colors.textPrimary} />
                <View style={{ flex: 1 }}>
                  <Text style={map.nextTurnInstr} numberOfLines={2}>{nextStep.instruction}</Text>
                  {distToNextMi !== null && (
                    <Text style={map.nextTurnDist}>
                      {distToNextMi < 0.1 ? `${Math.round(distToNextMi * 5280)} ft` : `${distToNextMi.toFixed(1)} mi`}
                    </Text>
                  )}
                </View>
                <Pressable onPress={toggleVoice} hitSlop={8} style={[map.voiceBtn, !voiceEnabled && map.voiceBtnMuted]}>
                  <MaterialIcons
                    name={voiceEnabled ? 'volume-up' : 'volume-off'}
                    size={18}
                    color={voiceEnabled ? Colors.blueBright : Colors.textMuted}
                  />
                </Pressable>
              </View>
            )}

            {!navigating && routeResult && (
              <View style={map.routeOverlay}>
                <View style={map.routeStat}>
                  <Text style={map.routeStatVal}>{routeResult.distanceMi.toLocaleString()}</Text>
                  <Text style={map.routeStatLbl}>mi</Text>
                </View>
                <View style={map.routeStatDiv} />
                <View style={map.routeStat}>
                  <Text style={map.routeStatVal}>{fmtDuration(routeResult.durationMin)}</Text>
                  <Text style={map.routeStatLbl}>drive</Text>
                </View>
                {routeResult.warnings.length > 0 && (
                  <>
                    <View style={map.routeStatDiv} />
                    <View style={map.routeStat}>
                      <MaterialIcons name="warning" size={14} color={Colors.orange} />
                      <Text style={[map.routeStatLbl, { color: Colors.orange }]}>{routeResult.warnings.length} RV alerts</Text>
                    </View>
                  </>
                )}
              </View>
            )}

            {routeResult && (
              <View style={[
                map.sourceBadge,
                (routeResult.source === 'here' || routeResult.source === 'osrm') && map.sourceBadgeReal,
                routeResult.source === 'here' && map.sourceBadgeHere,
              ]}>
                <Text style={[map.sourceBadgeText, routeResult.source === 'here' && { color: Colors.gold }]}>
                  {routeResult.source === 'here'
                    ? `HERE${routeResult.vehicleConstrained ? ' · RV CONSTRAINED' : ' · TRUCK ROUTE'}`
                    : routeResult.source === 'osrm' ? 'REAL ROUTE · OSRM' : 'ESTIMATE · NO NETWORK'}
                </Text>
              </View>
            )}
          </View>

          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
            keyboardShouldPersistTaps="handled"
          >
            <View style={{ paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, gap: Spacing.md }}>

              <Pressable
                style={({ pressed }) => [nav.destPicker, pressed && { opacity: 0.8 }]}
                onPress={() => setDestModalOpen(true)}
              >
                <View style={nav.destIconWrap}>
                  <MaterialIcons name="place" size={20} color={Colors.gold} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={nav.destPickerLabel}>DESTINATION</Text>
                  <Text style={[nav.destPickerValue, !destLabel && nav.destPickerPlaceholder]} numberOfLines={1}>
                    {destLabel || 'Tap to set destination...'}
                  </Text>
                </View>
                <MaterialIcons name="keyboard-arrow-right" size={22} color={Colors.textMuted} />
              </Pressable>

              {navigating && rvProfile && rvProfile.heightFt >= 12 && (
                <View style={nav.liveAlertBar}>
                  <MaterialIcons name="warning" size={13} color={Colors.orange} />
                  <Text style={nav.liveAlertText} numberOfLines={1}>
                    {rvProfile.heightFt >= 13.5
                      ? `${rvProfile.heightFt}ft tall — watch for low bridges & tunnels`
                      : `${rvProfile.heightFt}ft tall — verify tunnel clearances`}
                  </Text>
                  {rvProfile.widthFt > 8 ? (
                    <Text style={[nav.liveAlertText, { color: Colors.blueBright }]}> · {rvProfile.widthFt}ft wide</Text>
                  ) : null}
                </View>
              )}
              {permissionError && (
                <View style={nav.errorCard}>
                  <MaterialIcons name="location-off" size={18} color={Colors.red} />
                  <Text style={nav.errorText}>{permissionError}</Text>
                </View>
              )}

              {routeResult && routeResult.warnings.length > 0 && !navigating && (
                <View>
                  <View style={nav.warnHeader}>
                    <MaterialIcons name="warning" size={15} color={Colors.orange} />
                    <Text style={nav.warnHeaderText}>RV RESTRICTION WARNINGS</Text>
                    <View style={nav.warnCount}><Text style={nav.warnCountText}>{routeResult.warnings.length}</Text></View>
                  </View>
                  {routeResult.warnings.map((w, i) => <WarningCard key={i} w={w} />)}
                </View>
              )}

              {navigating && (
                <View style={nav.statsRow}>
                  <View style={nav.statCard}>
                    <MaterialIcons name="speed" size={18} color={Colors.blueBright} />
                    <Text style={[nav.statVal, { color: Colors.blueBright }]}>{Math.round(speedMph)}</Text>
                    <Text style={nav.statLbl}>mph</Text>
                  </View>
                  <View style={nav.statCard}>
                    <MaterialIcons name="timer" size={18} color={Colors.gold} />
                    <Text style={[nav.statVal, { color: Colors.gold }]}>{fmtElapsed(elapsedSec)}</Text>
                    <Text style={nav.statLbl}>elapsed</Text>
                  </View>
                  <Pressable style={[nav.statCard, { borderColor: voiceEnabled ? 'rgba(77,166,255,0.35)' : Colors.border }]} onPress={toggleVoice}>
                    <MaterialIcons name={voiceEnabled ? 'volume-up' : 'volume-off'} size={18} color={voiceEnabled ? Colors.blueBright : Colors.textMuted} />
                    <Text style={[nav.statVal, { color: voiceEnabled ? Colors.blueBright : Colors.textMuted, fontSize: FontSize.sm }]}>
                      {voiceEnabled ? 'ON' : 'OFF'}
                    </Text>
                    <Text style={nav.statLbl}>voice</Text>
                  </Pressable>
                </View>
              )}

              {!navigating && (
                <View style={nav.actionRow}>
                  <Pressable
                    style={({ pressed }) => [nav.calcBtn, (!destCoords || routing) && nav.calcBtnDisabled, pressed && destCoords && nav.calcBtnPressed]}
                    onPress={handlePlanRoute}
                    disabled={!destCoords || routing}
                  >
                    {routing
                      ? <ActivityIndicator size="small" color={Colors.green} />
                      : <MaterialIcons name="alt-route" size={18} color={!destCoords ? Colors.textMuted : Colors.green} />
                    }
                    <Text style={[nav.calcBtnText, !destCoords && { color: Colors.textMuted }]}>
                      {routing ? 'Calculating RV Route...' : 'Calculate RV Route'}
                    </Text>
                  </Pressable>
                  {routeResult && (
                    <Pressable style={({ pressed }) => [nav.startBtn, pressed && nav.startBtnPressed]} onPress={startNavigation}>
                      <MaterialIcons name="navigation" size={22} color="#000" />
                      <Text style={nav.startBtnText}>Start Turn-by-Turn</Text>
                    </Pressable>
                  )}
                </View>
              )}

              {navigating && (
                <Pressable style={({ pressed }) => [nav.stopBtn, pressed && { opacity: 0.8 }]} onPress={stopNavigation}>
                  <MaterialIcons name="stop" size={22} color="#fff" />
                  <Text style={nav.stopBtnText}>Stop Navigation</Text>
                </Pressable>
              )}

              {/* ── CAMPGROUNDS ALONG ROUTE ── */}
              {(routeCampsLoading || routeCamps.length > 0) && routeResult && (
                <View style={nav.routeCampsSection}>
                  <View style={nav.routeCampsHeader}>
                    <FontAwesome5 name="campground" size={13} color={Colors.green} />
                    <Text style={nav.routeCampsTitle}>CAMPGROUNDS ALONG ROUTE</Text>
                    {routeCamps.length > 0 && (
                      <View style={nav.routeCampsCount}>
                        <Text style={nav.routeCampsCountText}>{routeCamps.length}</Text>
                      </View>
                    )}
                    <Text style={nav.routeCampsSource}>via OpenStreetMap</Text>
                  </View>
                  {routeCampsLoading ? (
                    <View style={nav.routeCampsLoading}>
                      <ActivityIndicator size="small" color={Colors.green} />
                      <Text style={nav.routeCampsLoadingText}>Finding campgrounds along your route...</Text>
                    </View>
                  ) : (
                    <View style={{ gap: 10 }}>
                      {routeCamps.map(camp => (
                        <View key={camp.id} style={nav.routeCampCard}>
                          <View style={nav.routeCampCardLeft}>
                            <View style={nav.routeCampIconWrap}>
                              <FontAwesome5
                                name={camp.type === 'caravan_site' ? 'caravan' : 'campground'}
                                size={14} color={Colors.green}
                              />
                            </View>
                            <View style={{ flex: 1 }}>
                              <Text style={nav.routeCampName} numberOfLines={1}>{camp.name}</Text>
                              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 }}>
                                <MaterialIcons name="place" size={10} color={Colors.green} />
                                <Text style={nav.routeCampDist}>{camp.distanceMi} mi from midpoint</Text>
                                {camp.hookups ? (
                                  <View style={nav.routeCampAmenity}>
                                    <MaterialIcons name="bolt" size={9} color={Colors.gold} />
                                    <Text style={nav.routeCampAmenityText}>{camp.hookups}</Text>
                                  </View>
                                ) : null}
                              </View>
                            </View>
                          </View>
                          <Pressable
                            style={({ pressed }) => [nav.reserveBtn, pressed && { opacity: 0.8 }]}
                            onPress={() => Linking.openURL(
                              `https://campspot.com/search?q=${encodeURIComponent(camp.name)}`
                            )}
                          >
                            <MaterialIcons name="open-in-new" size={13} color="#000" />
                            <Text style={nav.reserveBtnText}>Reserve on Campspot</Text>
                          </Pressable>
                        </View>
                      ))}
                    </View>
                  )}
                </View>
              )}

              {!loadingProfile && !hasProfile && (
                <View style={nav.noProfileCard}>
                  <MaterialIcons name="person-add" size={20} color={Colors.gold} />
                  <View style={{ flex: 1 }}>
                    <Text style={nav.noProfileTitle}>Set Your RV Profile</Text>
                    <Text style={nav.noProfileSub}>
                      Add your RV height, length, weight and propane status in the More tab to unlock bridge, tunnel, and weight restriction warnings on every route.
                    </Text>
                  </View>
                </View>
              )}
            </View>
          </ScrollView>
        </View>
      )}

      {/* ══════════════════════════════════════════════════════════════════ */}
      {/*  DIRECTIONS TAB                                                    */}
      {/* ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'directions' && (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
          <View style={{ paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, gap: Spacing.md }}>
            {(routeResult?.warnings.length ?? 0) > 0 && (
              <View>
                <View style={nav.warnHeader}>
                  <MaterialIcons name="warning" size={15} color={Colors.orange} />
                  <Text style={nav.warnHeaderText}>RV RESTRICTIONS FOR THIS ROUTE</Text>
                  <View style={nav.warnCount}><Text style={nav.warnCountText}>{routeResult!.warnings.length}</Text></View>
                </View>
                {routeResult!.warnings.map((w, i) => <WarningCard key={i} w={w} />)}
              </View>
            )}
            {routeResult && routeResult.warnings.length === 0 && (
              <View style={nav.noWarnCard}>
                <MaterialIcons name="check-circle" size={20} color={Colors.green} />
                <View style={{ flex: 1 }}>
                  <Text style={nav.noWarnTitle}>No RV Restrictions Detected</Text>
                  <Text style={nav.noWarnSub}>Based on your RV profile, this route has no flagged bridge, tunnel, weight, or propane restrictions. Always verify locally.</Text>
                </View>
              </View>
            )}
            {routeResult && routeResult.steps.length > 0 ? (
              <View>
                <View style={nav.warnHeader}>
                  <MaterialIcons name="turn-right" size={15} color={Colors.blueBright} />
                  <Text style={[nav.warnHeaderText, { color: Colors.blueBright }]}>TURN-BY-TURN DIRECTIONS</Text>
                  <Text style={{ fontSize: FontSize.xs, color: Colors.textMuted, marginLeft: 'auto' }}>
                    {routeResult.distanceMi.toLocaleString()} mi · {fmtDuration(routeResult.durationMin)}
                  </Text>
                </View>
                <View style={{ backgroundColor: '#080F18', borderRadius: Radius.xl, borderWidth: 1, borderColor: 'rgba(77,166,255,0.2)', overflow: 'hidden' }}>
                  {routeResult.steps.map((step, i) => (
                    <StepCard key={i} step={step} index={i} isNext={navigating && i === nextStepIdx} />
                  ))}
                </View>
                {routeResult.source === 'fallback' && (
                  <View style={nav.fallbackNote}>
                    <MaterialIcons name="info-outline" size={13} color={Colors.textMuted} />
                    <Text style={nav.fallbackNoteText}>
                      Could not reach the routing server. Showing a straight-line estimate — connect to a network for real turn-by-turn directions.
                    </Text>
                  </View>
                )}
              </View>
            ) : (
              <View style={nav.emptyState}>
                <FontAwesome5 name="route" size={40} color={Colors.textDim} />
                <Text style={nav.emptyTitle}>No Route Yet</Text>
                <Text style={nav.emptySub}>Go to the Navigate tab, set a destination, and tap "Calculate RV Route" to see turn-by-turn directions here.</Text>
              </View>
            )}
          </View>
        </ScrollView>
      )}

      {/* ══════════════════════════════════════════════════════════════════ */}
      {/*  CAMPGROUNDS TAB                                                   */}
      {/* ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'camps' && (
        <CampsTab insetBottom={insets.bottom} onNavigateTo={handleCampNavigate} />
      )}

      {/* ══════════════════════════════════════════════════════════════════ */}
      {/*  PACK LIST TAB                                                     */}
      {/* ══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'pack' && <PackingTab insetBottom={insets.bottom} />}

      <DestModal
        visible={destModalOpen}
        onClose={() => setDestModalOpen(false)}
        onSelect={(label, coords) => {
          setDestLabel(label);
          setDestCoords(coords);
          setRouteResult(null);
          setRouteCamps([]);
        }}
      />
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const root = StyleSheet.create({
  container:        { flex: 1, backgroundColor: '#1A2A3A' },
  heroBackdrop:     { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0 },
  header:           { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, paddingBottom: Spacing.sm, zIndex: 2 },
  headerLeft:       { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  iconWrap:         { width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(74,155,212,0.18)', borderWidth: 1.5, borderColor: 'rgba(74,155,212,0.55)', alignItems: 'center', justifyContent: 'center' },
  title:            { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: '#FFFFFF' },
  subtitle:         { fontSize: 10, color: 'rgba(255,255,255,0.60)', fontWeight: FontWeight.semibold, letterSpacing: 0.5, marginTop: 1 },
  noProfileBadge:   { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(255,140,0,0.08)', borderWidth: 1, borderColor: 'rgba(255,140,0,0.3)', borderRadius: Radius.full, paddingHorizontal: 9, paddingVertical: 5 },
  noProfileText:    { fontSize: 10, color: Colors.orange, fontWeight: FontWeight.semibold },
  profileBadge:     { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(74,155,212,0.12)', borderWidth: 1, borderColor: 'rgba(74,155,212,0.45)', borderRadius: Radius.full, paddingHorizontal: 9, paddingVertical: 5 },
  profileBadgeText: { fontSize: 10, color: '#4A9BD4', fontWeight: FontWeight.extrabold, letterSpacing: 0.8 },
  tabBar:           { flexDirection: 'row', marginHorizontal: Spacing.md, marginBottom: Spacing.sm, backgroundColor: 'rgba(4,8,22,0.82)', borderRadius: Radius.lg, borderWidth: 1.5, borderColor: 'rgba(74,155,212,0.55)', padding: 3, zIndex: 2 },
  tabBtn:           { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 9, borderRadius: Radius.md },
  tabBtnActive:     { backgroundColor: '#4A9BD4' },
  tabText:          { fontSize: 10, fontWeight: FontWeight.semibold, color: 'rgba(255,255,255,0.50)' },
  tabTextActive:    { color: '#fff' },
  warningDot:       { width: 14, height: 14, borderRadius: 7, backgroundColor: Colors.orange, alignItems: 'center', justifyContent: 'center' },
  warningDotText:   { fontSize: 8, fontWeight: FontWeight.extrabold, color: '#000' },
});

const map = StyleSheet.create({
  container:       { borderRadius: Radius.xl, overflow: 'hidden', borderWidth: 1.5, borderColor: 'rgba(74,155,212,0.50)', marginBottom: Spacing.sm, shadowColor: '#4A9BD4', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 16, elevation: 8, zIndex: 2 },
  originMarker:    { width: 22, height: 22, borderRadius: 11, backgroundColor: 'rgba(0,104,192,0.25)', borderWidth: 1.5, borderColor: Colors.blueBright, alignItems: 'center', justifyContent: 'center' },
  originDot:       { width: 8, height: 8, borderRadius: 4, backgroundColor: '#4A9BD4', shadowColor: '#4A9BD4', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 6 },
  destWrap:        { alignItems: 'center' },
  destPin:         { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,215,0,0.2)', borderWidth: 2, borderColor: Colors.gold, alignItems: 'center', justifyContent: 'center', shadowColor: Colors.gold, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.8, shadowRadius: 8, elevation: 6 },
  destLabel:       { backgroundColor: 'rgba(0,0,0,0.85)', borderRadius: Radius.sm, borderWidth: 1, borderColor: 'rgba(255,215,0,0.5)', paddingHorizontal: 6, paddingVertical: 2, marginTop: 2 },
  destLabelText:   { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.gold },
  rvMarker:        { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(77,166,255,0.2)', borderWidth: 2, borderColor: Colors.blueBright, alignItems: 'center', justifyContent: 'center', shadowColor: Colors.blueBright, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.9, shadowRadius: 10, elevation: 8 },
  speedHUD:        { position: 'absolute', bottom: 12, left: 12, backgroundColor: 'rgba(0,0,0,0.85)', borderRadius: Radius.lg, borderWidth: 1.5, borderColor: Colors.blueBright, paddingHorizontal: 14, paddingVertical: 8, alignItems: 'center' },
  speedVal:        { fontSize: 28, fontWeight: FontWeight.extrabold, color: Colors.blueBright },
  speedUnit:       { fontSize: 10, color: Colors.textMuted, fontWeight: FontWeight.bold },
  nextTurnHUD:     { position: 'absolute', top: 12, left: 12, right: 12, flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: 'rgba(10,20,30,0.92)', borderRadius: Radius.xl, borderWidth: 2, borderColor: '#4A9BD4', paddingHorizontal: Spacing.md, paddingVertical: 12, shadowColor: '#4A9BD4', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.5, shadowRadius: 16, elevation: 10 },
  nextTurnInstr:   { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  nextTurnDist:    { fontSize: FontSize.sm, color: '#4A9BD4', fontWeight: FontWeight.semibold, marginTop: 2 },
  routeOverlay:    { position: 'absolute', top: 12, left: 12, right: 12, flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(10,20,30,0.85)', borderRadius: Radius.lg, borderWidth: 1, borderColor: 'rgba(74,155,212,0.40)', paddingHorizontal: Spacing.sm, paddingVertical: 10 },
  routeStat:       { flex: 1, alignItems: 'center', gap: 2, flexDirection: 'row', justifyContent: 'center' },
  routeStatVal:    { fontSize: FontSize.base, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  routeStatLbl:    { fontSize: 10, color: Colors.textMuted, fontWeight: FontWeight.medium, marginLeft: 3 },
  routeStatDiv:    { width: 1, height: 22, backgroundColor: 'rgba(255,255,255,0.08)' },
  sourceBadge:     { position: 'absolute', bottom: 10, right: 10, backgroundColor: 'rgba(0,0,0,0.85)', borderRadius: Radius.sm, borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', paddingHorizontal: 7, paddingVertical: 3 },
  sourceBadgeReal: { borderColor: 'rgba(74,155,212,0.40)' },
  sourceBadgeHere: { borderColor: '#4A9BD4', backgroundColor: 'rgba(74,155,212,0.10)' },
  sourceBadgeText: { fontSize: 9, color: Colors.textMuted, fontWeight: FontWeight.semibold, letterSpacing: 0.5 },
  voiceBtn:        { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(74,155,212,0.12)', borderWidth: 1.5, borderColor: 'rgba(74,155,212,0.4)', alignItems: 'center', justifyContent: 'center' },
  voiceBtnMuted:   { backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(255,255,255,0.1)' },
  speedLimitSign:  { marginTop: 5, alignItems: 'center', backgroundColor: '#FFFFFF', borderRadius: 4, borderWidth: 2, borderColor: '#000', paddingHorizontal: 5, paddingVertical: 2, minWidth: 38 },
  speedLimitLabel: { fontSize: 7, fontWeight: '900', color: '#000', textAlign: 'center', letterSpacing: 0.3 },
  speedLimitNum:   { fontSize: 15, fontWeight: '900', color: '#000', textAlign: 'center', lineHeight: 17 },
});

const nav = StyleSheet.create({
  liveAlertBar:  { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(255,140,0,0.1)', borderWidth: 1, borderColor: 'rgba(255,140,0,0.4)', borderRadius: Radius.lg, paddingHorizontal: Spacing.sm, paddingVertical: 8, marginBottom: 4 },
  liveAlertText: { fontSize: 12, color: Colors.orange, fontWeight: FontWeight.semibold, flexShrink: 0 },
  destPicker:            { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: 'rgba(4,10,28,0.85)', borderWidth: 2, borderColor: 'rgba(74,155,212,0.70)', borderRadius: Radius.xl, paddingHorizontal: Spacing.md, paddingVertical: 14, shadowColor: '#4A9BD4', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.25, shadowRadius: 12, elevation: 4 },
  destIconWrap:          { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(74,155,212,0.12)', borderWidth: 1.5, borderColor: 'rgba(74,155,212,0.45)', alignItems: 'center', justifyContent: 'center' },
  destPickerLabel:       { fontSize: FontSize.xs, fontWeight: FontWeight.extrabold, color: '#4A9BD4', letterSpacing: 1.2, marginBottom: 3 },
  destPickerValue:       { fontSize: FontSize.lg, fontWeight: FontWeight.semibold, color: '#FFFFFF' },
  destPickerPlaceholder: { color: Colors.textMuted, fontSize: FontSize.base, fontWeight: FontWeight.regular },
  errorCard:             { flexDirection: 'row', alignItems: 'flex-start', gap: 8, backgroundColor: 'rgba(255,68,68,0.08)', borderWidth: 1, borderColor: 'rgba(255,68,68,0.35)', borderRadius: Radius.lg, padding: Spacing.md },
  errorText:             { flex: 1, fontSize: FontSize.sm, color: Colors.red, lineHeight: 20 },
  warnHeader:            { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: Spacing.sm },
  warnHeaderText:        { fontSize: FontSize.xs, fontWeight: FontWeight.extrabold, color: Colors.orange, letterSpacing: 1 },
  warnCount:             { width: 20, height: 20, borderRadius: 10, backgroundColor: Colors.orange, alignItems: 'center', justifyContent: 'center' },
  warnCountText:         { fontSize: 10, fontWeight: FontWeight.extrabold, color: '#000' },
  noWarnCard:            { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, backgroundColor: 'rgba(0,104,192,0.06)', borderWidth: 1.5, borderColor: Colors.borderBlue, borderRadius: Radius.xl, padding: Spacing.md },
  noWarnTitle:           { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.blueBright, marginBottom: 4 },
  noWarnSub:             { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 18 },
  statsRow:              { flexDirection: 'row', gap: Spacing.sm },
  statCard:              { flex: 1, backgroundColor: '#080E18', borderRadius: Radius.lg, borderWidth: 1, borderColor: 'rgba(77,166,255,0.2)', padding: Spacing.sm, alignItems: 'center', gap: 4 },
  statVal:               { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, textAlign: 'center' },
  statLbl:               { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },
  actionRow:             { gap: Spacing.sm },
  calcBtn:               { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: 'rgba(74,155,212,0.10)', borderWidth: 2, borderColor: 'rgba(74,155,212,0.45)', borderRadius: Radius.full, paddingVertical: 15 },
  calcBtnDisabled:       { opacity: 0.5 },
  calcBtnPressed:        { borderColor: '#4A9BD4', backgroundColor: 'rgba(74,155,212,0.18)' },
  calcBtnText:           { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: '#4A9BD4' },
  startBtn:              { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#4A9BD4', borderRadius: Radius.full, paddingVertical: 16, shadowColor: '#4A9BD4', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.6, shadowRadius: 14, elevation: 8 },
  startBtnPressed:       { transform: [{ scale: 0.98 }], shadowOpacity: 0.9 },
  startBtnText:          { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#000' },
  stopBtn:               { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: Colors.red, borderRadius: Radius.full, paddingVertical: 15, shadowColor: Colors.red, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.5, shadowRadius: 12, elevation: 6 },
  stopBtnText:           { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#fff' },
  routeCampsSection:     { backgroundColor: 'rgba(74,155,212,0.05)', borderRadius: Radius.xl, borderWidth: 1.5, borderColor: 'rgba(74,155,212,0.35)', padding: Spacing.md, gap: Spacing.sm },
  routeCampsHeader:      { flexDirection: 'row', alignItems: 'center', gap: 6 },
  routeCampsTitle:       { fontSize: FontSize.xs, fontWeight: FontWeight.extrabold, color: '#4A9BD4', letterSpacing: 1.1, flex: 1 },
  routeCampsCount:       { width: 18, height: 18, borderRadius: 9, backgroundColor: '#4A9BD4', alignItems: 'center', justifyContent: 'center' },
  routeCampsCountText:   { fontSize: 9, fontWeight: FontWeight.extrabold, color: '#000' },
  routeCampsSource:      { fontSize: 10, color: Colors.textMuted, fontStyle: 'italic' },
  routeCampsLoading:     { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: Spacing.sm },
  routeCampsLoadingText: { fontSize: FontSize.sm, color: Colors.textMuted },
  routeCampCard:         { backgroundColor: 'rgba(4,10,28,0.82)', borderRadius: Radius.lg, borderWidth: 1, borderColor: 'rgba(74,155,212,0.50)', padding: Spacing.sm, gap: 8 },
  routeCampCardLeft:     { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  routeCampIconWrap:     { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(74,155,212,0.10)', borderWidth: 1, borderColor: 'rgba(74,155,212,0.35)', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  routeCampName:         { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary, flex: 1 },
  routeCampDist:         { fontSize: 10, color: '#4A9BD4', fontWeight: FontWeight.semibold },
  routeCampAmenity:      { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: 'rgba(188,185,186,0.08)', borderRadius: Radius.sm, paddingHorizontal: 5, paddingVertical: 2 },
  routeCampAmenityText:  { fontSize: 9, color: Colors.silver, fontWeight: FontWeight.semibold },
  reserveBtn:            { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: '#4A9BD4', borderRadius: Radius.lg, paddingVertical: 10 },
  reserveBtnText:        { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: '#000' },
  noProfileCard:         { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, backgroundColor: 'rgba(4,10,28,0.82)', borderWidth: 1.5, borderColor: Colors.borderSilver, borderRadius: Radius.xl, padding: Spacing.md },
  noProfileTitle:        { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.silverBright, marginBottom: 4 },
  noProfileSub:          { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 18 },
  fallbackNote:          { flexDirection: 'row', alignItems: 'flex-start', gap: 6, backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: Radius.md, padding: Spacing.sm, marginTop: Spacing.sm },
  fallbackNoteText:      { flex: 1, fontSize: 11, color: Colors.textMuted, lineHeight: 16 },
  emptyState:            { alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.xxl, paddingHorizontal: Spacing.md },
  emptyTitle:            { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#FFFFFF' },
  emptySub:              { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', lineHeight: 20, maxWidth: 300 },
});
