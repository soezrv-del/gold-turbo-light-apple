import {
  View, Text, StyleSheet, TextInput, Pressable, ScrollView, Platform, Modal,
} from 'react-native';
import { useState, useMemo, useCallback } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';

// ─── TRUCK DATABASE (with trim-level tow ratings) ──────────────────────────

interface TrimSpec {
  trim: string;
  maxTow: number;
  maxPayload: number;
  gcwr: number;
  curb: number;
  engine: string;
  hitch: string;
  notes?: string;
}

interface TruckModel {
  trims: TrimSpec[];
}

const TRUCK_DB: Record<string, Record<string, Record<string, TruckModel>>> = {
  '2025': {
    ford: {
      'F-150': {
        trims: [
          { trim: 'XL / XLT — 2.7L EcoBoost (base)', maxTow: 8200, maxPayload: 1900, gcwr: 14400, curb: 4720, engine: '2.7L EcoBoost V6', hitch: 'Class IV' },
          { trim: 'XL / XLT — 3.5L EcoBoost', maxTow: 11300, maxPayload: 2120, gcwr: 17700, curb: 4820, engine: '3.5L EcoBoost V6', hitch: 'Class IV' },
          { trim: 'Lariat / King Ranch — 3.5L EcoBoost', maxTow: 12100, maxPayload: 2200, gcwr: 19000, curb: 4920, engine: '3.5L EcoBoost V6', hitch: 'Class IV' },
          { trim: 'Platinum / Limited — 3.5L EcoBoost Max Tow', maxTow: 13000, maxPayload: 2455, gcwr: 20000, curb: 4960, engine: '3.5L EcoBoost V6 (Max Tow Pkg)', hitch: 'Class IV', notes: 'Requires Max Tow Package' },
          { trim: 'Lightning EV Standard Range', maxTow: 7700, maxPayload: 1800, gcwr: 14400, curb: 6015, engine: 'Dual Motor Electric', hitch: 'Class III' },
          { trim: 'Lightning EV Extended Range', maxTow: 10000, maxPayload: 2235, gcwr: 18400, curb: 6270, engine: 'Dual Motor Electric (Ext.)', hitch: 'Class IV' },
        ],
      },
      'F-250 Super Duty': {
        trims: [
          { trim: 'XL / XLT — 6.2L V8 Gas', maxTow: 15000, maxPayload: 3540, gcwr: 24200, curb: 7260, engine: '6.2L V8 Gas', hitch: 'Class V' },
          { trim: 'XL / XLT — 6.7L Power Stroke Diesel', maxTow: 20000, maxPayload: 4260, gcwr: 33000, curb: 7570, engine: '6.7L Power Stroke Diesel', hitch: 'Class V' },
          { trim: 'Platinum / Tremor — 6.7L Power Stroke Diesel', maxTow: 20000, maxPayload: 3930, gcwr: 33000, curb: 7770, engine: '6.7L Power Stroke Diesel', hitch: 'Class V' },
        ],
      },
      'F-350 Super Duty': {
        trims: [
          { trim: 'XL / XLT — 6.7L Diesel (SRW)', maxTow: 32500, maxPayload: 5690, gcwr: 43500, curb: 8510, engine: '6.7L Power Stroke Diesel', hitch: 'Class V' },
          { trim: 'XL / XLT — 6.7L Diesel (DRW)', maxTow: 40000, maxPayload: 7850, gcwr: 52000, curb: 8920, engine: '6.7L Power Stroke Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel — max conventional tow' },
        ],
      },
      'Expedition': {
        trims: [
          { trim: 'XL / XLT — 3.5L EcoBoost V6', maxTow: 9300, maxPayload: 1630, gcwr: 15500, curb: 5639, engine: '3.5L EcoBoost V6 (375 HP)', hitch: 'Class IV', notes: 'Requires Max Trailer Tow Package' },
          { trim: 'Expedition MAX — 3.5L EcoBoost V6 (Long WB)', maxTow: 9300, maxPayload: 1750, gcwr: 15500, curb: 5803, engine: '3.5L EcoBoost V6', hitch: 'Class IV', notes: 'Longer wheelbase; same 9,300 lb tow rating' },
        ],
      },
      'Ranger': { trims: [{ trim: 'XL / XLT — 2.3L EcoBoost', maxTow: 7500, maxPayload: 1625, gcwr: 13000, curb: 4520, engine: '2.3L EcoBoost I4', hitch: 'Class III' }] },
    },
    ram: {
      '1500': {
        trims: [
          { trim: 'Big Horn / Laramie — 5.7L HEMI V8', maxTow: 10640, maxPayload: 2110, gcwr: 17500, curb: 5110, engine: '5.7L HEMI V8', hitch: 'Class IV' },
          { trim: 'Limited — 5.7L HEMI Max Tow', maxTow: 12750, maxPayload: 2300, gcwr: 19500, curb: 5310, engine: '5.7L HEMI V8 (Max Tow)', hitch: 'Class IV', notes: 'Requires Max Tow Package' },
          { trim: '3.0L EcoDiesel V6', maxTow: 12560, maxPayload: 2030, gcwr: 19300, curb: 5360, engine: '3.0L EcoDiesel V6', hitch: 'Class IV' },
        ],
      },
      '2500': { trims: [{ trim: 'Tradesman — 6.7L Cummins Diesel', maxTow: 20000, maxPayload: 3990, gcwr: 30000, curb: 7350, engine: '6.7L Cummins HO Diesel I6', hitch: 'Class V' }] },
      '3500': { trims: [{ trim: 'Tradesman — 6.7L Cummins Diesel (DRW)', maxTow: 37100, maxPayload: 7680, gcwr: 49000, curb: 8010, engine: '6.7L Cummins HO Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel — max conventional rating' }] },
      'Durango': {
        trims: [
          { trim: 'SXT / GT — 3.6L Pentastar V6', maxTow: 6200, maxPayload: 1400, gcwr: 11800, curb: 4820, engine: '3.6L Pentastar V6 (293 HP)', hitch: 'Class III' },
          { trim: 'Citadel / R/T — 5.7L HEMI V8', maxTow: 8700, maxPayload: 1550, gcwr: 15200, curb: 5030, engine: '5.7L HEMI V8 (360 HP)', hitch: 'Class IV', notes: 'Requires Trailer Tow Group IV' },
        ],
      },
    },
    chevrolet: {
      'Silverado 1500': {
        trims: [
          { trim: 'Work Truck / Custom — 2.7L Turbo', maxTow: 7200, maxPayload: 1870, gcwr: 13600, curb: 4530, engine: '2.7L Turbo I4', hitch: 'Class III' },
          { trim: 'LT / RST — 5.3L V8', maxTow: 9300, maxPayload: 1980, gcwr: 16500, curb: 4710, engine: '5.3L EcoTec3 V8', hitch: 'Class IV' },
          { trim: 'High Country — 6.2L V8 Max Trailering', maxTow: 13300, maxPayload: 2280, gcwr: 20800, curb: 4810, engine: '6.2L EcoTec3 V8 (Max Trailering)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
        ],
      },
      'Silverado 2500HD': { trims: [{ trim: 'Work Truck — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3979, gcwr: 28000, curb: 7210, engine: '6.6L Duramax Diesel', hitch: 'Class V' }] },
      'Silverado 3500HD': { trims: [{ trim: 'Work Truck — 6.6L Duramax (DRW)', maxTow: 36000, maxPayload: 7442, gcwr: 46500, curb: 8510, engine: '6.6L Duramax Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel — max conventional rating' }] },
      'Suburban': {
        trims: [
          { trim: 'LS / LT — 5.3L EcoTec3 V8', maxTow: 8300, maxPayload: 1600, gcwr: 15200, curb: 5866, engine: '5.3L EcoTec3 V8 (355 HP)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
          { trim: 'High Country — 6.2L V8', maxTow: 8300, maxPayload: 1450, gcwr: 15200, curb: 6100, engine: '6.2L EcoTec3 V8 (420 HP)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
        ],
      },
    },
    gmc: {
      'Sierra 1500': {
        trims: [
          { trim: 'SLE / Elevation — 5.3L V8', maxTow: 10800, maxPayload: 2100, gcwr: 18000, curb: 4760, engine: '5.3L EcoTec3 V8', hitch: 'Class IV' },
          { trim: 'Denali / AT4X — 6.2L V8 Max Trailering', maxTow: 13200, maxPayload: 2240, gcwr: 20400, curb: 4910, engine: '6.2L EcoTec3 V8 (Max Trailering)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
        ],
      },
      'Sierra 2500HD': { trims: [{ trim: 'SLE / AT4 — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3879, gcwr: 28000, curb: 7260, engine: '6.6L Duramax Diesel', hitch: 'Class V' }] },
      'Sierra 3500HD': { trims: [{ trim: 'Denali — 6.6L Duramax (DRW)', maxTow: 36000, maxPayload: 7150, gcwr: 46500, curb: 8660, engine: '6.6L Duramax Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel — max conventional rating' }] },
      'Yukon XL': {
        trims: [
          { trim: 'SLE / SLT — 5.3L EcoTec3 V8', maxTow: 8500, maxPayload: 1630, gcwr: 15700, curb: 5836, engine: '5.3L EcoTec3 V8 (355 HP)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
          { trim: 'Denali Ultimate — 6.2L V8', maxTow: 8500, maxPayload: 1480, gcwr: 15700, curb: 6060, engine: '6.2L EcoTec3 V8 (420 HP)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
        ],
      },
    },
    toyota: {
      'Tundra': {
        trims: [
          { trim: 'SR5 — 3.4L Twin-Turbo V6', maxTow: 8000, maxPayload: 1940, gcwr: 15600, curb: 5540, engine: '3.4L Twin-Turbo V6 (389 HP)', hitch: 'Class IV' },
          { trim: 'Platinum Hybrid — 3.4L TT-V6 Hybrid', maxTow: 12000, maxPayload: 1640, gcwr: 18600, curb: 6070, engine: '3.4L TT-V6 Hybrid (437 HP)', hitch: 'Class IV', notes: 'Requires Tow Technology Package' },
        ],
      },
      'Sequoia': { trims: [{ trim: 'SR5 / Limited — 3.4L TT-V6 Hybrid', maxTow: 9000, maxPayload: 1620, gcwr: 16200, curb: 5990, engine: '3.4L TT-V6 Hybrid (437 HP)', hitch: 'Class IV' }] },
      '4Runner': {
        trims: [
          { trim: 'SR5 / TRD Sport — 2.4L Turbo I4 (all-new)', maxTow: 6000, maxPayload: 1350, gcwr: 11500, curb: 4715, engine: '2.4L Turbo I4 (278 HP)', hitch: 'Class III', notes: 'All-new 2025 4Runner' },
          { trim: 'TRD Pro — 2.4L Turbo Hybrid', maxTow: 5000, maxPayload: 1050, gcwr: 11000, curb: 5100, engine: '2.4L Turbo Hybrid I4 (326 HP)', hitch: 'Class III' },
        ],
      },
      'Tacoma': { trims: [{ trim: 'SR / SR5 — 2.4L Turbo I4', maxTow: 6500, maxPayload: 1440, gcwr: 11000, curb: 4490, engine: '2.4L Turbo I4 (278 HP)', hitch: 'Class III' }] },
    },
    nissan: {
      'Titan': { trims: [{ trim: 'PRO-4X / Platinum (w/ Tow Pkg)', maxTow: 11040, maxPayload: 1810, gcwr: 18500, curb: 5790, engine: '5.6L Endurance V8 (Tow Pkg)', hitch: 'Class IV', notes: 'Requires Tow Package' }] },
    },
    jeep: {
      'Gladiator': {
        trims: [
          { trim: 'Sport / Overland — 3.6L V6', maxTow: 7650, maxPayload: 1650, gcwr: 13500, curb: 4660, engine: '3.6L Pentastar V6', hitch: 'Class III' },
          { trim: 'Rubicon — 3.6L V6', maxTow: 7000, maxPayload: 1450, gcwr: 13000, curb: 4860, engine: '3.6L Pentastar V6', hitch: 'Class III', notes: 'Off-road hardware reduces tow rating' },
        ],
      },
      'Wagoneer': { trims: [{ trim: 'Series II / III — 3.0L Hurricane TT I6', maxTow: 10000, maxPayload: 1600, gcwr: 17500, curb: 5750, engine: '3.0L Hurricane I6 TT (420 HP)', hitch: 'Class IV', notes: 'Requires Trailer Tow Group IV Package' }] },
    },
  },
  '2024': {
    ford: {
      'F-150': {
        trims: [
          { trim: 'XL / XLT — 2.7L EcoBoost (base)', maxTow: 8200, maxPayload: 1880, gcwr: 14400, curb: 4705, engine: '2.7L EcoBoost V6', hitch: 'Class IV' },
          { trim: 'XL / XLT — 3.5L EcoBoost', maxTow: 11100, maxPayload: 2100, gcwr: 17600, curb: 4800, engine: '3.5L EcoBoost V6', hitch: 'Class IV' },
          { trim: 'Lariat / King Ranch — 3.5L EcoBoost', maxTow: 12000, maxPayload: 2200, gcwr: 19000, curb: 4900, engine: '3.5L EcoBoost V6', hitch: 'Class IV' },
          { trim: 'Platinum / Limited — 3.5L EcoBoost Max Tow', maxTow: 13000, maxPayload: 2455, gcwr: 20000, curb: 4950, engine: '3.5L EcoBoost V6 (Max Tow Pkg)', hitch: 'Class IV', notes: 'Requires Max Tow Package' },
          { trim: 'Raptor — 3.5L EcoBoost High Output', maxTow: 8200, maxPayload: 1400, gcwr: 14600, curb: 5697, engine: '3.5L EcoBoost V6 HO', hitch: 'Class III', notes: 'Off-road suspension limits tow rating' },
          { trim: 'Lightning EV (Standard Range)', maxTow: 7700, maxPayload: 1800, gcwr: 14400, curb: 6015, engine: 'Dual Motor Electric', hitch: 'Class III' },
          { trim: 'Lightning EV (Extended Range)', maxTow: 10000, maxPayload: 2235, gcwr: 18400, curb: 6270, engine: 'Dual Motor Electric (Ext.)', hitch: 'Class IV' },
        ],
      },
      'F-250 Super Duty': {
        trims: [
          { trim: 'XL / XLT — 6.2L V8 Gas', maxTow: 15000, maxPayload: 3540, gcwr: 24200, curb: 7250, engine: '6.2L V8 Gas', hitch: 'Class V' },
          { trim: 'XL / XLT — 6.7L Power Stroke Diesel', maxTow: 20000, maxPayload: 4260, gcwr: 33000, curb: 7550, engine: '6.7L Power Stroke V8 Diesel', hitch: 'Class V' },
          { trim: 'Platinum / Tremor — 6.7L Power Stroke Diesel', maxTow: 20000, maxPayload: 3930, gcwr: 33000, curb: 7750, engine: '6.7L Power Stroke V8 Diesel', hitch: 'Class V' },
        ],
      },
      'F-350 Super Duty': {
        trims: [
          { trim: 'XL / XLT — 6.7L Diesel (SRW)', maxTow: 32500, maxPayload: 5690, gcwr: 43500, curb: 8500, engine: '6.7L Power Stroke Diesel', hitch: 'Class V' },
          { trim: 'XL / XLT — 6.7L Diesel (DRW)', maxTow: 40000, maxPayload: 7850, gcwr: 52000, curb: 8900, engine: '6.7L Power Stroke Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel — max conventional tow' },
        ],
      },
      'Ranger': { trims: [{ trim: 'XL / XLT — 2.3L EcoBoost', maxTow: 7500, maxPayload: 1625, gcwr: 13000, curb: 4508, engine: '2.3L EcoBoost I4', hitch: 'Class III' }] },
      'Maverick': {
        trims: [
          { trim: 'XL / XLT — 2.5L Hybrid', maxTow: 2000, maxPayload: 1500, gcwr: 7200, curb: 3674, engine: '2.5L FHEV Hybrid', hitch: 'Class II' },
          { trim: 'Lariat / Tremor — 2.0L EcoBoost', maxTow: 4000, maxPayload: 1500, gcwr: 9000, curb: 3756, engine: '2.0L EcoBoost I4', hitch: 'Class III' },
        ],
      },
    },
    ram: {
      '1500': {
        trims: [
          { trim: 'Tradesman / Big Horn — 3.6L Pentastar V6', maxTow: 7630, maxPayload: 1800, gcwr: 13900, curb: 4933, engine: '3.6L Pentastar V6', hitch: 'Class IV' },
          { trim: 'Big Horn / Laramie — 5.7L HEMI V8', maxTow: 10640, maxPayload: 2110, gcwr: 17500, curb: 5100, engine: '5.7L HEMI V8', hitch: 'Class IV' },
          { trim: 'Limited / TRX — 5.7L HEMI Max Tow', maxTow: 12750, maxPayload: 2300, gcwr: 19500, curb: 5300, engine: '5.7L HEMI V8 (Max Tow Pkg)', hitch: 'Class IV', notes: 'Requires Max Tow Package' },
          { trim: '1500 eTorque Hybrid — 3.0L EcoDiesel', maxTow: 12560, maxPayload: 2030, gcwr: 19300, curb: 5350, engine: '3.0L EcoDiesel V6', hitch: 'Class IV' },
        ],
      },
      '2500': {
        trims: [
          { trim: 'Tradesman / Big Horn — 6.4L HEMI Gas', maxTow: 16320, maxPayload: 3510, gcwr: 26000, curb: 7200, engine: '6.4L HEMI V8 Gas', hitch: 'Class V' },
          { trim: 'Tradesman — 6.7L Cummins Diesel', maxTow: 20000, maxPayload: 3990, gcwr: 30000, curb: 7340, engine: '6.7L Cummins HO Turbo Diesel I6', hitch: 'Class V' },
          { trim: 'Laramie / Longhorn — 6.7L Cummins Diesel', maxTow: 20000, maxPayload: 3760, gcwr: 30000, curb: 7500, engine: '6.7L Cummins HO Turbo Diesel I6', hitch: 'Class V' },
        ],
      },
      '3500': {
        trims: [
          { trim: 'Tradesman — 6.7L Cummins Diesel (SRW)', maxTow: 31210, maxPayload: 5460, gcwr: 41000, curb: 7950, engine: '6.7L Cummins HO Diesel (SRW)', hitch: 'Class V' },
          { trim: 'Tradesman — 6.7L Cummins Diesel (DRW)', maxTow: 37100, maxPayload: 7680, gcwr: 49000, curb: 8000, engine: '6.7L Cummins HO Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel — maximum conventional rating' },
        ],
      },
    },
    chevrolet: {
      'Silverado 1500': {
        trims: [
          { trim: 'Work Truck / Custom — 2.7L Turbo (4-cyl)', maxTow: 7200, maxPayload: 1870, gcwr: 13600, curb: 4520, engine: '2.7L Turbo I4', hitch: 'Class III' },
          { trim: 'LT / RST — 5.3L V8 (no trailering pkg)', maxTow: 9300, maxPayload: 1980, gcwr: 16500, curb: 4700, engine: '5.3L EcoTec3 V8', hitch: 'Class IV' },
          { trim: 'High Country / ZR2 — 6.2L V8 Max Tow', maxTow: 13300, maxPayload: 2280, gcwr: 20800, curb: 4800, engine: '6.2L EcoTec3 V8 (Max Trailering Pkg)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
        ],
      },
      'Silverado 2500HD': {
        trims: [
          { trim: 'Work Truck — 6.6L V8 Gas', maxTow: 14500, maxPayload: 3534, gcwr: 24000, curb: 6950, engine: '6.6L V8 Gas', hitch: 'Class V' },
          { trim: 'Work Truck — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3979, gcwr: 28000, curb: 7200, engine: '6.6L Duramax V8 Diesel', hitch: 'Class V' },
        ],
      },
      'Silverado 3500HD': {
        trims: [
          { trim: 'Work Truck — 6.6L Duramax Diesel (SRW)', maxTow: 27500, maxPayload: 5673, gcwr: 37500, curb: 8100, engine: '6.6L Duramax V8 Diesel (SRW)', hitch: 'Class V' },
          { trim: 'Work Truck — 6.6L Duramax Diesel (DRW)', maxTow: 36000, maxPayload: 7442, gcwr: 46500, curb: 8500, engine: '6.6L Duramax V8 Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel — max conventional rating' },
        ],
      },
      'Colorado': {
        trims: [
          { trim: 'Work Truck / LT — 2.7L Turbo L4 (base)', maxTow: 7700, maxPayload: 1640, gcwr: 13000, curb: 4540, engine: '2.7L Turbo I4 (237 HP)', hitch: 'Class III' },
          { trim: 'ZR2 / Bison — 2.7L Turbo High Output', maxTow: 7700, maxPayload: 1400, gcwr: 13000, curb: 5000, engine: '2.7L Turbo HO I4 (430 HP)', hitch: 'Class III', notes: 'Lifted suspension limits tow stability' },
        ],
      },
      'Suburban': {
        trims: [
          { trim: 'LS / LT — 5.3L EcoTec3 V8', maxTow: 8300, maxPayload: 1600, gcwr: 15200, curb: 5857, engine: '5.3L EcoTec3 V8 (355 HP)', hitch: 'Class IV', notes: 'Requires Max Trailering Package for 8,300 lb rating' },
          { trim: 'High Country — 6.2L V8', maxTow: 8300, maxPayload: 1450, gcwr: 15200, curb: 6090, engine: '6.2L EcoTec3 V8 (420 HP)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
        ],
      },
    },
    gmc: {
      'Sierra 1500': {
        trims: [
          { trim: 'SLE / Elevation — 5.3L V8', maxTow: 10800, maxPayload: 2100, gcwr: 18000, curb: 4750, engine: '5.3L EcoTec3 V8', hitch: 'Class IV' },
          { trim: 'Denali / AT4X — 6.2L V8 Max Tow', maxTow: 13200, maxPayload: 2240, gcwr: 20400, curb: 4900, engine: '6.2L EcoTec3 V8 (Max Trailering Pkg)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
        ],
      },
      'Sierra 2500HD': {
        trims: [
          { trim: 'SLE / Elevation — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3879, gcwr: 28000, curb: 7250, engine: '6.6L Duramax V8 Diesel', hitch: 'Class V' },
          { trim: 'Denali Ultimate — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3700, gcwr: 28000, curb: 7400, engine: '6.6L Duramax V8 Diesel', hitch: 'Class V' },
        ],
      },
      'Sierra 3500HD': {
        trims: [
          { trim: 'Regular Cab — 6.6L Duramax Diesel (SRW)', maxTow: 27500, maxPayload: 5673, gcwr: 37500, curb: 8100, engine: '6.6L Duramax V8 Diesel (SRW)', hitch: 'Class V' },
          { trim: 'Denali — 6.6L Duramax (DRW)', maxTow: 36000, maxPayload: 7150, gcwr: 46500, curb: 8650, engine: '6.6L Duramax V8 Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel — max conventional rating' },
        ],
      },
      'Yukon XL': {
        trims: [
          { trim: 'SLE / SLT — 5.3L EcoTec3 V8', maxTow: 8500, maxPayload: 1630, gcwr: 15700, curb: 5827, engine: '5.3L EcoTec3 V8 (355 HP)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
          { trim: 'Denali Ultimate — 6.2L V8', maxTow: 8500, maxPayload: 1480, gcwr: 15700, curb: 6050, engine: '6.2L EcoTec3 V8 (420 HP)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' },
        ],
      },
    },
    toyota: {
      'Tundra': {
        trims: [
          { trim: 'SR / SR5 — 3.4L Twin-Turbo V6', maxTow: 8000, maxPayload: 1940, gcwr: 15600, curb: 5530, engine: '3.4L Twin-Turbo V6 (389 HP)', hitch: 'Class IV' },
          { trim: 'Limited / TRD Pro — 3.4L Twin-Turbo V6', maxTow: 11000, maxPayload: 1810, gcwr: 17600, curb: 5680, engine: '3.4L Twin-Turbo V6 (389 HP)', hitch: 'Class IV', notes: 'Requires tow package and 3.31 rear axle' },
          { trim: 'Platinum Hybrid — 3.4L TT-V6 + Electric', maxTow: 12000, maxPayload: 1640, gcwr: 18600, curb: 6060, engine: '3.4L Twin-Turbo V6 Hybrid (MAX Tow)', hitch: 'Class IV', notes: 'Requires Tow Technology Package' },
        ],
      },
      'Tacoma': {
        trims: [
          { trim: 'SR / SR5 — 2.4L Turbo I4', maxTow: 6500, maxPayload: 1440, gcwr: 11000, curb: 4480, engine: '2.4L Turbo I4 (278 HP)', hitch: 'Class III' },
          { trim: 'Trailhunter / TRD Pro — 2.4L Turbo', maxTow: 6000, maxPayload: 1150, gcwr: 11000, curb: 4960, engine: '2.4L Turbo I4', hitch: 'Class III', notes: 'Heavier off-road equipment reduces ratings' },
        ],
      },
      '4Runner': {
        trims: [
          { trim: 'SR5 / TRD Sport — 4.0L V6', maxTow: 5000, maxPayload: 1545, gcwr: 9300, curb: 4695, engine: '4.0L V6 (270 HP)', hitch: 'Class III' },
          { trim: 'TRD Pro / Trailhunter — 4.0L V6', maxTow: 4400, maxPayload: 1150, gcwr: 9300, curb: 5090, engine: '4.0L V6', hitch: 'Class III', notes: 'Off-road equipment adds weight' },
        ],
      },
      'Land Cruiser': { trims: [{ trim: 'Standard — 2.4L Twin-Turbo Hybrid', maxTow: 6000, maxPayload: 1100, gcwr: 11600, curb: 5500, engine: '2.4L TT-I4 Hybrid (326 HP)', hitch: 'Class III', notes: 'All-new Land Cruiser; reintroduced for 2024' }] },
      'Sequoia': { trims: [{ trim: 'SR5 / Limited — 3.4L TT-V6 Hybrid', maxTow: 9000, maxPayload: 1620, gcwr: 16200, curb: 5985, engine: '3.4L Twin-Turbo V6 Hybrid (437 HP)', hitch: 'Class IV' }] },
    },
    nissan: {
      'Titan': {
        trims: [
          { trim: 'S / SV — 5.6L Endurance V8', maxTow: 9210, maxPayload: 1890, gcwr: 16700, curb: 5683, engine: '5.6L Endurance V8 (400 HP)', hitch: 'Class IV' },
          { trim: 'SL / PRO-4X — 5.6L V8 (w/ Tow Pkg)', maxTow: 11040, maxPayload: 1810, gcwr: 18500, curb: 5783, engine: '5.6L Endurance V8 (w/ Tow Package)', hitch: 'Class IV', notes: 'Requires Tow Package' },
        ],
      },
      'Frontier': { trims: [{ trim: 'S / SV — 3.8L V6', maxTow: 6720, maxPayload: 1590, gcwr: 11000, curb: 4508, engine: '3.8L DOHC V6 (310 HP)', hitch: 'Class III' }] },
    },
    jeep: {
      'Gladiator': {
        trims: [
          { trim: 'Sport / Sport S — 3.6L Pentastar V6', maxTow: 7650, maxPayload: 1650, gcwr: 13500, curb: 4650, engine: '3.6L Pentastar V6 (285 HP)', hitch: 'Class III' },
          { trim: 'Rubicon / Mojave — 3.6L V6', maxTow: 7000, maxPayload: 1450, gcwr: 13000, curb: 4850, engine: '3.6L Pentastar V6', hitch: 'Class III', notes: 'Off-road hardware reduces tow rating' },
        ],
      },
      'Wagoneer': { trims: [{ trim: 'Grand Wagoneer — 3.0L Hurricane TT', maxTow: 10000, maxPayload: 1480, gcwr: 17500, curb: 5970, engine: '3.0L Hurricane I6 TT', hitch: 'Class IV' }] },
      'Grand Cherokee': {
        trims: [
          { trim: 'Laredo / Altitude — 3.6L Pentastar V6', maxTow: 6200, maxPayload: 1200, gcwr: 11600, curb: 5079, engine: '3.6L Pentastar V6', hitch: 'Class III' },
          { trim: 'Limited / Overland — 5.7L HEMI V8', maxTow: 7200, maxPayload: 1400, gcwr: 13400, curb: 5079, engine: '5.7L HEMI V8', hitch: 'Class III' },
        ],
      },
    },
  },
  '2023': {
    ford: {
      'F-150': {
        trims: [
          { trim: 'XL / XLT — 2.7L EcoBoost', maxTow: 8200, maxPayload: 1880, gcwr: 14400, curb: 4705, engine: '2.7L EcoBoost V6', hitch: 'Class IV' },
          { trim: 'Platinum / Limited — 3.5L EcoBoost Max Tow', maxTow: 13000, maxPayload: 2455, gcwr: 20000, curb: 4950, engine: '3.5L EcoBoost V6 (Max Tow)', hitch: 'Class IV', notes: 'Requires Max Tow Package' },
        ],
      },
      'F-250 Super Duty': { trims: [{ trim: 'XL / XLT — 6.7L Power Stroke Diesel', maxTow: 20000, maxPayload: 4260, gcwr: 33000, curb: 7550, engine: '6.7L Power Stroke Diesel', hitch: 'Class V' }] },
      'F-350 Super Duty': { trims: [{ trim: 'XL — 6.7L Diesel (DRW)', maxTow: 37000, maxPayload: 7850, gcwr: 52000, curb: 8500, engine: '6.7L Power Stroke Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel' }] },
    },
    ram: {
      '1500': { trims: [{ trim: 'Limited / TRX — 5.7L HEMI Max Tow', maxTow: 12750, maxPayload: 2300, gcwr: 19500, curb: 5300, engine: '5.7L HEMI V8 (Max Tow)', hitch: 'Class IV', notes: 'Requires Max Tow Package' }] },
      '2500': { trims: [{ trim: 'Tradesman — 6.7L Cummins Diesel', maxTow: 20000, maxPayload: 3990, gcwr: 30000, curb: 7340, engine: '6.7L Cummins HO Diesel', hitch: 'Class V' }] },
      '3500': { trims: [{ trim: 'Tradesman — 6.7L Cummins Diesel (DRW)', maxTow: 37100, maxPayload: 7680, gcwr: 49000, curb: 8000, engine: '6.7L Cummins Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel' }] },
    },
    chevrolet: {
      'Silverado 1500': { trims: [{ trim: 'High Country — 6.2L V8 Max Trailering', maxTow: 13300, maxPayload: 2280, gcwr: 20800, curb: 4800, engine: '6.2L EcoTec3 V8 (Max Trailering)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' }] },
      'Silverado 2500HD': { trims: [{ trim: 'Work Truck — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3979, gcwr: 28000, curb: 7000, engine: '6.6L Duramax Diesel', hitch: 'Class V' }] },
      'Silverado 3500HD': { trims: [{ trim: 'Work Truck — 6.6L Duramax (DRW)', maxTow: 35500, maxPayload: 7442, gcwr: 46500, curb: 8000, engine: '6.6L Duramax Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel' }] },
    },
    gmc: {
      'Sierra 1500': { trims: [{ trim: 'Denali — 6.2L V8 Max Trailering', maxTow: 13200, maxPayload: 2240, gcwr: 20400, curb: 4900, engine: '6.2L EcoTec3 V8 (Max Trailering)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' }] },
      'Sierra 2500HD': { trims: [{ trim: 'Denali — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3650, gcwr: 28000, curb: 7400, engine: '6.6L Duramax Diesel', hitch: 'Class V' }] },
      'Sierra 3500HD': { trims: [{ trim: 'Regular Cab — 6.6L Duramax (DRW)', maxTow: 36000, maxPayload: 7442, gcwr: 46500, curb: 8000, engine: '6.6L Duramax Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel' }] },
    },
    toyota: {
      'Tundra': { trims: [{ trim: 'Platinum Hybrid — 3.4L TT-V6 Hybrid', maxTow: 12000, maxPayload: 1640, gcwr: 18600, curb: 6060, engine: '3.4L Twin-Turbo V6 Hybrid', hitch: 'Class IV', notes: 'Requires Tow Technology Package' }] },
      'Tacoma': { trims: [{ trim: 'SR / SR5 — 3.5L V6', maxTow: 6800, maxPayload: 1440, gcwr: 11200, curb: 4480, engine: '3.5L V6', hitch: 'Class III' }] },
    },
    nissan: { 'Titan': { trims: [{ trim: 'PRO-4X (w/ Tow Pkg) — 5.6L V8', maxTow: 11040, maxPayload: 1810, gcwr: 18500, curb: 5783, engine: '5.6L Endurance V8 (Tow Package)', hitch: 'Class IV' }] } },
    jeep: { 'Gladiator': { trims: [{ trim: 'Sport / Overland — 3.6L V6', maxTow: 7650, maxPayload: 1650, gcwr: 13500, curb: 4650, engine: '3.6L Pentastar V6', hitch: 'Class III' }] } },
  },
  '2022': {
    ford: {
      'F-150': {
        trims: [
          { trim: 'XL / XLT — 2.7L EcoBoost', maxTow: 8000, maxPayload: 1880, gcwr: 14000, curb: 4705, engine: '2.7L EcoBoost V6', hitch: 'Class IV' },
          { trim: 'Lariat / Platinum — 3.5L EcoBoost Max Tow', maxTow: 13000, maxPayload: 2455, gcwr: 20000, curb: 4950, engine: '3.5L EcoBoost V6 (Max Tow)', hitch: 'Class IV', notes: 'Requires Max Tow Package' },
        ],
      },
      'F-250 Super Duty': { trims: [{ trim: 'XL — 6.7L Power Stroke Diesel', maxTow: 20000, maxPayload: 4260, gcwr: 33000, curb: 7350, engine: '6.7L Power Stroke Diesel', hitch: 'Class V' }] },
      'F-350 Super Duty': { trims: [{ trim: 'XL (DRW) — 6.7L Diesel', maxTow: 37000, maxPayload: 7850, gcwr: 52000, curb: 8500, engine: '6.7L Power Stroke Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel' }] },
    },
    ram: {
      '1500': { trims: [{ trim: 'Limited — 5.7L HEMI Max Tow', maxTow: 12750, maxPayload: 2300, gcwr: 19500, curb: 5300, engine: '5.7L HEMI V8 (Max Tow)', hitch: 'Class IV', notes: 'Requires Max Tow Package' }] },
      '2500': { trims: [{ trim: 'Tradesman — 6.7L Cummins Diesel', maxTow: 20000, maxPayload: 3990, gcwr: 30000, curb: 7340, engine: '6.7L Cummins HO Diesel', hitch: 'Class V' }] },
      '3500': { trims: [{ trim: 'Tradesman (DRW) — 6.7L Cummins Diesel', maxTow: 37100, maxPayload: 7680, gcwr: 49000, curb: 8000, engine: '6.7L Cummins Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel' }] },
    },
    chevrolet: {
      'Silverado 1500': { trims: [{ trim: 'High Country — 6.2L V8 Max Trailering', maxTow: 13300, maxPayload: 2280, gcwr: 20800, curb: 4800, engine: '6.2L EcoTec3 V8 (Max Trailering)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' }] },
      'Silverado 2500HD': { trims: [{ trim: 'Work Truck — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3979, gcwr: 28000, curb: 7000, engine: '6.6L Duramax Diesel', hitch: 'Class V' }] },
      'Silverado 3500HD': { trims: [{ trim: 'Work Truck (DRW) — 6.6L Duramax Diesel', maxTow: 35500, maxPayload: 7442, gcwr: 46500, curb: 8000, engine: '6.6L Duramax Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel' }] },
    },
    gmc: {
      'Sierra 1500': { trims: [{ trim: 'Denali — 6.2L V8 Max Trailering', maxTow: 13000, maxPayload: 2240, gcwr: 20400, curb: 4900, engine: '6.2L EcoTec3 V8 (Max Trailering)', hitch: 'Class IV', notes: 'Requires Max Trailering Package' }] },
      'Sierra 2500HD': { trims: [{ trim: 'Denali — 6.6L Duramax Diesel', maxTow: 18500, maxPayload: 3700, gcwr: 28000, curb: 7400, engine: '6.6L Duramax Diesel', hitch: 'Class V' }] },
      'Sierra 3500HD': { trims: [{ trim: 'Regular Cab (DRW) — 6.6L Duramax', maxTow: 36000, maxPayload: 7442, gcwr: 46500, curb: 8000, engine: '6.6L Duramax Diesel (DRW)', hitch: 'Class V', notes: 'Dual rear wheel' }] },
    },
    toyota: {
      'Tundra': { trims: [{ trim: 'Limited Hybrid — 3.4L TT-V6 Hybrid', maxTow: 12000, maxPayload: 1640, gcwr: 18600, curb: 6060, engine: '3.4L Twin-Turbo V6 Hybrid', hitch: 'Class IV', notes: 'Requires Tow Technology Package' }] },
      'Tacoma': { trims: [{ trim: 'SR5 / TRD — 3.5L V6', maxTow: 6800, maxPayload: 1440, gcwr: 11200, curb: 4480, engine: '3.5L V6', hitch: 'Class III' }] },
    },
    nissan: { 'Titan': { trims: [{ trim: 'SV / PRO-4X (w/ Tow Pkg) — 5.6L V8', maxTow: 11040, maxPayload: 1890, gcwr: 18500, curb: 5883, engine: '5.6L Endurance V8', hitch: 'Class IV' }] } },
    jeep: { 'Gladiator': { trims: [{ trim: 'Sport / Overland — 3.6L V6', maxTow: 7650, maxPayload: 1650, gcwr: 13500, curb: 4650, engine: '3.6L Pentastar V6', hitch: 'Class III' }] } },
  },
};

// ─── HITCH CLASSES ────────────────────────────────────────────────────────────

const HITCH_CLASSES = [
  { cls: 'Class I', maxTow: 2000, color: '#888888', desc: 'Light-duty — small trailers only' },
  { cls: 'Class II', maxTow: 3500, color: '#4DA6FF', desc: 'Mid-size — small pop-ups & teardrops' },
  { cls: 'Class III', maxTow: 8000, color: Colors.blueBright, desc: 'Standard — travel trailers up to 30ft' },
  { cls: 'Class IV', maxTow: 14000, color: Colors.silverBright, desc: 'Heavy-duty — large 5th wheels & TTs' },
  { cls: 'Class V', maxTow: 20000, color: '#AACCFF', desc: 'Gooseneck/commercial — all RV types' },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function fmt(n: number) { return n.toLocaleString('en-US'); }
function getYears() {
  const years: string[] = [];
  for (let y = 2026; y >= 2010; y--) years.push(String(y));
  return years;
}
function getMakes(year: string): string[] {
  const d = TRUCK_DB[year] ?? TRUCK_DB['2024'];
  return Object.keys(d);
}
function getModels(year: string, make: string): string[] {
  const d = TRUCK_DB[year] ?? TRUCK_DB['2024'];
  const m = d[make.toLowerCase()];
  return m ? Object.keys(m) : [];
}
function getTrims(year: string, make: string, model: string): TrimSpec[] {
  const yearKey = TRUCK_DB[year] ? year : '2024';
  const d = TRUCK_DB[yearKey];
  if (!d) return [];
  const m = d[make.toLowerCase()];
  if (!m) return [];
  return m[model]?.trims ?? [];
}

interface SafetyResult {
  score: number;
  rating: 'SAFE' | 'CAUTION' | 'UNSAFE';
  color: string;
  towRatio: number;
  payloadRatio: number;
  gcwrUsed: number;
  gcwrHeadroom: number;
  issues: string[];
  recommendations: string[];
}

function calcSafety(trim: TrimSpec, rvGvwr: number, tongueWeight: number): SafetyResult {
  const issues: string[] = [];
  const recommendations: string[] = [];
  const towRatio = rvGvwr / trim.maxTow;
  const payloadRatio = tongueWeight / trim.maxPayload;
  const gcwrUsed = trim.curb + rvGvwr;
  const gcwrHeadroom = trim.gcwr - gcwrUsed;
  let score = 100;

  if (towRatio > 1.0) { score -= 50; issues.push(`RV GVWR (${fmt(rvGvwr)} lbs) exceeds max tow rating (${fmt(trim.maxTow)} lbs) for this trim`); recommendations.push('Select a higher-capacity trim or engine/package, or a lighter RV'); }
  else if (towRatio > 0.9) { score -= 25; issues.push(`At ${Math.round(towRatio * 100)}% of max tow — operating near capacity for this trim`); recommendations.push('Consider the 80% rule: keep tow weight under 80% of rated capacity for safety margin'); }
  else if (towRatio > 0.8) { score -= 10; recommendations.push('Above the 80% rule — acceptable but reduce speed in wind and mountain grades'); }

  if (payloadRatio > 1.0) { score -= 40; issues.push(`Tongue weight (${fmt(tongueWeight)} lbs) exceeds payload capacity (${fmt(trim.maxPayload)} lbs)`); recommendations.push('Upgrade to a higher-payload trim/package or reduce tongue weight with WD hitch'); }
  else if (payloadRatio > 0.8) { score -= 15; issues.push(`Tongue weight is ${Math.round(payloadRatio * 100)}% of payload capacity`); recommendations.push('A weight-distribution hitch is strongly recommended at this tongue weight'); }

  if (gcwrHeadroom < 0) { score -= 30; issues.push(`Combined weight (${fmt(gcwrUsed)} lbs) exceeds GCWR (${fmt(trim.gcwr)} lbs)`); recommendations.push('GCWR exceeded — this combination is unsafe for road use'); }
  else if (gcwrHeadroom < 2000) { score -= 10; recommendations.push('GCWR headroom is tight — factor in passengers, gear, and fuel weight'); }

  score = Math.max(0, Math.min(100, score));
  let rating: 'SAFE' | 'CAUTION' | 'UNSAFE';
  let color: string;
  if (score >= 75) { rating = 'SAFE'; color = '#4DA6FF'; }
  else if (score >= 40) { rating = 'CAUTION'; color = '#87BFFF'; }
  else { rating = 'UNSAFE'; color = Colors.red; }

  if (issues.length === 0) {
    recommendations.push('Install a transmission temp gauge for extended towing');
    recommendations.push('Verify tire pressure ratings handle the combined weight');
    if (tongueWeight > 500) recommendations.push('Consider a weight-distribution hitch for tongue weights over 500 lbs');
    if (tongueWeight > 1000) recommendations.push('Trailer brake controller required for tongue weights over 1,000 lbs');
  }

  return { score, rating, color, towRatio, payloadRatio, gcwrUsed, gcwrHeadroom, issues, recommendations };
}

function getHitchRecommendation(rvGvwr: number) {
  for (const h of HITCH_CLASSES) { if (rvGvwr <= h.maxTow) return h; }
  return HITCH_CLASSES[HITCH_CLASSES.length - 1];
}

// ─── DROPDOWN SELECTOR ────────────────────────────────────────────────────────

function Selector({ label, value, options, onSelect, placeholder, color = Colors.blueBright, disabled = false }: {
  label: string; value: string; options: string[]; onSelect: (v: string) => void;
  placeholder: string; color?: string; disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  return (
    <View style={ddStyles.wrapper}>
      <Text style={[ddStyles.label, { color }]}>{label}</Text>
      <Pressable
        style={({ pressed }) => [ddStyles.trigger, open && ddStyles.triggerOpen, disabled && ddStyles.triggerDisabled, pressed && !disabled && { opacity: 0.85 }]}
        onPress={() => !disabled && setOpen(prev => !prev)}
      >
        <Text style={[ddStyles.triggerText, !value && ddStyles.triggerPlaceholder]} numberOfLines={1}>{value || placeholder}</Text>
        <MaterialIcons name={open ? 'keyboard-arrow-up' : 'keyboard-arrow-down'} size={18} color={open ? color : Colors.textMuted} />
      </Pressable>
      {open && options.length > 0 && (
        <View style={ddStyles.dropdown}>
          <ScrollView nestedScrollEnabled showsVerticalScrollIndicator={false} style={{ maxHeight: 240 }} contentContainerStyle={{ gap: 2 }}>
            {options.map(opt => (
              <Pressable key={opt} style={({ pressed }) => [ddStyles.option, value === opt && ddStyles.optionActive, pressed && { opacity: 0.75 }]} onPress={() => { onSelect(opt); setOpen(false); }}>
                <Text style={[ddStyles.optionText, value === opt && { color, fontWeight: FontWeight.bold }]} numberOfLines={2}>{opt}</Text>
                {value === opt && <MaterialIcons name="check" size={14} color={color} />}
              </Pressable>
            ))}
          </ScrollView>
        </View>
      )}
    </View>
  );
}

const ddStyles = StyleSheet.create({
  wrapper: { gap: Spacing.xs, zIndex: 10 },
  label: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, letterSpacing: 1.2 },
  trigger: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 12 },
  triggerOpen: { borderColor: Colors.borderBlue, backgroundColor: 'rgba(0,104,192,0.05)' },
  triggerDisabled: { opacity: 0.4 },
  triggerText: { fontSize: FontSize.md, color: Colors.textPrimary, flex: 1, marginRight: 6 },
  triggerPlaceholder: { color: Colors.textMuted },
  dropdown: { position: 'absolute', top: '100%', left: 0, right: 0, backgroundColor: '#1A1A1A', borderWidth: 1, borderColor: Colors.borderBlue, borderRadius: Radius.md, zIndex: 999, marginTop: 4, overflow: 'hidden', shadowColor: Colors.blue, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 12, elevation: 12 },
  option: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.md, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border },
  optionActive: { backgroundColor: 'rgba(0,104,192,0.07)' },
  optionText: { fontSize: FontSize.sm, color: Colors.textSecondary, flex: 1, lineHeight: 18 },
});

// ─── SAFETY SCORE BAR ────────────────────────────────────────────────────────

function SafetyBar({ score, rating, color }: { score: number; rating: string; color: string }) {
  const pct = Math.max(0, Math.min(100, score));
  return (
    <View style={safetyStyles.container}>
      <View style={safetyStyles.header}>
        <Text style={safetyStyles.label}>SAFETY SCORE</Text>
        <View style={[safetyStyles.badge, { borderColor: color + '55', backgroundColor: color + '18' }]}>
          <Text style={[safetyStyles.badgeText, { color }]}>{rating}</Text>
        </View>
      </View>
      <Text style={[safetyStyles.scoreNumber, { color }]}>{score}</Text>
      <Text style={safetyStyles.scoreMax}>/100</Text>
      <View style={safetyStyles.track}>
        <View style={[safetyStyles.zone, { backgroundColor: Colors.red + '30', flex: 40 }]} />
        <View style={[safetyStyles.zone, { backgroundColor: 'rgba(135,191,255,0.30)', flex: 35 }]} />
        <View style={[safetyStyles.zone, { backgroundColor: 'rgba(77,166,255,0.30)', flex: 25 }]} />
        <View style={[safetyStyles.fill, { width: `${pct}%` as any, backgroundColor: color }]} />
        <View style={[safetyStyles.thumb, { left: `${pct}%` as any, borderColor: color, shadowColor: color }]} />
      </View>
      <View style={safetyStyles.zoneLabelRow}>
        <Text style={[safetyStyles.zoneLabel, { color: Colors.red }]}>UNSAFE</Text>
        <Text style={[safetyStyles.zoneLabel, { color: '#87BFFF' }]}>CAUTION</Text>
        <Text style={[safetyStyles.zoneLabel, { color: '#4DA6FF' }]}>SAFE</Text>
      </View>
    </View>
  );
}

const safetyStyles = StyleSheet.create({
  container: { gap: Spacing.sm },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  label: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 1.5 },
  badge: { borderWidth: 1, borderRadius: Radius.full, paddingHorizontal: 12, paddingVertical: 5 },
  badgeText: { fontSize: FontSize.sm, fontWeight: FontWeight.extrabold, letterSpacing: 1.5 },
  scoreNumber: { fontSize: 52, fontWeight: FontWeight.extrabold, lineHeight: 56, letterSpacing: -2, alignSelf: 'center' },
  scoreMax: { fontSize: FontSize.md, color: Colors.textMuted, alignSelf: 'center', marginTop: -Spacing.sm, marginBottom: Spacing.xs },
  track: { height: 14, backgroundColor: Colors.bgCardAlt, borderRadius: 7, borderWidth: 1, borderColor: Colors.border, overflow: 'hidden', flexDirection: 'row', position: 'relative' },
  zone: { height: '100%' },
  fill: { position: 'absolute', left: 0, top: 0, height: '100%', borderRadius: 7, opacity: 0.75 },
  thumb: { position: 'absolute', top: -3, width: 20, height: 20, borderRadius: 10, backgroundColor: '#1A1A1A', borderWidth: 3, transform: [{ translateX: -10 }], shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.8, shadowRadius: 6, elevation: 4 },
  zoneLabelRow: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 2 },
  zoneLabel: { fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1 },
});

// ─── METRIC CARD ─────────────────────────────────────────────────────────────

function MetricCard({ icon, label, value, sub, color, accent = false, warning = false }: {
  icon: string; label: string; value: string; sub: string; color: string; accent?: boolean; warning?: boolean;
}) {
  return (
    <View style={[metricStyles.card, accent && { borderColor: color + '55', backgroundColor: color + '0D' }, warning && { borderColor: Colors.red + '55', backgroundColor: Colors.red + '0A' }]}>
      <MaterialIcons name={icon as any} size={18} color={warning ? Colors.red : color} />
      <Text style={[metricStyles.value, { color: warning ? Colors.red : color }]}>{value}</Text>
      <Text style={metricStyles.label}>{label}</Text>
      <Text style={metricStyles.sub}>{sub}</Text>
    </View>
  );
}

const metricStyles = StyleSheet.create({
  card: { flex: 1, backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.lg, alignItems: 'center', paddingVertical: 14, paddingHorizontal: 8, gap: 4 },
  value: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, letterSpacing: -0.5 },
  label: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 1, textAlign: 'center' },
  sub: { fontSize: 9, color: Colors.textMuted, textAlign: 'center' },
});

// ─── CHECKLIST ITEMS DATA ────────────────────────────────────────────────────

const CHECKLIST_ITEMS = [
  { id: 'tire_rv',    category: 'TIRES',        icon: 'radio-button-checked',  label: 'RV Tire Pressure',          desc: 'Check all tires incl. spare — match door sticker PSI' },
  { id: 'tire_tow',   category: 'TIRES',        icon: 'radio-button-checked',  label: 'Tow Vehicle Tire Pressure', desc: 'Verify front and rear axle pressures per door sticker' },
  { id: 'hitch_pin',  category: 'HITCH',        icon: 'push-pin',              label: 'Hitch Pin & Clip',          desc: 'Locking hitch pin installed and safety clip secured' },
  { id: 'ball',       category: 'HITCH',        icon: 'adjust',                label: 'Coupler Latched & Locked',  desc: 'Ball seated, latch closed, coupler lock engaged' },
  { id: 'safety_ch',  category: 'HITCH',        icon: 'link',                  label: 'Safety Chains Crossed',     desc: 'Chains crossed under tongue in X-pattern with some slack' },
  { id: 'brake_ctrl', category: 'BRAKES',       icon: 'settings',              label: 'Brake Controller',          desc: 'Trailer brakes functional, gain adjusted for load' },
  { id: 'breakaway',  category: 'BRAKES',       icon: 'warning',               label: 'Breakaway Cable',           desc: 'Cable attached to tow vehicle (NOT the hitch ball)' },
  { id: 'emer_brake', category: 'BRAKES',       icon: 'pan-tool',              label: 'Emergency Brake Released',  desc: 'Parking/emergency brake fully released on both vehicles' },
  { id: 'wd_hitch',   category: 'WEIGHT DIST',  icon: 'horizontal-rule',       label: 'Weight Distribution Hitch', desc: 'Spring bars tensioned, head angle set, sway control attached' },
  { id: 'electric',   category: 'ELECTRICAL',   icon: 'electrical-services',   label: '7-Pin Plug Connected',      desc: 'Running lights, turn signals, and brake lights all working' },
  { id: 'mirrors',    category: 'VISIBILITY',   icon: 'visibility',            label: 'Extended Mirrors',          desc: 'Both mirrors extended and adjusted for trailer width' },
  { id: 'slides_in',  category: 'RV PREP',      icon: 'crop-square',           label: 'Slides Fully Retracted',    desc: 'All room slides in and locked before moving' },
  { id: 'jacks_up',   category: 'RV PREP',      icon: 'vertical-align-top',    label: 'Leveling Jacks Retracted',  desc: 'All jacks up and secured, warning lights off' },
  { id: 'steps',      category: 'RV PREP',      icon: 'stairs',                label: 'Entry Steps Retracted',     desc: 'Manual or power steps fully in before departure' },
  { id: 'propane',    category: 'SAFETY',       icon: 'local-fire-department', label: 'Propane Valve Closed',      desc: 'Main propane tank valve closed for highway travel' },
];

const CHECKLIST_CATEGORIES = Array.from(new Set(CHECKLIST_ITEMS.map(i => i.category)));

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

export default function RvTowScreen() {
  const insets = useSafeAreaInsets();

  const [year, setYear]   = useState('2024');
  const [make, setMake]   = useState('');
  const [model, setModel] = useState('');
  const [trim, setTrim]   = useState('');

  const [rvGvwrText, setRvGvwrText] = useState('');
  const [tongueText, setTongueText] = useState('');
  const [rvType, setRvType]         = useState('');
  const [bedLength, setBedLength]   = useState('');

  // ── CHECKLIST STATE ───────────────────────────────────────────────────────
  const [checklistOpen, setChecklistOpen] = useState(false);
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  const checkedCount = Object.values(checked).filter(Boolean).length;
  const totalChecklist = CHECKLIST_ITEMS.length;
  const allChecked = checkedCount === totalChecklist;
  const toggleCheck = useCallback((id: string) => setChecked(prev => ({ ...prev, [id]: !prev[id] })), []);
  const resetChecklist = useCallback(() => setChecked({}), []);

  const isFifthWheel = rvType === 'Fifth Wheel';
  const BED_LENGTHS = ['5.5 ft (Short Bed)', '6.5 ft (Standard Bed)', '8.0 ft (Long Bed)'];

  const fwHitchFit = useMemo(() => {
    if (!bedLength || !isFifthWheel) return null;
    if (bedLength.startsWith('5.5')) return { ok: false, msg: 'Short bed (5.5 ft) requires a slider hitch or extended pin box to prevent cab contact during turns. Budget $500–$1,200 extra for a slider hitch.' };
    if (bedLength.startsWith('6.5')) return { ok: true, msg: '6.5 ft bed accommodates most standard fifth wheel hitches. Verify clearance with a full lock-to-lock turn before your first trip.' };
    return { ok: true, msg: '8.0 ft long bed has maximum clearance for all fifth wheel hitch styles with no restrictions.' };
  }, [bedLength, isFifthWheel]);

  const years  = useMemo(() => getYears(), []);
  const makes  = useMemo(() => getMakes(year), [year]);
  const models = useMemo(() => (make ? getModels(year, make) : []), [year, make]);
  const trims  = useMemo(() => (make && model ? getTrims(year, make, model) : []), [year, make, model]);

  const selectedTrimSpec = useMemo<TrimSpec | null>(() => {
    if (!trim) return null;
    return trims.find(t => t.trim === trim) ?? null;
  }, [trim, trims]);

  const rvGvwr = useMemo(() => { const n = parseInt(rvGvwrText.replace(/,/g, ''), 10); return isNaN(n) ? 0 : n; }, [rvGvwrText]);
  const tongueWeight = useMemo(() => { const n = parseInt(tongueText.replace(/,/g, ''), 10); return isNaN(n) ? 0 : n; }, [tongueText]);

  const autoWeightPct = isFifthWheel ? 0.20 : 0.15;
  const autoWeightLabel = isFifthWheel ? 'pin weight' : 'tongue weight';

  const safetyResult = useMemo<SafetyResult | null>(() => {
    if (!selectedTrimSpec || rvGvwr <= 0) return null;
    const tongue = tongueWeight > 0 ? tongueWeight : Math.round(rvGvwr * autoWeightPct);
    return calcSafety(selectedTrimSpec, rvGvwr, tongue);
  }, [selectedTrimSpec, rvGvwr, tongueWeight, autoWeightPct]);

  const hitchRec = useMemo(() => getHitchRecommendation(rvGvwr), [rvGvwr]);

  const handleYearChange = useCallback((v: string) => { setYear(v); setMake(''); setModel(''); setTrim(''); }, []);
  const handleMakeChange = useCallback((v: string) => { setMake(v); setModel(''); setTrim(''); }, []);
  const handleModelChange = useCallback((v: string) => { setModel(v); setTrim(''); }, []);

  const RV_TYPES = ['Travel Trailer', 'Fifth Wheel'];
  const makeCaps = make ? make.charAt(0).toUpperCase() + make.slice(1) : '';

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* SUPERHAULER HERO BACKDROP — blue Entegra front-facing */}
      <View style={styles.heroBackdrop}>
        <Image
          source={require('../../assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.3 }}
          transition={400}
        />
        <LinearGradient
          colors={['rgba(30,46,64,0.70)', 'rgba(20,38,72,0.28)', 'rgba(20,38,72,0.22)', 'rgba(30,46,64,0.40)', 'rgba(18,28,50,0.76)']}
          locations={[0, 0.18, 0.5, 0.82, 1]}
          style={StyleSheet.absoluteFill}
        />
      </View>

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>RvTow</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Pressable
            style={({ pressed }) => [styles.checklistBtn, pressed && { opacity: 0.75 }]}
            onPress={() => setChecklistOpen(true)}
          >
            <MaterialIcons name="checklist" size={14} color={Colors.blueBright} />
            <Text style={styles.checklistBtnText}>Checklist</Text>
            {checkedCount > 0 && (
              <View style={styles.checklistBadge}>
                <Text style={styles.checklistBadgeText}>{checkedCount}/{totalChecklist}</Text>
              </View>
            )}
          </Pressable>
          <View style={styles.headerBadge}>
            <MaterialIcons name="verified-user" size={13} color={Colors.blueBright} />
            <Text style={styles.headerBadgeText}>Safety First</Text>
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: insets.bottom + Spacing.xl }}>

        {/* ── Tow Vehicle Card ── */}
        <View style={[styles.card, { zIndex: 400 }]}>
          <View style={styles.cardHeaderRow}>
            <MaterialIcons name="local-shipping" size={16} color={Colors.blueBright} />
            <Text style={styles.cardTitle}>Tow Vehicle</Text>
          </View>
          <Text style={styles.cardSub}>Select year · make · model · trim for exact OEM tow ratings</Text>
          <View style={{ zIndex: 400 }}>
            <Selector label="YEAR" value={year} options={years} onSelect={handleYearChange} placeholder="Select year" />
          </View>
          <View style={{ zIndex: 300 }}>
            <Selector label="MAKE" value={makeCaps} options={makes.map(m => m.charAt(0).toUpperCase() + m.slice(1))} onSelect={v => handleMakeChange(v.toLowerCase())} placeholder="Ford, RAM, Chevy..." disabled={!year} />
          </View>
          <View style={{ zIndex: 200 }}>
            <Selector label="MODEL" value={model} options={models} onSelect={handleModelChange} placeholder={make ? 'Select model...' : 'Select make first'} disabled={!make} />
          </View>
          <View style={{ zIndex: 100 }}>
            <Selector label="TRIM / ENGINE / CONFIGURATION" value={trim} options={trims.map(t => t.trim)} onSelect={setTrim} placeholder={model ? 'Select trim & engine...' : 'Select model first'} disabled={!model} color={Colors.blueBright} />
          </View>
          {selectedTrimSpec?.notes && (
            <View style={styles.trimNoteCard}>
              <MaterialIcons name="info" size={13} color={Colors.blueBright} />
              <Text style={styles.trimNoteText}>{selectedTrimSpec.notes}</Text>
            </View>
          )}
        </View>

        {/* ── Truck Specs Panel ── */}
        {selectedTrimSpec && (
          <View style={styles.specsPanel}>
            <View style={styles.specsPanelHeader}>
              <MaterialIcons name="info-outline" size={14} color={Colors.blueBright} />
              <Text style={styles.specsPanelTitle} numberOfLines={2}>{year} {makeCaps} {model} — {selectedTrimSpec.engine}</Text>
            </View>
            <Text style={styles.specsPanelTrim}>{trim}</Text>
            <View style={styles.specsGrid}>
              <MetricCard icon="local-shipping" label="MAX TOW" value={`${(selectedTrimSpec.maxTow / 1000).toFixed(0)}K`} sub={`${fmt(selectedTrimSpec.maxTow)} lbs`} color={Colors.blueBright} accent />
              <MetricCard icon="fitness-center" label="PAYLOAD" value={`${(selectedTrimSpec.maxPayload / 1000).toFixed(1)}K`} sub={`${fmt(selectedTrimSpec.maxPayload)} lbs`} color={Colors.blueBright} accent />
              <MetricCard icon="compare-arrows" label="GCWR" value={`${(selectedTrimSpec.gcwr / 1000).toFixed(0)}K`} sub={`${fmt(selectedTrimSpec.gcwr)} lbs`} color={Colors.blueBright} accent />
            </View>
            <View style={styles.hitchRow}>
              <MaterialIcons name="link" size={14} color={Colors.textMuted} />
              <Text style={styles.hitchText}>OEM Hitch: </Text>
              <Text style={styles.hitchClass}>{selectedTrimSpec.hitch}</Text>
            </View>
          </View>
        )}

        {model && !trim && (
          <View style={styles.trimPromptCard}>
            <MaterialIcons name="arrow-upward" size={16} color={Colors.blueBright} />
            <View style={{ flex: 1 }}>
              <Text style={styles.trimPromptTitle}>Select trim & engine above</Text>
              <Text style={styles.trimPromptSub}>Tow ratings vary significantly by trim — an F-150 XL 2.7L tows 8,200 lbs while an F-150 Platinum 3.5L Max Tow handles 13,000 lbs.</Text>
            </View>
          </View>
        )}

        {/* ── RV Details Card ── */}
        <View style={[styles.card, { zIndex: 50 }]}>
          <View style={styles.cardHeaderRow}>
            <MaterialIcons name="home" size={16} color={Colors.blueBright} />
            <Text style={[styles.cardTitle, { color: Colors.blueBright }]}>RV Details</Text>
          </View>
          <View style={{ zIndex: 200 }}>
            <Selector label="RV TYPE" value={rvType} options={RV_TYPES} onSelect={setRvType} placeholder="Travel Trailer, Fifth Wheel..." color={Colors.blueBright} />
          </View>
          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: Colors.blueBright }]}>RV GVWR (lbs) *</Text>
            <TextInput style={styles.input} value={rvGvwrText} onChangeText={setRvGvwrText} placeholder="e.g. 14,500" placeholderTextColor={Colors.textMuted} keyboardType="numeric" />
            <Text style={styles.fieldHint}>Gross Vehicle Weight Rating — from RV door sticker or spec sheet</Text>
          </View>
          {isFifthWheel && (
            <View style={{ zIndex: 150 }}>
              <Selector label="TRUCK BED LENGTH" value={bedLength} options={BED_LENGTHS} onSelect={setBedLength} placeholder="Select bed length for hitch fit check..." color={Colors.blueBright} disabled={!selectedTrimSpec} />
            </View>
          )}
          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: Colors.blueBright }]}>
              {isFifthWheel ? 'PIN WEIGHT (lbs)' : 'TONGUE WEIGHT (lbs)'}{' '}
              <Text style={{ color: Colors.textMuted, fontWeight: FontWeight.regular }}>OPTIONAL</Text>
            </Text>
            <TextInput style={styles.input} value={tongueText} onChangeText={setTongueText}
              placeholder={isFifthWheel ? 'e.g. 3,000  (est. 20% of GVWR)' : 'e.g. 1,800  (est. 15% of GVWR)'}
              placeholderTextColor={Colors.textMuted} keyboardType="numeric" />
            <Text style={styles.fieldHint}>
              {isFifthWheel ? 'Leave blank to auto-estimate at 20% of GVWR — fifth wheel pin weight is higher than conventional tongue weight' : 'Leave blank to auto-estimate at 15% of GVWR'}
            </Text>
          </View>
          {rvGvwr > 0 && tongueWeight === 0 && (
            <View style={styles.estimateNote}>
              <MaterialIcons name="lightbulb-outline" size={13} color={Colors.blueBright} />
              <Text style={styles.estimateNoteText}>Auto-estimating {autoWeightLabel} at {fmt(Math.round(rvGvwr * autoWeightPct))} lbs ({isFifthWheel ? '20' : '15'}% of GVWR)</Text>
            </View>
          )}
        </View>

        {/* ── Fifth Wheel vs Conventional Guide ── */}
        {rvType !== '' && (
          <View style={styles.fwCard}>
            <View style={styles.cardHeaderRow}>
              <MaterialIcons name="rv-hookup" size={16} color={Colors.blueBright} />
              <Text style={[styles.cardTitle, { color: Colors.blueBright }]}>
                {isFifthWheel ? '5th Wheel: Pin Weight & Hitch Guide' : 'Conventional Trailer: Tongue Weight Guide'}
              </Text>
            </View>
            <View style={styles.fwCompareRow}>
              <View style={[styles.fwCompareCol, isFifthWheel && styles.fwCompareColActive]}>
                <MaterialIcons name="rv-hookup" size={18} color={isFifthWheel ? Colors.blueBright : Colors.textMuted} />
                <Text style={[styles.fwCompareHead, isFifthWheel && { color: Colors.blueBright }]}>5th Wheel</Text>
                <Text style={styles.fwCompareStat}>Pin Weight</Text>
                <Text style={[styles.fwCompareVal, isFifthWheel && { color: Colors.blueBright }]}>18–25%</Text>
                <Text style={styles.fwCompareSub}>of trailer GVWR</Text>
                <View style={styles.fwDivider} />
                <Text style={styles.fwCompareFeature}>✓ More stable at speed</Text>
                <Text style={styles.fwCompareFeature}>✓ Higher weight limits</Text>
                <Text style={styles.fwCompareFeature}>✓ Lower center of gravity</Text>
                <Text style={[styles.fwCompareFeature, { color: '#87BFFF' }]}>⚠ Bed hitch required</Text>
                <Text style={[styles.fwCompareFeature, { color: '#87BFFF' }]}>⚠ Bed access reduced</Text>
              </View>
              <View style={styles.fwVsDivider}><Text style={styles.fwVsText}>VS</Text></View>
              <View style={[styles.fwCompareCol, !isFifthWheel && styles.fwCompareColActiveGold]}>
                <MaterialIcons name="local-shipping" size={18} color={!isFifthWheel ? Colors.blueBright : Colors.textMuted} />
                <Text style={[styles.fwCompareHead, !isFifthWheel && { color: Colors.blueBright }]}>Conventional</Text>
                <Text style={styles.fwCompareStat}>Tongue Weight</Text>
                <Text style={[styles.fwCompareVal, !isFifthWheel && { color: Colors.blueBright }]}>10–15%</Text>
                <Text style={styles.fwCompareSub}>of trailer GVWR</Text>
                <View style={styles.fwDivider} />
                <Text style={styles.fwCompareFeature}>✓ No bed modification</Text>
                <Text style={styles.fwCompareFeature}>✓ Ball hitch (universal)</Text>
                <Text style={styles.fwCompareFeature}>✓ Full bed access kept</Text>
                <Text style={[styles.fwCompareFeature, { color: '#87BFFF' }]}>⚠ Lower weight limit</Text>
                <Text style={[styles.fwCompareFeature, { color: '#87BFFF' }]}>⚠ More sway risk</Text>
              </View>
            </View>
            {fwHitchFit && (
              <View style={[styles.fwHitchResult, fwHitchFit.ok ? styles.fwHitchOk : styles.fwHitchWarn]}>
                <MaterialIcons name={fwHitchFit.ok ? 'check-circle' : 'warning-amber'} size={15} color={fwHitchFit.ok ? '#4DA6FF' : '#87BFFF'} />
                <Text style={[styles.fwHitchResultText, { color: fwHitchFit.ok ? '#4DA6FF' : '#87BFFF' }]}>{fwHitchFit.ok ? 'BED FIT: OK' : 'BED FIT: SLIDER HITCH NEEDED'}</Text>
              </View>
            )}
            {fwHitchFit && <Text style={styles.fwHitchMsg}>{fwHitchFit.msg}</Text>}
            {isFifthWheel && !bedLength && selectedTrimSpec && (
              <View style={styles.fwBedPrompt}>
                <MaterialIcons name="arrow-upward" size={13} color={Colors.blueBright} />
                <Text style={styles.fwBedPromptText}>Select truck bed length above to check fifth wheel hitch compatibility</Text>
              </View>
            )}
            <View style={styles.fwPayloadNote}>
              <MaterialIcons name="info-outline" size={12} color={Colors.textMuted} />
              <Text style={styles.fwPayloadNoteText}>
                {isFifthWheel
                  ? 'Fifth wheel pin weight loads over the rear axle — a heavier vertical force on the truck bed and frame than an equivalent tongue weight. Payload is consumed faster. Always check your door-jamb payload sticker, not just the tow rating.'
                  : 'Tongue weight (10–15% of trailer GVWR) acts behind the rear axle. A weight-distribution hitch is recommended for tongue weights over 600 lbs — it restores front axle weight and significantly improves steering control and handling.'}
              </Text>
            </View>
          </View>
        )}

        {/* ── Safety Results ── */}
        {safetyResult && selectedTrimSpec ? (
          <>
            <View style={styles.safetyHero}>
              <SafetyBar score={safetyResult.score} rating={safetyResult.rating} color={safetyResult.color} />
            </View>

            <View style={styles.card}>
              <View style={styles.cardHeaderRow}>
                <MaterialIcons name="bar-chart" size={16} color={Colors.blueBright} />
                <Text style={styles.cardTitle}>Capacity Analysis</Text>
              </View>
              <View style={styles.ratioSection}>
                <View style={styles.ratioHeader}>
                  <Text style={styles.ratioLabel}>TOW CAPACITY USED</Text>
                  <Text style={[styles.ratioPct, { color: safetyResult.towRatio > 1 ? Colors.red : safetyResult.towRatio > 0.9 ? '#87BFFF' : '#4DA6FF' }]}>{Math.round(safetyResult.towRatio * 100)}%</Text>
                </View>
                <View style={styles.ratioTrack}>
                  <View style={styles.ratioSafe}><Text style={styles.ratioZoneText}>80% Rule</Text></View>
                  <View style={[styles.ratioFill, { width: `${Math.min(100, safetyResult.towRatio * 100)}%` as any, backgroundColor: safetyResult.towRatio > 1 ? Colors.red : safetyResult.towRatio > 0.9 ? '#87BFFF' : '#4DA6FF' }]} />
                </View>
                <View style={styles.ratioMeta}>
                  <Text style={styles.ratioMetaText}>RV: {fmt(rvGvwr)} lbs</Text>
                  <Text style={styles.ratioMetaText}>Max: {fmt(selectedTrimSpec.maxTow)} lbs</Text>
                </View>
              </View>
              <View style={styles.ratioSection}>
                <View style={styles.ratioHeader}>
                  <Text style={styles.ratioLabel}>PAYLOAD USED ({isFifthWheel ? 'PIN WEIGHT' : 'TONGUE WEIGHT'})</Text>
                  <Text style={[styles.ratioPct, { color: safetyResult.payloadRatio > 1 ? Colors.red : safetyResult.payloadRatio > 0.8 ? '#87BFFF' : '#4DA6FF' }]}>{Math.round(safetyResult.payloadRatio * 100)}%</Text>
                </View>
                <View style={styles.ratioTrack}>
                  <View style={[styles.ratioFill, { width: `${Math.min(100, safetyResult.payloadRatio * 100)}%` as any, backgroundColor: safetyResult.payloadRatio > 1 ? Colors.red : safetyResult.payloadRatio > 0.8 ? '#87BFFF' : '#4DA6FF' }]} />
                </View>
                <View style={styles.ratioMeta}>
                  <Text style={styles.ratioMetaText}>{isFifthWheel ? 'Pin' : 'Tongue'}: {fmt(tongueWeight > 0 ? tongueWeight : Math.round(rvGvwr * autoWeightPct))} lbs</Text>
                  <Text style={styles.ratioMetaText}>Max Payload: {fmt(selectedTrimSpec.maxPayload)} lbs</Text>
                </View>
              </View>
              <View style={[styles.gcwrCard, safetyResult.gcwrHeadroom < 0 && styles.gcwrCardDanger, safetyResult.gcwrHeadroom >= 0 && safetyResult.gcwrHeadroom < 2000 && styles.gcwrCardCaution]}>
                <View style={styles.gcwrRow}><Text style={styles.gcwrLabel}>COMBINED (Curb + RV GVWR)</Text><Text style={styles.gcwrValue}>{fmt(safetyResult.gcwrUsed)} lbs</Text></View>
                <View style={styles.gcwrRow}><Text style={styles.gcwrLabel}>GCWR LIMIT</Text><Text style={styles.gcwrValue}>{fmt(selectedTrimSpec.gcwr)} lbs</Text></View>
                <View style={styles.gcwrDivider} />
                <View style={styles.gcwrRow}>
                  <Text style={styles.gcwrHeadroomLabel}>GCWR HEADROOM</Text>
                  <Text style={[styles.gcwrHeadroomValue, { color: safetyResult.gcwrHeadroom < 0 ? Colors.red : safetyResult.gcwrHeadroom < 2000 ? '#87BFFF' : '#4DA6FF' }]}>
                    {safetyResult.gcwrHeadroom < 0 ? '-' : '+'}{fmt(Math.abs(safetyResult.gcwrHeadroom))} lbs
                  </Text>
                </View>
              </View>
            </View>

            {(safetyResult.issues.length > 0 || safetyResult.recommendations.length > 0) && (
              <View style={styles.card}>
                {safetyResult.issues.length > 0 && (
                  <>
                    <View style={styles.cardHeaderRow}><MaterialIcons name="warning-amber" size={16} color={Colors.red} /><Text style={[styles.cardTitle, { color: Colors.red }]}>Issues Found</Text></View>
                    {safetyResult.issues.map((issue, i) => (
                      <View key={i} style={styles.issueRow}><MaterialIcons name="cancel" size={15} color={Colors.red} style={{ marginTop: 1 }} /><Text style={styles.issueText}>{issue}</Text></View>
                    ))}
                    <View style={styles.cardDivider} />
                  </>
                )}
                {safetyResult.recommendations.length > 0 && (
                  <>
                    <View style={styles.cardHeaderRow}><MaterialIcons name="lightbulb" size={16} color={Colors.blueBright} /><Text style={[styles.cardTitle, { color: Colors.blueBright }]}>Recommendations</Text></View>
                    {safetyResult.recommendations.map((rec, i) => (
                      <View key={i} style={styles.recRow}><MaterialIcons name="chevron-right" size={15} color={Colors.blueBright} style={{ marginTop: 1 }} /><Text style={styles.recText}>{rec}</Text></View>
                    ))}
                  </>
                )}
              </View>
            )}

            <View style={styles.card}>
              <View style={styles.cardHeaderRow}><MaterialIcons name="link" size={16} color={Colors.blueBright} /><Text style={[styles.cardTitle, { color: Colors.blueBright }]}>Hitch Class Recommendation</Text></View>
              {HITCH_CLASSES.map((h, i) => {
                const isRec = h.cls === hitchRec.cls;
                const isOem = h.cls === selectedTrimSpec.hitch;
                return (
                  <View key={i} style={[styles.hitchRow2, isRec && { borderColor: h.color + '55', backgroundColor: h.color + '0D' }]}>
                    <View style={[styles.hitchColorDot, { backgroundColor: h.color }]} />
                    <View style={{ flex: 1 }}>
                      <View style={styles.hitchNameRow}>
                        <Text style={[styles.hitchClassName, isRec && { color: h.color }]}>{h.cls}</Text>
                        {isRec && <View style={[styles.hitchBadge, { backgroundColor: h.color }]}><Text style={styles.hitchBadgeText}>RECOMMENDED</Text></View>}
                        {isOem && !isRec && <View style={[styles.hitchBadge, { backgroundColor: Colors.bgCardAlt, borderWidth: 1, borderColor: Colors.border }]}><Text style={[styles.hitchBadgeText, { color: Colors.textSecondary }]}>OEM</Text></View>}
                      </View>
                      <Text style={styles.hitchClassSub}>Up to {fmt(h.maxTow)} lbs — {h.desc}</Text>
                    </View>
                  </View>
                );
              })}
            </View>

            <Text style={styles.disclaimer}>
              Specs sourced from manufacturer tow guides. Ratings shown are maximum figures for the stated trim/package
              configuration — actual capacity depends on cab, bed, drivetrain, and optional equipment. Always verify your
              door sticker and owner manual before towing. RvFOX Pro {new Date().getFullYear()}
            </Text>
          </>
        ) : (
          <View style={styles.emptyState}>
            <View style={styles.emptyIconWrap}><MaterialIcons name="local-shipping" size={36} color={Colors.textDim} /></View>
            <Text style={styles.emptyTitle}>Select truck + trim + enter RV GVWR</Text>
            <Text style={styles.emptySub}>Exact tow rating · Payload · GCWR · Safety Score · Hitch Class</Text>
            <View style={styles.emptyTips}>
              {[
                'Trim matters: F-150 base tows 8,200 lbs; Platinum Max Tow tows 13,000 lbs',
                '80% Rule: Keep tow weight under 80% of max rating for safety margin',
                'Tongue weight should be 10–15% of trailer GVWR',
                'Always add passenger + gear weight to payload calculation',
              ].map((tip, i) => (
                <View key={i} style={styles.emptyTipRow}>
                  <MaterialIcons name="tips-and-updates" size={13} color={Colors.blueBright} />
                  <Text style={styles.emptyTipText}>{tip}</Text>
                </View>
              ))}
            </View>
          </View>
        )}
      </ScrollView>

      {/* ── Pre-Trip Safety Checklist Modal ── */}
      <Modal visible={checklistOpen} transparent animationType="slide" onRequestClose={() => setChecklistOpen(false)}>
        <View style={clStyles.overlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setChecklistOpen(false)} />
          <View style={[clStyles.panel, { paddingBottom: insets.bottom + 8 }]}>
            <View style={clStyles.handle} />
            <View style={clStyles.header}>
              <View style={clStyles.headerLeft}>
                <MaterialIcons name="checklist" size={20} color={Colors.blueBright} />
                <View>
                  <Text style={clStyles.headerTitle}>Pre-Trip Checklist</Text>
                  <Text style={clStyles.headerSub}>Complete before every tow</Text>
                </View>
              </View>
              <Pressable style={clStyles.closeBtn} onPress={() => setChecklistOpen(false)} hitSlop={8}>
                <MaterialIcons name="close" size={18} color={Colors.textSecondary} />
              </Pressable>
            </View>

            {/* Progress bar */}
            <View style={clStyles.progressWrap}>
              <View style={clStyles.progressTrack}>
                <View style={[clStyles.progressFill, {
                  width: `${(checkedCount / totalChecklist) * 100}%` as any,
                  backgroundColor: allChecked ? '#4DA6FF' : Colors.blueBright,
                }]} />
              </View>
              <Text style={[clStyles.progressLabel, { color: allChecked ? '#4DA6FF' : Colors.blueBright }]}>
                {allChecked ? '✓  ALL CLEAR — SAFE TO TOW' : `${checkedCount} of ${totalChecklist} items checked`}
              </Text>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled contentContainerStyle={{ paddingBottom: 8 }}>
              {CHECKLIST_CATEGORIES.map(cat => (
                <View key={cat} style={clStyles.categorySection}>
                  <Text style={clStyles.categoryLabel}>{cat}</Text>
                  {CHECKLIST_ITEMS.filter(i => i.category === cat).map(item => {
                    const isChecked = !!checked[item.id];
                    return (
                      <Pressable
                        key={item.id}
                        style={({ pressed }) => [clStyles.itemRow, isChecked && clStyles.itemRowChecked, pressed && { opacity: 0.75 }]}
                        onPress={() => toggleCheck(item.id)}
                      >
                        <View style={[clStyles.checkBox, isChecked && clStyles.checkBoxChecked]}>
                          {isChecked && <MaterialIcons name="check" size={14} color="#000" />}
                        </View>
                        <View style={clStyles.itemBody}>
                          <Text style={[clStyles.itemLabel, isChecked && clStyles.itemLabelChecked]}>{item.label}</Text>
                          <Text style={clStyles.itemDesc}>{item.desc}</Text>
                        </View>
                        <MaterialIcons name={item.icon as any} size={16} color={isChecked ? '#4DA6FF' : Colors.textDim} />
                      </Pressable>
                    );
                  })}
                </View>
              ))}
            </ScrollView>

            <View style={clStyles.footer}>
              <Pressable style={({ pressed }) => [clStyles.resetBtn, pressed && { opacity: 0.7 }]} onPress={resetChecklist}>
                <MaterialIcons name="refresh" size={16} color={Colors.textSecondary} />
                <Text style={clStyles.resetBtnText}>Reset All</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [clStyles.doneBtn, allChecked && clStyles.doneBtnReady, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]}
                onPress={() => setChecklistOpen(false)}
              >
                <MaterialIcons name={allChecked ? 'check-circle' : 'close'} size={16} color={allChecked ? '#000' : Colors.blueBright} />
                <Text style={[clStyles.doneBtnText, allChecked && { color: '#000' }]}>
                  {allChecked ? 'All Clear — Close' : 'Close'}
                </Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A2A3A' },
  heroBackdrop: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, paddingBottom: Spacing.md, zIndex: 2 },
  headerTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.extrabold, color: '#FFFFFF', letterSpacing: 1 },
  headerBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: 'rgba(0,104,192,0.1)', borderWidth: 1, borderColor: Colors.borderBlue, paddingHorizontal: 12, paddingVertical: 7, borderRadius: Radius.full },
  headerBadgeText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.blueBright },
  checklistBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(0,104,192,0.10)', borderWidth: 1, borderColor: Colors.borderBlue, paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.full },
  checklistBtnText: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.blueBright },
  checklistBadge: { backgroundColor: Colors.blue, borderRadius: Radius.full, paddingHorizontal: 5, paddingVertical: 1 },
  checklistBadgeText: { fontSize: 9, fontWeight: FontWeight.bold, color: '#fff' },
  card: { marginHorizontal: Spacing.md, marginBottom: Spacing.md, backgroundColor: 'rgba(4,8,22,0.82)', borderRadius: Radius.xl, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.22)', padding: Spacing.md, gap: Spacing.md, zIndex: 2, shadowColor: '#4A9BD4', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.20, shadowRadius: 14, elevation: 4 },
  cardHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  cardTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#FFFFFF' },
  cardSub: { fontSize: FontSize.sm, color: Colors.textSecondary, marginTop: -Spacing.sm },
  cardDivider: { height: 1, backgroundColor: Colors.border, marginVertical: Spacing.xs },
  fieldGroup: { gap: Spacing.xs },
  fieldLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: '#FFFFFF', letterSpacing: 1.2 },
  fieldHint: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },
  input: { backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 12, color: '#FFFFFF', fontSize: FontSize.md },
  trimNoteCard: { flexDirection: 'row', alignItems: 'flex-start', gap: 7, backgroundColor: 'rgba(77,166,255,0.08)', borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(77,166,255,0.3)', padding: Spacing.sm },
  trimNoteText: { flex: 1, fontSize: FontSize.xs, color: Colors.blueBright, lineHeight: 17 },
  trimPromptCard: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, marginHorizontal: Spacing.md, marginBottom: Spacing.md, backgroundColor: 'rgba(77,166,255,0.06)', borderRadius: Radius.xl, borderWidth: 1.5, borderColor: 'rgba(77,166,255,0.3)', padding: Spacing.md, zIndex: 2 },
  trimPromptTitle: { fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.blueBright, marginBottom: 4 },
  trimPromptSub: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 18 },
  specsPanel: { marginHorizontal: Spacing.md, marginBottom: Spacing.md, backgroundColor: 'rgba(4,8,22,0.85)', borderWidth: 1.5, borderColor: Colors.borderBlue, borderRadius: Radius.xl, padding: Spacing.md, gap: Spacing.md, shadowColor: Colors.blue, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.18, shadowRadius: 12, elevation: 4, zIndex: 2 },
  specsPanelHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.xs },
  specsPanelTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: '#FFFFFF', flex: 1, lineHeight: 20 },
  specsPanelTrim: { fontSize: FontSize.xs, color: Colors.textSecondary, marginTop: -Spacing.sm, lineHeight: 17 },
  specsGrid: { flexDirection: 'row', gap: Spacing.sm },
  hitchRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  hitchText: { fontSize: FontSize.sm, color: Colors.textMuted },
  hitchClass: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.blueBright },
  estimateNote: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: 'rgba(0,104,192,0.07)', borderRadius: Radius.sm, paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs + 2 },
  estimateNoteText: { fontSize: FontSize.xs, color: Colors.blueBright, flex: 1 },
  safetyHero: { marginHorizontal: Spacing.md, marginBottom: Spacing.md, backgroundColor: 'rgba(4,8,22,0.88)', borderWidth: 1.5, borderColor: Colors.borderBlue, borderRadius: Radius.xl, padding: Spacing.md, shadowColor: Colors.blue, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.20, shadowRadius: 16, elevation: 5, zIndex: 2 },
  ratioSection: { gap: Spacing.xs },
  ratioHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  ratioLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 1 },
  ratioPct: { fontSize: FontSize.md, fontWeight: FontWeight.extrabold },
  ratioTrack: { height: 10, backgroundColor: Colors.bgCardAlt, borderRadius: 5, borderWidth: 1, borderColor: Colors.border, overflow: 'hidden', position: 'relative' },
  ratioSafe: { position: 'absolute', left: 0, width: '80%', height: '100%', borderRightWidth: 2, borderRightColor: 'rgba(255,255,255,0.15)', borderStyle: 'dashed', alignItems: 'flex-end', justifyContent: 'center' },
  ratioZoneText: { fontSize: 7, color: 'rgba(255,255,255,0.25)', paddingRight: 4 },
  ratioFill: { position: 'absolute', left: 0, top: 0, height: '100%', borderRadius: 5, opacity: 0.8 },
  ratioMeta: { flexDirection: 'row', justifyContent: 'space-between' },
  ratioMetaText: { fontSize: FontSize.xs, color: Colors.textMuted },
  gcwrCard: { backgroundColor: Colors.bgCardAlt, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, padding: Spacing.sm, gap: 8 },
  gcwrCardDanger: { borderColor: Colors.red + '44', backgroundColor: Colors.red + '0A' },
  gcwrCardCaution: { borderColor: 'rgba(135,191,255,0.27)', backgroundColor: 'rgba(135,191,255,0.06)' },
  gcwrRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  gcwrLabel: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.semibold },
  gcwrValue: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  gcwrDivider: { height: 1, backgroundColor: Colors.border },
  gcwrHeadroomLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, letterSpacing: 0.8 },
  gcwrHeadroomValue: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold },
  issueRow: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm },
  issueText: { flex: 1, fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20 },
  recRow: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm },
  recText: { flex: 1, fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20 },
  hitchRow2: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, padding: 10, borderRadius: Radius.md, borderWidth: 1, borderColor: 'transparent' },
  hitchColorDot: { width: 10, height: 10, borderRadius: 5, flexShrink: 0 },
  hitchNameRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: 2 },
  hitchClassName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  hitchClassSub: { fontSize: FontSize.xs, color: Colors.textMuted },
  hitchBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: Radius.full },
  hitchBadgeText: { fontSize: 9, fontWeight: FontWeight.extrabold, color: '#000', letterSpacing: 0.5 },
  fwCard: { marginHorizontal: Spacing.md, marginBottom: Spacing.md, backgroundColor: 'rgba(4,8,22,0.82)', borderRadius: Radius.xl, borderWidth: 1.5, borderColor: 'rgba(77,166,255,0.40)', padding: Spacing.md, gap: Spacing.sm, zIndex: 2 },
  fwCompareRow: { flexDirection: 'row', alignItems: 'stretch', gap: 8 },
  fwCompareCol: { flex: 1, backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, padding: Spacing.sm, alignItems: 'center', gap: 4 },
  fwCompareColActive: { borderColor: 'rgba(77,166,255,0.5)', backgroundColor: 'rgba(77,166,255,0.06)' },
  fwCompareColActiveGold: { borderColor: 'rgba(77,166,255,0.45)', backgroundColor: 'rgba(77,166,255,0.06)' },
  fwCompareHead: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textMuted, marginTop: 4, textAlign: 'center' },
  fwCompareStat: { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },
  fwCompareVal: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textMuted },
  fwCompareSub: { fontSize: 9, color: Colors.textDim, marginTop: -4, textAlign: 'center' },
  fwDivider: { width: '100%', height: 1, backgroundColor: Colors.border, marginVertical: 4 },
  fwCompareFeature: { fontSize: 10, color: Colors.textSecondary, textAlign: 'center', lineHeight: 16 },
  fwVsDivider: { width: 28, alignItems: 'center', justifyContent: 'center' },
  fwVsText: { fontSize: FontSize.xs, fontWeight: FontWeight.extrabold, color: Colors.textDim },
  fwHitchResult: { flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: Radius.md, paddingHorizontal: Spacing.sm, paddingVertical: 7 },
  fwHitchOk: { backgroundColor: 'rgba(74,222,128,0.08)', borderWidth: 1, borderColor: 'rgba(74,222,128,0.3)' },
  fwHitchWarn: { backgroundColor: 'rgba(255,140,0,0.08)', borderWidth: 1, borderColor: 'rgba(255,140,0,0.35)' },
  fwHitchResultText: { fontSize: FontSize.xs, fontWeight: FontWeight.extrabold, letterSpacing: 0.8 },
  fwHitchMsg: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 18 },
  fwBedPrompt: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(77,166,255,0.06)', borderRadius: Radius.sm, padding: Spacing.xs + 2 },
  fwBedPromptText: { flex: 1, fontSize: FontSize.xs, color: Colors.blueBright },
  fwPayloadNote: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: Radius.md, padding: Spacing.sm },
  fwPayloadNoteText: { flex: 1, fontSize: 11, color: Colors.textMuted, lineHeight: 16 },
  disclaimer: { fontSize: FontSize.xs, color: Colors.textDim, textAlign: 'center', marginHorizontal: Spacing.md, marginBottom: Spacing.md, lineHeight: 16, zIndex: 2 },
  emptyState: { alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: Spacing.xl, gap: Spacing.md, zIndex: 2 },
  emptyIconWrap: { width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(4,8,22,0.85)', borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: '#FFFFFF', textAlign: 'center' },
  emptySub: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center' },
  emptyTips: { width: '100%', backgroundColor: 'rgba(4,8,22,0.85)', borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.borderBlue, padding: Spacing.md, gap: Spacing.sm, marginTop: Spacing.sm },
  emptyTipRow: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm },
  emptyTipText: { flex: 1, fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 18 },
});

// ─── CHECKLIST MODAL STYLES ───────────────────────────────────────────────────

const clStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.72)', justifyContent: 'flex-end' },
  panel: {
    backgroundColor: '#080E18', borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    borderTopWidth: 2, borderColor: Colors.borderBlue, maxHeight: '90%',
    paddingHorizontal: Spacing.md, paddingTop: 8,
    shadowColor: Colors.blue, shadowOffset: { width: 0, height: -6 }, shadowOpacity: 0.40, shadowRadius: 20, elevation: 20,
  },
  handle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.sm },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: Spacing.sm },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  headerSub: { fontSize: FontSize.xs, color: Colors.textMuted },
  closeBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.07)', alignItems: 'center', justifyContent: 'center' },
  progressWrap: { marginBottom: Spacing.md, gap: 6 },
  progressTrack: { height: 8, backgroundColor: Colors.bgCardAlt, borderRadius: 4, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border },
  progressFill: { height: '100%', borderRadius: 4, opacity: 0.85 },
  progressLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, letterSpacing: 0.8, textAlign: 'center' },
  categorySection: { marginBottom: Spacing.md },
  categoryLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.extrabold, color: Colors.textMuted, letterSpacing: 1.5, marginBottom: Spacing.xs, marginLeft: 4 },
  itemRow: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, paddingVertical: 11, paddingHorizontal: Spacing.sm, borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', backgroundColor: 'rgba(255,255,255,0.02)', marginBottom: 6 },
  itemRowChecked: { backgroundColor: 'rgba(74,222,128,0.06)', borderColor: 'rgba(74,222,128,0.30)' },
  checkBox: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: Colors.borderBlue, backgroundColor: 'rgba(0,104,192,0.06)', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 },
  checkBoxChecked: { backgroundColor: '#4DA6FF', borderColor: '#4DA6FF' },
  itemBody: { flex: 1, gap: 2 },
  itemLabel: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  itemLabelChecked: { color: Colors.textSecondary, textDecorationLine: 'line-through' },
  itemDesc: { fontSize: FontSize.xs, color: Colors.textMuted, lineHeight: 16 },
  footer: { flexDirection: 'row', gap: Spacing.sm, paddingTop: Spacing.sm, borderTopWidth: 1, borderTopColor: Colors.border },
  resetBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1, justifyContent: 'center', borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.full, paddingVertical: 13, backgroundColor: 'rgba(255,255,255,0.04)' },
  resetBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
  doneBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 2, justifyContent: 'center', borderWidth: 1, borderColor: Colors.borderBlue, borderRadius: Radius.full, paddingVertical: 13, backgroundColor: 'rgba(0,104,192,0.12)' },
  doneBtnReady: { backgroundColor: '#4DA6FF', borderColor: '#4DA6FF' },
  doneBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.blueBright },
});
