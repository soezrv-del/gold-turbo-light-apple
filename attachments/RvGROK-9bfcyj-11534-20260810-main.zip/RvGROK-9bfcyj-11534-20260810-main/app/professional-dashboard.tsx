/**
 * Professional Dashboard
 * Gated behind rvfox.professional.monthly subscription
 * Features: Bulk VIN lookup · Saved client reports · Dealership branding settings
 */
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
  Modal, FlatList,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useState, useCallback, useRef } from 'react';
import { getSupabaseClient } from '@/template';
import { useSubscriptionContext } from '@/contexts/SubscriptionContext';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface VinResult {
  vin: string;
  status: 'loading' | 'success' | 'error';
  year?: string;
  make?: string;
  model?: string;
  bodyClass?: string;
  fuelType?: string;
  gvwr?: string;
  errorText?: string;
}

interface SavedReport {
  id: string;
  vin: string;
  year: string;
  make: string;
  model: string;
  clientName: string;
  savedAt: string;
  bodyClass: string;
}

interface DealerBranding {
  dealerName: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  logoUrl: string;
  tagline: string;
}

// ─── SECTION HEADER ──────────────────────────────────────────────────────────

function SectionHeader({ icon, label, color = Colors.gold }: {
  icon: string; label: string; color?: string;
}) {
  return (
    <View style={sh.row}>
      <MaterialIcons name={icon as any} size={14} color={color} />
      <Text style={[sh.label, { color }]}>{label}</Text>
    </View>
  );
}
const sh = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: Spacing.md },
  label: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, letterSpacing: 1.8 },
});

// ─── VIN RESULT ROW ──────────────────────────────────────────────────────────

function VinResultRow({
  item, onSave, onView,
}: {
  item: VinResult;
  onSave: () => void;
  onView: () => void;
}) {
  const isLoading = item.status === 'loading';
  const isError   = item.status === 'error';
  const isOk      = item.status === 'success';

  return (
    <View style={vr.row}>
      {/* Status icon */}
      <View style={[vr.statusDot,
        { backgroundColor: isLoading ? 'rgba(77,166,255,0.15)' : isError ? 'rgba(255,68,68,0.15)' : 'rgba(74,222,128,0.15)' },
      ]}>
        {isLoading ? (
          <ActivityIndicator size="small" color={Colors.blueBright} style={{ transform: [{ scale: 0.75 }] }} />
        ) : (
          <MaterialIcons
            name={isError ? 'cancel' : 'check-circle'}
            size={16}
            color={isError ? Colors.red : Colors.green}
          />
        )}
      </View>

      {/* VIN info */}
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={vr.vin}>{item.vin}</Text>
        {isOk ? (
          <Text style={vr.vehicle} numberOfLines={1}>
            {item.year} {item.make} {item.model}
            {item.bodyClass ? ` · ${item.bodyClass}` : ''}
          </Text>
        ) : isError ? (
          <Text style={vr.error}>{item.errorText ?? 'Decode failed'}</Text>
        ) : (
          <Text style={vr.loading}>Decoding…</Text>
        )}
      </View>

      {/* Actions */}
      {isOk ? (
        <View style={vr.actions}>
          <Pressable style={({ pressed }) => [vr.actionBtn, vr.saveBtn, pressed && { opacity: 0.75 }]} onPress={onSave}>
            <MaterialIcons name="bookmark-add" size={13} color="#000" />
            <Text style={vr.saveBtnText}>Save</Text>
          </Pressable>
          <Pressable style={({ pressed }) => [vr.actionBtn, vr.viewBtn, pressed && { opacity: 0.75 }]} onPress={onView}>
            <MaterialIcons name="open-in-new" size={13} color={Colors.gold} />
          </Pressable>
        </View>
      ) : null}
    </View>
  );
}
const vr = StyleSheet.create({
  row: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  statusDot: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  vin: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary, letterSpacing: 1 },
  vehicle: { fontSize: FontSize.xs, color: Colors.textSecondary },
  error: { fontSize: FontSize.xs, color: Colors.red },
  loading: { fontSize: FontSize.xs, color: Colors.textMuted },
  actions: { flexDirection: 'row', gap: 6 },
  actionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    borderRadius: Radius.full, paddingHorizontal: 10, paddingVertical: 6,
  },
  saveBtn: { backgroundColor: Colors.gold },
  saveBtnText: { fontSize: 11, fontWeight: FontWeight.bold, color: '#000' },
  viewBtn: {
    backgroundColor: 'rgba(255,215,0,0.1)', borderWidth: 1, borderColor: Colors.borderGold,
  },
});

// ─── SAVED REPORT CARD ────────────────────────────────────────────────────────

function SavedReportCard({
  report, onDelete, onView,
}: {
  report: SavedReport;
  onDelete: () => void;
  onView: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [scard.wrap, pressed && { opacity: 0.85 }]}
      onPress={onView}
    >
      <View style={scard.iconWrap}>
        <MaterialIcons name="directions-bus" size={20} color={Colors.gold} />
      </View>
      <View style={{ flex: 1, gap: 3 }}>
        {report.clientName ? (
          <Text style={scard.client}>{report.clientName}</Text>
        ) : null}
        <Text style={scard.vehicle}>{report.year} {report.make} {report.model}</Text>
        <Text style={scard.vin}>{report.vin}</Text>
        <Text style={scard.date}>{new Date(report.savedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</Text>
      </View>
      <View style={scard.actions}>
        <Pressable
          style={({ pressed }) => [scard.viewBtn, pressed && { opacity: 0.75 }]}
          onPress={onView}
        >
          <MaterialIcons name="open-in-new" size={14} color={Colors.gold} />
        </Pressable>
        <Pressable
          style={({ pressed }) => [scard.deleteBtn, pressed && { opacity: 0.75 }]}
          onPress={onDelete}
          hitSlop={8}
        >
          <MaterialIcons name="delete-outline" size={16} color={Colors.textMuted} />
        </Pressable>
      </View>
    </Pressable>
  );
}
const scard = StyleSheet.create({
  wrap: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: 12, paddingHorizontal: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  iconWrap: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: 'rgba(255,215,0,0.1)', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.borderGold,
  },
  client: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  vehicle: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
  vin: { fontSize: FontSize.xs, color: Colors.textMuted, letterSpacing: 0.8, fontWeight: FontWeight.medium },
  date: { fontSize: FontSize.xs, color: Colors.textMuted },
  actions: { gap: 6, alignItems: 'center' },
  viewBtn: {
    width: 32, height: 32, borderRadius: 8,
    backgroundColor: 'rgba(255,215,0,0.1)', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.borderGold,
  },
  deleteBtn: {
    width: 32, height: 32, borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.04)', alignItems: 'center', justifyContent: 'center',
  },
});

// ─── SAVE CLIENT MODAL ────────────────────────────────────────────────────────

function SaveClientModal({
  visible, vinResult, onSave, onClose,
}: {
  visible: boolean;
  vinResult: VinResult | null;
  onSave: (clientName: string) => void;
  onClose: () => void;
}) {
  const [clientName, setClientName] = useState('');

  const handleSave = () => {
    onSave(clientName.trim());
    setClientName('');
    onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.8)' }}
      >
        <View style={scm.sheet}>
          <View style={scm.handle} />
          <Text style={scm.title}>Save to Client Reports</Text>
          {vinResult ? (
            <View style={scm.vehicleBadge}>
              <MaterialIcons name="directions-bus" size={14} color={Colors.gold} />
              <Text style={scm.vehicleBadgeText}>
                {vinResult.year} {vinResult.make} {vinResult.model}
              </Text>
            </View>
          ) : null}
          <Text style={scm.label}>Client Name (optional)</Text>
          <TextInput
            style={scm.input}
            value={clientName}
            onChangeText={setClientName}
            placeholder="e.g. John Smith"
            placeholderTextColor={Colors.textMuted}
            autoCapitalize="words"
            returnKeyType="done"
            onSubmitEditing={handleSave}
          />
          <Pressable
            style={({ pressed }) => [scm.saveBtn, pressed && { opacity: 0.85 }]}
            onPress={handleSave}
          >
            <MaterialIcons name="bookmark-add" size={18} color="#000" />
            <Text style={scm.saveBtnText}>Save Report</Text>
          </Pressable>
          <Pressable onPress={onClose} style={{ marginTop: Spacing.sm }} hitSlop={8}>
            <Text style={scm.cancelText}>Cancel</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
const scm = StyleSheet.create({
  sheet: {
    backgroundColor: '#060D1F',
    borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl,
    borderTopWidth: 2,
    borderColor: Colors.gold,
    padding: Spacing.xl,
    paddingBottom: 36,
    gap: Spacing.md,
    shadowColor: Colors.gold,
    shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 20,
  },
  handle: { width: 36, height: 4, backgroundColor: Colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.xs },
  title: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  vehicleBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: 'rgba(255,215,0,0.08)',
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.borderGold,
    paddingHorizontal: Spacing.md, paddingVertical: 10,
  },
  vehicleBadgeText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.gold },
  label: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.green, letterSpacing: 1.2 },
  input: {
    backgroundColor: 'rgba(10,28,60,0.85)',
    borderWidth: 1.5, borderColor: 'rgba(30,111,255,0.45)',
    borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 14,
    color: Colors.textPrimary, fontSize: FontSize.base,
  },
  saveBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.full, paddingVertical: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.45, shadowRadius: 12, elevation: 6,
  },
  saveBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#000' },
  cancelText: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center' },
});

// ─── BRANDING FIELD ──────────────────────────────────────────────────────────

function BrandingField({
  label, value, onChange, placeholder, icon, multiline = false, keyboardType = 'default',
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  icon: string;
  multiline?: boolean;
  keyboardType?: 'default' | 'email-address' | 'phone-pad' | 'url';
}) {
  return (
    <View style={bf.wrap}>
      <Text style={bf.label}>{label}</Text>
      <View style={bf.inputRow}>
        <MaterialIcons name={icon as any} size={15} color={Colors.textMuted} style={{ marginLeft: Spacing.sm }} />
        <TextInput
          style={[bf.input, multiline && { height: 72, textAlignVertical: 'top', paddingTop: 12 }]}
          value={value}
          onChangeText={onChange}
          placeholder={placeholder}
          placeholderTextColor={Colors.textMuted}
          keyboardType={keyboardType}
          autoCorrect={false}
          multiline={multiline}
          returnKeyType={multiline ? 'default' : 'next'}
        />
      </View>
    </View>
  );
}
const bf = StyleSheet.create({
  wrap: { gap: Spacing.xs },
  label: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.green, letterSpacing: 1 },
  inputRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(10,28,60,0.85)',
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.35)',
    borderRadius: Radius.md, overflow: 'hidden',
  },
  input: {
    flex: 1, color: Colors.textPrimary, fontSize: FontSize.sm,
    paddingHorizontal: Spacing.sm, paddingVertical: 13,
    fontWeight: FontWeight.medium,
  },
});

// ─── PRO GATE ────────────────────────────────────────────────────────────────

function ProGate({ onUpgrade }: { onUpgrade: () => void }) {
  return (
    <View style={pg.container}>
      <View style={pg.iconWrap}>
        <MaterialIcons name="workspace-premium" size={48} color={Colors.gold} />
      </View>
      <Text style={pg.title}>Professional Dashboard</Text>
      <Text style={pg.sub}>
        This feature is exclusively available to RvFOX Professional subscribers ($29.99/mo).
      </Text>
      <View style={pg.featuresBox}>
        {[
          'Bulk VIN lookup — decode up to 10 VINs at once',
          'Client report management — save & organize by customer',
          'Dealership branding — logo + contact info on PDF reports',
          'Priority access to new professional features',
        ].map((f, i) => (
          <View key={i} style={pg.featureRow}>
            <MaterialIcons name="check-circle" size={14} color={Colors.gold} />
            <Text style={pg.featureText}>{f}</Text>
          </View>
        ))}
      </View>
      <Pressable
        style={({ pressed }) => [pg.upgradeBtn, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]}
        onPress={onUpgrade}
      >
        <MaterialIcons name="workspace-premium" size={20} color="#000" />
        <Text style={pg.upgradeBtnText}>Upgrade to Professional</Text>
      </Pressable>
      <Text style={pg.price}>$29.99/month · Cancel anytime</Text>
    </View>
  );
}
const pg = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.xl, gap: Spacing.md },
  iconWrap: {
    width: 96, height: 96, borderRadius: 48,
    backgroundColor: 'rgba(255,215,0,0.1)', borderWidth: 2, borderColor: Colors.borderGold,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.5, shadowRadius: 20, elevation: 8,
  },
  title: { fontSize: FontSize.h2, fontWeight: FontWeight.extrabold, color: Colors.textPrimary, textAlign: 'center' },
  sub: { fontSize: FontSize.sm, color: Colors.textSecondary, textAlign: 'center', lineHeight: 21, maxWidth: 320 },
  featuresBox: {
    width: '100%', backgroundColor: 'rgba(255,215,0,0.04)',
    borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.borderGold,
    padding: Spacing.md, gap: Spacing.sm,
  },
  featureRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  featureText: { flex: 1, fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20 },
  upgradeBtn: {
    width: '100%', backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingVertical: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.45, shadowRadius: 14, elevation: 6,
  },
  upgradeBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#000' },
  price: { fontSize: FontSize.xs, color: Colors.textMuted, textAlign: 'center' },
});

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

const INITIAL_BRANDING: DealerBranding = {
  dealerName: '',
  address: '',
  phone: '',
  email: '',
  website: '',
  logoUrl: '',
  tagline: '',
};

export default function ProfessionalDashboard() {
  const router  = useRouter();
  const insets  = useSafeAreaInsets();
  const { tier, isActive } = useSubscriptionContext();

  const isPro = tier === 'professional';

  // ── Bulk VIN state ──────────────────────────────────────────────────────
  const [vinInput, setVinInput]         = useState('');
  const [vinResults, setVinResults]     = useState<VinResult[]>([]);
  const [bulkLoading, setBulkLoading]   = useState(false);

  // ── Saved reports ────────────────────────────────────────────────────────
  const [savedReports, setSavedReports] = useState<SavedReport[]>([]);
  const [saveModal, setSaveModal]       = useState(false);
  const [saveTarget, setSaveTarget]     = useState<VinResult | null>(null);

  // ── Branding ─────────────────────────────────────────────────────────────
  const [branding, setBranding]         = useState<DealerBranding>(INITIAL_BRANDING);
  const [brandingSaved, setBrandingSaved] = useState(false);

  // ── Active tab ────────────────────────────────────────────────────────────
  type Tab = 'vins' | 'reports' | 'branding';
  const [activeTab, setActiveTab] = useState<Tab>('vins');

  // ── Parse VINs from input ────────────────────────────────────────────────
  const parseVins = useCallback((raw: string): string[] => {
    return raw
      .split(/[\n,;\s]+/)
      .map(v => v.trim().toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, ''))
      .filter(v => v.length === 17)
      .slice(0, 10);
  }, []);

  // ── Run bulk decode ──────────────────────────────────────────────────────
  const handleBulkDecode = useCallback(async () => {
    const vins = parseVins(vinInput);
    if (vins.length === 0) {
      Alert.alert('No Valid VINs', 'Paste 1–10 valid 17-character VINs separated by commas or new lines.');
      return;
    }

    setBulkLoading(true);
    // Initialize all as loading
    setVinResults(vins.map(vin => ({ vin, status: 'loading' })));

    const supabase = getSupabaseClient();

    // Decode concurrently (throttled to avoid rate limiting)
    const BATCH = 3;
    for (let i = 0; i < vins.length; i += BATCH) {
      const batch = vins.slice(i, i + BATCH);
      await Promise.allSettled(
        batch.map(async (vin) => {
          try {
            const { data, error } = await supabase.functions.invoke('vin-decoder', {
              body: { vin },
            });
            setVinResults(prev => prev.map(r =>
              r.vin === vin
                ? error || data?.error
                  ? { vin, status: 'error', errorText: data?.error ?? 'Decode failed' }
                  : {
                      vin,
                      status: 'success',
                      year: data.year,
                      make: data.make,
                      model: data.model,
                      bodyClass: data.bodyClass,
                      fuelType: data.fuelType,
                      gvwr: data.gvwr,
                    }
                : r
            ));
          } catch {
            setVinResults(prev => prev.map(r =>
              r.vin === vin ? { vin, status: 'error', errorText: 'Network error' } : r
            ));
          }
        })
      );
      // Small delay between batches
      if (i + BATCH < vins.length) await new Promise(res => setTimeout(res, 400));
    }

    setBulkLoading(false);
  }, [vinInput, parseVins]);

  const handleSaveReport = useCallback((vinResult: VinResult) => {
    setSaveTarget(vinResult);
    setSaveModal(true);
  }, []);

  const handleConfirmSave = useCallback((clientName: string) => {
    if (!saveTarget || saveTarget.status !== 'success') return;
    const report: SavedReport = {
      id: `${saveTarget.vin}-${Date.now()}`,
      vin: saveTarget.vin,
      year: saveTarget.year ?? '',
      make: saveTarget.make ?? '',
      model: saveTarget.model ?? '',
      bodyClass: saveTarget.bodyClass ?? '',
      clientName,
      savedAt: new Date().toISOString(),
    };
    setSavedReports(prev => [report, ...prev]);
  }, [saveTarget]);

  const handleDeleteReport = useCallback((id: string) => {
    Alert.alert('Delete Report', 'Remove this saved report?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => setSavedReports(prev => prev.filter(r => r.id !== id)) },
    ]);
  }, []);

  const updateBranding = (key: keyof DealerBranding) => (value: string) => {
    setBranding(prev => ({ ...prev, [key]: value }));
    setBrandingSaved(false);
  };

  const saveBranding = useCallback(() => {
    setBrandingSaved(true);
    setTimeout(() => setBrandingSaved(false), 2500);
  }, []);

  const parsedCount = parseVins(vinInput).length;

  // ── Gate check ───────────────────────────────────────────────────────────
  const renderContent = () => {
    if (!isPro) {
      return <ProGate onUpgrade={() => router.push('/subscription')} />;
    }

    return (
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: insets.bottom + 48 }}
      >

        {/* ── TAB BAR ── */}
        <View style={styles.tabBar}>
          {([
            { id: 'vins',     icon: 'qr-code-scanner', label: 'Bulk VIN' },
            { id: 'reports',  icon: 'folder-shared',   label: `Reports${savedReports.length > 0 ? ` (${savedReports.length})` : ''}` },
            { id: 'branding', icon: 'business',        label: 'Branding' },
          ] as const).map(tab => (
            <Pressable
              key={tab.id}
              style={[styles.tabBtn, activeTab === tab.id && styles.tabBtnActive]}
              onPress={() => setActiveTab(tab.id)}
            >
              <MaterialIcons
                name={tab.icon}
                size={15}
                color={activeTab === tab.id ? '#000' : Colors.textSecondary}
              />
              <Text style={[styles.tabBtnText, activeTab === tab.id && styles.tabBtnTextActive]}>
                {tab.label}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* ─────────────────── TAB: BULK VIN ─────────────────── */}
        {activeTab === 'vins' && (
          <View style={styles.section}>
            <View style={styles.card}>
              <SectionHeader icon="qr-code-scanner" label="BULK VIN DECODER" />
              <Text style={styles.cardDesc}>
                Paste up to 10 VINs separated by commas, spaces, or new lines. Each is decoded against NHTSA vPIC.
              </Text>

              {/* Input */}
              <View style={styles.vinInputWrap}>
                <TextInput
                  style={styles.vinTextArea}
                  value={vinInput}
                  onChangeText={setVinInput}
                  placeholder={"1FTFW1E84LKE12345\n3VWFE21C04M000001\nWA1LFAFPXHA123456"}
                  placeholderTextColor={Colors.textMuted}
                  multiline
                  autoCapitalize="characters"
                  autoCorrect={false}
                  contextMenuHidden={false}
                />
                {vinInput.length > 0 && (
                  <Pressable
                    style={styles.clearBtn}
                    onPress={() => { setVinInput(''); setVinResults([]); }}
                    hitSlop={8}
                  >
                    <MaterialIcons name="close" size={14} color={Colors.textMuted} />
                  </Pressable>
                )}
              </View>

              {/* VIN count + decode button */}
              <View style={styles.vinCountRow}>
                <View style={styles.vinCountBadge}>
                  <Text style={styles.vinCountText}>
                    {parsedCount} / 10 VINs detected
                  </Text>
                </View>
                <Pressable
                  style={({ pressed }) => [
                    styles.decodeBtn,
                    parsedCount === 0 && styles.decodeBtnDisabled,
                    pressed && parsedCount > 0 && { opacity: 0.85 },
                  ]}
                  onPress={handleBulkDecode}
                  disabled={parsedCount === 0 || bulkLoading}
                >
                  {bulkLoading ? (
                    <ActivityIndicator color="#000" size="small" />
                  ) : (
                    <>
                      <MaterialIcons name="manage-search" size={16} color={parsedCount === 0 ? Colors.textMuted : '#000'} />
                      <Text style={[styles.decodeBtnText, parsedCount === 0 && { color: Colors.textMuted }]}>
                        Decode All
                      </Text>
                    </>
                  )}
                </Pressable>
              </View>
            </View>

            {/* Results */}
            {vinResults.length > 0 && (
              <View style={styles.card}>
                <SectionHeader icon="list-alt" label="DECODE RESULTS" color={Colors.blueBright} />
                <View style={{ gap: 0 }}>
                  {vinResults.map((item, i) => (
                    <VinResultRow
                      key={item.vin + i}
                      item={item}
                      onSave={() => handleSaveReport(item)}
                      onView={() => router.push({ pathname: '/vin-history', params: { vin: item.vin } })}
                    />
                  ))}
                </View>

                {/* Summary row */}
                <View style={styles.resultsSummary}>
                  <View style={styles.summaryChip}>
                    <MaterialIcons name="check-circle" size={12} color={Colors.green} />
                    <Text style={[styles.summaryChipText, { color: Colors.green }]}>
                      {vinResults.filter(v => v.status === 'success').length} decoded
                    </Text>
                  </View>
                  {vinResults.filter(v => v.status === 'error').length > 0 && (
                    <View style={[styles.summaryChip, { backgroundColor: 'rgba(255,68,68,0.1)', borderColor: 'rgba(255,68,68,0.3)' }]}>
                      <MaterialIcons name="cancel" size={12} color={Colors.red} />
                      <Text style={[styles.summaryChipText, { color: Colors.red }]}>
                        {vinResults.filter(v => v.status === 'error').length} failed
                      </Text>
                    </View>
                  )}
                  <Pressable
                    style={({ pressed }) => [styles.clearResultsBtn, pressed && { opacity: 0.75 }]}
                    onPress={() => { setVinResults([]); setVinInput(''); }}
                  >
                    <Text style={styles.clearResultsBtnText}>Clear</Text>
                  </Pressable>
                </View>
              </View>
            )}

            {/* Empty state */}
            {vinResults.length === 0 && (
              <View style={styles.emptyState}>
                <MaterialIcons name="qr-code-scanner" size={36} color={Colors.textDim} />
                <Text style={styles.emptyText}>Paste VINs above to decode</Text>
                <Text style={styles.emptySub}>Results will appear here with full vehicle details</Text>
              </View>
            )}
          </View>
        )}

        {/* ─────────────────── TAB: SAVED REPORTS ─────────────────── */}
        {activeTab === 'reports' && (
          <View style={styles.section}>
            <View style={styles.card}>
              <View style={styles.cardHeaderRow}>
                <SectionHeader icon="folder-shared" label="SAVED CLIENT REPORTS" color={Colors.blueBright} />
                {savedReports.length > 0 && (
                  <Pressable
                    onPress={() => Alert.alert('Clear All', 'Delete all saved reports?', [
                      { text: 'Cancel', style: 'cancel' },
                      { text: 'Clear All', style: 'destructive', onPress: () => setSavedReports([]) },
                    ])}
                  >
                    <Text style={styles.clearAllText}>Clear all</Text>
                  </Pressable>
                )}
              </View>

              {savedReports.length === 0 ? (
                <View style={styles.emptyCard}>
                  <MaterialIcons name="folder-open" size={32} color={Colors.textDim} />
                  <Text style={styles.emptyText}>No saved reports yet</Text>
                  <Text style={styles.emptySub}>Decode VINs and tap "Save" to add client reports here</Text>
                </View>
              ) : (
                <View>
                  {savedReports.map(r => (
                    <SavedReportCard
                      key={r.id}
                      report={r}
                      onDelete={() => handleDeleteReport(r.id)}
                      onView={() => router.push({ pathname: '/vin-history', params: { vin: r.vin } })}
                    />
                  ))}
                </View>
              )}
            </View>

            {/* Import tip */}
            <View style={styles.tipCard}>
              <MaterialIcons name="info-outline" size={14} color={Colors.blueBright} />
              <Text style={styles.tipText}>
                Saved reports persist for this session. Save the VIN history reports to share PDF reports with clients.
              </Text>
            </View>
          </View>
        )}

        {/* ─────────────────── TAB: BRANDING ─────────────────── */}
        {activeTab === 'branding' && (
          <View style={styles.section}>
            {/* Preview card */}
            <View style={styles.brandPreviewCard}>
              <View style={styles.brandPreviewHeader}>
                <View style={styles.brandPreviewLogoWrap}>
                  {branding.logoUrl ? (
                    <Image
                      source={{ uri: branding.logoUrl }}
                      style={styles.brandPreviewLogo}
                      contentFit="contain"
                      transition={200}
                    />
                  ) : (
                    <MaterialIcons name="business" size={28} color={Colors.gold} />
                  )}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.brandPreviewName}>
                    {branding.dealerName || 'Your Dealership Name'}
                  </Text>
                  {branding.tagline ? (
                    <Text style={styles.brandPreviewTagline}>{branding.tagline}</Text>
                  ) : null}
                </View>
              </View>
              {(branding.phone || branding.email || branding.website) ? (
                <View style={styles.brandPreviewContact}>
                  {branding.phone   ? <Text style={styles.brandPreviewContactItem}>📞 {branding.phone}</Text> : null}
                  {branding.email   ? <Text style={styles.brandPreviewContactItem}>✉️ {branding.email}</Text> : null}
                  {branding.website ? <Text style={styles.brandPreviewContactItem}>🌐 {branding.website}</Text> : null}
                </View>
              ) : null}
              <View style={styles.brandPreviewBadge}>
                <MaterialIcons name="visibility" size={10} color={Colors.textMuted} />
                <Text style={styles.brandPreviewBadgeText}>PDF REPORT PREVIEW</Text>
              </View>
            </View>

            {/* Form */}
            <View style={styles.card}>
              <SectionHeader icon="business" label="DEALERSHIP DETAILS" />
              <BrandingField
                label="DEALERSHIP NAME"
                value={branding.dealerName}
                onChange={updateBranding('dealerName')}
                placeholder="e.g. Sunshine RV Center"
                icon="store"
              />
              <View style={{ height: Spacing.md }} />
              <BrandingField
                label="TAGLINE"
                value={branding.tagline}
                onChange={updateBranding('tagline')}
                placeholder="e.g. Texas' #1 RV Dealer"
                icon="format-quote"
              />
              <View style={{ height: Spacing.md }} />
              <BrandingField
                label="ADDRESS"
                value={branding.address}
                onChange={updateBranding('address')}
                placeholder="123 Main St, Houston TX 77001"
                icon="location-on"
                multiline
              />
            </View>

            <View style={styles.card}>
              <SectionHeader icon="contact-phone" label="CONTACT INFORMATION" color={Colors.blueBright} />
              <BrandingField
                label="PHONE"
                value={branding.phone}
                onChange={updateBranding('phone')}
                placeholder="(555) 000-0000"
                icon="phone"
                keyboardType="phone-pad"
              />
              <View style={{ height: Spacing.md }} />
              <BrandingField
                label="EMAIL"
                value={branding.email}
                onChange={updateBranding('email')}
                placeholder="sales@yourdealership.com"
                icon="email"
                keyboardType="email-address"
              />
              <View style={{ height: Spacing.md }} />
              <BrandingField
                label="WEBSITE"
                value={branding.website}
                onChange={updateBranding('website')}
                placeholder="www.yourdealership.com"
                icon="language"
                keyboardType="url"
              />
            </View>

            <View style={styles.card}>
              <SectionHeader icon="image" label="LOGO URL" color={Colors.green} />
              <Text style={styles.logoHint}>
                Enter a URL to your dealership logo (JPEG, PNG, or WebP). This appears on all PDF reports.
              </Text>
              <BrandingField
                label="LOGO URL"
                value={branding.logoUrl}
                onChange={updateBranding('logoUrl')}
                placeholder="https://yourdealership.com/logo.png"
                icon="link"
                keyboardType="url"
              />
              {branding.logoUrl ? (
                <View style={styles.logoPreviewRow}>
                  <Image
                    source={{ uri: branding.logoUrl }}
                    style={styles.logoPreview}
                    contentFit="contain"
                    transition={200}
                  />
                  <View>
                    <Text style={styles.logoPreviewLabel}>Logo Preview</Text>
                    <Text style={styles.logoPreviewSub}>Appears on PDF headers</Text>
                  </View>
                </View>
              ) : null}
            </View>

            {/* Save button */}
            <Pressable
              style={({ pressed }) => [styles.saveBrandingBtn, pressed && { opacity: 0.85 }, brandingSaved && { backgroundColor: Colors.green }]}
              onPress={saveBranding}
            >
              <MaterialIcons name={brandingSaved ? 'check-circle' : 'save'} size={18} color="#000" />
              <Text style={styles.saveBrandingBtnText}>
                {brandingSaved ? 'Branding Saved!' : 'Save Branding Settings'}
              </Text>
            </Pressable>

            <View style={styles.tipCard}>
              <MaterialIcons name="info-outline" size={14} color={Colors.gold} />
              <Text style={styles.tipText}>
                Branding settings are applied to all PDF reports generated from this device. Export functionality coming soon.
              </Text>
            </View>
          </View>
        )}

      </ScrollView>
    );
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* Hero backdrop */}
        <View style={styles.heroBackdrop}>
          <Image
            source={require('@/assets/entegra-hero.png')}
            style={StyleSheet.absoluteFill}
            contentFit="cover"
            transition={400}
          />
          <LinearGradient
            colors={['rgba(8,8,8,0.65)', 'rgba(8,8,8,0.28)', 'rgba(8,8,8,0.40)']}
            style={StyleSheet.absoluteFill}
          />
        </View>

        {/* Header */}
        <View style={styles.header}>
          <Pressable
            style={styles.backBtn}
            onPress={() => router.back()}
            hitSlop={8}
          >
            <MaterialIcons name="arrow-back-ios" size={18} color={Colors.textPrimary} />
          </Pressable>
          <View style={styles.headerCenter}>
            <View style={styles.proBadge}>
              <MaterialIcons name="workspace-premium" size={13} color="#000" />
              <Text style={styles.proBadgeText}>PRO</Text>
            </View>
            <Text style={styles.headerTitle}>Professional Dashboard</Text>
          </View>
          {isPro ? (
            <View style={styles.activeBadge}>
              <MaterialIcons name="verified" size={11} color={Colors.green} />
              <Text style={styles.activeBadgeText}>Active</Text>
            </View>
          ) : (
            <View style={{ width: 60 }} />
          )}
        </View>

        {/* Main content */}
        {renderContent()}

        {/* Save modal */}
        <SaveClientModal
          visible={saveModal}
          vinResult={saveTarget}
          onSave={handleConfirmSave}
          onClose={() => { setSaveModal(false); setSaveTarget(null); }}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.black },
  heroBackdrop: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 0,
  },

  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    gap: Spacing.sm,
    zIndex: 2,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.bgCard, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  headerCenter: { flex: 1, alignItems: 'center', gap: 4 },
  proBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  proBadgeText: { fontSize: 10, fontWeight: FontWeight.extrabold, color: '#000', letterSpacing: 1 },
  headerTitle: { fontSize: FontSize.base, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  activeBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(74,222,128,0.1)',
    borderRadius: Radius.full, borderWidth: 1, borderColor: 'rgba(74,222,128,0.35)',
    paddingHorizontal: 10, paddingVertical: 5, width: 60, justifyContent: 'center',
  },
  activeBadgeText: { fontSize: 10, fontWeight: FontWeight.bold, color: Colors.green },

  // Tabs
  tabBar: {
    flexDirection: 'row', gap: 6,
    margin: Spacing.md, marginBottom: Spacing.sm,
    backgroundColor: 'rgba(0,0,0,0.42)', borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border,
    padding: 4,
    zIndex: 2,
  },
  tabBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5,
    paddingVertical: 10, borderRadius: Radius.md,
  },
  tabBtnActive: {
    backgroundColor: Colors.gold,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35, shadowRadius: 6, elevation: 3,
  },
  tabBtnText: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.textMuted },
  tabBtnTextActive: { color: '#000' },

  section: { paddingHorizontal: Spacing.md, gap: Spacing.md, zIndex: 2 },

  card: {
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderRadius: Radius.xl,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
    padding: Spacing.md,
  },
  cardHeaderRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  cardDesc: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 18, marginBottom: Spacing.md, marginTop: -Spacing.sm },
  clearAllText: { fontSize: FontSize.sm, color: Colors.red, fontWeight: FontWeight.semibold, marginBottom: Spacing.md },

  // VIN input
  vinInputWrap: {
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderWidth: 1.5, borderColor: Colors.borderBlue,
    borderRadius: Radius.md, overflow: 'hidden', position: 'relative',
    minHeight: 120,
  },
  vinTextArea: {
    color: '#FFFFFF', fontSize: FontSize.sm,
    padding: Spacing.md, lineHeight: 22,
    fontWeight: FontWeight.medium, letterSpacing: 0.5,
    minHeight: 120,
    textAlignVertical: 'top',
    fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace',
  },
  clearBtn: {
    position: 'absolute', top: 10, right: 10,
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },

  vinCountRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: Spacing.sm,
  },
  vinCountBadge: {
    backgroundColor: 'rgba(77,166,255,0.1)',
    borderRadius: Radius.full, borderWidth: 1, borderColor: 'rgba(77,166,255,0.3)',
    paddingHorizontal: 12, paddingVertical: 6,
  },
  vinCountText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright },

  decodeBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingHorizontal: 20, paddingVertical: 10,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.4, shadowRadius: 8, elevation: 4,
  },
  decodeBtnDisabled: {
    backgroundColor: Colors.bgCardAlt, shadowOpacity: 0, elevation: 0,
    borderWidth: 1, borderColor: Colors.border,
  },
  decodeBtnText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: '#000' },

  resultsSummary: {
    flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: Spacing.md,
    paddingTop: Spacing.sm, borderTopWidth: 1, borderTopColor: Colors.border,
  },
  summaryChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(74,222,128,0.1)', borderWidth: 1, borderColor: 'rgba(74,222,128,0.3)',
    borderRadius: Radius.full, paddingHorizontal: 10, paddingVertical: 5,
  },
  summaryChipText: { fontSize: 11, fontWeight: FontWeight.bold },
  clearResultsBtn: { marginLeft: 'auto' as any },
  clearResultsBtnText: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium },

  // Empty state
  emptyState: {
    alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm,
    marginTop: Spacing.sm,
  },
  emptyCard: {
    alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm,
  },
  emptyText: { fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: '#FFFFFF' },
  emptySub: { fontSize: FontSize.sm, color: Colors.textMuted, textAlign: 'center', maxWidth: 260 },

  // Tip card
  tipCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 8,
    backgroundColor: 'transparent',
    borderRadius: Radius.lg, borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)',
    padding: Spacing.md,
  },
  tipText: { flex: 1, fontSize: FontSize.xs, color: Colors.textMuted, lineHeight: 17 },

  // Branding preview
  brandPreviewCard: {
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderRadius: Radius.xl, borderWidth: 1.5, borderColor: Colors.borderSilver,
    padding: Spacing.md, gap: Spacing.sm,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2, shadowRadius: 14, elevation: 4,
  },
  brandPreviewHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  brandPreviewLogoWrap: {
    width: 56, height: 56, borderRadius: 12,
    backgroundColor: 'rgba(255,215,0,0.1)',
    borderWidth: 1, borderColor: Colors.borderGold,
    alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden',
  },
  brandPreviewLogo: { width: 56, height: 56 },
  brandPreviewName: { fontSize: FontSize.lg, fontWeight: FontWeight.extrabold, color: Colors.textPrimary },
  brandPreviewTagline: { fontSize: FontSize.xs, color: Colors.textSecondary, marginTop: 2 },
  brandPreviewContact: { gap: 4, paddingTop: Spacing.xs, borderTopWidth: 1, borderTopColor: Colors.border },
  brandPreviewContactItem: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.medium },
  brandPreviewBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: 10, paddingVertical: 4, alignSelf: 'flex-start',
  },
  brandPreviewBadgeText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.textMuted, letterSpacing: 1 },

  logoHint: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 17, marginBottom: Spacing.md, marginTop: -Spacing.xs },
  logoPreviewRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    marginTop: Spacing.md, backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: Radius.md, padding: Spacing.sm,
  },
  logoPreview: { width: 56, height: 56, borderRadius: 8, backgroundColor: Colors.bgCard },
  logoPreviewLabel: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  logoPreviewSub: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 2 },

  saveBrandingBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.full, paddingVertical: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45, shadowRadius: 14, elevation: 6,
  },
  saveBrandingBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#000' },
});
