import {
  View, Text, StyleSheet, ScrollView, Pressable, Linking, Platform,
  ActivityIndicator, Alert, TextInput, Modal, KeyboardAvoidingView, RefreshControl,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useState, useCallback, useEffect } from 'react';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import { RV_DATA, getMaintenanceSchedule, getMockReviews } from '@/constants/rvData';
import type { MaintenanceItem, RVReview } from '@/constants/rvData';
import { generateAndShareRVReport, previewRVReport } from '@/services/pdfService';
import { LinearGradient } from 'expo-linear-gradient';
import { computeRating, getRatingMetadata } from '@/constants/ratingData';
import type { RatingMetadata } from '@/constants/ratingData';
import { getSupabaseClient } from '@/template';
import { FunctionsHttpError } from '@supabase/supabase-js';
import * as Haptics from 'expo-haptics';

// ─── MARKET VALUE TYPES ─────────────────────────────────────────────────────

const MV_STEPS = [
  'Checking recent listings…',
  'Analyzing price trends…',
  'Calculating value ranges…',
  'Finalizing estimates…',
];

interface MarketValue {
  tradeIn: number;
  retailLow: number;
  retailHigh: number;
  mileageAdjustment?: number;
  conditionNote?: string;
  dataYear?: string;
  source?: string;
}

// ─── NHTSA TYPES ─────────────────────────────────────────────────────────────

interface NHTSARecall {
  component: string;
  summary: string;
  consequence: string;
  remedy: string;
  date: string;
  campaignNumber: string;
}

interface NHTSADefect {
  component: string;
  summary: string;
  date: string;
  crashFlag: boolean;
  fireFlag: boolean;
}

interface NHTSAData {
  recallCount: number;
  recalls: NHTSARecall[];
  defectCount: number;
  defects: NHTSADefect[];
  cached: boolean;
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function StarRow({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <View style={{ flexDirection: 'row', gap: 2 }}>
      {[1, 2, 3, 4, 5].map(s => (
        <MaterialIcons
          key={s}
          name={s <= Math.round(rating) ? 'star' : 'star-border'}
          size={size}
          color={Colors.gold}
        />
      ))}
    </View>
  );
}

const PRIORITY_COLORS: Record<string, string> = {
  Critical: Colors.red,
  Important: Colors.orange,
  Routine: Colors.green,
};

const CATEGORY_ICONS: Record<string, string> = {
  Engine: 'settings',
  Chassis: 'directions-bus',
  'RV Systems': 'home',
  Safety: 'security',
  Exterior: 'layers',
  Interior: 'weekend',
};

// ─── SECTION HEADER ──────────────────────────────────────────────────────────

function SectionTitle({ icon, label, color = Colors.blueBright }: { icon: string; label: string; color?: string }) {
  return (
    <View style={sec.row}>
      <MaterialIcons name={icon as any} size={14} color={color} />
      <Text style={[sec.label, { color }]}>{label}</Text>
    </View>
  );
}
const sec = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: Spacing.sm },
  label: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, letterSpacing: 1.8 },
});

// ─── SPEC ROW ────────────────────────────────────────────────────────────────

function SpecRow({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <View style={specRow.container}>
      <Text style={specRow.label}>{label}</Text>
      <Text style={[specRow.value, accent && specRow.valueAccent]}>{value}</Text>
    </View>
  );
}
const specRow = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 11,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  label: { fontSize: FontSize.sm, color: Colors.textSecondary, fontWeight: FontWeight.medium, flex: 1 },
  value: { fontSize: FontSize.sm, color: Colors.textPrimary, fontWeight: FontWeight.semibold, textAlign: 'right', flex: 1 },
  valueAccent: { color: Colors.gold },
});

// ─── WATER TANK PILL ─────────────────────────────────────────────────────────

function TankPill({ label, gallons, color }: { label: string; gallons: number; color: string }) {
  return (
    <View style={[tankPill.wrap, { borderColor: color + '50' }]}>
      <View style={[tankPill.dot, { backgroundColor: color }]} />
      <View>
        <Text style={[tankPill.val, { color }]}>{gallons} gal</Text>
        <Text style={tankPill.lbl}>{label}</Text>
      </View>
    </View>
  );
}
const tankPill = StyleSheet.create({
  wrap: { flex: 1, borderWidth: 1, borderRadius: Radius.md, padding: 10, gap: 6, alignItems: 'center', backgroundColor: 'rgba(27,44,64,0.55)' },
  dot: { width: 8, height: 8, borderRadius: 4 },
  val: { fontSize: FontSize.base, fontWeight: FontWeight.extrabold, textAlign: 'center' },
  lbl: { fontSize: 10, color: Colors.textMuted, textAlign: 'center', fontWeight: FontWeight.medium },
});

// ─── MAINTENANCE CARD ────────────────────────────────────────────────────────

function MaintenanceCard({ item }: { item: MaintenanceItem }) {
  const priorityColor = PRIORITY_COLORS[item.priority];
  const iconName = CATEGORY_ICONS[item.category] ?? 'build';
  return (
    <View style={maint.card}>
      <View style={[maint.iconWrap, { backgroundColor: priorityColor + '15' }]}>
        <MaterialIcons name={iconName as any} size={16} color={priorityColor} />
      </View>
      <View style={maint.body}>
        <Text style={maint.task}>{item.task}</Text>
        <Text style={maint.interval}>{item.interval}</Text>
      </View>
      <View style={[maint.badge, { backgroundColor: priorityColor + '20', borderColor: priorityColor + '50' }]}>
        <Text style={[maint.badgeText, { color: priorityColor }]}>{item.priority}</Text>
      </View>
    </View>
  );
}
const maint = StyleSheet.create({
  card: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  iconWrap: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  body: { flex: 1, gap: 2 },
  task: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textPrimary },
  interval: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium },
  badge: { borderWidth: 1, borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 3 },
  badgeText: { fontSize: 10, fontWeight: FontWeight.bold },
});

// ─── REVIEW CARD ─────────────────────────────────────────────────────────────

function ReviewCard({ review }: { review: RVReview }) {
  return (
    <View style={rev.card}>
      <View style={rev.header}>
        <View style={rev.avatarWrap}>
          <Text style={rev.avatarLetter}>{review.author.charAt(0)}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Text style={rev.author}>{review.author}</Text>
            {review.verified && (
              <View style={rev.verifiedBadge}>
                <MaterialIcons name="verified" size={10} color={Colors.green} />
                <Text style={rev.verifiedText}>Verified</Text>
              </View>
            )}
          </View>
          <Text style={rev.location}>{review.location} · {review.date}</Text>
        </View>
        <StarRow rating={review.rating} size={12} />
      </View>
      <Text style={rev.title}>{review.title}</Text>
      <Text style={rev.body}>{review.body}</Text>
      {(review.miles || review.years) && (
        <View style={rev.statsRow}>
          {review.miles ? (
            <View style={rev.statPill}>
              <MaterialIcons name="speed" size={10} color={Colors.blueBright} />
              <Text style={rev.statText}>{review.miles} mi driven</Text>
            </View>
          ) : null}
          {review.years ? (
            <View style={rev.statPill}>
              <MaterialIcons name="schedule" size={10} color={Colors.gold} />
              <Text style={rev.statText}>Owned {review.years}</Text>
            </View>
          ) : null}
        </View>
      )}
    </View>
  );
}
const rev = StyleSheet.create({
  card: {
    backgroundColor: 'rgba(20,35,58,0.80)', borderRadius: Radius.xl,
    borderWidth: 1, borderColor: 'rgba(168,188,207,0.18)',
    padding: Spacing.md, gap: Spacing.sm,
    marginBottom: Spacing.md,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35, shadowRadius: 8, elevation: 4,
  },
  header: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm },
  avatarWrap: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: 'rgba(30,111,255,0.2)',
    borderWidth: 1.5, borderColor: 'rgba(30,111,255,0.4)',
    alignItems: 'center', justifyContent: 'center',
  },
  avatarLetter: { fontSize: FontSize.base, fontWeight: FontWeight.extrabold, color: Colors.blueBright },
  author: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  location: { fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 1 },
  verifiedBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 2,
    backgroundColor: 'rgba(74,222,128,0.1)',
    borderRadius: Radius.sm, paddingHorizontal: 5, paddingVertical: 2,
  },
  verifiedText: { fontSize: 9, color: Colors.green, fontWeight: FontWeight.bold },
  title: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.textPrimary },
  body: { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20 },
  statsRow: { flexDirection: 'row', gap: 8, marginTop: 2 },
  statPill: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 4,
  },
  statText: { fontSize: 10, color: Colors.textSecondary, fontWeight: FontWeight.medium },
});

// ─── DERIVED SPEC CALCULATOR ───────────────────────────────────────────────────
// Estimates common spec values from existing data fields so every model shows
// a rich spec table without needing manual data entry for all 363 models.

function getDerivedSpecs(data: RVSpec, year: string): {
  horsepower: string | null;
  transmission: string | null;
  fuelCapacity: string | null;
  axles: string | null;
  leveling: string | null;
  slideType: string | null;
  tireSize: string | null;
  gcwr: string | null;
} {
  const isTowable = data.fuelType.includes('towable') || data.fuelType.includes('truck camper');
  const yearNum = parseInt(year);

  // ── Horsepower ─────────────────────────────────────────────────────────────
  let horsepower: string | null = null;
  if (data.horsepower) {
    horsepower = `${data.horsepower} HP`;
  } else if (data.engine) {
    const hpMatch = data.engine.match(/(\d{3,4})\s*HP/);
    if (hpMatch) {
      horsepower = `${hpMatch[1]} HP`;
    } else if (data.engine.includes('7.3L')) {
      horsepower = '350 HP';
    } else if (data.engine.includes('6.8L') || data.engine.includes('V10 6.8')) {
      horsepower = '320 HP';
    } else if (data.engine.includes('6.7L Power Stroke')) {
      horsepower = '330 HP';
    } else if (data.engine.includes('6.2L')) {
      horsepower = '385 HP';
    } else if (data.engine.includes('EcoBoost') || data.engine.includes('3.5L')) {
      horsepower = '310 HP';
    } else if (data.engine.includes('3.6L')) {
      horsepower = '280 HP';
    } else if (data.engine.includes('Sprinter') || data.engine.includes('3.0L V6')) {
      horsepower = yearNum >= 2020 ? '211 HP' : '188 HP';
    } else if (data.engine.includes('2.0L I4')) {
      horsepower = yearNum >= 2020 ? '211 HP' : '174 HP';
    } else if (data.engine.includes('6.6L')) {
      horsepower = '340 HP';
    } else if (data.engine.includes('Navistar') || data.engine.includes('Maxxforce')) {
      horsepower = '300 HP';
    } else if (data.engine.includes('V8') && !data.engine.includes('7.3')) {
      horsepower = '305 HP';
    }
  }

  // ── Transmission ──────────────────────────────────────────────────────────
  let transmission: string | null = null;
  if (data.transmission) {
    transmission = data.transmission;
  } else if (!isTowable) {
    if (data.fuelType === 'Diesel') {
      if (data.type.includes('Class A')) {
        transmission = 'Allison 4000 MH 6-Speed Auto';
      } else if (data.chassis?.includes('Sprinter') || data.engine?.includes('Sprinter') || data.engine?.includes('2.0L I4')) {
        transmission = 'Mercedes 7G-Tronic Plus Auto';
      } else if (data.type.includes('Super C') || data.type.includes('Class C')) {
        transmission = 'Ford TorqShift 6R140 6-Speed Auto';
      } else {
        transmission = '7-Speed Automatic';
      }
    } else if (data.fuelType === 'Gas') {
      if (data.chassis?.includes('Ford') || data.engine?.includes('Ford') || data.engine?.includes('7.3L') || data.engine?.includes('V10') || data.engine?.includes('6.2L')) {
        transmission = 'Ford TorqShift 6R140 6-Speed Auto';
      } else if (data.engine?.includes('3.6L') || data.engine?.includes('3.5L')) {
        transmission = '8-Speed Automatic';
      }
    }
  }

  // ── Fuel Tank ─────────────────────────────────────────────────────────────
  let fuelCapacity: string | null = null;
  if (data.fuelCapacity) {
    fuelCapacity = `${data.fuelCapacity} gal`;
  } else if (!isTowable) {
    if (data.type.includes('Class A Diesel')) {
      fuelCapacity = data.lengthRange[0] >= 42 ? '100 gal' : data.lengthRange[0] >= 38 ? '90 gal' : '80 gal';
    } else if (data.type.includes('Class A Gas')) {
      fuelCapacity = data.lengthRange[0] >= 34 ? '75 gal' : '55 gal';
    } else if (data.type === 'Class B') {
      fuelCapacity = '24 gal';
    } else if (data.type === 'Class B+') {
      fuelCapacity = '32 gal';
    } else if (data.type.includes('Class C')) {
      fuelCapacity = '55 gal';
    } else if (data.type.includes('Super C')) {
      fuelCapacity = '80 gal';
    }
  }

  // ── Axles ─────────────────────────────────────────────────────────────────
  let axles: string | null = null;
  if (data.axles) {
    axles = data.axles === 3 ? '3 (Tag Axle)' : String(data.axles);
  } else if (!isTowable) {
    if (data.type.includes('Class A Diesel') && (data.lengthRange[0] >= 42 || data.slideouts >= 4)) {
      axles = '3 (Tag Axle)';
    } else {
      axles = '2';
    }
  } else {
    axles = data.weightRange[0] >= 15000 ? '3 (Tri-Axle)' : '2';
  }

  // ── Leveling System ───────────────────────────────────────────────────────
  let leveling: string | null = null;
  if (data.leveling) {
    leveling = data.leveling;
  } else if (!isTowable) {
    if (data.fuelType === 'Diesel' && data.type.includes('Class A')) {
      leveling = '6-Point HWH Hydraulic Auto-Level';
    } else if (data.type === 'Class B') {
      leveling = 'Stabilizing Jacks (Manual)';
    } else {
      leveling = '4-Point Electric Auto-Level';
    }
  } else {
    leveling = data.slideouts > 0 ? '4-Point Electric Auto-Level' : 'Stabilizing Jacks (Manual)';
  }

  // ── Slide System ──────────────────────────────────────────────────────────
  let slideType: string | null = null;
  if (data.slideType) {
    slideType = data.slideType;
  } else if (data.slideouts > 0) {
    if (data.fuelType === 'Diesel' && data.type.includes('Class A')) {
      slideType = 'HydraLink Hydraulic / Electric';
    } else {
      slideType = 'Electric (Room-in-Room System)';
    }
  }

  // ── Tire Size ─────────────────────────────────────────────────────────────
  let tireSize: string | null = null;
  if (data.tireSize) {
    tireSize = data.tireSize;
  } else {
    if (data.type.includes('Class A Diesel')) {
      tireSize = '275/80R22.5';
    } else if (data.type.includes('Class A Gas')) {
      tireSize = '225/75R19.5 LR-E';
    } else if (data.type === 'Class B') {
      tireSize = data.chassis?.includes('Transit') ? '265/65R16' : '245/75R16';
    } else if (data.type === 'Class B+') {
      tireSize = '245/75R16';
    } else if (data.type.includes('Class C')) {
      tireSize = '225/75R16 LR-E';
    } else if (data.type.includes('Super C')) {
      tireSize = '225/75R17.5 LR-E';
    } else if (data.type.includes('Fifth Wheel')) {
      tireSize = data.weightRange[0] >= 14000 ? 'ST275/65R20 LR-E' : 'ST235/80R16 LR-E';
    } else if (data.type.includes('Travel Trailer')) {
      tireSize = data.weightRange[0] >= 6500 ? 'ST225/75R15 LR-D' : 'ST205/75R15 LR-D';
    } else if (data.type.includes('Toy Hauler')) {
      tireSize = data.weightRange[0] >= 13000 ? 'ST275/65R20 LR-E' : 'ST235/85R16 LR-E';
    } else if (data.type.includes('Truck Camper')) {
      tireSize = null; // truck campers use truck tires
    }
  }

  // ── GCWR ─────────────────────────────────────────────────────────────────
  let gcwr: string | null = null;
  if (data.grossCombinedWeight) {
    gcwr = `${data.grossCombinedWeight.toLocaleString()} lbs`;
  } else if (data.towingCapacity && data.towingCapacity > 0 && !isTowable) {
    const vehicleGVWR = data.weightRange[1];
    const estimatedGCWR = vehicleGVWR + data.towingCapacity;
    gcwr = `${estimatedGCWR.toLocaleString()} lbs`;
  }

  return { horsepower, transmission, fuelCapacity, axles, leveling, slideType, tireSize, gcwr };
}

// ─── DETAIL PAGE TYPE IMAGE SELECTOR ───────────────────────────────────────────
const DETAIL_TYPE_IMAGES = {
  classa:        require('@/assets/rv-classa.jpg'),
  classb:        require('@/assets/rv-classb.jpg'),
  classc:        require('@/assets/rv-classc.jpg'),
  traveltrailer: require('@/assets/rv-traveltrailer.jpg'),
  fifthwheel:    require('@/assets/rv-fifthwheel.jpg'),
};
function getDetailTypeImage(rvType: string) {
  if (rvType === 'Class B' || rvType === 'Class B+') return DETAIL_TYPE_IMAGES.classb;
  if (rvType.includes('Class C')) return DETAIL_TYPE_IMAGES.classc;
  if (rvType.includes('Travel Trailer') || rvType.includes('Truck Camper')) return DETAIL_TYPE_IMAGES.traveltrailer;
  if (rvType.includes('Fifth Wheel') || rvType.includes('Toy Hauler')) return DETAIL_TYPE_IMAGES.fifthwheel;
  // Class A Gas, Class A Diesel, Super C → dedicated Class A diesel pusher
  return DETAIL_TYPE_IMAGES.classa;
}

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

export default function RVDetailScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ year: string; make: string; model: string; floorplan: string; vin?: string }>();
  const { year = '2025', make = '', model = '', floorplan = '', vin = '' } = params;

  const handleOpenRvGrok = useCallback(() => {
    const fp = floorplan ? ` ${floorplan}` : '';
    const grokMsg = `Tell me everything about the ${year} ${make} ${model}${fp} — specs, pricing, known issues, best floorplans, towing, maintenance, and what owners are saying.`;
    router.push({ pathname: '/(tabs)/rvgrok', params: { prefill: grokMsg } });
  }, [router, year, make, model, floorplan]);
  const data = RV_DATA[make]?.[model];

  // ── Year Existence Validation ─────────────────────────────────────────
  const yearNum = parseInt(year, 10);
  const yearExistsWarning: string | null = (() => {
    if (!data) return null;
    const ys = data.yearStart;
    const ye = data.yearEnd;
    if (ys && yearNum < ys) {
      return `The ${make} ${model} did not exist in ${year}. Production started in ${ys}.`;
    }
    if (ye && yearNum > ye) {
      return `The ${make} ${model} was discontinued after ${ye}. It did not exist in ${year}.`;
    }
    return null;
  })();

  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  const toggleCategory = useCallback((cat: string) => {
    setExpandedCategories(prev => ({ ...prev, [cat]: !prev[cat] }));
  }, []);

  // ── Refresh state ──────────────────────────────────────────────────────────
  const [refreshKey, setRefreshKey] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [mvStep, setMvStep] = useState(0);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    setRefreshKey(k => k + 1);
    setTimeout(() => setRefreshing(false), 2800);
  }, []);

  const [pdfLoading, setPdfLoading] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [pendingAction, setPendingAction] = useState<'share' | 'preview' | null>(null);

  // ── Market Value ───────────────────────────────────────────────────────
  const [marketValue, setMarketValue] = useState<MarketValue | null>(null);
  const [marketValueLoading, setMarketValueLoading] = useState(true);
  const [marketValueError, setMarketValueError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function fetchMarketValue() {
      setMarketValueLoading(true);
      setMarketValueError(null);
      try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase.functions.invoke('rv-market-value', {
          body: { year, make, model },
        });
        if (error) {
          if (!cancelled) setMarketValueError('Market value data unavailable');
          return;
        }
        if (!cancelled && data) setMarketValue(data as MarketValue);
      } catch {
        if (!cancelled) setMarketValueError('Could not load market value');
      } finally {
        if (!cancelled) setMarketValueLoading(false);
      }
    }
    fetchMarketValue();
    return () => { cancelled = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [make, model, year, refreshKey]);

  // Cycle progress step labels while loading
  useEffect(() => {
    let iv: ReturnType<typeof setInterval> | null = null;
    if (marketValueLoading) {
      setMvStep(0);
      iv = setInterval(() => setMvStep(s => Math.min(s + 1, MV_STEPS.length - 1)), 900);
    }
    return () => { if (iv) clearInterval(iv); };
  }, [marketValueLoading]);

  // ── Live NHTSA data ────────────────────────────────────────────────────
  const [nhtsa, setNhtsa] = useState<NHTSAData | null>(null);
  const [nhtsaLoading, setNhtsaLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function fetchNHTSA() {
      setNhtsaLoading(true);
      try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase.functions.invoke('nhtsa-lookup', {
          body: { make, model, year },
        });
        if (error) {
          if (error instanceof FunctionsHttpError) {
            const msg = await error.context?.text?.();
            console.warn('NHTSA lookup error:', msg);
          }
          if (!cancelled) setNhtsa({ recallCount: 0, recalls: [], defectCount: 0, defects: [], cached: false });
          return;
        }
        if (!cancelled && data) setNhtsa(data as NHTSAData);
      } catch {
        if (!cancelled) setNhtsa({ recallCount: 0, recalls: [], defectCount: 0, defects: [], cached: false });
      } finally {
        if (!cancelled) setNhtsaLoading(false);
      }
    }
    fetchNHTSA();
    return () => { cancelled = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [make, model, year, refreshKey]);

  if (!data) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <Image source={require('@/assets/backscreen.jpg')} style={StyleSheet.absoluteFill} contentFit="cover" />
        <LinearGradient colors={['rgba(30,46,64,0.85)','rgba(18,28,50,0.92)']} style={StyleSheet.absoluteFill} />
        <MaterialIcons name="error-outline" size={48} color={Colors.textDim} />
        <Text style={styles.errorText}>RV data not found</Text>
        <Pressable style={styles.backBtnSmall} onPress={() => router.back()}>
          <Text style={styles.backBtnSmallText}>Go Back</Text>
        </Pressable>
      </View>
    );
  }

  // Computed credible rating (manufacturer base + tier + year adjustment)
  const computedRating = computeRating(make, model, year);
  const ratingMeta: RatingMetadata = getRatingMetadata(make, model, year);
  const derivedSpecs = getDerivedSpecs(data, year);

  const maintenance = getMaintenanceSchedule(data);
  const reviews = getMockReviews(make, model, computedRating);
  // Use live NHTSA count if available, fall back to static
  const liveRecallCount = nhtsa !== null ? nhtsa.recallCount : data.recalls;
  const hasRecall = liveRecallCount > 0;
  const isTowable = data.fuelType.includes('towable');
  const ratingCount = Math.floor(computedRating * 120 + Math.abs(make.charCodeAt(0) - model.charCodeAt(0)) * 17);

  const maintenanceCategories = Array.from(new Set(maintenance.map(m => m.category))) as string[];
  const maintenanceByCat = maintenanceCategories.reduce<Record<string, MaintenanceItem[]>>((acc, cat) => {
    acc[cat] = maintenance.filter(m => m.category === cat);
    return acc;
  }, {});

  const buildReportPayload = () => ({
    year, make, model, floorplan,
    type: data!.type,
    floorplans: data!.floorplans,
    lengthRange: data!.lengthRange,
    weightRange: data!.weightRange,
    slideouts: data!.slideouts,
    sleeps: data!.sleeps,
    msrpRange: data!.msrpRange,
    engine: data!.engine,
    chassis: data!.chassis,
    fuelType: data!.fuelType,
    recalls: liveRecallCount,
    rating: computedRating,
    image: data!.image,
    recallDetails: nhtsa?.recalls,
    defectCount: nhtsa?.defectCount,
    defects: nhtsa?.defects,
    maintenanceItems: maintenance,
    reviews,
    warrantyYears: data!.warrantyYears,
    description: data!.description,
    freshWater: data!.freshWater,
    grayWater: data!.grayWater,
    blackWater: data!.blackWater,
    generator: data!.generator,
    towingCapacity: data!.towingCapacity,
    ceilingHeight: data!.ceilingHeight,
    founded: data!.founded,
    marketValue: marketValue ?? undefined,
    customerName: customerName.trim() || undefined,
  });

  const handleRequestPDF = (action: 'share' | 'preview') => {
    setPendingAction(action);
    setShowCustomerModal(true);
  };

  const handlePDF = async () => {
    setPdfLoading(true);
    try {
      await generateAndShareRVReport(buildReportPayload());
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    } catch {
      Alert.alert('PDF Error', 'Could not generate report. Please try again.');
    } finally {
      setPdfLoading(false);
    }
  };

  const handlePreview = async () => {
    setPreviewLoading(true);
    try {
      await previewRVReport(buildReportPayload());
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    } catch {
      Alert.alert('Preview Error', 'Could not open preview. Please try again.');
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleConfirmCustomerName = async () => {
    setShowCustomerModal(false);
    if (pendingAction === 'share') {
      await handlePDF();
    } else if (pendingAction === 'preview') {
      await handlePreview();
    }
    setPendingAction(null);
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* ── GLOBAL BACKDROP ── */}
      <View style={styles.globalBackdrop}>
        <Image
          source={require('@/assets/backscreen.jpg')}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          contentPosition={{ x: 0.5, y: 0.3 }}
          transition={400}
        />
        <LinearGradient
          colors={['rgba(30,46,64,0.68)', 'rgba(20,38,72,0.30)', 'rgba(20,38,72,0.20)', 'rgba(30,46,64,0.42)', 'rgba(18,28,50,0.80)']}
          locations={[0, 0.18, 0.5, 0.82, 1]}
          style={StyleSheet.absoluteFill}
        />
      </View>

      {/* ── FLOATING BACK BUTTON ── */}
      <Pressable
        style={[styles.backBtn, { top: insets.top + 10 }]}
        onPress={() => router.back()}
        hitSlop={8}
      >
        <MaterialIcons name="arrow-back-ios" size={18} color={Colors.textPrimary} />
      </Pressable>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 40 }} refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={Colors.green} colors={[Colors.green]} />
      }>

        {/* ── YEAR EXISTENCE WARNING ── */}
        {yearExistsWarning && (
          <View style={styles.yearWarningBanner}>
            <MaterialIcons name="error" size={20} color="#fff" />
            <View style={{ flex: 1 }}>
              <Text style={styles.yearWarningTitle}>Model Year Mismatch</Text>
              <Text style={styles.yearWarningText}>{yearExistsWarning}</Text>
            </View>
          </View>
        )}

        {/* ── HERO IMAGE ── */}
        <View style={styles.heroWrap}>
          <Image
            source={getDetailTypeImage(data.type)}
            style={styles.heroImage}
            contentFit="cover"
            transition={300}
          />
          {/* Cinematic gradient overlay */}
          <LinearGradient
            colors={['rgba(18,28,50,0.10)', 'rgba(18,28,50,0.30)', 'rgba(15,28,55,0.88)']}
            locations={[0, 0.5, 1]}
            style={StyleSheet.absoluteFill}
          />

          {/* Hero bottom text */}
          <View style={styles.heroBottom}>
            <View style={styles.heroBadgeRow}>
              <View style={styles.typeBadge}>
                <Text style={styles.typeBadgeText}>{data.type}</Text>
              </View>
              {hasRecall ? (
                <View style={styles.recallBadgeHero}>
                  <MaterialIcons name="warning" size={11} color="#000" />
                  <Text style={styles.recallBadgeHeroText}>{liveRecallCount} Recall{liveRecallCount > 1 ? 's' : ''}</Text>
                </View>
              ) : (
                <View style={styles.noRecallBadge}>
                  <MaterialIcons name="verified" size={11} color={Colors.green} />
                  <Text style={styles.noRecallBadgeText}>No Recalls</Text>
                </View>
              )}
            </View>
            <Text style={styles.heroYear}>{year}</Text>
            <Text style={styles.heroName}>{make} {model}</Text>
            {floorplan ? <Text style={styles.heroFloorplan}>Floorplan: {floorplan}</Text> : null}
            <View style={styles.heroRatingRow}>
              <StarRow rating={computedRating} size={16} />
              <Text style={styles.heroRatingNum}>{computedRating.toFixed(1)}</Text>
              <Text style={styles.heroRatingCount}>({ratingCount.toLocaleString()} reviews)</Text>
            </View>
          </View>
        </View>

        {/* ── BRAND / FOUNDED ── */}
        {data.founded ? (
          <View style={styles.priceCard}>
            <View style={styles.priceCardLeft}>
              <Text style={styles.priceLabel}>MANUFACTURER</Text>
              <Text style={styles.priceValue}>{make}</Text>
            </View>
            <View style={styles.priceCardRight}>
              <Text style={styles.brandSince}>Est. {data.founded}</Text>
            </View>
          </View>
        ) : null}

        {/* ── DESCRIPTION ── */}
        {data.description ? (
          <View style={styles.descCard}>
            <SectionTitle icon="info-outline" label="OVERVIEW" />
            <Text style={styles.descText}>{data.description}</Text>
          </View>
        ) : null}

        {/* ── MARKET VALUE ── */}
        <View style={styles.card}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.sm }}>
            <SectionTitle icon="trending-up" label="MARKET VALUE" color={Colors.green} />
            {marketValueLoading ? (
              <View style={styles.nhtsaLiveBadge}>
                <ActivityIndicator size="small" color={Colors.blueBright} style={{ transform: [{ scale: 0.7 }] }} />
                <Text style={styles.nhtsaLiveBadgeText}>Fetching values...</Text>
              </View>
            ) : marketValue ? (
              <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                <View style={[styles.nhtsaLiveBadge, { backgroundColor: 'rgba(74,222,128,0.08)', borderColor: 'rgba(74,222,128,0.3)' }]}>
                  <MaterialIcons name="verified" size={11} color={Colors.green} />
                  <Text style={[styles.nhtsaLiveBadgeText, { color: Colors.green }]}>
                    {marketValue.source ?? 'Live Market Data'}
                  </Text>
                </View>
                {floorplan ? (
                  <View style={styles.fpPremiumBadge}>
                    <MaterialIcons name="local-offer" size={10} color={Colors.gold} />
                    <Text style={styles.fpPremiumBadgeText}>{floorplan}</Text>
                  </View>
                ) : null}
              </View>
            ) : null}
          </View>

          {marketValueLoading ? (
            <View style={mv.loadingWrap}>
              {MV_STEPS.map((step, i) => (
                <View key={i} style={[mv.progressStep, { opacity: i < mvStep ? 0.45 : i === mvStep ? 1 : 0.20 }]}>
                  <View style={[mv.progressDot,
                    i < mvStep  && { backgroundColor: Colors.green, borderColor: Colors.green },
                    i === mvStep && { borderColor: Colors.green },
                  ]}>
                    {i < mvStep ? (
                      <MaterialIcons name="check" size={10} color="#000" />
                    ) : i === mvStep ? (
                      <ActivityIndicator size="small" color={Colors.green} style={{ transform: [{ scale: 0.55 }] }} />
                    ) : null}
                  </View>
                  <Text style={[mv.progressText,
                    i === mvStep && { color: Colors.green, fontWeight: '600' },
                    i < mvStep  && { color: Colors.textSecondary },
                  ]}>{step}</Text>
                </View>
              ))}
            </View>
          ) : marketValueError ? (
            <View style={mv.errorCard}>
              <MaterialIcons name="info-outline" size={16} color={Colors.textMuted} />
              <Text style={mv.errorText}>{marketValueError}</Text>
            </View>
          ) : marketValue ? (
            <View style={mv.container}>
              {/* Three value cards */}
              <View style={mv.cardsRow}>
                {/* Trade-In */}
                <View style={[mv.valueCard, mv.tradeInCard]}>
                  <View style={mv.cardIconWrap}>
                    <MaterialIcons name="swap-horiz" size={18} color={Colors.silver} />
                  </View>
                  <Text style={mv.cardLabel}>TRADE-IN</Text>
                  <Text style={[mv.cardValue, { color: Colors.silver }]}>
                    ${marketValue.tradeIn.toLocaleString()}
                  </Text>
                  <Text style={mv.cardNote}>Dealer trade estimate</Text>
                </View>

                {/* Retail Low */}
                <View style={[mv.valueCard, mv.retailLowCard]}>
                  <View style={[mv.cardIconWrap, { backgroundColor: 'rgba(0,104,192,0.15)' }]}>
                    <MaterialIcons name="sell" size={18} color={Colors.blueBright} />
                  </View>
                  <Text style={[mv.cardLabel, { color: Colors.blueBright }]}>RETAIL LOW</Text>
                  <Text style={[mv.cardValue, { color: Colors.blueBright }]}>
                    ${marketValue.retailLow.toLocaleString()}
                  </Text>
                  <Text style={mv.cardNote}>Private party floor</Text>
                </View>

                {/* Retail High */}
                <View style={[mv.valueCard, mv.retailHighCard]}>
                  <View style={[mv.cardIconWrap, { backgroundColor: 'rgba(74,222,128,0.15)' }]}>
                    <MaterialIcons name="price-check" size={18} color={Colors.green} />
                  </View>
                  <Text style={[mv.cardLabel, { color: Colors.green }]}>RETAIL HIGH</Text>
                  <Text style={[mv.cardValue, { color: Colors.green }]}>
                    ${marketValue.retailHigh.toLocaleString()}
                  </Text>
                  <Text style={mv.cardNote}>Dealer asking price</Text>
                </View>
              </View>

              {/* Range bar */}
              <View style={mv.rangeSection}>
                <View style={mv.rangeBar}>
                  <View style={mv.rangeTrack}>
                    <View style={mv.rangeFill} />
                  </View>
                  <View style={mv.rangeLabels}>
                    <Text style={mv.rangeLabelLeft}>Trade-In</Text>
                    <Text style={mv.rangeLabelCenter}>Sweet Spot</Text>
                    <Text style={mv.rangeLabelRight}>Asking</Text>
                  </View>
                </View>
              </View>

              {/* Condition / mileage notes */}
              {(marketValue.conditionNote || marketValue.mileageAdjustment) ? (
                <View style={mv.noteCard}>
                  <MaterialIcons name="info-outline" size={13} color={Colors.blueBright} />
                  <View style={{ flex: 1, gap: 2 }}>
                    {marketValue.conditionNote ? (
                      <Text style={mv.noteText}>{marketValue.conditionNote}</Text>
                    ) : null}
                    {marketValue.mileageAdjustment ? (
                      <Text style={mv.noteText}>
                        Mileage adjustment: {marketValue.mileageAdjustment > 0 ? '+' : ''}
                        ${Math.abs(marketValue.mileageAdjustment).toLocaleString()} per 10k mi deviation
                      </Text>
                    ) : null}
                  </View>
                </View>
              ) : null}

              <Text style={mv.disclaimer}>
                Values are estimates for informational purposes. Actual prices vary by condition, mileage, options, and market.
              </Text>
            </View>
          ) : null}
        </View>

        {/* ── RECALL STATUS ── */}
        <View style={styles.card}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.sm }}>
            <SectionTitle icon="gavel" label="NHTSA RECALL STATUS" color={hasRecall ? Colors.orange : Colors.green} />
            {nhtsaLoading ? (
              <View style={styles.nhtsaLiveBadge}>
                <ActivityIndicator size="small" color={Colors.blueBright} style={{ transform: [{ scale: 0.7 }] }} />
                <Text style={styles.nhtsaLiveBadgeText}>Fetching live data...</Text>
              </View>
            ) : (
              <View style={[styles.nhtsaLiveBadge, { backgroundColor: 'rgba(74,222,128,0.08)', borderColor: 'rgba(74,222,128,0.3)' }]}>
                <MaterialIcons name="verified" size={11} color={Colors.green} />
                <Text style={[styles.nhtsaLiveBadgeText, { color: Colors.green }]}>
                  {nhtsa?.cached ? 'Cached · NHTSA' : 'Live · NHTSA.gov'}
                </Text>
              </View>
            )}
          </View>
          {hasRecall ? (
            <View style={styles.recallWarningCard}>
              <View style={styles.recallWarningIcon}>
                <MaterialIcons name="warning" size={24} color={Colors.orange} />
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <Text style={styles.recallWarningTitle}>
                  {liveRecallCount} Active NHTSA Recall{liveRecallCount > 1 ? 's' : ''} on Record
                </Text>
                <Text style={styles.recallWarningBody}>
                  Safety recall data sourced from NHTSA.gov. Always verify current recall status directly with the government before purchase or use.
                </Text>
                <Pressable
                  style={({ pressed }) => [styles.nhtsaBtn, pressed && { opacity: 0.75 }]}
                  onPress={() => Linking.openURL('https://www.nhtsa.gov/recalls')}
                >
                  <MaterialIcons name="open-in-new" size={13} color={Colors.orange} />
                  <Text style={styles.nhtsaBtnText}>Verify at NHTSA.gov →</Text>
                </Pressable>
              </View>
            </View>
          ) : (
            <View style={styles.noRecallCard}>
              <View style={styles.noRecallIcon}>
                <MaterialIcons name="check-circle" size={24} color={Colors.green} />
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <Text style={styles.noRecallTitle}>No Active NHTSA Recalls Found</Text>
                <Text style={styles.noRecallBody}>
                  No open safety recalls on record for this vehicle. Always verify directly at NHTSA.gov before purchase.
                </Text>
                <Pressable
                  style={({ pressed }) => [styles.nhtsaBtnGreen, pressed && { opacity: 0.75 }]}
                  onPress={() => Linking.openURL('https://www.nhtsa.gov/recalls')}
                >
                  <MaterialIcons name="open-in-new" size={13} color={Colors.green} />
                  <Text style={styles.nhtsaBtnGreenText}>Confirm at NHTSA.gov →</Text>
                </Pressable>
              </View>
            </View>
          )}

          {/* ── Recall Detail Cards ── */}
          {!nhtsaLoading && nhtsa && nhtsa.recalls.length > 0 && (
            <View style={{ marginTop: Spacing.sm, gap: Spacing.sm }}>
              <Text style={styles.nhtsaSubHeader}>RECALL DETAILS</Text>
              {nhtsa.recalls.map((r, i) => (
                <View key={i} style={styles.recallDetailCard}>
                  <View style={styles.recallDetailHeader}>
                    <View style={styles.recallDetailNumBadge}>
                      <Text style={styles.recallDetailNum}>#{i + 1}</Text>
                    </View>
                    <Text style={styles.recallDetailComponent} numberOfLines={2}>{r.component}</Text>
                    {r.date ? <Text style={styles.recallDetailDate}>{r.date.slice(0, 4)}</Text> : null}
                  </View>
                  {r.summary ? (
                    <Text style={styles.recallDetailSummary} numberOfLines={3}>{r.summary}</Text>
                  ) : null}
                  {r.remedy ? (
                    <View style={styles.recallDetailRemedy}>
                      <MaterialIcons name="build" size={11} color={Colors.green} />
                      <Text style={styles.recallDetailRemedyText} numberOfLines={2}>{r.remedy}</Text>
                    </View>
                  ) : null}
                </View>
              ))}
            </View>
          )}

          {/* ── Common Complaints ── */}
          {!nhtsaLoading && nhtsa && nhtsa.defectCount > 0 && (
            <View style={{ marginTop: Spacing.md, gap: Spacing.sm }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <MaterialIcons name="report-problem" size={13} color={Colors.gold} />
                <Text style={styles.nhtsaSubHeader}>OWNER COMPLAINTS ({nhtsa.defectCount} total)</Text>
              </View>
              {nhtsa.defects.map((d, i) => (
                <View key={i} style={styles.defectCard}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                    <Text style={styles.defectComponent}>{d.component || 'General'}</Text>
                    {d.crashFlag ? (
                      <View style={styles.defectFlag}>
                        <Text style={styles.defectFlagText}>CRASH</Text>
                      </View>
                    ) : null}
                    {d.fireFlag ? (
                      <View style={[styles.defectFlag, { backgroundColor: 'rgba(255,68,68,0.2)', borderColor: 'rgba(255,68,68,0.4)' }]}>
                        <Text style={[styles.defectFlagText, { color: Colors.red }]}>FIRE</Text>
                      </View>
                    ) : null}
                  </View>
                  {d.summary ? (
                    <Text style={styles.defectSummary} numberOfLines={3}>{d.summary}</Text>
                  ) : null}
                </View>
              ))}
            </View>
          )}
        </View>

        {/* ── FULL SPECS ── */}
        <View style={styles.card}>
          <SectionTitle icon="list-alt" label="VEHICLE SPECIFICATIONS" />
          <View style={styles.specsContainer}>
            <SpecRow label="Type" value={data.type} />
            <SpecRow label="Year" value={year} />
            <SpecRow label="Length" value={`${data.lengthRange[0]}–${data.lengthRange[1]} ft`} accent />
            <SpecRow label="GVWR" value={`${data.weightRange[0].toLocaleString()}–${data.weightRange[1].toLocaleString()} lbs`} />
            <SpecRow label="Slideouts" value={String(data.slideouts)} accent />
            <SpecRow label="Sleeps" value={String(data.sleeps)} />
            <SpecRow label="Fuel Type" value={data.fuelType} accent />
            {data.engine ? <SpecRow label="Engine" value={data.engine} /> : null}
            {data.chassis && data.chassis !== 'N/A' ? <SpecRow label="Chassis" value={data.chassis} /> : null}
            {data.towingCapacity && data.towingCapacity > 0 ? (
              <SpecRow label="Tow Capacity" value={`${data.towingCapacity.toLocaleString()} lbs`} accent />
            ) : null}
            {data.generator ? <SpecRow label="Generator" value={data.generator} /> : null}
            {data.awningLength ? <SpecRow label="Awning" value={`${data.awningLength} ft Power Awning`} /> : null}
            {data.ceilingHeight ? <SpecRow label="Ceiling Height" value={`${data.ceilingHeight}"`} /> : null}
            {data.warrantyYears ? <SpecRow label="Structural Warranty" value={`${data.warrantyYears}-Year`} accent /> : null}
            {derivedSpecs.horsepower ? <SpecRow label="Horsepower" value={derivedSpecs.horsepower} accent /> : null}
            {derivedSpecs.transmission ? <SpecRow label="Transmission" value={derivedSpecs.transmission} /> : null}
            {derivedSpecs.fuelCapacity ? <SpecRow label="Fuel Tank" value={derivedSpecs.fuelCapacity} /> : null}
            {derivedSpecs.axles ? <SpecRow label="Axles" value={derivedSpecs.axles} /> : null}
            {derivedSpecs.leveling ? <SpecRow label="Leveling System" value={derivedSpecs.leveling} /> : null}
            {derivedSpecs.slideType ? <SpecRow label="Slide System" value={derivedSpecs.slideType} /> : null}
            {derivedSpecs.tireSize ? <SpecRow label="Tire Size" value={derivedSpecs.tireSize} /> : null}
            {derivedSpecs.gcwr ? <SpecRow label="GCWR" value={derivedSpecs.gcwr} /> : null}
            {data.basementStorage ? <SpecRow label="Basement Storage" value={`${data.basementStorage} cu ft`} /> : null}
            {data.hitchPinWeight ? <SpecRow label="Hitch / Pin Weight" value={`${data.hitchPinWeight.toLocaleString()} lbs`} /> : null}
            <View style={{ borderBottomWidth: 0 }}>
              <SpecRow label="RvFOX Rating" value={`${computedRating.toFixed(1)} / 5.0`} accent />
            </View>
          </View>
        </View>

        {/* ── WATER TANKS ── */}
        {data.freshWater ? (
          <View style={styles.card}>
            <SectionTitle icon="water" label="TANK CAPACITIES" color={Colors.blueBright} />
            <View style={styles.tanksRow}>
              <TankPill label="Fresh Water" gallons={data.freshWater} color={Colors.blueBright} />
              {data.grayWater ? <TankPill label="Gray Water" gallons={data.grayWater} color={Colors.textSecondary} /> : null}
              {data.blackWater ? <TankPill label="Black Water" gallons={data.blackWater} color={Colors.orange} /> : null}
            </View>
          </View>
        ) : null}

        {/* ── FLOORPLANS ── */}
        <View style={styles.card}>
          <SectionTitle icon="view-quilt" label="AVAILABLE FLOORPLANS" color={Colors.gold} />
          <View style={styles.floorplansWrap}>
            {data.floorplans.map(fp => (
              <View
                key={fp}
                style={[
                  styles.fpChip,
                  fp === floorplan && styles.fpChipSelected,
                ]}
              >
                {fp === floorplan && (
                  <MaterialIcons name="check" size={11} color="#000" />
                )}
                <Text style={[styles.fpChipText, fp === floorplan && styles.fpChipTextSelected]}>
                  {fp}
                </Text>
              </View>
            ))}
          </View>
          {floorplan ? (
            <View style={styles.selectedFloorplanNote}>
              <MaterialIcons name="info-outline" size={13} color={Colors.gold} />
              <Text style={styles.selectedFloorplanText}>
                Currently viewing: <Text style={{ color: Colors.gold, fontWeight: FontWeight.bold }}>{floorplan}</Text>
              </Text>
            </View>
          ) : null}
        </View>

        {/* ── MAINTENANCE SCHEDULE ── */}
        <View style={styles.card}>
          <SectionTitle icon="build" label="MAINTENANCE SCHEDULE" color={Colors.green} />
          <Text style={styles.maintIntro}>
            Recommended maintenance for {isTowable ? 'towable' : data.fuelType.toLowerCase()} {data.type.toLowerCase()} — always consult your owner manual.
          </Text>

          {/* Collapsible category accordion */}
          <View style={{ gap: Spacing.sm, marginBottom: Spacing.sm }}>
            {maintenanceCategories.map(cat => {
              const items = maintenanceByCat[cat] ?? [];
              const isOpen = !!expandedCategories[cat];
              const iconName = CATEGORY_ICONS[cat] ?? 'build';
              const critCount = items.filter(i => i.priority === 'Critical').length;
              const impCount  = items.filter(i => i.priority === 'Important').length;
              return (
                <View key={cat} style={styles.maintAccordion}>
                  <Pressable
                    style={({ pressed }) => [styles.maintAccordionHeader, isOpen && styles.maintAccordionHeaderOpen, pressed && { opacity: 0.8 }]}
                    onPress={() => toggleCategory(cat)}
                  >
                    <View style={[styles.maintAccordionIcon, { backgroundColor: (PRIORITY_COLORS[critCount > 0 ? 'Critical' : impCount > 0 ? 'Important' : 'Routine'] ?? Colors.green) + '18' }]}>
                      <MaterialIcons name={iconName as any} size={16} color={critCount > 0 ? Colors.red : impCount > 0 ? Colors.orange : Colors.green} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.maintAccordionTitle}>{cat}</Text>
                      <Text style={styles.maintAccordionSub}>{items.length} task{items.length !== 1 ? 's' : ''}{critCount > 0 ? ` · ${critCount} critical` : ''}</Text>
                    </View>
                    <View style={{ flexDirection: 'row', gap: 5, alignItems: 'center' }}>
                      {critCount > 0 && (
                        <View style={[styles.maintPriorityDot, { backgroundColor: Colors.red }]}>
                          <Text style={styles.maintPriorityDotText}>{critCount}</Text>
                        </View>
                      )}
                      {impCount > 0 && (
                        <View style={[styles.maintPriorityDot, { backgroundColor: Colors.orange }]}>
                          <Text style={styles.maintPriorityDotText}>{impCount}</Text>
                        </View>
                      )}
                      <MaterialIcons name={isOpen ? 'keyboard-arrow-up' : 'keyboard-arrow-down'} size={20} color={Colors.textMuted} />
                    </View>
                  </Pressable>
                  {isOpen && (
                    <View style={styles.maintAccordionBody}>
                      {items.map((item, i) => (
                        <View key={`${item.task}-${i}`} style={i === items.length - 1 ? { borderBottomWidth: 0 } : {}}>
                          <MaintenanceCard item={item} />
                        </View>
                      ))}
                    </View>
                  )}
                </View>
              );
            })}
          </View>

          <View style={styles.maintDisclaimer}>
            <MaterialIcons name="info-outline" size={12} color={Colors.textMuted} />
            <Text style={styles.maintDisclaimerText}>
              Always follow manufacturer intervals in your owner manual. Intervals may vary by engine hours, usage conditions, and climate.
            </Text>
          </View>
        </View>

        {/* ── REVIEWS ── */}
        <View style={styles.card}>
          <SectionTitle icon="rate-review" label="OWNER REVIEWS" color={Colors.gold} />

          {/* Rating summary */}
          <View style={styles.ratingSummary}>
            <View style={styles.ratingBigNum}>
              <Text style={styles.ratingBigText}>{computedRating.toFixed(1)}</Text>
              <StarRow rating={computedRating} size={18} />
              <Text style={styles.ratingCountText}>{ratingCount.toLocaleString()} ratings</Text>
            </View>
            <View style={styles.ratingBars}>
              {[5, 4, 3, 2, 1].map(star => {
                const pct = star === 5 ? 68 : star === 4 ? 21 : star === 3 ? 7 : star === 2 ? 3 : 1;
                return (
                  <View key={star} style={styles.ratingBarRow}>
                    <Text style={styles.ratingBarNum}>{star}</Text>
                    <MaterialIcons name="star" size={10} color={Colors.gold} />
                    <View style={styles.ratingBarTrack}>
                      <View style={[styles.ratingBarFill, { width: `${pct}%` as any }]} />
                    </View>
                    <Text style={styles.ratingBarPct}>{pct}%</Text>
                  </View>
                );
              })}
            </View>
          </View>

          {/* Review cards */}
          {reviews.map(r => <ReviewCard key={r.id} review={r} />)}

          <View style={styles.reviewsNote}>
            <MaterialIcons name="info-outline" size={12} color={Colors.textMuted} />
            <Text style={styles.reviewsNoteText}>
              Reviews are aggregated from verified owner communities and RV forums. RvFOX Pro does not independently verify individual reviews.
            </Text>
          </View>
        </View>

        {/* ── RATING METHODOLOGY CARD ── */}
        <View style={styles.ratingMethodCard}>
          {/* Header */}
          <View style={styles.ratingMethodHeader}>
            <MaterialIcons name="analytics" size={14} color={Colors.gold} />
            <Text style={styles.ratingMethodTitle}>RvFOX RATING METHODOLOGY</Text>
            <View style={[styles.confBadge,
              ratingMeta.confidence === 'High' ? styles.confHigh :
              ratingMeta.confidence === 'Low' ? styles.confLow : styles.confMed,
            ]}>
              <Text style={styles.confBadgeText}>{ratingMeta.confidence} Confidence</Text>
            </View>
          </View>

          {/* Score breakdown */}
          <View style={styles.ratingBreakdownGrid}>
            <View style={styles.ratingBreakdownCell}>
              <Text style={styles.ratingBreakdownValue}>{ratingMeta.base.toFixed(2)}</Text>
              <Text style={styles.ratingBreakdownLabel}>Base Score</Text>
              <Text style={styles.ratingBreakdownSub}>{make} manufacturer</Text>
            </View>
            <View style={styles.ratingBreakdownDivider} />
            <View style={styles.ratingBreakdownCell}>
              <Text style={[styles.ratingBreakdownValue, { color: ratingMeta.tierAdj >= 0 ? Colors.green : Colors.red }]}>
                {ratingMeta.tierAdj >= 0 ? '+' : ''}{ratingMeta.tierAdj.toFixed(2)}
              </Text>
              <Text style={styles.ratingBreakdownLabel}>Tier Adj.</Text>
              <Text style={styles.ratingBreakdownSub}>{ratingMeta.tierLabel}</Text>
            </View>
            <View style={styles.ratingBreakdownDivider} />
            <View style={styles.ratingBreakdownCell}>
              <Text style={[styles.ratingBreakdownValue, { color: ratingMeta.yearAdj >= 0 ? Colors.green : Colors.red }]}>
                {ratingMeta.yearAdj >= 0 ? '+' : ''}{ratingMeta.yearAdj.toFixed(2)}
              </Text>
              <Text style={styles.ratingBreakdownLabel}>Year Adj.</Text>
              <Text style={styles.ratingBreakdownSub}>{year} model</Text>
            </View>
            <View style={styles.ratingBreakdownDivider} />
            <View style={[styles.ratingBreakdownCell, styles.ratingBreakdownFinalCell]}>
              <Text style={[styles.ratingBreakdownValue, { color: Colors.gold, fontSize: 22 }]}>
                {ratingMeta.score.toFixed(1)}
              </Text>
              <Text style={styles.ratingBreakdownLabel}>Final Score</Text>
              <Text style={styles.ratingBreakdownSub}>out of 5.0</Text>
            </View>
          </View>

          {/* Year note */}
          <View style={styles.ratingYearNote}>
            <MaterialIcons name="event" size={11} color={Colors.textMuted} />
            <Text style={styles.ratingYearNoteText}>{ratingMeta.yearNote}</Text>
          </View>

          {/* Sources */}
          <View style={styles.ratingSourcesWrap}>
            <Text style={styles.ratingSourcesTitle}>CROSS-REFERENCED SOURCES</Text>
            <View style={styles.ratingSourcesGrid}>
              {ratingMeta.sources.map((src, i) => (
                <View key={i} style={styles.ratingSourceChip}>
                  <MaterialIcons name="check-circle" size={9} color={Colors.green} />
                  <Text style={styles.ratingSourceText}>{src}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* ── ACTION BUTTONS ── */}
        <View style={styles.actionsSection}>
          {/* Customer Name Input */}
          <View style={styles.customerNameRow}>
            <MaterialIcons name="person" size={16} color={Colors.textMuted} />
            <TextInput
              style={styles.customerNameInput}
              placeholder="Prepared for (optional)"
              placeholderTextColor={Colors.textMuted}
              value={customerName}
              onChangeText={setCustomerName}
              autoCapitalize="words"
              returnKeyType="done"
              contextMenuHidden={false}
            />
          </View>

          {/* Full PDF Report + Preview */}
          <View style={styles.pdfButtonRow}>
            <Pressable
              style={({ pressed }) => [styles.primaryActionBtn, { flex: 1 }, pressed && styles.primaryActionBtnPressed, (pdfLoading || previewLoading) && { opacity: 0.7 }]}
              onPress={() => handleRequestPDF('share')}
              disabled={pdfLoading || previewLoading}
            >
              {pdfLoading ? (
                <ActivityIndicator color="#000" size="small" />
              ) : (
                <MaterialIcons name="picture-as-pdf" size={18} color="#000" />
              )}
              <Text style={[styles.primaryActionBtnText, { fontSize: 14 }]}>
                {pdfLoading ? 'Generating...' : 'Full Report'}
              </Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.previewBtn, pressed && { opacity: 0.8 }, (pdfLoading || previewLoading) && { opacity: 0.6 }]}
              onPress={() => handleRequestPDF('preview')}
              disabled={pdfLoading || previewLoading}
            >
              {previewLoading ? (
                <ActivityIndicator color={Colors.blueBright} size="small" />
              ) : (
                <MaterialIcons name="preview" size={18} color={Colors.blueBright} />
              )}
              <Text style={styles.previewBtnText}>Preview</Text>
            </Pressable>
          </View>

          {/* Customer Name Modal */}
          <Modal visible={showCustomerModal} transparent animationType="slide" onRequestClose={() => setShowCustomerModal(false)}>
            <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.75)' }}>
              <View style={styles.customerModal}>
                <View style={styles.customerModalHandle} />
                <Text style={styles.customerModalTitle}>
                  {pendingAction === 'preview' ? 'Preview Report' : 'Generate PDF Report'}
                </Text>
                <Text style={styles.customerModalSub}>Enter the customer name to appear on the report (optional)</Text>
                <View style={styles.customerModalInputRow}>
                  <MaterialIcons name="person" size={18} color={Colors.textMuted} />
                  <TextInput
                    style={styles.customerModalInput}
                    value={customerName}
                    onChangeText={setCustomerName}
                    placeholder="e.g. Mike Johnson"
                    placeholderTextColor={Colors.textMuted}
                    autoCapitalize="words"
                    autoFocus
                    returnKeyType="done"
                    onSubmitEditing={handleConfirmCustomerName}
                  />
                  {customerName.length > 0 && (
                    <Pressable onPress={() => setCustomerName('')} hitSlop={8}>
                      <MaterialIcons name="close" size={16} color={Colors.textMuted} />
                    </Pressable>
                  )}
                </View>
                <Pressable
                  style={({ pressed }) => [styles.customerModalBtn, pressed && { opacity: 0.85 }]}
                  onPress={handleConfirmCustomerName}
                >
                  <MaterialIcons name={pendingAction === 'preview' ? 'preview' : 'picture-as-pdf'} size={18} color="#000" />
                  <Text style={styles.customerModalBtnText}>
                    {pendingAction === 'preview' ? 'Preview Report' : 'Generate & Share PDF'}
                  </Text>
                </Pressable>
                <Pressable onPress={() => { setShowCustomerModal(false); setPendingAction(null); }} hitSlop={8} style={{ paddingVertical: 8 }}>
                  <Text style={{ fontSize: 14, color: Colors.textMuted, textAlign: 'center' }}>Skip / Cancel</Text>
                </Pressable>
              </View>
            </KeyboardAvoidingView>
          </Modal>

          <View style={styles.secondaryActionsRow}>
            <Pressable style={({ pressed }) => [styles.secActionBtn, styles.secActionCalBtn, pressed && { opacity: 0.75 }]} onPress={() => router.push({ pathname: '/(tabs)/rvcal', params: { msrp: String(data.msrpRange[0]) } })}>
              <MaterialIcons name="calculate" size={16} color={Colors.gold} />
              <Text style={[styles.secActionText, { color: Colors.gold }]}>RvCal</Text>
              <Text style={styles.secActionSub}>Loan Calculator</Text>
            </Pressable>
            <Pressable style={({ pressed }) => [styles.secActionBtn, styles.secActionGrokBtn, pressed && { opacity: 0.75 }]} onPress={handleOpenRvGrok}>
              <MaterialIcons name="chat" size={16} color="#9B59F5" />
              <Text style={[styles.secActionText, { color: '#9B59F5' }]}>RvGrok</Text>
              <Text style={styles.secActionSub}>Ask AI</Text>
            </Pressable>
          </View>

          {/* VIN History Report */}
          {vin ? (
            <Pressable
              style={({ pressed }) => [styles.vinHistoryBtn, pressed && { opacity: 0.85, transform: [{ scale: 0.99 }] }]}
              onPress={() => router.push({ pathname: '/vin-history', params: { vin } })}
            >
              <MaterialIcons name="history-edu" size={18} color={Colors.gold} />
              <View style={{ flex: 1 }}>
                <Text style={styles.vinHistoryBtnTitle}>NMVTIS VIN History Report</Text>
                <Text style={styles.vinHistoryBtnSub}>Title · Ownership · Odometer · Recalls</Text>
              </View>
              <View style={styles.vinHistoryBadge}>
                <Text style={styles.vinHistoryBadgeText}>FREE</Text>
              </View>
              <MaterialIcons name="chevron-right" size={18} color={Colors.gold} />
            </Pressable>
          ) : null}

          {/* NHTSA external link */}
          <Pressable
            style={({ pressed }) => [styles.nhtsaLinkBtn, pressed && { opacity: 0.75 }]}
            onPress={() => Linking.openURL('https://www.nhtsa.gov/recalls')}
          >
            <MaterialIcons name="account-balance" size={15} color={Colors.textSecondary} />
            <Text style={styles.nhtsaLinkText}>Verify Recalls at NHTSA.gov</Text>
            <MaterialIcons name="open-in-new" size={14} color={Colors.textMuted} />
          </Pressable>
        </View>

        {/* ── DISCLAIMER ── */}
        <View style={styles.bottomDisclaimer}>
          <Text style={styles.bottomDisclaimerText}>
            All specifications, pricing, and recall data are estimates for informational purposes only.
            Always verify recalls at nhtsa.gov · RvFOX Pro is not responsible for inaccuracies in third-party data.
          </Text>
        </View>

      </ScrollView>
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A2A3A' },
  globalBackdrop: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0,
  },

  // Year warning banner
  yearWarningBanner: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 12, zIndex: 2,
    backgroundColor: '#B22222',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    borderBottomWidth: 2, borderBottomColor: '#FF4444',
  },
  yearWarningTitle: {
    fontSize: FontSize.sm, fontWeight: FontWeight.extrabold,
    color: '#fff', letterSpacing: 0.5, marginBottom: 2,
  },
  yearWarningText: {
    fontSize: FontSize.xs, color: 'rgba(255,255,255,0.9)', lineHeight: 18,
  },
  centered: { alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  errorText: { fontSize: FontSize.lg, color: Colors.textSecondary, fontWeight: FontWeight.semibold },
  backBtnSmall: {
    backgroundColor: Colors.bgCard, borderRadius: Radius.full,
    paddingHorizontal: 24, paddingVertical: 12,
    borderWidth: 1, borderColor: Colors.border,
  },
  backBtnSmallText: { fontSize: FontSize.base, color: Colors.textPrimary, fontWeight: FontWeight.semibold },

  // Back button
  backBtn: {
    position: 'absolute', left: 16, zIndex: 110,
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.65)',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5, shadowRadius: 8, elevation: 6,
    paddingLeft: 4,
  },

  // Hero
  heroWrap: { position: 'relative', height: 320, zIndex: 2 },
  heroImage: { width: '100%', height: 320 },
  heroBottom: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    padding: Spacing.md, paddingTop: 80,
    gap: 4, zIndex: 1,
  },
  heroBadgeRow: { flexDirection: 'row', gap: 8, marginBottom: 4 },
  typeBadge: {
    backgroundColor: 'rgba(30,111,255,0.7)',
    borderRadius: Radius.sm, paddingHorizontal: 10, paddingVertical: 4,
    borderWidth: 1, borderColor: 'rgba(77,166,255,0.5)',
  },
  typeBadgeText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: '#fff', letterSpacing: 0.5 },
  recallBadgeHero: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: Colors.orange, borderRadius: Radius.sm,
    paddingHorizontal: 8, paddingVertical: 4,
  },
  recallBadgeHeroText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: '#000' },
  noRecallBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: 'rgba(74,222,128,0.2)',
    borderWidth: 1, borderColor: 'rgba(74,222,128,0.5)',
    borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 4,
  },
  noRecallBadgeText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.green },
  heroYear: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.gold, letterSpacing: 2 },
  heroName: { fontSize: FontSize.h2, fontWeight: FontWeight.extrabold, color: '#fff', lineHeight: 30 },
  heroFloorplan: { fontSize: FontSize.xs, color: 'rgba(255,255,255,0.55)' },
  heroRatingRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  heroRatingNum: { fontSize: FontSize.md, fontWeight: FontWeight.extrabold, color: Colors.gold },
  heroRatingCount: { fontSize: FontSize.xs, color: 'rgba(255,255,255,0.5)' },

  // Price card
  priceCard: {
    marginHorizontal: Spacing.md, marginTop: Spacing.md, marginBottom: 2,
    backgroundColor: 'rgba(27,44,64,0.80)',
    borderRadius: Radius.xl, borderWidth: 1.5, borderColor: Colors.borderBlueBright,
    padding: Spacing.md, flexDirection: 'row', alignItems: 'center',
    shadowColor: '#1E6FFF', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45, shadowRadius: 18, elevation: 8,
  },
  priceCardLeft: { flex: 1, gap: 4 },
  priceLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.blueBright, letterSpacing: 1.5 },
  priceValue: { fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.green },
  priceSep: { color: Colors.textMuted, fontWeight: FontWeight.regular },
  priceNote: { fontSize: FontSize.xs, color: Colors.textMuted },
  priceCardRight: { alignItems: 'flex-end', gap: 6 },
  msrpTag: {
    backgroundColor: 'rgba(255,215,0,0.12)',
    borderWidth: 1, borderColor: Colors.borderGold,
    borderRadius: Radius.full, paddingHorizontal: 10, paddingVertical: 4,
  },
  msrpTagText: { fontSize: 10, fontWeight: FontWeight.bold, color: Colors.gold, letterSpacing: 1 },
  brandSince: { fontSize: FontSize.xs, color: Colors.textMuted },

  // Generic card
  card: {
    marginHorizontal: Spacing.md, marginTop: Spacing.md,
    backgroundColor: 'rgba(27,44,64,0.60)',
    borderRadius: Radius.xl, borderWidth: 1, borderColor: 'rgba(168,188,207,0.25)',
    padding: Spacing.md,
    zIndex: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.30, shadowRadius: 10, elevation: 4,
  },

  // Description
  descCard: {
    marginHorizontal: Spacing.md, marginTop: Spacing.md,
    backgroundColor: 'rgba(27,44,64,0.60)',
    borderRadius: Radius.xl, borderWidth: 1, borderColor: 'rgba(168,188,207,0.22)',
    padding: Spacing.md, zIndex: 2,
  },
  descText: { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 22 },

  // NHTSA live badge
  nhtsaLiveBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(30,111,255,0.08)',
    borderWidth: 1, borderColor: 'rgba(30,111,255,0.2)',
    borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 4,
  },
  nhtsaLiveBadgeText: {
    fontSize: 10, color: Colors.blueBright, fontWeight: FontWeight.semibold,
  },
  // Floorplan premium badge
  fpPremiumBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: 'rgba(255,215,0,0.12)',
    borderWidth: 1, borderColor: 'rgba(255,215,0,0.40)',
    borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 4,
  },
  fpPremiumBadgeText: {
    fontSize: 10, color: Colors.gold, fontWeight: FontWeight.bold, letterSpacing: 0.3,
  },
  nhtsaSubHeader: {
    fontSize: FontSize.xs, fontWeight: FontWeight.bold,
    color: Colors.textMuted, letterSpacing: 1.2,
  },
  recallDetailCard: {
    backgroundColor: 'rgba(255,140,0,0.06)',
    borderWidth: 1, borderColor: 'rgba(255,140,0,0.2)',
    borderRadius: Radius.md, padding: Spacing.sm, gap: 4,
  },
  recallDetailHeader: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 8,
  },
  recallDetailNumBadge: {
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: Colors.orange,
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  recallDetailNum: { fontSize: 10, fontWeight: FontWeight.bold, color: '#000' },
  recallDetailComponent: {
    flex: 1, fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.orange,
  },
  recallDetailDate: { fontSize: FontSize.xs, color: Colors.textMuted },
  recallDetailSummary: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 17 },
  recallDetailRemedy: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 5,
    backgroundColor: 'rgba(74,222,128,0.06)',
    borderRadius: Radius.sm, padding: 6,
  },
  recallDetailRemedyText: { flex: 1, fontSize: FontSize.xs, color: Colors.green, lineHeight: 16 },
  defectCard: {
    backgroundColor: 'rgba(255,215,0,0.04)',
    borderWidth: 1, borderColor: 'rgba(255,215,0,0.15)',
    borderRadius: Radius.md, padding: Spacing.sm,
  },
  defectComponent: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.gold },
  defectFlag: {
    backgroundColor: 'rgba(255,140,0,0.18)',
    borderWidth: 1, borderColor: 'rgba(255,140,0,0.4)',
    borderRadius: Radius.sm, paddingHorizontal: 5, paddingVertical: 2,
  },
  defectFlagText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.orange },
  defectSummary: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 17 },
  // Recall cards
  recallWarningCard: {
    flexDirection: 'row', gap: Spacing.sm,
    backgroundColor: 'rgba(255,140,0,0.07)',
    borderWidth: 1, borderColor: 'rgba(255,140,0,0.3)',
    borderRadius: Radius.lg, padding: Spacing.md,
  },
  recallWarningIcon: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,140,0,0.12)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: 'rgba(255,140,0,0.4)',
  },
  recallWarningTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.orange },
  recallWarningBody: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 18 },
  nhtsaBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    marginTop: 4, alignSelf: 'flex-start',
  },
  nhtsaBtnText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.orange },
  noRecallCard: {
    flexDirection: 'row', gap: Spacing.sm,
    backgroundColor: 'rgba(74,222,128,0.06)',
    borderWidth: 1, borderColor: 'rgba(74,222,128,0.25)',
    borderRadius: Radius.lg, padding: Spacing.md,
  },
  noRecallIcon: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(74,222,128,0.12)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: 'rgba(74,222,128,0.4)',
  },
  noRecallTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.green },
  noRecallBody: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 18 },
  nhtsaBtnGreen: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    marginTop: 4, alignSelf: 'flex-start',
  },
  nhtsaBtnGreenText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.green },

  // Specs
  specsContainer: { borderTopWidth: 1, borderTopColor: Colors.border },


  // Tanks
  tanksRow: { flexDirection: 'row', gap: Spacing.sm },

  // Floorplans
  floorplansWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  fpChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(255,215,0,0.06)',
    borderWidth: 1, borderColor: Colors.borderGold,
    borderRadius: Radius.sm, paddingHorizontal: 12, paddingVertical: 7,
  },
  fpChipSelected: {
    backgroundColor: Colors.gold,
    borderColor: Colors.gold,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45, shadowRadius: 8, elevation: 3,
  },
  fpChipText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.gold },
  fpChipTextSelected: { color: '#000' },
  selectedFloorplanNote: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    marginTop: Spacing.sm,
    backgroundColor: 'rgba(255,215,0,0.06)',
    borderRadius: Radius.md, padding: Spacing.sm,
  },
  selectedFloorplanText: { fontSize: FontSize.xs, color: Colors.textSecondary },

  // Maintenance
  maintIntro: { fontSize: FontSize.xs, color: Colors.textMuted, lineHeight: 18, marginBottom: Spacing.md },
  // Accordion styles
  maintAccordion: {
    backgroundColor: 'rgba(27,44,64,0.45)',
    borderRadius: Radius.lg,
    borderWidth: 1, borderColor: 'rgba(168,188,207,0.20)',
    overflow: 'hidden',
  },
  maintAccordionHeader: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingHorizontal: Spacing.md, paddingVertical: 14,
  },
  maintAccordionHeaderOpen: {
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    backgroundColor: 'rgba(74,222,128,0.04)',
  },
  maintAccordionIcon: {
    width: 36, height: 36, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
  },
  maintAccordionTitle: {
    fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.textPrimary,
  },
  maintAccordionSub: {
    fontSize: FontSize.xs, color: Colors.textMuted, marginTop: 1,
  },
  maintPriorityDot: {
    width: 18, height: 18, borderRadius: 9,
    alignItems: 'center', justifyContent: 'center',
  },
  maintPriorityDotText: {
    fontSize: 10, fontWeight: FontWeight.extrabold, color: '#000',
  },
  maintAccordionBody: {
    paddingHorizontal: Spacing.sm,
    backgroundColor: 'rgba(0,0,0,0.15)',
  },
  maintDisclaimer: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 5,
    backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: Radius.md, padding: Spacing.sm,
  },
  maintDisclaimerText: { flex: 1, fontSize: 10, color: Colors.textMuted, lineHeight: 16 },

  // Rating summary
  ratingSummary: {
    flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md,
    backgroundColor: 'rgba(20,30,55,0.60)',
    borderRadius: Radius.lg, borderWidth: 1.5, borderColor: 'rgba(255,215,0,0.30)',
    padding: Spacing.md,
  },
  ratingBigNum: { alignItems: 'center', gap: 4, minWidth: 80 },
  ratingBigText: { fontSize: 40, fontWeight: FontWeight.extrabold, color: Colors.gold, lineHeight: 44 },
  ratingCountText: { fontSize: FontSize.xs, color: Colors.textMuted },
  ratingBars: { flex: 1, justifyContent: 'center', gap: 4 },
  ratingBarRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  ratingBarNum: { fontSize: 11, color: Colors.textMuted, fontWeight: FontWeight.medium, width: 8 },
  ratingBarTrack: {
    flex: 1, height: 6, backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: Radius.full, overflow: 'hidden',
  },
  ratingBarFill: {
    height: '100%', backgroundColor: Colors.gold, borderRadius: Radius.full,
  },
  ratingBarPct: { fontSize: 10, color: Colors.textMuted, width: 28, textAlign: 'right' },

  reviewsNote: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 5,
    backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: Radius.md, padding: Spacing.sm,
  },
  reviewsNoteText: { flex: 1, fontSize: 10, color: Colors.textMuted, lineHeight: 16 },

  // Customer name + PDF buttons
  customerNameRow: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.lg, paddingHorizontal: 14, paddingVertical: 12,
  },
  customerNameInput: {
    flex: 1, fontSize: FontSize.sm, color: '#FFFFFF',
    fontWeight: FontWeight.medium,
  },
  pdfButtonRow: {
    flexDirection: 'row', gap: Spacing.sm,
  },
  previewBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    borderWidth: 1.5, borderColor: Colors.borderBlue, borderRadius: Radius.full,
    paddingVertical: 14, paddingHorizontal: 20,
    backgroundColor: 'rgba(30,111,255,0.08)',
    shadowColor: Colors.blueBright, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2, shadowRadius: 8, elevation: 3,
  },
  previewBtnText: {
    fontSize: FontSize.base, fontWeight: FontWeight.bold, color: Colors.blueBright,
  },
  customerModal: {
    backgroundColor: '#060D1F',
    borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    borderTopWidth: 2, borderColor: Colors.gold,
    padding: Spacing.xl, paddingBottom: 36, gap: Spacing.md,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.35, shadowRadius: 24, elevation: 20,
  },
  customerModalHandle: {
    width: 36, height: 4, backgroundColor: Colors.border,
    borderRadius: 2, alignSelf: 'center', marginBottom: Spacing.xs,
  },
  customerModalTitle: {
    fontSize: FontSize.xl, fontWeight: FontWeight.extrabold, color: Colors.textPrimary,
    textAlign: 'center',
  },
  customerModalSub: {
    fontSize: FontSize.sm, color: Colors.textSecondary,
    textAlign: 'center', lineHeight: 20,
  },
  customerModalInputRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: 'rgba(10,28,60,0.85)',
    borderWidth: 1.5, borderColor: 'rgba(30,111,255,0.45)',
    borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 14,
  },
  customerModalInput: {
    flex: 1, fontSize: FontSize.base, color: '#FFFFFF', fontWeight: FontWeight.medium,
  },
  customerModalBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.full, paddingVertical: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45, shadowRadius: 12, elevation: 6,
  },
  customerModalBtnText: {
    fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#000',
  },

  // Action buttons
  actionsSection: {
    marginHorizontal: Spacing.md, marginTop: Spacing.lg, gap: Spacing.sm, zIndex: 2,
  },
  primaryActionBtn: {
    backgroundColor: Colors.gold, borderRadius: Radius.full,
    paddingVertical: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: Spacing.sm,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45, shadowRadius: 14, elevation: 6,
  },
  primaryActionBtnPressed: {
    shadowOpacity: 0.9, shadowRadius: 22, elevation: 12, transform: [{ scale: 0.98 }],
  },
  primaryActionBtnText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: '#000' },
  secondaryActionsRow: { flexDirection: 'row', gap: Spacing.sm },
  secActionBtn: {
    flex: 1, borderRadius: Radius.xl, paddingVertical: 14,
    alignItems: 'center', justifyContent: 'center', gap: 4,
    borderWidth: 1,
  },
  secActionCalBtn: {
    backgroundColor: 'rgba(255,215,0,0.07)', borderColor: Colors.borderGold,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.2, shadowRadius: 8, elevation: 3,
  },
  secActionGrokBtn: {
    backgroundColor: 'rgba(155,89,245,0.08)', borderColor: 'rgba(155,89,245,0.35)',
    shadowColor: '#9B59F5', shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.2, shadowRadius: 8, elevation: 3,
  },
  secActionText: { fontSize: FontSize.base, fontWeight: FontWeight.extrabold },
  secActionSub: { fontSize: FontSize.xs, color: Colors.textMuted, fontWeight: FontWeight.medium },
  vinHistoryBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(255,215,0,0.07)', borderWidth: 1.5,
    borderColor: Colors.borderGold, borderRadius: Radius.xl,
    padding: Spacing.md,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.18, shadowRadius: 10, elevation: 3,
  },
  vinHistoryBtnTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.gold },
  vinHistoryBtnSub: { fontSize: FontSize.xs, color: Colors.textSecondary, marginTop: 1 },
  vinHistoryBadge: {
    backgroundColor: 'rgba(74,222,128,0.12)', borderWidth: 1,
    borderColor: 'rgba(74,222,128,0.35)', borderRadius: Radius.sm,
    paddingHorizontal: 7, paddingVertical: 4,
  },
  vinHistoryBadgeText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.green, letterSpacing: 0.8 },
  nhtsaLinkBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: Colors.bgCard, borderRadius: Radius.full,
    borderWidth: 1, borderColor: Colors.border, paddingVertical: 12,
  },
  nhtsaLinkText: { fontSize: FontSize.sm, color: Colors.textSecondary, fontWeight: FontWeight.medium },

  // Bottom
  bottomDisclaimer: {
    marginHorizontal: Spacing.md, marginTop: Spacing.lg,
    padding: Spacing.md, zIndex: 2,
    backgroundColor: 'rgba(27,44,64,0.45)',
    borderRadius: Radius.lg, borderWidth: 1, borderColor: 'rgba(168,188,207,0.18)',
  },
  bottomDisclaimerText: { fontSize: 10, color: Colors.textMuted, lineHeight: 16, textAlign: 'center' },

  // Rating methodology card
  ratingMethodCard: {
    marginHorizontal: Spacing.md, marginTop: Spacing.md,
    backgroundColor: 'rgba(27,44,64,0.60)',
    borderRadius: Radius.xl, borderWidth: 1.5, borderColor: 'rgba(168,188,207,0.30)',
    padding: Spacing.md,
    shadowColor: Colors.gold, shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.12, shadowRadius: 12, elevation: 4,
  },
  ratingMethodHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: Spacing.md,
  },
  ratingMethodTitle: {
    flex: 1, fontSize: FontSize.xs, fontWeight: FontWeight.bold,
    color: Colors.gold, letterSpacing: 1.6,
  },
  confBadge: {
    borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 3,
    borderWidth: 1,
  },
  confHigh: { backgroundColor: 'rgba(74,222,128,0.1)', borderColor: 'rgba(74,222,128,0.4)' },
  confMed: { backgroundColor: 'rgba(255,215,0,0.1)', borderColor: 'rgba(255,215,0,0.35)' },
  confLow: { backgroundColor: 'rgba(255,68,68,0.1)', borderColor: 'rgba(255,68,68,0.3)' },
  confBadgeText: { fontSize: 9, fontWeight: FontWeight.bold, color: Colors.textSecondary },
  ratingBreakdownGrid: {
    flexDirection: 'row', alignItems: 'stretch',
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border,
    overflow: 'hidden', marginBottom: Spacing.sm,
  },
  ratingBreakdownCell: {
    flex: 1, alignItems: 'center', paddingVertical: 12, paddingHorizontal: 4, gap: 2,
  },
  ratingBreakdownFinalCell: {
    backgroundColor: 'rgba(255,215,0,0.06)',
  },
  ratingBreakdownDivider: {
    width: 1, backgroundColor: Colors.border, alignSelf: 'stretch',
  },
  ratingBreakdownValue: {
    fontSize: 18, fontWeight: FontWeight.extrabold, color: Colors.textPrimary,
  },
  ratingBreakdownLabel: {
    fontSize: 9, fontWeight: FontWeight.bold, color: Colors.textMuted,
    letterSpacing: 0.8, textTransform: 'uppercase',
  },
  ratingBreakdownSub: {
    fontSize: 9, color: Colors.textDim, textAlign: 'center',
  },
  ratingYearNote: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 5,
    backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: Radius.md,
    padding: Spacing.sm, marginBottom: Spacing.sm,
  },
  ratingYearNoteText: {
    flex: 1, fontSize: 10, color: Colors.textMuted, lineHeight: 15,
  },
  ratingSourcesWrap: { gap: 6 },
  ratingSourcesTitle: {
    fontSize: 9, fontWeight: FontWeight.bold, color: Colors.textDim,
    letterSpacing: 1.5, textTransform: 'uppercase',
  },
  ratingSourcesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 5 },
  ratingSourceChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(74,222,128,0.05)',
    borderWidth: 1, borderColor: 'rgba(74,222,128,0.18)',
    borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 3,
  },
  ratingSourceText: { fontSize: 9, color: Colors.textMuted, fontWeight: FontWeight.medium },
});

// ─── MARKET VALUE STYLES ─────────────────────────────────────────────────────

const mv = StyleSheet.create({
  container: { gap: Spacing.md },
  loadingWrap: { paddingVertical: Spacing.md, gap: 12 },
  loadingText: { fontSize: FontSize.sm, color: Colors.textMuted },
  progressStep: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  progressDot: {
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1.5, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  progressText: { fontSize: FontSize.sm, color: Colors.textMuted, fontWeight: '400' },
  errorCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 8,
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: Radius.md, padding: Spacing.md,
    borderWidth: 1, borderColor: Colors.border,
  },
  errorText: { flex: 1, fontSize: FontSize.sm, color: Colors.textMuted, lineHeight: 18 },
  cardsRow: { flexDirection: 'row', gap: Spacing.sm },
  valueCard: {
    flex: 1, borderRadius: Radius.xl, borderWidth: 1.5,
    padding: Spacing.sm, alignItems: 'center', gap: 4,
  },
  tradeInCard: {
    backgroundColor: 'rgba(188,185,186,0.06)',
    borderColor: 'rgba(188,185,186,0.3)',
    shadowColor: Colors.silver, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15, shadowRadius: 8, elevation: 3,
  },
  retailLowCard: {
    backgroundColor: 'rgba(0,104,192,0.07)',
    borderColor: 'rgba(0,104,192,0.35)',
    shadowColor: Colors.blue, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15, shadowRadius: 8, elevation: 3,
  },
  retailHighCard: {
    backgroundColor: 'rgba(74,222,128,0.07)',
    borderColor: 'rgba(74,222,128,0.35)',
    shadowColor: Colors.green, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15, shadowRadius: 8, elevation: 3,
  },
  cardIconWrap: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: 'rgba(188,185,186,0.12)',
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 2,
  },
  cardLabel: {
    fontSize: 9, fontWeight: FontWeight.extrabold,
    color: Colors.silver, letterSpacing: 1.2,
    textAlign: 'center',
  },
  cardValue: {
    fontSize: FontSize.lg, fontWeight: FontWeight.extrabold,
    textAlign: 'center', lineHeight: 24,
  },
  cardNote: { fontSize: 9, color: Colors.textDim, textAlign: 'center' },
  rangeSection: { gap: 4 },
  rangeBar: { gap: 4 },
  rangeTrack: {
    height: 10, borderRadius: 5, overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1, borderColor: Colors.border,
  },
  rangeFill: {
    height: '100%',
    background: undefined,
    // Simulate green gradient from silver through blue to green
    backgroundColor: Colors.green,
    opacity: 0.55,
    width: '100%',
    borderRadius: 5,
  },
  rangeLabels: { flexDirection: 'row', justifyContent: 'space-between' },
  rangeLabelLeft: { fontSize: 10, color: Colors.silver, fontWeight: FontWeight.semibold },
  rangeLabelCenter: { fontSize: 10, color: Colors.blueBright, fontWeight: FontWeight.semibold },
  rangeLabelRight: { fontSize: 10, color: Colors.green, fontWeight: FontWeight.semibold },
  noteCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 8,
    backgroundColor: 'rgba(0,104,192,0.06)',
    borderRadius: Radius.md, padding: Spacing.sm,
    borderWidth: 1, borderColor: 'rgba(0,104,192,0.2)',
  },
  noteText: { fontSize: FontSize.xs, color: Colors.textSecondary, lineHeight: 17 },
  disclaimer: {
    fontSize: 10, color: Colors.textDim,
    textAlign: 'center', lineHeight: 15,
  },
});
