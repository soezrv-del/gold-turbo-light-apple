import { Redirect } from 'expo-router';
import { useEffect, useState } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { useAuth, getSupabaseClient } from '@/template';
import { Colors } from '@/constants/theme';
import { useRouter } from 'expo-router';

export default function RootScreen() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [ndaStatus, setNdaStatus] = useState<'checking' | 'needs-nda' | 'ready'>('checking');

  useEffect(() => {
    // Wait for auth to finish loading
    if (loading) return;

    // Not authenticated — go to login
    if (!user) {
      router.replace('/login');
      return;
    }

    // Authenticated — check NDA
    const checkNda = async () => {
      const supabase = getSupabaseClient();
      const { data } = await supabase
        .from('user_profiles')
        .select('nda_accepted_at')
        .eq('id', user.id)
        .maybeSingle();

      setNdaStatus(data?.nda_accepted_at ? 'ready' : 'needs-nda');
    };

    checkNda();
  }, [user, loading]);

  // Always show spinner while auth or NDA check is in progress
  if (loading || ndaStatus === 'checking') {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.black, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={Colors.gold} />
      </View>
    );
  }

  if (ndaStatus === 'needs-nda') {
    return <Redirect href="/nda" />;
  }

  return <Redirect href="/(tabs)" />;
}
