
// ─── APPLE IAP SUBSCRIPTION HOOK ─────────────────────────────────────────────
// Safe-loads react-native-iap — if the native module is not available in the
// current build (OnSpace preview), falls back to the web stub gracefully.

import { useState, useEffect, useCallback } from 'react';
import { Platform, Alert } from 'react-native';

// ─── PRODUCT IDS ──────────────────────────────────────────────────────────────

export const PRODUCT_IDS = {
  CONSUMER:     'rvfox.consumer.monthly',
  PROFESSIONAL: 'rvfox.professional.monthly',
} as const;

export type ProductId = typeof PRODUCT_IDS[keyof typeof PRODUCT_IDS];
export type SubscriptionTier = 'none' | 'consumer' | 'professional';

export interface SubscriptionState {
  tier: SubscriptionTier;
  productId: ProductId | null;
  expiryDate: Date | null;
  isActive: boolean;
  loading: boolean;
  purchasing: boolean;
  products: any[];
  error: string | null;
}

export const TIER_LABELS: Record<SubscriptionTier, string> = {
  none:         'Free',
  consumer:     'RvFOX Consumer',
  professional: 'RvFOX Professional',
};

export const TIER_PRICES: Record<ProductId, string> = {
  'rvfox.consumer.monthly':     '$9.99/mo',
  'rvfox.professional.monthly': '$29.99/mo',
};

// ─── SAFE MODULE LOAD ─────────────────────────────────────────────────────────

let iap: typeof import('react-native-iap') | null = null;
try {
  // The original error "Definition for rule '@typescript-eslint/no-var-requires' was not found."
  // indicates an ESLint configuration issue, not a TypeScript syntax error.
  // The 'no-var-requires' rule is usually used to enforce `import` statements over `require()`.
  // Since the `require` is intentionally used here for conditional loading,
  // and the problem is with ESLint configuration, the best immediate fix
  // for *syntax correction* is to remove the problematic ESLint directive.
  // The TypeScript code itself is valid.
  iap = require('react-native-iap');
} catch {
  // react-native-iap not available in this build — hook will return stub state
}

// ─── TIER HELPERS ─────────────────────────────────────────────────────────────

function productToTier(productId: string): SubscriptionTier {
  if (productId === PRODUCT_IDS.PROFESSIONAL) return 'professional';
  if (productId === PRODUCT_IDS.CONSUMER) return 'consumer';
  return 'none';
}

// ─── HOOK ─────────────────────────────────────────────────────────────────────

export function useSubscription() {
  const [state, setState] = useState<SubscriptionState>({
    tier: 'none',
    productId: null,
    expiryDate: null,
    isActive: false,
    loading: false,   // start false when IAP not available
    purchasing: false,
    products: [],
    error: null,
  });

  useEffect(() => {
    // If react-native-iap isn't available, skip IAP initialization entirely
    if (!iap) return;

    let purchaseUpdateSub: any = null;
    let purchaseErrorSub: any  = null;

    const checkActivePurchases = async (subs: any[]) => {
      try {
        const purchases = await iap!.getAvailablePurchases();
        let activeTier: SubscriptionTier = 'none';
        let activePid: ProductId | null = null;
        let activeExpiry: Date | null = null;

        for (const p of purchases) {
          const tier = productToTier(p.productId);
          if (tier === 'professional') {
            activeTier = 'professional';
            activePid  = p.productId as ProductId;
            activeExpiry = p.transactionDate
              ? new Date(p.transactionDate + 30 * 24 * 60 * 60 * 1000)
              : null;
            break;
          }
          if (tier === 'consumer' && activeTier !== 'professional') {
            activeTier = 'consumer';
            activePid  = p.productId as ProductId;
            activeExpiry = p.transactionDate
              ? new Date(p.transactionDate + 30 * 24 * 60 * 60 * 1000)
              : null;
          }
        }

        setState(prev => ({
          ...prev,
          tier: activeTier, productId: activePid, expiryDate: activeExpiry,
          isActive: activeTier !== 'none', loading: false, products: subs,
        }));
      } catch {
        setState(prev => ({ ...prev, loading: false, products: subs }));
      }
    };

    const init = async () => {
      setState(prev => ({ ...prev, loading: true }));
      try {
        await iap!.initConnection();

        if (Platform.OS === 'ios') {
          await iap!.clearTransactionIOS();
        }

        const subs = await iap!.getSubscriptions({ skus: Object.values(PRODUCT_IDS) });
        await checkActivePurchases(subs);

        purchaseUpdateSub = iap!.purchaseUpdatedListener(async (purchase: any) => {
          if (purchase.transactionReceipt) {
            await iap!.finishTransaction({ purchase, isConsumable: false });
            const tier = productToTier(purchase.productId);
            const expiry = purchase.transactionDate
              ? new Date(purchase.transactionDate + 30 * 24 * 60 * 60 * 1000)
              : null;
            setState(prev => ({
              ...prev, tier, productId: purchase.productId as ProductId,
              expiryDate: expiry, isActive: tier !== 'none', purchasing: false, error: null,
            }));
          }
        });

        purchaseErrorSub = iap!.purchaseErrorListener((error: any) => {
          if (error?.code !== 'E_USER_CANCELLED') {
            setState(prev => ({ ...prev, purchasing: false, error: error?.message ?? 'Purchase failed' }));
          } else {
            setState(prev => ({ ...prev, purchasing: false }));
          }
        });

      } catch {
        // IAP unavailable (simulator / preview) — fail silently
        setState(prev => ({ ...prev, loading: false, error: null }));
      }
    };

    init();

    return () => {
      purchaseUpdateSub?.remove();
      purchaseErrorSub?.remove();
      try { iap?.endConnection(); } catch { /* ignore */ }
    };
  }, []);

  const subscribe = useCallback(async (productId: ProductId) => {
    if (!iap) {
      Alert.alert('Not Available', 'In-app purchases require a full app build.');
      return;
    }
    setState(prev => ({ ...prev, purchasing: true, error: null }));
    try {
      await iap!.requestSubscription({ sku: productId });
    } catch (err: any) {
      if (err?.code !== 'E_USER_CANCELLED') {
        setState(prev => ({ ...prev, purchasing: false, error: err?.message ?? 'Purchase failed' }));
      } else {
        setState(prev => ({ ...prev, purchasing: false }));
      }
    }
  }, []);

  const restorePurchases = useCallback(async () => {
    if (!iap) {
      Alert.alert('Not Available', 'Restore purchases requires a full app build.');
      return;
    }
    setState(prev => ({ ...prev, loading: true, error: null }));
    try {
      const purchases = await iap!.getAvailablePurchases();
      let activeTier: SubscriptionTier = 'none';
      let activePid: ProductId | null = null;

      for (const p of purchases) {
        const tier = productToTier(p.productId);
        if (tier === 'professional') { activeTier = 'professional'; activePid = p.productId as ProductId; break; }
        if (tier === 'consumer')     { activeTier = 'consumer';     activePid = p.productId as ProductId; }
      }

      setState(prev => ({ ...prev, tier: activeTier, productId: activePid, isActive: activeTier !== 'none', loading: false }));

      if (activeTier !== 'none') {
        Alert.alert('Restored', `${TIER_LABELS[activeTier]} subscription restored.`);
      } else {
        Alert.alert('No Purchases Found', 'No active subscriptions were found for this Apple ID.');
      }
    } catch (err: any) {
      setState(prev => ({ ...prev, loading: false, error: err?.message ?? 'Restore failed' }));
    }
  }, []);

  return { ...state, subscribe, restorePurchases };
}
