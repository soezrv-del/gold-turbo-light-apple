// ─── WEB STUB — react-native-iap is iOS/Android only ─────────────────────────
// This file is resolved on web; the real IAP logic is in useSubscription.native.ts

export const PRODUCT_IDS = {
  CONSUMER:     'rvfox.consumer.monthly',
  PROFESSIONAL: 'rvfox.professional.monthly',
} as const;

export type ProductId = typeof PRODUCT_IDS[keyof typeof PRODUCT_IDS];
export type SubscriptionTier = 'none' | 'consumer' | 'professional';

export interface SubscriptionState {
  tier: SubscriptionTier;
  productId: ProductId | null;
  expiryDate: Date | null;
  isActive: boolean;
  loading: boolean;
  purchasing: boolean;
  products: any[];
  error: string | null;
}

export const TIER_LABELS: Record<SubscriptionTier, string> = {
  none:         'Free',
  consumer:     'RvFOX Consumer',
  professional: 'RvFOX Professional',
};

export const TIER_PRICES: Record<ProductId, string> = {
  'rvfox.consumer.monthly':     '$9.99/mo',
  'rvfox.professional.monthly': '$29.99/mo',
};

export function useSubscription() {
  return {
    tier:             'none'  as SubscriptionTier,
    productId:        null    as ProductId | null,
    expiryDate:       null    as Date | null,
    isActive:         false,
    loading:          false,
    purchasing:       false,
    products:         [] as any[],
    error:            null    as string | null,
    subscribe:        async (_productId: ProductId) => {
      console.log('[IAP] Web: in-app purchases not available in preview');
    },
    restorePurchases: async () => {
      console.log('[IAP] Web: restore purchases not available in preview');
    },
  };
}
