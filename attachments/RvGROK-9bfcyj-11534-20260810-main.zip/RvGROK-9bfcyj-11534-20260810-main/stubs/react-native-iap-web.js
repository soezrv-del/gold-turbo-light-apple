// react-native-iap web stub
// react-native-iap is iOS/Android only. This empty stub is returned by the
// Metro resolver on web so its native dependency tree (which pulls in
// react-native@0.79 with Flow types unsupported by hermes-parser@0.25) is
// never bundled for the web/preview platform.

module.exports = {
  initConnection:          () => Promise.resolve(),
  endConnection:           () => Promise.resolve(),
  clearTransactionIOS:     () => Promise.resolve(),
  getSubscriptions:        () => Promise.resolve([]),
  getAvailablePurchases:   () => Promise.resolve([]),
  requestSubscription:     () => Promise.resolve(),
  finishTransaction:       () => Promise.resolve(),
  purchaseUpdatedListener: () => ({ remove: () => {} }),
  purchaseErrorListener:   () => ({ remove: () => {} }),
};
