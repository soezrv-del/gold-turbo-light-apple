// Stub for babel-plugin-syntax-hermes-parser
// The real plugin uses the Hermes parser (unavailable in this environment).
// Instead we swap in @babel/parser's TypeScript plugin so .ts/.tsx files in
// node_modules (e.g. expo-modules-core) parse correctly on web / SSR bundles.
module.exports = function hermesParserPlugin() {
  return {
    name: 'syntax-hermes-parser',
    parserOverride(code, opts, parse) {
      const plugins = (opts.plugins || []).filter(
        (p) => p !== 'flow' && p !== 'flowComments'
      );
      if (!plugins.some((p) => p === 'typescript' || (Array.isArray(p) && p[0] === 'typescript'))) {
        plugins.push('typescript');
      }
      return parse(code, { ...opts, plugins });
    },
  };
};
module.exports.default = module.exports;
