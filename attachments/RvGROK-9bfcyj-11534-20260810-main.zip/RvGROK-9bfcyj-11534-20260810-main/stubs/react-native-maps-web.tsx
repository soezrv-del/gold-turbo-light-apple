// Web stub for react-native-maps — native module not supported on web
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export const PROVIDER_DEFAULT = null;
export const PROVIDER_GOOGLE = null;

const Stub = ({ children, style }: any) => (
  <View style={[stub.container, style]}>
    <Text style={stub.text}>🗺 Map view (mobile only)</Text>
    {children}
  </View>
);

const stub = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 16,
  },
  text: {
    fontSize: 13,
    color: '#555',
    fontWeight: '500',
  },
});

// Named exports that mirror react-native-maps API
export const Marker = ({ children }: any) => <>{children}</>;
export const Polyline = () => null;
export const Polygon = () => null;
export const Circle = () => null;
export const Callout = ({ children }: any) => <>{children}</>;
export const CalloutSubview = ({ children }: any) => <>{children}</>;
export const Overlay = () => null;
export const Heatmap = () => null;
export const UrlTile = () => null;
export const LocalTile = () => null;
export const MapCallout = () => null;
export const MapMarker = () => null;
export const AnimatedRegion = class {
  constructor(region: any) {}
  timing() { return { start: () => {} }; }
  spring() { return { start: () => {} }; }
};

// Default export is MapView
export default Stub;
