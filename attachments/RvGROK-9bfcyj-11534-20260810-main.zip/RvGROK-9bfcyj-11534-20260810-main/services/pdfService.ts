import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Platform } from 'react-native';
import { getSupabaseClient } from '@/template';
import { getMaintenanceSchedule, getMockReviews, type MaintenanceItem, type RVReview } from '@/constants/rvData';

// ─── TYPES ────────────────────────────────────────────────────────────────────

export interface NHTSARecallDetail {
  component: string; summary: string; consequence: string;
  remedy: string; date: string; campaignNumber: string;
}
export interface NHTSADefectDetail {
  component: string; summary: string; date: string;
  crashFlag: boolean; fireFlag: boolean;
}
export interface RVReportData {
  year: string; make: string; model: string; floorplan: string;
  type: string; floorplans: string[]; lengthRange: [number, number];
  weightRange: [number, number]; slideouts: number; sleeps: number;
  msrpRange: [number, number]; engine?: string; chassis?: string;
  fuelType: string; recalls: number; rating: number; image: string;
  warrantyYears?: number; description?: string; freshWater?: number;
  grayWater?: number; blackWater?: number; generator?: string;
  towingCapacity?: number; ceilingHeight?: number; founded?: number;
  recallDetails?: NHTSARecallDetail[]; defectCount?: number;
  defects?: NHTSADefectDetail[]; maintenanceItems?: MaintenanceItem[];
  reviews?: RVReview[]; customerName?: string;
  marketValue?: { tradeIn: number; retailLow: number; retailHigh: number; mileageAdjustment?: number; conditionNote?: string; source?: string };
}
export interface LoanReportData {
  rv: RVReportData; sellingPrice: number; downPct: number; downAmt: number;
  tradeValue?: number; tradeOwed?: number; amountFinanced: number;
  apr: number; termMonths: number; monthlyPayment: number;
  totalInterest: number; totalPayments: number; salesTax: number;
  taxRate: number; regFee: number; stateCode?: string; stateName?: string;
  negativeEquity?: number; tradeNetCredit?: number;
}
export interface DealerQuoteData extends LoanReportData {
  customerName?: string; dealerName?: string; dealerAddress?: string;
  salespersonName?: string; validDays?: number; notes?: string;
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function fmt(n: number): string {
  return n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}
function fmtDec(n: number): string {
  return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function reportId(): string { return `RVF-${Date.now().toString(36).toUpperCase()}`; }
function reportDate(): string {
  return new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}
function calcMonthlyPayment(principal: number, annualRate: number, months: number): number {
  if (principal <= 0 || months <= 0) return 0;
  if (annualRate === 0) return principal / months;
  const r = annualRate / 100 / 12;
  return (principal * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1);
}
function stars(n: number): string {
  return '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n));
}

// ─── BRAND PALETTE ────────────────────────────────────────────────────────────
// Red: #D42535 | Blue: #1565C0 | Black: #0A0A0A | Green: #00C853 — strict 4-color

const BASE_CSS = `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, 'Helvetica Neue', Arial, sans-serif; background: #ffffff; color: #1A1A1A; font-size: 13px; line-height: 1.5; }
  .page-header { background: linear-gradient(135deg, #0A0A0A 0%, #0D2B6B 55%, #0A0A0A 100%); padding: 22px 32px 18px; display: flex; align-items: flex-start; justify-content: space-between; }
  .brand { font-size: 26px; font-weight: 900; color: #ffffff; letter-spacing: 2px; }
  .brand-sub { font-size: 10px; color: #FF4444; font-weight: 800; letter-spacing: 3px; margin-top: 2px; }
  .report-tag { display: inline-flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.20); border: 1px solid rgba(255,255,255,0.40); border-radius: 20px; padding: 4px 14px; margin-top: 8px; font-size: 10px; font-weight: 800; color: #ffffff; letter-spacing: 1.5px; }
  .report-meta { text-align: right; }
  .report-id { font-size: 11px; color: rgba(255,255,255,0.70); letter-spacing: 1px; }
  .report-date { font-size: 12px; color: rgba(255,255,255,0.85); margin-top: 3px; }
  .prepared-bar { background: linear-gradient(90deg, #D42535 0%, #A01C28 100%); padding: 10px 32px; display: flex; align-items: center; justify-content: space-between; }
  .prepared-label { font-size: 11px; font-weight: 800; color: rgba(255,255,255,0.7); letter-spacing: 1.5px; text-transform: uppercase; }
  .prepared-name { font-size: 16px; font-weight: 900; color: #ffffff; margin-top: 1px; }
  .prepared-right { text-align: right; font-size: 10px; color: rgba(255,255,255,0.55); font-weight: 600; }
  .content { padding: 0 32px 32px; background: #ffffff; }
  .section { margin-top: 22px; border: 1px solid #E0E0E0; border-radius: 10px; overflow: hidden; }
  .section-header { display: flex; align-items: center; gap: 8px; padding: 12px 18px; background: #F5F5F5; border-bottom: 2px solid #E0E0E0; }
  .section-icon { font-size: 16px; }
  .section-title { font-size: 12px; font-weight: 800; letter-spacing: 1.5px; text-transform: uppercase; }
  .section-body { padding: 16px 18px; background: #FAFAFA; }
  .vehicle-overview-card { background: #EEF3FF; border-radius: 10px; padding: 22px 24px; margin-top: 20px; display: flex; align-items: flex-start; justify-content: space-between; border: 1px solid rgba(21,101,192,0.25); }
  .ov-left { flex: 1; }
  .ov-year { font-size: 11px; font-weight: 800; color: #1565C0; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 4px; }
  .ov-name { font-size: 28px; font-weight: 900; color: #0A0A0A; line-height: 1.1; }
  .ov-fp { font-size: 13px; color: #1A1A1A; margin-top: 4px; }
  .ov-badges { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
  .ov-badge { display: inline-flex; align-items: center; gap: 5px; padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; }
  .ov-badge-type { background: rgba(21,101,192,0.12); border: 1px solid rgba(21,101,192,0.35); color: #1565C0; }
  .ov-badge-clear { background: rgba(21,101,192,0.10); border: 1px solid rgba(21,101,192,0.35); color: #1565C0; }
  .ov-badge-recall { background: rgba(212,37,53,0.10); border: 1px solid rgba(212,37,53,0.40); color: #D42535; }
  .ov-right { text-align: right; min-width: 140px; }
  .ov-rating-num { font-size: 44px; font-weight: 900; color: #1565C0; line-height: 1; }
  .ov-stars { color: #1565C0; font-size: 16px; letter-spacing: 1px; margin-top: 2px; }
  .ov-rating-label { font-size: 10px; color: #1A1A1A; margin-top: 2px; letter-spacing: 0.8px; }
  .summary-strip { display: flex; gap: 0; margin-top: 14px; border: 1px solid #E0E0E0; border-radius: 8px; overflow: hidden; }
  .summary-cell { flex: 1; padding: 12px 14px; background: #F8F8F8; border-right: 1px solid #E0E0E0; }
  .summary-cell:last-child { border-right: none; }
  .summary-cell-value { font-size: 18px; font-weight: 900; color: #0068C0; }
  .summary-cell-value.green { color: #006633; }
  .summary-cell-value.red { color: #D42535; }
  .summary-cell-value.orange { color: #C84000; }
  .summary-cell-label { font-size: 10px; font-weight: 700; color: #1A1A1A; letter-spacing: 1px; text-transform: uppercase; margin-top: 2px; }
  .market-price-row { display: flex; align-items: center; justify-content: space-between; padding: 14px 0; border-bottom: 1px solid #E0E0E0; }
  .market-price-main { font-size: 28px; font-weight: 900; color: #1565C0; }
  .market-price-label { font-size: 10px; font-weight: 700; color: #1A1A1A; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 3px; }
  .market-price-note { font-size: 11px; color: #000000; margin-top: 3px; }
  .market-mid-badge { background: #EEF3FF; border-radius: 8px; padding: 10px 16px; text-align: center; min-width: 140px; border: 1px solid rgba(21,101,192,0.30); }
  .market-mid-label { font-size: 9px; font-weight: 800; color: #1A1A1A; letter-spacing: 1.5px; text-transform: uppercase; }
  .market-mid-value { font-size: 20px; font-weight: 900; color: #1565C0; margin-top: 2px; }
  .market-range-bar { display: flex; align-items: center; gap: 10px; margin-top: 12px; }
  .range-track { flex: 1; height: 10px; background: #EEEEEE; border-radius: 5px; overflow: hidden; }
  .range-fill { height: 10px; background: linear-gradient(90deg, #1565C0, #00C853); border-radius: 5px; }
  .range-label { font-size: 11px; color: #1A1A1A; font-weight: 600; width: 56px; }
  .specs-grid { display: flex; flex-wrap: wrap; gap: 0; }
  .spec-row { width: 50%; display: flex; align-items: center; padding: 10px 0; border-bottom: 1px solid #EEEEEE; }
  .spec-row:nth-child(even) { padding-left: 16px; border-left: 1px solid #EEEEEE; }
  .spec-label { font-size: 11px; font-weight: 700; color: #0068C0; text-transform: uppercase; letter-spacing: 0.8px; width: 44%; flex-shrink: 0; }
  .spec-value { font-size: 13px; font-weight: 600; color: #1A1A1A; }
  .spec-value.accent { color: #0068C0; font-weight: 700; }
  .floorplan-chips { display: flex; flex-wrap: wrap; gap: 7px; margin-top: 12px; }
  .fp-chip { background: rgba(212,37,53,0.08); border: 1.5px solid rgba(212,37,53,0.40); border-radius: 6px; padding: 4px 12px; font-size: 12px; font-weight: 700; color: #D42535; }
  .status-overview { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 14px; }
  .status-card { flex: 1; min-width: 120px; border-radius: 8px; padding: 12px 14px; display: flex; align-items: flex-start; gap: 8px; }
  .status-card-green { background: rgba(21,101,192,0.07); border: 1.5px solid rgba(21,101,192,0.25); }
  .status-card-red { background: rgba(212,37,53,0.07); border: 1.5px solid rgba(212,37,53,0.25); }
  .status-card-orange { background: rgba(200,64,0,0.07); border: 1.5px solid rgba(200,64,0,0.25); }
  .status-icon { font-size: 20px; flex-shrink: 0; margin-top: 1px; }
  .status-title { font-size: 13px; font-weight: 800; }
  .status-title-green { color: #0068C0; }
  .status-title-red { color: #D42535; }
  .status-title-orange { color: #C84000; }
  .status-sub { font-size: 10px; color: #1A1A1A; margin-top: 2px; line-height: 1.4; }
  .recall-row { display: flex; gap: 10px; padding: 12px 0; border-bottom: 1px solid #EEEEEE; }
  .recall-num { width: 24px; height: 24px; border-radius: 12px; background: #D42535; color: #fff; font-size: 11px; font-weight: 900; display: flex; align-items: center; justify-content: center; flex-shrink: 0; text-align: center; line-height: 24px; }
  .recall-component { font-size: 12px; font-weight: 800; color: #D42535; }
  .recall-campaign { font-size: 9px; color: #000000; font-family: monospace; margin-top: 1px; }
  .recall-summary { font-size: 11px; color: #1A1A1A; line-height: 1.5; margin-top: 4px; }
  .recall-remedy-tag { display: inline-block; margin-top: 5px; background: rgba(21,101,192,0.08); border: 1px solid rgba(21,101,192,0.25); border-radius: 4px; padding: 2px 8px; font-size: 9px; font-weight: 700; color: #1565C0; }
  .defect-row { padding: 10px 0; border-bottom: 1px solid #EEEEEE; }
  .defect-header { display: flex; align-items: center; gap: 6px; margin-bottom: 4px; }
  .defect-comp { font-size: 12px; font-weight: 800; color: #0068C0; }
  .defect-flag { display: inline-block; background: rgba(200,64,0,0.10); border: 1px solid rgba(200,64,0,0.35); border-radius: 3px; padding: 1px 6px; font-size: 9px; font-weight: 800; color: #C84000; }
  .defect-flag-fire { background: rgba(212,37,53,0.10); border-color: rgba(212,37,53,0.35); color: #D42535; }
  .defect-summary { font-size: 11px; color: #1A1A1A; line-height: 1.5; }
  .maint-table { width: 100%; border-collapse: collapse; }
  .maint-table th { background: #EEF3FF; padding: 9px 12px; font-size: 10px; font-weight: 800; color: #0068C0; text-align: left; letter-spacing: 1px; text-transform: uppercase; border-bottom: 2px solid #D0D9F0; }
  .maint-table td { padding: 9px 12px; font-size: 12px; border-bottom: 1px solid #EEEEEE; vertical-align: middle; color: #000000; }
  .maint-table tr:last-child td { border-bottom: none; }
  .maint-table tr:nth-child(even) td { background: #F8F9FF; }
  .priority-badge { display: inline-block; border-radius: 4px; padding: 2px 8px; font-size: 9px; font-weight: 800; }
  .priority-critical { background: rgba(212,37,53,0.12); border: 1px solid rgba(212,37,53,0.35); color: #D42535; }
  .priority-important { background: rgba(200,64,0,0.10); border: 1px solid rgba(200,64,0,0.35); color: #C84000; }
  .priority-routine { background: rgba(0,168,68,0.10); border: 1px solid rgba(0,168,68,0.30); color: #00A844; }
  .review-card { background: #F8F8F8; border: 1px solid #E0E0E0; border-radius: 8px; padding: 14px 16px; margin-bottom: 10px; }
  .review-header { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 8px; }
  .review-avatar { width: 38px; height: 38px; border-radius: 19px; background: rgba(0,104,192,0.12); border: 1.5px solid rgba(0,104,192,0.30); display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 900; color: #0068C0; flex-shrink: 0; text-align: center; line-height: 38px; }
  .review-author { font-size: 13px; font-weight: 700; color: #1A1A1A; }
  .review-meta { font-size: 10px; color: #000000; margin-top: 1px; }
  .review-stars { color: #0068C0; font-size: 13px; letter-spacing: 1px; margin-left: auto; flex-shrink: 0; }
  .review-title { font-size: 13px; font-weight: 700; color: #1A1A1A; margin-bottom: 5px; }
  .review-body { font-size: 12px; color: #1A1A1A; line-height: 1.6; }
  .breakdown-table { width: 100%; border-collapse: collapse; }
  .breakdown-table td { padding: 9px 14px; border-bottom: 1px solid #EEEEEE; font-size: 13px; }
  .bd-label { color: #1A1A1A; font-weight: 500; }
  .bd-value { text-align: right; font-weight: 700; color: #1A1A1A; }
  .bd-green .bd-value { color: #0068C0; }
  .bd-red .bd-value { color: #D42535; }
  .bd-total td { background: #EEF3FF; font-weight: 800; font-size: 14px; }
  .bd-total .bd-value { color: #0068C0; font-size: 16px; }
  .payment-hero { background: #EEF3FF; border-radius: 12px; padding: 22px 26px; display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border: 1px solid rgba(21,101,192,0.25); }
  .payment-label { font-size: 10px; font-weight: 700; color: #000000; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 4px; }
  .payment-amount { font-size: 52px; font-weight: 900; color: #1565C0; line-height: 1; letter-spacing: -2px; }
  .payment-sub { font-size: 12px; color: #1A1A1A; margin-top: 4px; }
  .payment-right { text-align: right; }
  .financed-label { font-size: 11px; color: #1A1A1A; }
  .financed-value { font-size: 22px; font-weight: 900; color: #1565C0; }
  .scenarios-strip { display: flex; border: 1px solid #E0E0E0; border-radius: 10px; overflow: hidden; margin-bottom: 12px; }
  .sc-cell { flex: 1; text-align: center; padding: 12px 6px; border-right: 1px solid #E0E0E0; background: #FFFFFF; }
  .sc-cell:last-child { border-right: none; }
  .sc-cell.active { background: #EEF3FF; border-top: 2px solid #1565C0; }
  .sc-pct { font-size: 17px; font-weight: 900; color: #0068C0; }
  .sc-pct.active { color: #00C853; }
  .sc-down { font-size: 10px; color: #000000; margin-top: 2px; }
  .sc-down.active { color: #0A0A0A; }
  .sc-mo { font-size: 19px; font-weight: 900; color: #1A1A1A; margin-top: 4px; }
  .sc-mo.active { color: #0068C0; }
  .sc-lbl { font-size: 9px; color: #000000; }
  .sc-lbl.active { color: #1A1A1A; }
  .sc-int { font-size: 10px; color: #D42535; margin-top: 2px; }
  .sc-int.active { color: #D42535; }
  .comp-table { width: 100%; border-collapse: collapse; }
  .comp-table th { background: #EEF3FF; color: #1565C0; font-size: 11px; font-weight: 800; letter-spacing: 1px; padding: 10px 14px; text-align: left; border-bottom: 2px solid rgba(21,101,192,0.3); }
  .comp-table th.num { text-align: right; }
  .comp-table th.active-col { color: #00A844; }
  .comp-table td { padding: 10px 14px; font-size: 12px; border-bottom: 1px solid #EEEEEE; color: #0A0A0A; }
  .comp-table td.num { text-align: right; font-weight: 700; }
  .comp-table tr.active-row td { background: #EEF3FF; }
  .comp-table tr.active-row td.num { color: #00A844; font-size: 15px; font-weight: 900; }
  .comp-table tr.savings-row td { background: rgba(0,168,68,0.05); font-size: 10px; }
  .comp-table tr.savings-row td.savings-val { color: #00A844; font-weight: 800; text-align: right; }
  .comp-table .label-col { color: #1A1A1A; font-weight: 500; }
  .sig-area { display: flex; gap: 28px; margin-top: 14px; }
  .sig-block { flex: 1; }
  .sig-line { border-bottom: 1.5px solid #CCCCCC; height: 36px; margin-bottom: 6px; }
  .sig-label { font-size: 10px; font-weight: 700; color: #000000; letter-spacing: 1px; text-transform: uppercase; }
  .info-box { background: rgba(0,104,192,0.07); border-radius: 8px; border-left: 3px solid #0068C0; padding: 10px 14px; margin: 10px 0; }
  .info-box p { font-size: 12px; color: #0A0A0A; font-weight: 600; line-height: 1.5; }
  .warn-box { background: rgba(212,37,53,0.07); border-radius: 8px; border-left: 3px solid #D42535; padding: 10px 14px; margin: 10px 0; }
  .warn-box p { font-size: 11px; color: #D42535; line-height: 1.5; }
  .disclosure { background: #F0F0F0; border-radius: 8px; padding: 10px 14px; border-left: 3px solid #1565C0; margin-top: 20px; }
  .disclosure p { font-size: 10px; color: #1A1A1A; line-height: 1.6; }
  .disclosure strong { color: #0068C0; }
  .page-footer { background: #1A1A1A; padding: 14px 32px; border-top: 1px solid #D42535; display: flex; justify-content: space-between; align-items: center; margin-top: 8px; }
  .footer-brand { font-size: 13px; font-weight: 800; color: #D42535; }
  .footer-copy { font-size: 10px; color: rgba(255,255,255,0.50); margin-top: 2px; }
  .footer-right { text-align: right; font-size: 10px; color: rgba(255,255,255,0.50); }
`;

// ─── VALUATION REPORT ────────────────────────────────────────────────────────

function buildValuationReportHTML(rv: RVReportData): string {
  const id = reportId();
  const date = reportDate();
  const syntheticSpec: any = {
    type: rv.type, floorplans: rv.floorplans, lengthRange: rv.lengthRange,
    weightRange: rv.weightRange, slideouts: rv.slideouts, sleeps: rv.sleeps,
    msrpRange: rv.msrpRange, engine: rv.engine, chassis: rv.chassis,
    fuelType: rv.fuelType, recalls: rv.recalls, rating: rv.rating, image: rv.image,
    towingCapacity: rv.towingCapacity ?? 0, freshWater: rv.freshWater,
    grayWater: rv.grayWater, blackWater: rv.blackWater, generator: rv.generator,
    ceilingHeight: rv.ceilingHeight, warrantyYears: rv.warrantyYears,
    description: rv.description, founded: rv.founded,
  };
  const maintenanceItems: MaintenanceItem[] = rv.maintenanceItems ?? getMaintenanceSchedule(syntheticSpec);
  const reviewList: RVReview[] = rv.reviews ?? getMockReviews(rv.make, rv.model, rv.rating);
  const recallDetails: NHTSARecallDetail[] = rv.recallDetails ?? [];
  const defects: NHTSADefectDetail[] = rv.defects ?? [];
  const ratingCount = Math.floor(rv.rating * 120 + 17);
  const mv = rv.marketValue;
  const reportTimestamp = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  const liveMarketSection = mv ? `<div style="display:flex;gap:10px;margin-bottom:12px;"><div style="flex:1;text-align:center;padding:12px 8px;background:#F8F8F8;border:1px solid #E0E0E0;border-top:3px solid #D42535;border-radius:8px;"><div style="font-size:9px;font-weight:800;color:#D42535;text-transform:uppercase;margin-bottom:4px;">TRADE-IN</div><div style="font-size:22px;font-weight:900;color:#0A0A0A;">$${fmt(mv.tradeIn)}</div><div style="font-size:10px;color:#000000;margin-top:2px;">Dealer offer estimate</div></div><div style="flex:1;text-align:center;padding:12px 8px;background:#F8F8F8;border:1px solid #E0E0E0;border-top:3px solid #1565C0;border-radius:8px;"><div style="font-size:9px;font-weight:800;color:#1565C0;text-transform:uppercase;margin-bottom:4px;">RETAIL LOW</div><div style="font-size:22px;font-weight:900;color:#1565C0;">$${fmt(mv.retailLow)}</div><div style="font-size:10px;color:#000000;margin-top:2px;">Private party / auction</div></div><div style="flex:1;text-align:center;padding:12px 8px;background:#EEF3FF;border:1px solid rgba(21,101,192,0.3);border-top:3px solid #0068C0;border-radius:8px;"><div style="font-size:9px;font-weight:800;color:#0068C0;text-transform:uppercase;margin-bottom:4px;">RETAIL HIGH</div><div style="font-size:22px;font-weight:900;color:#0068C0;">$${fmt(mv.retailHigh)}</div><div style="font-size:10px;color:#000000;margin-top:2px;">Dealer asking price</div></div></div><div style="display:flex;align-items:center;gap:8px;padding:7px 12px;background:#EEF3FF;border:1px solid rgba(21,101,192,0.25);border-radius:6px;margin-bottom:10px;"><span style="font-size:13px;">&#128269;</span><div style="flex:1;"><span style="font-size:10px;font-weight:800;color:#1565C0;">${mv.source ?? 'Live Market Research'}</span><span style="font-size:10px;color:#000000;margin-left:8px;"> &middot; Generated ${date} at ${reportTimestamp}</span></div><div style="font-size:9px;font-weight:800;color:#ffffff;background:#1565C0;border-radius:4px;padding:2px 8px;">LIVE</div></div>` : '';

  const recallBadge = rv.recalls > 0
    ? `<span class="ov-badge ov-badge-recall">⚠ ${rv.recalls} Recall${rv.recalls > 1 ? 's' : ''}</span>`
    : `<span class="ov-badge ov-badge-clear">✓ No Recalls</span>`;

  const vehicleOverview = `
    <div class="vehicle-overview-card">
      <div class="ov-left">
        <div class="ov-year">${rv.year}</div>
        <div class="ov-name">${rv.make} ${rv.model}</div>
        ${rv.floorplan ? `<div class="ov-fp">Floorplan: ${rv.floorplan}</div>` : ''}
        <div class="ov-badges">
          <span class="ov-badge ov-badge-type">${rv.type}</span>
          ${recallBadge}
          ${rv.warrantyYears ? `<span class="ov-badge" style="background:rgba(21,101,192,0.10);border:1px solid rgba(21,101,192,0.30);color:#1565C0;">${rv.warrantyYears}-Year Warranty</span>` : ''}
          ${rv.founded ? `<span class="ov-badge" style="background:rgba(21,101,192,0.10);border:1px solid rgba(21,101,192,0.30);color:#1565C0;">Est. ${rv.founded}</span>` : ''}
        </div>
      </div>
      <div class="ov-right">
        <div class="ov-rating-num">${rv.rating.toFixed(1)}</div>
        <div class="ov-stars">${stars(rv.rating)}</div>
        <div class="ov-rating-label">RvFOX RATING</div>
        <div style="font-size:10px;color:#000000;margin-top:3px;">${ratingCount.toLocaleString()} reviews</div>
      </div>
    </div>
    <div class="summary-strip">
      <div class="summary-cell"><div class="summary-cell-value">${rv.lengthRange[0]}–${rv.lengthRange[1]} ft</div><div class="summary-cell-label">Length</div></div>
      <div class="summary-cell"><div class="summary-cell-value">${rv.slideouts}</div><div class="summary-cell-label">Slideouts</div></div>
      <div class="summary-cell"><div class="summary-cell-value">${rv.sleeps}</div><div class="summary-cell-label">Sleeps</div></div>
      <div class="summary-cell"><div class="summary-cell-value ${rv.recalls > 0 ? 'orange' : 'green'}">${rv.recalls > 0 ? rv.recalls + ' ⚠' : '✓ Clear'}</div><div class="summary-cell-label">NHTSA Status</div></div>
    </div>
    ${rv.description ? `<div style="margin-top:14px;font-size:12px;color:#0A0A0A;line-height:1.6;padding:12px 16px;background:#EEF3FF;border-radius:8px;border-left:3px solid #1565C0;">${rv.description}</div>` : ''}
  `;

  const marketValue = `
    ${liveMarketSection}
    <div style="margin-top:8px;display:flex;gap:10px;">
      ${[
        ['Value Factors (+)', rv.recalls === 0 ? 'No active recalls' : null],
        ['Value Factors (+)', rv.rating >= 4.5 ? `High owner rating ${rv.rating.toFixed(1)}/5.0` : null],
        ['Value Factors (+)', (rv.warrantyYears ?? 0) >= 2 ? `${rv.warrantyYears}-year structural warranty` : null],
        ['Value Factor (−)', rv.recalls > 0 ? `${rv.recalls} active NHTSA recall${rv.recalls > 1 ? 's' : ''}` : null],
      ].filter(([, val]) => val).map(([label, val]) => {
        const isNeg = (label as string).includes('−');
        return `<div style="flex:1;padding:8px 12px;background:${isNeg ? 'rgba(212,37,53,0.07)' : 'rgba(21,101,192,0.07)'};border:1px solid ${isNeg ? 'rgba(212,37,53,0.25)' : 'rgba(21,101,192,0.20)'};border-radius:6px;"><div style="font-size:9px;font-weight:800;color:${isNeg ? '#D42535' : '#1565C0'};letter-spacing:0.8px;text-transform:uppercase;">${label}</div><div style="font-size:11px;color:${isNeg ? '#D42535' : '#1565C0'};font-weight:600;margin-top:2px;">${val}</div></div>`;
      }).join('')}
    </div>
  `;

  const specRows = [
    ['Type', rv.type], ['Year', rv.year],
    ['Length', `${rv.lengthRange[0]}–${rv.lengthRange[1]} ft`],
    ['GVWR', `${rv.weightRange[0].toLocaleString()}–${rv.weightRange[1].toLocaleString()} lbs`],
    ['Slideouts', String(rv.slideouts)], ['Sleeps', String(rv.sleeps)],
    ['Fuel Type', rv.fuelType],
    rv.engine ? ['Engine', rv.engine] : null,
    rv.chassis && rv.chassis !== 'N/A' ? ['Chassis', rv.chassis] : null,
    rv.towingCapacity && rv.towingCapacity > 0 ? ['Tow Capacity', `${rv.towingCapacity.toLocaleString()} lbs`] : null,
    rv.generator ? ['Generator', rv.generator] : null,
    rv.ceilingHeight ? ['Ceiling Height', `${rv.ceilingHeight}"`] : null,
    rv.warrantyYears ? ['Warranty', `${rv.warrantyYears}-Year Structural`] : null,
    ['RvFOX Rating', `${rv.rating.toFixed(1)} / 5.0`],
  ].filter(Boolean) as [string, string][];

  const fullSpecs = `
    <div class="specs-grid">
      ${specRows.map(([label, val]) => `<div class="spec-row"><div class="spec-label">${label}</div><div class="spec-value">${val}</div></div>`).join('')}
    </div>
    ${(rv.freshWater || rv.grayWater || rv.blackWater) ? `
      <div style="margin-top:14px;border-top:1px solid #E0E0E0;padding-top:12px;">
        <div style="font-size:10px;font-weight:800;color:#1565C0;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:10px;">Tank Capacities</div>
        <div style="display:flex;gap:10px;">
          ${rv.freshWater ? `<div style="flex:1;text-align:center;padding:10px;background:rgba(21,101,192,0.10);border:1px solid rgba(21,101,192,0.3);border-radius:8px;"><div style="font-size:18px;font-weight:900;color:#1565C0;">${rv.freshWater} gal</div><div style="font-size:10px;color:#000000;margin-top:2px;">Fresh Water</div></div>` : ''}
          ${rv.grayWater ? `<div style="flex:1;text-align:center;padding:10px;background:#F5F5F5;border:1px solid #E0E0E0;border-radius:8px;"><div style="font-size:18px;font-weight:900;color:#0A0A0A;">${rv.grayWater} gal</div><div style="font-size:10px;color:#000000;margin-top:2px;">Gray Water</div></div>` : ''}
          ${rv.blackWater ? `<div style="flex:1;text-align:center;padding:10px;background:rgba(212,37,53,0.10);border:1px solid rgba(255,100,100,0.25);border-radius:8px;"><div style="font-size:18px;font-weight:900;color:#FF6464;">${rv.blackWater} gal</div><div style="font-size:10px;color:#000000;margin-top:2px;">Black Water</div></div>` : ''}
        </div>
      </div>` : ''}
    <div style="margin-top:14px;border-top:1px solid #E0E0E0;padding-top:12px;">
      <div style="font-size:10px;font-weight:800;color:#D42535;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:10px;">Available Floorplans (${rv.floorplans.length} total)</div>
      <div class="floorplan-chips">${rv.floorplans.map(fp => `<span class="fp-chip">${fp}</span>`).join('')}</div>
    </div>
  `;

  const noRecallCard = `<div class="status-overview"><div class="status-card status-card-green" style="flex:2;"><div class="status-icon">✓</div><div><div class="status-title status-title-green">No Active NHTSA Recalls Found</div><div class="status-sub">No open safety recalls on record for this ${rv.year} ${rv.make} ${rv.model}. Always verify at nhtsa.gov before purchase.</div></div></div></div>`;

  const recallRows = recallDetails.map((r, i) => `
    <div class="recall-row">
      <div class="recall-num">${i + 1}</div>
      <div style="flex:1;">
        <div class="recall-component">${r.component || '—'}</div>
        ${r.campaignNumber ? `<div class="recall-campaign">Campaign: ${r.campaignNumber}${r.date ? ` · ${r.date.slice(0, 4)}` : ''}</div>` : ''}
        ${r.summary ? `<div class="recall-summary">${r.summary.slice(0, 200)}${r.summary.length > 200 ? '…' : ''}</div>` : ''}
        ${r.remedy ? `<div><span class="recall-remedy-tag">✓ Remedy: ${r.remedy.slice(0, 120)}${r.remedy.length > 120 ? '…' : ''}</span></div>` : ''}
      </div>
    </div>`).join('');

  const safetySection = rv.recalls > 0 ? `
    <div class="status-overview"><div class="status-card status-card-orange" style="flex:2;"><div class="status-icon">⚠</div><div><div class="status-title status-title-orange">${rv.recalls} Active NHTSA Recall${rv.recalls > 1 ? 's' : ''} on Record</div><div class="status-sub">Safety recall data from NHTSA.gov. Always verify current recall status before purchase or use.</div></div></div></div>
    ${recallRows.length > 0 ? `<div style="margin-top:4px;"><div style="font-size:10px;font-weight:800;color:#D42535;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;">Recall Details</div>${recallRows}</div>` : ''}
  ` : noRecallCard;

  const defectRows = defects.map((d, i) => `
    <div class="defect-row">
      <div class="defect-header">
        <span style="font-size:10px;color:#000000;font-weight:800;min-width:18px;">#${i + 1}</span>
        <span class="defect-comp">${d.component || 'General'}</span>
        ${d.crashFlag ? `<span class="defect-flag">CRASH</span>` : ''}
        ${d.fireFlag ? `<span class="defect-flag defect-flag-fire">FIRE</span>` : ''}
        ${d.date ? `<span style="font-size:10px;color:#000000;margin-left:auto;">${d.date.slice(0, 4)}</span>` : ''}
      </div>
      ${d.summary ? `<div class="defect-summary">${d.summary.slice(0, 180)}${d.summary.length > 180 ? '…' : ''}</div>` : ''}
    </div>`).join('');

  const ownerComplaints = defects.length > 0 ? `
    <div style="margin-bottom:12px;padding:10px 14px;background:rgba(212,37,53,0.07);border:1px solid rgba(212,37,53,0.25);border-radius:8px;">
      <span style="font-size:13px;font-weight:800;color:#D42535;">${rv.defectCount ?? defects.length} Owner Complaints on File</span>
      <span style="font-size:11px;color:#000000;margin-left:8px;">Source: NHTSA Complaints Database</span>
    </div>${defectRows}
  ` : `<div class="status-card status-card-green" style="display:inline-flex;gap:8px;padding:12px 16px;"><span>✓</span><div><div class="status-title status-title-green">No Owner Complaints on Record</div><div class="status-sub">No NHTSA complaints found for this vehicle. Always check nhtsa.gov for the latest data.</div></div></div>`;

  const priorityOrder: Record<string, number> = { Critical: 0, Important: 1, Routine: 2 };
  const topMaint = [...maintenanceItems].sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]).slice(0, 12);

  const serviceRecs = `
    <table class="maint-table">
      <thead><tr><th>Service Task</th><th>Interval</th><th style="text-align:center;">Priority</th><th>Category</th></tr></thead>
      <tbody>
        ${topMaint.map(item => `<tr><td style="font-weight:600;color:#0A0A0A;">${item.task}</td><td style="color:#1A1A1A;">${item.interval}</td><td style="text-align:center;"><span class="priority-badge priority-${item.priority.toLowerCase()}">${item.priority}</span></td><td style="color:#1A1A1A;">${item.category}</td></tr>`).join('')}
      </tbody>
    </table>
    <div style="margin-top:10px;padding:8px 12px;background:#EEF3FF;border-radius:6px;border-left:3px solid #1565C0;">
      <span style="font-size:10px;color:#1565C0;font-weight:600;">Note: Always follow manufacturer intervals in your owner's manual. Intervals vary by usage, climate, and engine hours.</span>
    </div>
  `;

  const reviewCards = reviewList.slice(0, 4).map(r => `
    <div class="review-card">
      <div class="review-header">
        <div class="review-avatar">${r.author.charAt(0)}</div>
        <div style="flex:1;"><div class="review-author">${r.author}</div><div class="review-meta">${r.location} · ${r.date}${r.verified ? ' · ✓ Verified' : ''}</div></div>
        <div class="review-stars">${stars(r.rating)}</div>
      </div>
      <div class="review-title">${r.title}</div>
      <div class="review-body">${r.body}</div>
    </div>`).join('');

  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/><title>RvFOX Pro — Vehicle History Report</title><style>${BASE_CSS}</style></head>
<body>
  <div class="page-header">
    <div><div class="brand">RvFOX Pro</div><div class="brand-sub">KNOW BEFORE YOU BUY</div><div class="report-tag">VEHICLE HISTORY REPORT</div></div>
    <div class="report-meta"><div class="report-id">REPORT: ${id}</div><div class="report-date">${date}</div><div style="font-size:10px;color:rgba(255,255,255,0.35);margin-top:3px;">Verified &amp; True · RvFOX Pro</div></div>
  </div>
  <div class="prepared-bar">
    <div><div class="prepared-label">Prepared For</div><div class="prepared-name">${rv.customerName?.trim() || 'RvFOX Pro Customer'}</div></div>
    <div class="prepared-right"><div>${rv.year} ${rv.make} ${rv.model}</div><div style="margin-top:2px;">Generated ${date}</div></div>
  </div>
  <div class="content">
    <div class="section">
      <div class="section-header"><span class="section-icon">🚐</span><span class="section-title" style="color:#1565C0;">Vehicle Overview</span></div>
      <div class="section-body">${vehicleOverview}</div>
    </div>
    <div class="section">
      <div class="section-header"><span class="section-icon">💰</span><span class="section-title" style="color:#00A844;">Market Value</span></div>
      <div class="section-body">${marketValue}</div>
    </div>
    <div class="section">
      <div class="section-header"><span class="section-icon">📋</span><span class="section-title" style="color:#1565C0;">Vehicle Specifications</span></div>
      <div class="section-body">${fullSpecs}</div>
    </div>
    <div class="section">
      <div class="section-header" style="border-bottom:2px solid ${rv.recalls > 0 ? '#D42535' : '#00A844'};">
        <span class="section-icon">${rv.recalls > 0 ? '⚠' : '🔒'}</span>
        <span class="section-title" style="color:${rv.recalls > 0 ? '#D42535' : '#00A844'};">Safety &amp; NHTSA Recalls (${rv.recalls === 0 ? 'Clear' : rv.recalls + ' Found'})</span>
      </div>
      <div class="section-body">
        ${safetySection}
        <div style="margin-top:12px;padding:8px 12px;background:#EEF3FF;border-radius:6px;font-size:10px;color:#1A1A1A;">Recall data sourced from NHTSA.gov. Always verify at <strong style="color:#1565C0;">nhtsa.gov/recalls</strong> before purchase.</div>
      </div>
    </div>
    <div class="section">
      <div class="section-header" style="border-bottom:2px solid #D42535;">
        <span class="section-icon">⚡</span>
        <span class="section-title" style="color:#D42535;">Owner Complaints${defects.length > 0 ? ' (' + (rv.defectCount ?? defects.length) + ')' : ''}</span>
      </div>
      <div class="section-body">${ownerComplaints}</div>
    </div>
    <div class="section">
      <div class="section-header"><span class="section-icon">🔧</span><span class="section-title" style="color:#00A844;">Service Recommendations</span></div>
      <div class="section-body">${serviceRecs}</div>
    </div>
    <div class="section">
      <div class="section-header" style="border-bottom:2px solid #1565C0;">
        <span class="section-icon">⭐</span>
        <span class="section-title" style="color:#1565C0;">Owner Reviews (${ratingCount.toLocaleString()} ratings · ${rv.rating.toFixed(1)}/5.0)</span>
      </div>
      <div class="section-body">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;padding:12px 16px;background:#f8f9fa;border-radius:8px;border:1px solid #E0E0E0;">
          <div style="text-align:center;min-width:64px;">
            <div style="font-size:40px;font-weight:900;color:#1565C0;line-height:1;">${rv.rating.toFixed(1)}</div>
            <div style="color:#1565C0;font-size:14px;letter-spacing:1px;">${stars(rv.rating)}</div>
          </div>
          <div style="flex:1;font-size:12px;color:#1A1A1A;line-height:1.6;">Based on ${ratingCount.toLocaleString()} verified owner ratings aggregated from RV owner communities. Owner satisfaction rate: ${Math.round(rv.rating / 5 * 100)}%.</div>
        </div>
        ${reviewCards}
        <div style="font-size:10px;color:#1A1A1A;line-height:1.6;margin-top:6px;padding:8px 12px;background:#F0F0F0;border-radius:6px;">Reviews are aggregated from verified owner communities and RV forums. RvFOX Pro does not independently verify individual reviews.</div>
      </div>
    </div>
    <div class="disclosure"><p><strong>Important:</strong> All specifications and recall data are estimates for informational purposes only. Market values reflect current used RV market research and may vary by condition, mileage, options, and region. Always verify recalls at <strong>nhtsa.gov</strong>. RvFOX Pro is not responsible for inaccuracies in third-party data. Report ID: ${id} · ${date}</p></div>
  </div>
  <div class="page-footer">
    <div><div class="footer-brand">RvFOX Pro</div><div class="footer-copy">© 2026 RvFOX Pro · All Rights Reserved · contact@rvfox.app</div></div>
    <div class="footer-right"><div>Know before you buy.</div><div>RvFax™ Vehicle History Report</div></div>
  </div>
</body></html>`;
}

// ─── LOAN REPORT ─────────────────────────────────────────────────────────────

function buildLoanReportHTML(d: LoanReportData): string {
  const id = reportId(); const date = reportDate(); const rv = d.rv;
  const DOWN_SCENARIOS = [10, 15, 20, 30];
  const scenarioCells = DOWN_SCENARIOS.map(pct => {
    const down = Math.round((pct / 100) * d.sellingPrice);
    const financed = d.sellingPrice + d.salesTax + d.regFee + (d.negativeEquity ?? 0) - down - (d.tradeNetCredit ?? 0);
    const mo = Math.round(calcMonthlyPayment(financed, d.apr, d.termMonths));
    const totalInt = Math.round(mo * d.termMonths - financed);
    const active = pct === d.downPct; const cls = active ? 'active' : '';
    return `<div class="sc-cell${active ? ' active' : ''}"><div class="sc-pct ${cls}">${pct}%</div><div class="sc-down ${cls}">$${fmt(down)} down</div><div class="sc-mo ${cls}">$${fmt(mo)}</div><div class="sc-lbl ${cls}">/month</div><div class="sc-int ${cls}">+$${fmt(totalInt)} interest</div></div>`;
  }).join('');
  const tradeRows = (d.tradeValue && d.tradeValue > 0) ? `
    <tr class="bd-green"><td class="bd-label">Trade-In Value</td><td class="bd-value">$${fmt(d.tradeValue)}</td></tr>
    <tr><td class="bd-label">Trade Payoff (Owed)</td><td class="bd-value">$${fmt(d.tradeOwed ?? 0)}</td></tr>
    ${(d.negativeEquity ?? 0) > 0
      ? `<tr class="bd-red"><td class="bd-label">Negative Equity (added)</td><td class="bd-value">+$${fmt(d.negativeEquity ?? 0)}</td></tr>`
      : `<tr class="bd-green"><td class="bd-label">Trade Credit Applied</td><td class="bd-value">−$${fmt(d.tradeNetCredit ?? 0)}</td></tr>`
    }` : '';
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/><title>RvFOX Pro — Loan Report</title><style>${BASE_CSS}</style></head>
<body>
  <div class="page-header"><div><div class="brand">RvFOX Pro</div><div class="brand-sub">VERIFIED &amp; TRUE</div><div class="report-tag">DETAILED LOAN REPORT</div></div><div class="report-meta"><div class="report-id">REPORT: ${id}</div><div class="report-date">${date}</div></div></div>
  ${d.rv.customerName ? `<div class="prepared-bar"><div><div class="prepared-label">Prepared For</div><div class="prepared-name">${d.rv.customerName}</div></div><div class="prepared-right"><div>${rv.year} ${rv.make} ${rv.model}</div><div>${date}</div></div></div>` : ''}
  <div class="content" style="padding-top:20px;">
    <div style="background:#f8f9fa;border-radius:10px;padding:20px 24px;margin-bottom:14px;border:1px solid #E0E0E0;">
      <div style="font-size:11px;font-weight:800;color:#1565C0;letter-spacing:2px;margin-bottom:4px;">${rv.year}</div>
      <div style="font-size:24px;font-weight:900;color:#1A1A1A;">${rv.make} ${rv.model}${rv.floorplan ? ' · ' + rv.floorplan : ''}</div>
      <div style="display:flex;gap:20px;margin-top:12px;">
        <div><div style="font-size:18px;font-weight:900;color:#00C853;">$${fmt(d.sellingPrice)}</div><div style="font-size:10px;color:#000000;letter-spacing:1px;text-transform:uppercase;">Selling Price</div></div>
        <div><div style="font-size:18px;font-weight:900;color:#1565C0;">${d.downPct}% / $${fmt(d.downAmt)}</div><div style="font-size:10px;color:#000000;letter-spacing:1px;text-transform:uppercase;">Down Payment</div></div>
        <div><div style="font-size:18px;font-weight:900;color:#00C853;">${fmtDec(d.apr)}%</div><div style="font-size:10px;color:#000000;letter-spacing:1px;text-transform:uppercase;">APR</div></div>
        <div><div style="font-size:18px;font-weight:900;color:#D42535;">${d.termMonths} mo</div><div style="font-size:10px;color:#000000;letter-spacing:1px;text-transform:uppercase;">Term</div></div>
      </div>
    </div>
    <div class="payment-hero">
      <div><div class="payment-label">Estimated Monthly Payment</div><div class="payment-amount">$${fmt(Math.round(d.monthlyPayment))}</div><div class="payment-sub">for ${d.termMonths} months · ${fmtDec(d.apr)}% APR</div></div>
      <div class="payment-right"><div class="financed-label">Amount Financed</div><div class="financed-value">$${fmt(Math.round(d.amountFinanced))}</div><div style="font-size:11px;color:#000000;margin-top:5px;">${d.stateName ?? ''} · ${fmtDec(d.taxRate)}% tax</div></div>
    </div>
    <div class="section"><div class="section-header"><span class="section-icon">📊</span><span class="section-title" style="color:#1565C0;">Down Payment Scenarios</span></div>
      <div class="section-body"><div class="scenarios-strip">${scenarioCells}</div><div class="info-box"><p>The <strong>highlighted column</strong> reflects your current selection. Lower down payments increase total interest paid significantly.</p></div></div>
    </div>
    <div class="section"><div class="section-header"><span class="section-icon">💲</span><span class="section-title" style="color:#1565C0;">Cost Breakdown</span></div>
      <div class="section-body"><table class="breakdown-table">
        <tr><td class="bd-label">Vehicle Selling Price</td><td class="bd-value">$${fmt(d.sellingPrice)}</td></tr>
        <tr><td class="bd-label">Sales Tax (${fmtDec(d.taxRate)}% · ${d.stateName ?? ''})</td><td class="bd-value">$${fmt(Math.round(d.salesTax))}</td></tr>
        <tr><td class="bd-label">Registration &amp; Title Fees</td><td class="bd-value">$${fmt(d.regFee)}</td></tr>
        ${tradeRows}
        <tr class="bd-green"><td class="bd-label">Down Payment (${d.downPct}%)</td><td class="bd-value">−$${fmt(d.downAmt)}</td></tr>
        <tr><td class="bd-label" style="font-weight:700;">Amount Financed</td><td class="bd-value" style="color:#1565C0;font-size:15px;">$${fmt(Math.round(d.amountFinanced))}</td></tr>
        <tr class="bd-red"><td class="bd-label">Total Interest Cost</td><td class="bd-value">$${fmt(Math.round(d.totalInterest))}</td></tr>
        <tr class="bd-total"><td class="bd-label">Total of All Payments</td><td class="bd-value">$${fmt(Math.round(d.totalPayments))}</td></tr>
      </table></div>
    </div>
    <div class="section"><div class="section-header" style="border-bottom:2px solid ${rv.recalls > 0 ? '#D42535' : '#00A844'};"><span class="section-icon">${rv.recalls > 0 ? '⚠' : '✓'}</span><span class="section-title" style="color:${rv.recalls > 0 ? '#D42535' : '#00A844'};">NHTSA Recall Status</span></div>
      <div class="section-body">${rv.recalls > 0
        ? `<div class="status-card status-card-orange"><div class="status-icon">⚠</div><div><div class="status-title status-title-orange">${rv.recalls} Active Recall${rv.recalls > 1 ? 's' : ''}</div><div class="status-sub">Verify at nhtsa.gov before purchase</div></div></div>`
        : `<div class="status-card status-card-green"><div class="status-icon">✓</div><div><div class="status-title status-title-green">No Active NHTSA Recalls Found</div><div class="status-sub">Always verify at nhtsa.gov before purchase</div></div></div>`
      }</div>
    </div>
    <div class="disclosure"><p><strong>Important:</strong> All estimates are for informational purposes only. Verify all figures with your lender and dealer. Report ID: ${id} · ${date}</p></div>
  </div>
  <div class="page-footer"><div><div class="footer-brand">RvFOX Pro</div><div class="footer-copy">© 2026 RvFOX Pro · All Rights Reserved · contact@rvfox.app</div></div><div class="footer-right"><div>RvCal™ Loan Intelligence</div></div></div>
</body></html>`;
}

// ─── COMPARISON REPORT ────────────────────────────────────────────────────────

function buildComparisonReportHTML(d: LoanReportData): string {
  const id = reportId(); const date = reportDate(); const rv = d.rv;
  const DOWN_OPTIONS = [10, 15, 20, 30];
  const scenarios = DOWN_OPTIONS.map(pct => {
    const down = Math.round((pct / 100) * d.sellingPrice);
    const financed = d.sellingPrice + d.salesTax + d.regFee + (d.negativeEquity ?? 0) - down - (d.tradeNetCredit ?? 0);
    const mo = calcMonthlyPayment(financed, d.apr, d.termMonths);
    const totalInt = mo * d.termMonths - financed;
    const totalPaid = mo * d.termMonths;
    return { pct, down, financed, mo, totalInt, totalPaid };
  });
  const baseline = scenarios[0];
  const tableRows = scenarios.map(sc => {
    const active = sc.pct === d.downPct;
    const savingsVsBaseline = baseline.totalPaid - sc.totalPaid;
    const breakEvenMonths = savingsVsBaseline > 0 ? Math.ceil((sc.down - baseline.down) / ((baseline.mo - sc.mo) || 1)) : 0;
    return `<tr class="${active ? 'active-row' : ''}">
      <td class="label-col">${sc.pct}% Down${active ? ' ★' : ''}</td>
      <td class="num">$${fmt(sc.down)}</td><td class="num">$${fmt(Math.round(sc.financed))}</td>
      <td class="num">$${fmt(Math.round(sc.mo))}/mo</td><td class="num">$${fmt(Math.round(sc.totalInt))}</td>
      <td class="num">$${fmt(Math.round(sc.totalPaid))}</td></tr>
      ${sc.pct !== 10 ? `<tr class="savings-row"><td colspan="5" class="label-col" style="font-size:10px;color:#00A844;padding-left:24px;">↳ Saves $${fmt(Math.round(savingsVsBaseline))} total vs 10% down · Break-even: ~${breakEvenMonths} months</td><td class="savings-val">$${fmt(Math.round(savingsVsBaseline))} saved</td></tr>` : ''}`;
  }).join('');
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/><title>RvFOX Pro — Comparison Report</title><style>${BASE_CSS}</style></head>
<body>
  <div class="page-header"><div><div class="brand">RvFOX Pro</div><div class="brand-sub">VERIFIED &amp; TRUE</div><div class="report-tag">LOAN COMPARISON REPORT</div></div><div class="report-meta"><div class="report-id">REPORT: ${id}</div><div class="report-date">${date}</div></div></div>
  ${d.rv.customerName ? `<div class="prepared-bar"><div><div class="prepared-label">Prepared For</div><div class="prepared-name">${d.rv.customerName}</div></div><div class="prepared-right"><div>${rv.year} ${rv.make} ${rv.model}</div><div>${date}</div></div></div>` : ''}
  <div class="content" style="padding-top:20px;">
    <div style="background:#f8f9fa;border-radius:10px;padding:18px 24px;margin-bottom:14px;border:1px solid #E0E0E0;">
      <div style="font-size:22px;font-weight:900;color:#1A1A1A;">${rv.make} ${rv.model}${rv.floorplan ? ' · ' + rv.floorplan : ''}</div>
      <div style="display:flex;gap:20px;margin-top:10px;">
        <div><div style="font-size:16px;font-weight:900;color:#00C853;">$${fmt(d.sellingPrice)}</div><div style="font-size:9px;color:#000000;text-transform:uppercase;letter-spacing:1px;">Selling Price</div></div>
        <div><div style="font-size:16px;font-weight:900;color:#1565C0;">${fmtDec(d.apr)}%</div><div style="font-size:9px;color:#000000;text-transform:uppercase;letter-spacing:1px;">APR</div></div>
        <div><div style="font-size:16px;font-weight:900;color:#D42535;">${d.termMonths} mo</div><div style="font-size:9px;color:#000000;text-transform:uppercase;letter-spacing:1px;">Term</div></div>
        <div><div style="font-size:16px;font-weight:900;color:#00C853;">${d.stateName ?? 'N/A'}</div><div style="font-size:9px;color:#000000;text-transform:uppercase;letter-spacing:1px;">${fmtDec(d.taxRate)}% tax</div></div>
      </div>
    </div>
    <div class="section"><div class="section-header"><span class="section-title" style="color:#1565C0;">Quick Comparison — 4 Down Payment Scenarios</span></div>
      <div class="section-body"><div class="scenarios-strip">${scenarios.map(sc => { const active = sc.pct === d.downPct; const cls = active ? 'active' : ''; return `<div class="sc-cell${active ? ' active' : ''}"><div class="sc-pct ${cls}">${sc.pct}%</div><div class="sc-down ${cls}">$${fmt(sc.down)}</div><div class="sc-mo ${cls}">$${fmt(Math.round(sc.mo))}</div><div class="sc-lbl ${cls}">/month</div><div class="sc-int ${cls}">$${fmt(Math.round(sc.totalInt))} interest</div></div>`; }).join('')}</div></div>
    </div>
    <div class="section"><div class="section-header"><span class="section-title" style="color:#1565C0;">Side-by-Side Analysis</span></div>
      <div class="section-body"><table class="comp-table"><thead><tr><th>Down %</th><th class="num">Down Amt</th><th class="num">Financed</th><th class="num active-col">Monthly</th><th class="num">Total Interest</th><th class="num">Total Paid</th></tr></thead><tbody>${tableRows}</tbody></table></div>
    </div>
    <div class="info-box"><p><strong>Key Insight:</strong> Putting 20% down vs 10% down on this vehicle saves $${fmt(Math.round(baseline.totalPaid - scenarios[2].totalPaid))} over the life of the loan.</p></div>
    <div class="disclosure"><p><strong>Disclaimer:</strong> All figures are estimates. Actual rates, fees, and payments will vary by lender and deal terms. Report ID: ${id} · ${date}</p></div>
  </div>
  <div class="page-footer"><div><div class="footer-brand">RvFOX Pro</div><div class="footer-copy">© 2026 RvFOX Pro · All Rights Reserved</div></div><div class="footer-right"><div>RvCal™ Comparison Engine</div></div></div>
</body></html>`;
}

// ─── DEALER QUOTE ─────────────────────────────────────────────────────────────

function buildDealerQuoteHTML(d: DealerQuoteData): string {
  const id = reportId(); const date = reportDate(); const rv = d.rv;
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + (d.validDays ?? 7));
  const expiryStr = expiryDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  const tradeSection = (d.tradeValue && d.tradeValue > 0) ? `
    <tr><td class="bd-label">Trade-In Value</td><td class="bd-value" style="color:#00A844;">$${fmt(d.tradeValue)}</td></tr>
    <tr><td class="bd-label">Trade Payoff Owed</td><td class="bd-value">$${fmt(d.tradeOwed ?? 0)}</td></tr>
    ${(d.negativeEquity ?? 0) > 0
      ? `<tr><td class="bd-label">Negative Equity (added to loan)</td><td class="bd-value" style="color:#D42535;">+$${fmt(d.negativeEquity ?? 0)}</td></tr>`
      : `<tr><td class="bd-label">Net Trade Credit</td><td class="bd-value" style="color:#00A844;">−$${fmt(d.tradeNetCredit ?? 0)}</td></tr>`
    }` : '<tr><td class="bd-label">Trade-In</td><td class="bd-value" style="color:#000000;">None</td></tr>';
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/><title>RvFOX Pro — Customer Quote</title><style>${BASE_CSS}</style></head>
<body>
  <div class="page-header">
    <div><div class="brand">${d.dealerName ?? 'RvFOX Pro'}</div><div class="brand-sub">${d.dealerAddress ?? 'AUTHORIZED RV DEALER'}</div><div class="report-tag">CUSTOMER PURCHASE QUOTE</div></div>
    <div class="report-meta"><div class="report-id">QUOTE: ${id}</div><div class="report-date">${date}</div>${d.salespersonName ? `<div style="font-size:11px;color:rgba(255,255,255,0.55);margin-top:3px;">Sales: ${d.salespersonName}</div>` : ''}</div>
  </div>
  <div class="prepared-bar">
    <div><div class="prepared-label">Prepared For</div><div class="prepared-name">${d.customerName ?? 'Customer'}</div></div>
    <div class="prepared-right"><div>Valid until ${expiryStr}</div><div style="margin-top:2px;">${rv.year} ${rv.make} ${rv.model}</div></div>
  </div>
  <div class="content" style="padding-top:20px;">
    <div class="payment-hero">
      <div><div class="payment-label">Estimated Monthly Payment</div><div class="payment-amount">$${fmt(Math.round(d.monthlyPayment))}</div><div class="payment-sub">for ${d.termMonths} months · ${fmtDec(d.apr)}% APR (WAC)</div></div>
      <div class="payment-right"><div class="financed-label">Amount Financed</div><div class="financed-value">$${fmt(Math.round(d.amountFinanced))}</div><div style="font-size:11px;color:#000000;margin-top:5px;">${d.downPct}% Down · ${d.stateName ?? ''} ${fmtDec(d.taxRate)}% tax</div></div>
    </div>
    <div class="section"><div class="section-header"><span class="section-icon">💲</span><span class="section-title" style="color:#1565C0;">Deal Breakdown</span></div>
      <div class="section-body"><table class="breakdown-table">
        <tr><td class="bd-label" style="font-weight:700;font-size:14px;">${rv.year} ${rv.make} ${rv.model}</td><td class="bd-value" style="font-size:14px;">$${fmt(d.sellingPrice)}</td></tr>
        <tr><td class="bd-label">Sales Tax (${fmtDec(d.taxRate)}%)</td><td class="bd-value">$${fmt(Math.round(d.salesTax))}</td></tr>
        <tr><td class="bd-label">Registration &amp; Title Fees</td><td class="bd-value">$${fmt(d.regFee)}</td></tr>
        ${tradeSection}
        <tr class="bd-green"><td class="bd-label">Down Payment (${d.downPct}%)</td><td class="bd-value">−$${fmt(d.downAmt)}</td></tr>
        <tr><td class="bd-label" style="font-weight:700;">Amount to Finance</td><td class="bd-value" style="color:#1565C0;font-size:15px;">$${fmt(Math.round(d.amountFinanced))}</td></tr>
        <tr class="bd-red"><td class="bd-label">Est. Total Interest</td><td class="bd-value">$${fmt(Math.round(d.totalInterest))}</td></tr>
        <tr class="bd-total"><td class="bd-label">Est. Total of Payments</td><td class="bd-value">$${fmt(Math.round(d.totalPayments))}</td></tr>
      </table></div>
    </div>
    <div class="section"><div class="section-header"><span class="section-title" style="color:#1565C0;">Signature &amp; Acceptance</span></div>
      <div class="section-body"><div class="sig-area">
        <div class="sig-block"><div class="sig-line"></div><div class="sig-label">Customer Signature</div></div>
        <div class="sig-block"><div class="sig-line"></div><div class="sig-label">Date</div></div>
        <div class="sig-block"><div class="sig-line"></div><div class="sig-label">Salesperson</div></div>
        <div class="sig-block"><div class="sig-line"></div><div class="sig-label">Dealer Rep</div></div>
      </div></div>
    </div>
    <div class="warn-box"><p><strong>Valid for ${d.validDays ?? 7} days (expires ${expiryStr}).</strong> All payment estimates are subject to credit approval (WAC). Quote ID: ${id}</p></div>
  </div>
  <div class="page-footer"><div><div class="footer-brand">${d.dealerName ?? 'RvFOX Pro'}</div><div class="footer-copy">Powered by RvFOX Pro · © 2026</div></div><div class="footer-right"><div>RvCal™ Quote Engine</div></div></div>
</body></html>`;
}

// ─── SHARE / PRINT ────────────────────────────────────────────────────────────

async function printAndShare(html: string, filename: string): Promise<void> {
  if (Platform.OS === 'web') {
    const w = window.open('', '_blank');
    if (w) { w.document.write(html); w.document.close(); w.focus(); w.print(); }
    return;
  }
  const { uri } = await Print.printToFileAsync({ html, base64: false });
  const canShare = await Sharing.isAvailableAsync();
  if (canShare) { await Sharing.shareAsync(uri, { mimeType: 'application/pdf', dialogTitle: filename, UTI: 'com.adobe.pdf' }); }
  else { await Print.printAsync({ uri }); }
}
async function printPreview(html: string): Promise<void> {
  if (Platform.OS === 'web') {
    const w = window.open('', '_blank');
    if (w) { w.document.write(html); w.document.close(); w.focus(); w.print(); }
    return;
  }
  await Print.printAsync({ html });
}

// ─── ENRICH NHTSA ─────────────────────────────────────────────────────────────

async function enrichWithNhtsa(rv: RVReportData): Promise<RVReportData> {
  if (!rv.make || !rv.model || !rv.year) return rv;
  try {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase.functions.invoke('nhtsa-lookup', { body: { make: rv.make, model: rv.model, year: rv.year } });
    if (!error && data) {
      return { ...rv, recalls: data.recallCount ?? rv.recalls, recallDetails: data.recalls ?? rv.recallDetails ?? [], defectCount: data.defectCount ?? rv.defectCount ?? 0, defects: data.defects ?? rv.defects ?? [] };
    }
  } catch { /* graceful fallback */ }
  return rv;
}

// ─── PUBLIC API ───────────────────────────────────────────────────────────────

export async function generateAndShareRVReport(rv: RVReportData): Promise<void> {
  const enriched = (rv.recallDetails !== undefined) ? rv : await enrichWithNhtsa(rv);
  await printAndShare(buildValuationReportHTML(enriched), `${enriched.year} ${enriched.make} ${enriched.model} — RvFOX Vehicle Report`);
}
export async function previewRVReport(rv: RVReportData): Promise<void> {
  const enriched = (rv.recallDetails !== undefined) ? rv : await enrichWithNhtsa(rv);
  await printPreview(buildValuationReportHTML(enriched));
}
export async function generateAndShareLoanReport(data: LoanReportData): Promise<void> {
  await printAndShare(buildLoanReportHTML(data), `${data.rv.year} ${data.rv.make} ${data.rv.model} — Loan Report`);
}
export async function previewLoanReport(data: LoanReportData): Promise<void> {
  await printPreview(buildLoanReportHTML(data));
}
export async function generateAndShareComparisonReport(data: LoanReportData): Promise<void> {
  await printAndShare(buildComparisonReportHTML(data), `${data.rv.year} ${data.rv.make} ${data.rv.model} — Loan Comparison`);
}
export async function generateAndShareDealerQuote(data: DealerQuoteData): Promise<void> {
  await printAndShare(buildDealerQuoteHTML(data), `${data.rv.year} ${data.rv.make} ${data.rv.model} — Customer Quote`);
}
export async function generateAndShareValuationReport(rv: RVReportData): Promise<void> {
  const enriched = (rv.recallDetails !== undefined) ? rv : await enrichWithNhtsa(rv);
  await printAndShare(buildValuationReportHTML(enriched), `${enriched.year} ${enriched.make} ${enriched.model} — RvFOX Vehicle Report`);
}
