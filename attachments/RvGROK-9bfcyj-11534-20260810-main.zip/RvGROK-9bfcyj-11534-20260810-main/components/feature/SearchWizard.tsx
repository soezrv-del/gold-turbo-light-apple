import React, { useState, useMemo, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Pressable, TextInput, ScrollView } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import { RV_DATA, YEARS } from '@/constants/rvData';

// Use live Object.keys so extra brands added via rvDataExtra.ts are included
const MAKES = Object.keys(RV_DATA).sort();

// ─── RV TYPE ICON MAP ────────────────────────────────────────────────────────
const TYPE_ICON_MAP: Record<string, string> = {
  'Class A Gas':    'directions-bus',
  'Class A Diesel': 'directions-bus',
  'Class B':        'airport-shuttle',
  'Class B+':       'airport-shuttle',
  'Class C':        'rv-hookup',
  'Super C':        'rv-hookup',
  'Fifth Wheel':    'looks-5',
  'Travel Trailer': 'local-shipping',
  'Toy Hauler':     'sports-motorsports',
  'Truck Camper':   'outdoor-grill',
};

function getTypeIcon(rvType: string): string {
  for (const [key, icon] of Object.entries(TYPE_ICON_MAP)) {
    if (rvType === key || rvType.startsWith(key)) return icon;
  }
  if (rvType.includes('Super C'))   return TYPE_ICON_MAP['Super C'];
  if (rvType.includes('Class B+'))  return TYPE_ICON_MAP['Class B+'];
  if (rvType.includes('Class B'))   return TYPE_ICON_MAP['Class B'];
  if (rvType.includes('Class C'))   return TYPE_ICON_MAP['Class C'];
  if (rvType.includes('Fifth') || rvType.includes('5th')) return TYPE_ICON_MAP['Fifth Wheel'];
  if (rvType.includes('Travel'))    return TYPE_ICON_MAP['Travel Trailer'];
  if (rvType.includes('Toy'))       return TYPE_ICON_MAP['Toy Hauler'];
  if (rvType.includes('Truck'))     return TYPE_ICON_MAP['Truck Camper'];
  return 'directions-bus';
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

export type WizardStep = 'year' | 'make' | 'model' | 'floorplan';

function getMakesForYear(yearStr: string): string[] {
  const y = parseInt(yearStr, 10);
  if (isNaN(y)) return MAKES;
  return MAKES.filter(mk => {
    const models = RV_DATA[mk];
    if (!models) return false;
    return Object.values(models).some(spec => {
      const start = spec.yearStart ?? 2000;
      const end   = spec.yearEnd   ?? 2026;
      return y >= start && y <= end;
    });
  });
}

function getModelsForYearMake(yearStr: string, mk: string): string[] {
  const y = parseInt(yearStr, 10);
  const models = RV_DATA[mk];
  if (!models) return [];
  return Object.keys(models).filter(mdl => {
    const spec = models[mdl];
    if (!spec) return false;
    if (!isNaN(y)) {
      const start = spec.yearStart ?? 2000;
      const end   = spec.yearEnd   ?? 2026;
      return y >= start && y <= end;
    }
    return true;
  }).sort();
}

function getFloorplansForMakeModel(mk: string, mdl: string): string[] {
  return RV_DATA[mk]?.[mdl]?.floorplans ?? [];
}

// ─── CONSTANTS ────────────────────────────────────────────────────────────────

export const WIZARD_STEPS: WizardStep[] = ['year', 'make', 'model', 'floorplan'];

const STEP_LABELS: Record<WizardStep, string> = {
  year: 'Year', make: 'Make', model: 'Model', floorplan: 'Floorplan',
};

const STEP_COLORS: Record<WizardStep, string> = {
  year:      '#4DA6FF',
  make:      '#00C853',
  model:     '#FFD700',
  floorplan: '#FF6B35',
};

const STEP_HINTS: Record<WizardStep, (y: string, mk: string, mdl: string) => string> = {
  year:      ()         => 'Select a model year to begin',
  make:      (y)        => y ? `${y} · Pick a brand` : 'Pick a manufacturer',
  model:     (y, mk)    => mk ? `${y} ${mk} · Pick a model` : 'Pick a model',
  floorplan: (y, mk, m) => m ? `${y} ${mk} ${m} · Pick a floorplan` : 'Pick a floorplan',
};

// ─── PROPS ────────────────────────────────────────────────────────────────────

interface Props {
  onSearch: (year: string, make: string, model: string, floorplan: string) => void;
  externalSearch?: { year: string; make: string; model: string; floorplan: string; _ts: number } | null;
}

// ─── COMPONENT ───────────────────────────────────────────────────────────────

export default function SearchWizard({ onSearch, externalSearch }: Props) {
  // ── mode: 'wizard' | 'manual' ────────────────────────────────────────────
  const [mode, setMode] = useState<'wizard' | 'manual'>('wizard');

  // ── Wizard state ──────────────────────────────────────────────────────────
  const [step, setStep]         = useState<WizardStep>('year');
  const [selYear, setSelYear]   = useState('');
  const [selMake, setSelMake]   = useState('');
  const [selModel, setSelModel] = useState('');
  const [query, setQuery]       = useState('');

  // ── Manual state ──────────────────────────────────────────────────────────
  const [manYear,     setManYear]     = useState('');
  const [manMake,     setManMake]     = useState('');
  const [manModel,    setManModel]    = useState('');
  const [manFloorplan,setManFloorplan]= useState('');
  const [showMakeSuggestions, setShowMakeSuggestions] = useState(false);

  // Stable ref so effect never needs onSearch as a dep
  const onSearchRef = useRef(onSearch);
  onSearchRef.current = onSearch;

  // Fired when user taps a recent search
  useEffect(() => {
    if (!externalSearch) return;
    const { year, make, model, floorplan } = externalSearch;
    setQuery('');
    setSelYear(year);
    setSelMake(make);
    setSelModel(model);
    setStep('floorplan');
    onSearchRef.current(year, make, model, floorplan);
  }, [externalSearch]);

  const stepIdx = WIZARD_STEPS.indexOf(step);
  const accent  = STEP_COLORS[step];

  // ── Wizard: options for the current step ─────────────────────────────────
  const allOptions = useMemo<string[]>(() => {
    if (step === 'year')      return YEARS;
    if (step === 'make')      return selYear ? getMakesForYear(selYear) : MAKES;
    if (step === 'model')     return selMake ? getModelsForYearMake(selYear, selMake) : [];
    if (step === 'floorplan') {
      const fps = selMake && selModel ? getFloorplansForMakeModel(selMake, selModel) : [];
      return fps.length > 0 ? fps : ['(All Floorplans)'];
    }
    return [];
  }, [step, selYear, selMake, selModel]);

  const options = useMemo(() =>
    query.trim()
      ? allOptions.filter(o => o.toLowerCase().includes(query.toLowerCase()))
      : allOptions,
    [allOptions, query]
  );

  // ── Wizard: select & advance ──────────────────────────────────────────────
  const handleSelect = (value: string) => {
    setQuery('');
    if (step === 'year') {
      setSelYear(value); setSelMake(''); setSelModel('');
      setStep('make');
    } else if (step === 'make') {
      setSelMake(value); setSelModel('');
      setStep('model');
    } else if (step === 'model') {
      setSelModel(value);
      setStep('floorplan');
    } else {
      const fp = value === '(All Floorplans)' ? '' : value;
      onSearch(selYear, selMake, selModel, fp);
    }
  };

  // ── Wizard: back / reset ──────────────────────────────────────────────────
  const goBack = () => {
    setQuery('');
    if (step === 'make')      { setSelMake('');  setStep('year'); }
    if (step === 'model')     { setSelModel(''); setStep('make'); }
    if (step === 'floorplan') { setStep('model'); }
  };

  const reset = () => {
    setStep('year'); setSelYear(''); setSelMake(''); setSelModel(''); setQuery('');
  };

  // ── Manual: search ────────────────────────────────────────────────────────
  const handleManualSearch = () => {
    if (!manMake.trim() && !manModel.trim()) return;
    onSearch(manYear.trim(), manMake.trim(), manModel.trim(), manFloorplan.trim());
  };

  const clearManual = () => {
    setManYear(''); setManMake(''); setManModel(''); setManFloorplan('');
    setShowMakeSuggestions(false);
  };

  const manualReady = manMake.trim().length > 0 || manModel.trim().length > 0;

  // ── Autocomplete suggestions for Make field ───────────────────────────────
  const makeSuggestions = useMemo(() => {
    const q = manMake.trim().toLowerCase();
    if (!q || q.length < 1) return MAKES.slice(0, 8);
    return MAKES.filter(m => m.toLowerCase().includes(q)).slice(0, 8);
  }, [manMake]);

  // ── Breadcrumb values ─────────────────────────────────────────────────────
  const breadcrumbs = [selYear, selMake, selModel, ''];

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <View style={styles.card}>

      {/* ── MODE TOGGLE ── */}
      <View style={styles.modeToggleRow}>
        <Text style={styles.cardTitle}>Search Wizard</Text>
        <View style={styles.modeSwitch}>
          <Pressable
            style={[styles.modeTab, mode === 'wizard' && styles.modeTabActive]}
            onPress={() => setMode('wizard')}
            hitSlop={6}
          >
            <MaterialIcons name="auto-fix-high" size={11} color={mode === 'wizard' ? '#4DA6FF' : Colors.textMuted} />
            <Text style={[styles.modeTabText, mode === 'wizard' && styles.modeTabTextActive]}>Wizard</Text>
          </Pressable>
          <Pressable
            style={[styles.modeTab, mode === 'manual' && styles.modeTabActiveOrange]}
            onPress={() => setMode('manual')}
            hitSlop={6}
          >
            <MaterialIcons name="edit" size={11} color={mode === 'manual' ? '#FF6B35' : Colors.textMuted} />
            <Text style={[styles.modeTabText, mode === 'manual' && styles.modeTabTextOrange]}>Manual</Text>
          </Pressable>
        </View>
      </View>

      {/* ══════════════════════════════════════════════════════════════
          MANUAL MODE
      ══════════════════════════════════════════════════════════════ */}
      {mode === 'manual' && (
        <View style={styles.manualWrap}>
          <Text style={styles.manualHint}>
            Type any year, make, model, or floorplan — works for any RV brand
          </Text>

          {/* Year + Make row */}
          <View style={styles.manualRow}>
            <View style={[styles.manualField, { flex: 0.85 }]}>
              <Text style={styles.manualLabel}>YEAR</Text>
              <TextInput
                style={styles.manualInput}
                value={manYear}
                onChangeText={setManYear}
                placeholder="e.g. 2024"
                placeholderTextColor={Colors.textMuted}
                keyboardType="number-pad"
                maxLength={4}
                returnKeyType="next"
                onFocus={() => setShowMakeSuggestions(false)}
              />
            </View>
            <View style={[styles.manualField, { flex: 1.6 }]}>
              <Text style={styles.manualLabel}>MAKE</Text>
              <TextInput
                style={[
                  styles.manualInput,
                  showMakeSuggestions && makeSuggestions.length > 0 && styles.manualInputFocused,
                ]}
                value={manMake}
                onChangeText={(t) => { setManMake(t); setShowMakeSuggestions(true); }}
                onFocus={() => setShowMakeSuggestions(true)}
                onBlur={() => setTimeout(() => setShowMakeSuggestions(false), 180)}
                placeholder="e.g. Entegra Coach"
                placeholderTextColor={Colors.textMuted}
                autoCorrect={false}
                autoCapitalize="words"
                returnKeyType="next"
              />
              {/* Autocomplete dropdown */}
              {showMakeSuggestions && makeSuggestions.length > 0 && (
                <View style={styles.makeSuggestionsBox}>
                  {makeSuggestions.map((brand, idx) => {
                    const q = manMake.trim().toLowerCase();
                    const matchStart = q ? brand.toLowerCase().indexOf(q) : -1;
                    return (
                      <Pressable
                        key={brand}
                        style={({ pressed }) => [
                          styles.makeSuggestionRow,
                          idx < makeSuggestions.length - 1 && styles.makeSuggestionRowBorder,
                          pressed && { backgroundColor: 'rgba(77,166,255,0.18)' },
                        ]}
                        onPress={() => {
                          setManMake(brand);
                          setShowMakeSuggestions(false);
                        }}
                      >
                        {matchStart >= 0 && q.length > 0 ? (
                          <Text style={styles.makeSuggestionText} numberOfLines={1}>
                            {brand.slice(0, matchStart)}
                            <Text style={styles.makeSuggestionHighlight}>
                              {brand.slice(matchStart, matchStart + q.length)}
                            </Text>
                            {brand.slice(matchStart + q.length)}
                          </Text>
                        ) : (
                          <Text style={styles.makeSuggestionText} numberOfLines={1}>{brand}</Text>
                        )}
                        <MaterialIcons name="north-west" size={10} color={Colors.textDim} />
                      </Pressable>
                    );
                  })}
                </View>
              )}
            </View>
          </View>

          {/* Model */}
          <View style={styles.manualField}>
            <Text style={styles.manualLabel}>MODEL</Text>
            <TextInput
              style={styles.manualInput}
              value={manModel}
              onChangeText={setManModel}
              placeholder="e.g. Anthem, Accolade, Dutch Star..."
              placeholderTextColor={Colors.textMuted}
              autoCorrect={false}
              autoCapitalize="words"
              returnKeyType="next"
            />
          </View>

          {/* Floorplan */}
          <View style={styles.manualField}>
            <Text style={styles.manualLabel}>
              FLOORPLAN{'  '}
              <Text style={styles.optionalTag}>OPTIONAL</Text>
            </Text>
            <TextInput
              style={styles.manualInput}
              value={manFloorplan}
              onChangeText={setManFloorplan}
              placeholder="e.g. 44B, 37TS, 45OPP..."
              placeholderTextColor={Colors.textMuted}
              autoCorrect={false}
              autoCapitalize="characters"
              returnKeyType="search"
              onSubmitEditing={handleManualSearch}
            />
          </View>

          {/* Search button */}
          <Pressable
            style={({ pressed }) => [
              styles.manualSearchBtn,
              !manualReady && styles.manualSearchBtnDisabled,
              pressed && manualReady && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
            onPress={handleManualSearch}
            disabled={!manualReady}
          >
            <MaterialIcons
              name="search"
              size={18}
              color={manualReady ? '#000' : Colors.textMuted}
            />
            <Text style={[
              styles.manualSearchBtnText,
              !manualReady && { color: Colors.textMuted },
            ]}>
              Search
            </Text>
          </Pressable>

          {/* Clear */}
          {(manYear || manMake || manModel || manFloorplan) ? (
            <Pressable style={styles.clearManualBtn} onPress={clearManual} hitSlop={8}>
              <MaterialIcons name="clear" size={11} color={Colors.textDim} />
              <Text style={styles.clearManualText}>Clear all</Text>
            </Pressable>
          ) : null}
        </View>
      )}

      {/* ══════════════════════════════════════════════════════════════
          WIZARD MODE
      ══════════════════════════════════════════════════════════════ */}
      {mode === 'wizard' && (
        <>
          {/* Hint + Reset */}
          <View style={styles.header}>
            <Text style={[styles.hint, { color: accent, flex: 1 }]}>
              {STEP_HINTS[step](selYear, selMake, selModel)}
            </Text>
            {(selYear || selMake || selModel) ? (
              <Pressable onPress={reset} style={styles.resetBtn} hitSlop={8}>
                <MaterialIcons name="refresh" size={13} color={Colors.textMuted} />
                <Text style={styles.resetBtnText}>Reset</Text>
              </Pressable>
            ) : null}
          </View>

          {/* Step progress breadcrumbs */}
          <View style={styles.progressRow}>
            {WIZARD_STEPS.map((s, i) => {
              const isDone    = i < stepIdx;
              const isCurrent = i === stepIdx;
              const col       = STEP_COLORS[s];
              const lbl       = isDone
                ? (breadcrumbs[i] || STEP_LABELS[s]).slice(0, 12)
                : STEP_LABELS[s];
              return (
                <React.Fragment key={s}>
                  <Pressable
                    onPress={() => {
                      if (!isDone) return;
                      setQuery('');
                      if (s === 'year')  { setStep('year');  setSelMake(''); setSelModel(''); }
                      if (s === 'make')  { setStep('make');  setSelModel(''); }
                      if (s === 'model') { setStep('model'); }
                    }}
                    style={[
                      styles.stepBubble,
                      isCurrent && { backgroundColor: col + '22', borderColor: col },
                      isDone    && { backgroundColor: col + '18', borderColor: col + '80' },
                    ]}
                    hitSlop={4}
                  >
                    {isDone
                      ? <MaterialIcons name="check-circle" size={10} color={col} />
                      : <View style={[styles.stepDot, isCurrent && { backgroundColor: col }]} />
                    }
                    <Text
                      numberOfLines={1}
                      style={[
                        styles.stepLabel,
                        isCurrent && { color: col, fontWeight: FontWeight.bold },
                        isDone    && { color: col },
                      ]}
                    >
                      {lbl}
                    </Text>
                  </Pressable>
                  {i < WIZARD_STEPS.length - 1 && (
                    <View style={[
                      styles.stepArrow,
                      i < stepIdx && { backgroundColor: STEP_COLORS[WIZARD_STEPS[i]] + '60' },
                    ]} />
                  )}
                </React.Fragment>
              );
            })}
          </View>

          {/* Filter input — only for long lists */}
          {allOptions.length > 7 && (
            <View style={styles.searchRow}>
              <MaterialIcons name="search" size={14} color={Colors.textMuted} />
              <TextInput
                style={styles.searchInput}
                placeholder={`Filter ${STEP_LABELS[step].toLowerCase()}s...`}
                placeholderTextColor={Colors.textMuted}
                value={query}
                onChangeText={setQuery}
                autoCorrect={false}
              />
              {query.length > 0 && (
                <Pressable onPress={() => setQuery('')} hitSlop={8}>
                  <MaterialIcons name="close" size={12} color={Colors.textMuted} />
                </Pressable>
              )}
            </View>
          )}

          {/* Click-to-select list */}
          <View style={[styles.optionContainer, { borderColor: accent + '40' }]}>
            <ScrollView
              style={{ maxHeight: 252 }}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              nestedScrollEnabled
            >
              {options.length === 0 ? (
                <View style={styles.emptyRow}>
                  <MaterialIcons name="search-off" size={18} color={Colors.textDim} />
                  <Text style={styles.emptyText}>No results for "{query}"</Text>
                </View>
              ) : (
                options.map((opt, idx) => {
                  const rvType = (step === 'model' && selMake)
                    ? RV_DATA[selMake]?.[opt]?.type ?? ''
                    : '';
                  const typeIcon = rvType ? getTypeIcon(rvType) : null;
                  const isAllFP = opt === '(All Floorplans)';
                  return (
                    <Pressable
                      key={`${opt}-${idx}`}
                      style={({ pressed }) => [
                        styles.optionRow,
                        idx < options.length - 1 && styles.optionRowBorder,
                        pressed && { backgroundColor: accent + '18' },
                      ]}
                      onPress={() => handleSelect(opt)}
                    >
                      {typeIcon ? (
                        <MaterialIcons
                          name={typeIcon as any}
                          size={14}
                          color={accent + 'CC'}
                          style={{ marginRight: 6, flexShrink: 0 }}
                        />
                      ) : null}
                      <Text style={[styles.optionText, isAllFP && { color: Colors.textMuted, fontStyle: 'italic' }]} numberOfLines={1}>
                        {opt}
                      </Text>
                      {rvType ? (
                        <Text style={styles.typeTag} numberOfLines={1}>{rvType}</Text>
                      ) : null}
                      <MaterialIcons name="chevron-right" size={17} color={accent} />
                    </Pressable>
                  );
                })
              )}
            </ScrollView>
          </View>

          {/* Back button */}
          {stepIdx > 0 && (
            <Pressable
              style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.7 }]}
              onPress={goBack}
            >
              <MaterialIcons name="arrow-back" size={13} color={Colors.textMuted} />
              <Text style={styles.backBtnText}>
                Back to {STEP_LABELS[WIZARD_STEPS[stepIdx - 1]]}
              </Text>
            </Pressable>
          )}
        </>
      )}
    </View>
  );
}

// ─── STYLES ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  card: {
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    backgroundColor: 'rgba(0,0,0,0.38)',
    borderRadius: Radius.xl,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    zIndex: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
    gap: Spacing.sm,
  },

  // ── Mode toggle row ────────────────────────────────────────────────────────
  modeToggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  cardTitle: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.extrabold,
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },
  modeSwitch: {
    flexDirection: 'row',
    gap: 5,
    backgroundColor: 'rgba(0,0,0,0.30)',
    borderRadius: Radius.full,
    padding: 3,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  modeTab: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 11,
    paddingVertical: 5,
    borderRadius: Radius.full,
  },
  modeTabActive: {
    backgroundColor: 'rgba(77,166,255,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(77,166,255,0.45)',
  },
  modeTabActiveOrange: {
    backgroundColor: 'rgba(255,107,53,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(255,107,53,0.45)',
  },
  modeTabText: {
    fontSize: 11,
    color: Colors.textMuted,
    fontWeight: FontWeight.semibold,
    letterSpacing: 0.2,
  },
  modeTabTextActive: {
    color: '#4DA6FF',
  },
  modeTabTextOrange: {
    color: '#FF6B35',
  },

  // ── Manual mode ────────────────────────────────────────────────────────────
  manualWrap: {
    gap: Spacing.sm,
  },
  manualHint: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    lineHeight: 16,
  },
  manualRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  manualField: {
    gap: 4,
  },
  manualLabel: {
    fontSize: 10,
    fontWeight: FontWeight.bold,
    color: 'rgba(255,255,255,0.50)',
    letterSpacing: 1.1,
  },
  optionalTag: {
    fontSize: 9,
    color: Colors.textDim,
    fontWeight: '400',
    letterSpacing: 0.5,
  },
  manualInput: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    borderRadius: Radius.md,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: FontSize.md,
    color: '#FFFFFF',
    fontWeight: FontWeight.medium,
  },
  manualInputFocused: {
    borderColor: 'rgba(77,166,255,0.55)',
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },
  makeSuggestionsBox: {
    position: 'absolute',
    top: '100%',
    left: 0,
    right: 0,
    backgroundColor: '#0D1F3C',
    borderWidth: 1,
    borderTopWidth: 0,
    borderColor: 'rgba(77,166,255,0.40)',
    borderBottomLeftRadius: Radius.md,
    borderBottomRightRadius: Radius.md,
    overflow: 'hidden',
    zIndex: 999,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45,
    shadowRadius: 10,
    elevation: 16,
  },
  makeSuggestionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: 'transparent',
  },
  makeSuggestionRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(77,166,255,0.12)',
  },
  makeSuggestionText: {
    flex: 1,
    fontSize: FontSize.sm,
    color: 'rgba(255,255,255,0.80)',
    fontWeight: FontWeight.medium,
  },
  makeSuggestionHighlight: {
    color: '#4DA6FF',
    fontWeight: FontWeight.bold,
  },
  manualSearchBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#FF6B35',
    borderRadius: Radius.md,
    paddingVertical: 13,
    marginTop: 2,
    shadowColor: '#FF6B35',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.45,
    shadowRadius: 8,
    elevation: 4,
  },
  manualSearchBtnDisabled: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    shadowOpacity: 0,
    elevation: 0,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  manualSearchBtnText: {
    fontSize: FontSize.base,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
  },
  clearManualBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'center',
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  clearManualText: {
    fontSize: 10,
    color: Colors.textDim,
    fontWeight: FontWeight.medium,
  },

  // ── Wizard mode ────────────────────────────────────────────────────────────
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
  },
  hint: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.medium,
    letterSpacing: 0.2,
  },
  resetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    borderRadius: Radius.full,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  resetBtnText: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    fontWeight: FontWeight.medium,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepBubble: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.09)',
    borderRadius: Radius.full,
    paddingHorizontal: 7,
    paddingVertical: 5,
    flexShrink: 1,
  },
  stepDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: Colors.textDim,
  },
  stepLabel: {
    fontSize: 9,
    color: Colors.textDim,
    fontWeight: FontWeight.medium,
    flexShrink: 1,
  },
  stepArrow: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.10)',
    marginHorizontal: 2,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.11)',
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: FontSize.md,
    color: '#FFFFFF',
    paddingTop: 0,
    paddingBottom: 0,
  },
  optionContainer: {
    borderWidth: 1,
    borderRadius: Radius.lg,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.22)',
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: 13,
  },
  optionRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.07)',
  },
  optionText: {
    flex: 1,
    fontSize: FontSize.md,
    color: '#FFFFFF',
    fontWeight: FontWeight.medium,
  },
  typeTag: {
    fontSize: 9,
    color: Colors.textDim,
    fontWeight: FontWeight.medium,
    marginRight: 4,
    flexShrink: 1,
    maxWidth: 80,
  },
  emptyRow: {
    alignItems: 'center',
    paddingVertical: Spacing.lg,
    gap: Spacing.xs,
  },
  emptyText: {
    fontSize: FontSize.sm,
    color: Colors.textMuted,
  },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    alignSelf: 'flex-start',
    paddingHorizontal: Spacing.xs,
    paddingVertical: 4,
  },
  backBtnText: {
    fontSize: FontSize.xs,
    color: Colors.textMuted,
    fontWeight: FontWeight.medium,
  },
});
