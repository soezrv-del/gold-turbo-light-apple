// ─── APP PALETTE: Red · Blue · Black · Green ────────────────────────────────
// Four-color system — clean, legible, no gray/silver.
//   Black  #0A0A0B  — backgrounds
//   Blue   #0068C0  — primary brand / info
//   Red    #D42535  — AI / alerts / premium
//   Green  #00C853  — financial / success

export const Colors = {
  // ── Backgrounds ──────────────────────────────────────────────────────────
  black:        '#0A0A0B',
  bg:           '#0D0D0E',
  bgDeep:       '#070708',
  bgCard:       '#161618',
  bgCardAlt:    '#1E1E21',
  bgBlue:       '#060E1C',
  bgBlueMid:    '#0A1628',

  // ── Borders ──────────────────────────────────────────────────────────────
  border:           'rgba(255,255,255,0.09)',
  borderSilver:     'rgba(0,119,204,0.32)',   // was gray — now blue
  borderBlue:       'rgba(0,104,192,0.40)',
  borderBlueBright: 'rgba(0,104,192,0.65)',
  borderGold:       'rgba(0,119,204,0.28)',   // was gold/silver — now blue

  // ── Text ─────────────────────────────────────────────────────────────────
  textPrimary:   '#FFFFFF',
  textSilver:    'rgba(255,255,255,0.90)',    // was metallic gray — now bright white
  textSecondary: 'rgba(255,255,255,0.80)',
  textMuted:     'rgba(255,255,255,0.50)',
  textDim:       'rgba(255,255,255,0.28)',
  placeholder:   'rgba(255,255,255,0.50)',

  // ── Blue ─────────────────────────────────────────────────────────────────
  blue:          '#0068C0',
  blueBright:    '#0077CC',
  blueDeep:      '#004A8A',
  blueGlow:      '#0090E8',

  // ── White aliases (replaced silver/chrome — no gray) ─────────────────────
  silver:        'rgba(255,255,255,0.90)',    // was metallic silver — now white
  silverBright:  '#FFFFFF',
  silverDeep:    'rgba(255,255,255,0.45)',
  chrome:        'rgba(255,255,255,0.65)',

  // ── Status ────────────────────────────────────────────────────────────────
  success:       '#00C853',    // green
  warning:       '#FF4444',    // red-orange for caution (no amber/gray)
  danger:        '#D42535',    // red

  // ── Core four + aliases ───────────────────────────────────────────────────
  gold:          '#0090E8',    // was yellow-gold — now bright blue
  goldDark:      '#004A8A',
  goldDeep:      '#001F3F',
  green:         '#00C853',
  greenSoft:     '#69F0AE',
  red:           '#D42535',
  orange:        '#FF4444',    // kept for safety warnings — rendered as red
  info:          '#0077CC',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  full: 999,
};

export const FontSize = {
  xs: 11,
  sm: 13,
  md: 15,
  base: 16,
  lg: 18,
  xl: 20,
  xxl: 22,
  h2: 26,
  h1: 32,
};

export const FontWeight = {
  regular:   '400' as const,
  medium:    '500' as const,
  semibold:  '600' as const,
  bold:      '700' as const,
  extrabold: '800' as const,
};
