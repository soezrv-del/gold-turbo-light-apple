import React, { createContext, useContext, ReactNode } from 'react';
import { useSubscription, type SubscriptionState, type ProductId } from '@/hooks/useSubscription';

// ─── CONTEXT ──────────────────────────────────────────────────────────────────

interface SubscriptionContextType extends SubscriptionState {
  subscribe: (productId: ProductId) => Promise<void>;
  restorePurchases: () => Promise<void>;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export function SubscriptionProvider({ children }: { children: ReactNode }) {
  const subscription = useSubscription();
  return (
    <SubscriptionContext.Provider value={subscription}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscriptionContext() {
  const ctx = useContext(SubscriptionContext);
  if (!ctx) throw new Error('useSubscriptionContext must be used within SubscriptionProvider');
  return ctx;
}
