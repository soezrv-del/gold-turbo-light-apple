// metro.config.js
const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');
const fs = require('fs');

const config = getDefaultConfig(__dirname);

// ── Locate the project's own react-native@0.76.x in the pnpm store ──────────
const PROJECT_RN_PATH = (() => {
  const pnpmDir = path.join(__dirname, 'node_modules/.pnpm');
  try {
    if (fs.existsSync(pnpmDir)) {
      for (const entry of fs.readdirSync(pnpmDir)) {
        if (/^react-native@0\.76\./.test(entry)) {
          const candidate = path.join(pnpmDir, entry, 'node_modules', 'react-native');
          if (fs.existsSync(candidate)) return candidate;
        }
      }
    }
  } catch { /* fall through */ }
  try { return fs.realpathSync(path.resolve(__dirname, 'node_modules/react-native')); }
  catch { return path.resolve(__dirname, 'node_modules/react-native'); }
})();

// ── Find the react-native@0.79.x pnpm store directory ───────────────────────
const RN_079_PNPM_DIR = (() => {
  const pnpmDir = path.join(__dirname, 'node_modules/.pnpm');
  try {
    if (fs.existsSync(pnpmDir)) {
      for (const entry of fs.readdirSync(pnpmDir)) {
        if (/^react-native@0\.79\./.test(entry)) {
          return path.join(pnpmDir, entry, 'node_modules', 'react-native');
        }
      }
    }
  } catch { /* ignore */ }
  return null;
})();

// ── The pnpm directory prefix for the 0.79.x ecosystem ──────────────────────
// Covers react-native@0.79.x itself and any packages (like @expo/metro-runtime)
// that were resolved against it.
const RN_079_PNPM_PREFIX = (() => {
  const pnpmDir = path.join(__dirname, 'node_modules/.pnpm');
  try {
    if (fs.existsSync(pnpmDir)) {
      for (const entry of fs.readdirSync(pnpmDir)) {
        if (/^react-native@0\.79\./.test(entry)) {
          return path.join(pnpmDir, entry);
        }
      }
    }
  } catch { /* ignore */ }
  return null;
})();

// ── Helper: is a file path inside the 0.79.x pnpm subtree? ──────────────────
function isIn079Tree(filePath) {
  if (!filePath) return false;
  if (filePath.includes('/react-native@0.79.')) return true;
  if (RN_079_PNPM_PREFIX && filePath.startsWith(RN_079_PNPM_PREFIX)) return true;
  return false;
}

// ── Redirect a react-native sub-path to the 0.76.x install ──────────────────
function redirectToRN076(subPath) {
  const target = path.join(PROJECT_RN_PATH, subPath);
  if (fs.existsSync(target)) return target;
  return null;
}

// ── Post-resolution redirect for files resolved from 0.79.x ─────────────────
function redirectIfWrongRN(filePath) {
  if (!isIn079Tree(filePath)) return null;
  const marker = '/react-native/';
  const idx = filePath.lastIndexOf(marker);
  if (idx === -1) return null;
  const rel = filePath.slice(idx + marker.length);
  const redirected = path.join(PROJECT_RN_PATH, rel);
  if (fs.existsSync(redirected)) return redirected;
  return null;
}

config.resolver.resolveRequest = (context, moduleName, platform) => {
  // ── PLATFORM STUBS ──────────────────────────────────────────────────────
  if (platform === 'web' &&
      (moduleName === 'react-native-maps' || moduleName.startsWith('react-native-maps/'))) {
    return { filePath: path.resolve(__dirname, 'stubs/react-native-maps-web.tsx'), type: 'sourceFile' };
  }
  if (platform === 'web' &&
      (moduleName === 'react-native-iap' || moduleName.startsWith('react-native-iap/'))) {
    return { filePath: path.resolve(__dirname, 'stubs/react-native-iap-web.js'), type: 'sourceFile' };
  }
  if (moduleName === 'babel-plugin-syntax-hermes-parser') {
    return { filePath: path.resolve(__dirname, 'stubs/hermes-parser-plugin.js'), type: 'sourceFile' };
  }

  // ── PRE-RESOLUTION: intercept react-native/... from the 0.79.x tree ────
  // This handles packages like @expo/metro-runtime that live inside the 0.79.x
  // pnpm context and import react-native sub-paths directly.
  const originIn079 = isIn079Tree(context.originModulePath || '');
  if (originIn079 && (moduleName === 'react-native' || moduleName.startsWith('react-native/'))) {
    const subPath = moduleName === 'react-native' ? '' : moduleName.slice('react-native/'.length);
    if (subPath === '') {
      // Bare 'react-native' import — resolve via default from project root
      return context.resolveRequest(
        { ...context, originModulePath: path.join(__dirname, 'package.json') },
        moduleName,
        platform
      );
    }
    const redirected = redirectToRN076(subPath);
    if (redirected) return { filePath: redirected, type: 'sourceFile' };
    // Fall through to default if we can't find the file in 0.76.x
  }

  // ── If the module name itself points into 0.79.x, resolve to 0.76.x ────
  if (moduleName.includes('react-native@0.79.') ||
      (RN_079_PNPM_DIR && moduleName.startsWith(RN_079_PNPM_DIR))) {
    const marker = '/react-native/';
    const idx = moduleName.lastIndexOf(marker);
    if (idx !== -1) {
      const rel = moduleName.slice(idx + marker.length);
      const redirected = path.join(PROJECT_RN_PATH, rel);
      if (fs.existsSync(redirected)) return { filePath: redirected, type: 'sourceFile' };
    }
  }

  // ── DEFAULT RESOLUTION ──────────────────────────────────────────────────
  const resolution = context.resolveRequest(context, moduleName, platform);

  // ── POST-RESOLUTION REDIRECT ────────────────────────────────────────────
  if (resolution?.type === 'sourceFile') {
    const redirected = redirectIfWrongRN(resolution.filePath);
    if (redirected) return { filePath: redirected, type: 'sourceFile' };
  }

  return resolution;
};

module.exports = config;
